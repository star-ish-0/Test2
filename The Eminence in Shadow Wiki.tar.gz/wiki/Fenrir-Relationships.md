# Fenrir/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Fenrir/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Fenrir/Relationships)

[Main](Fenrir.md "Fenrir")

[Chronology](Fenrir-Chronology.md "Fenrir/Chronology")

Image Gallery

## Cult of Diablos

### Knights of Rounds

#### [Loki](Loki.md "Loki")

In the Cult factions, Fenrir had a long rivalry with Loki, a fellow Rounds member.

#### [Shiva](Shiva.md "Shiva")

#### Sergey Gorman

#### [Petos](Petos.md "Petos")

Fenrir aware that Petos was promoted to a 10th seat Knight of Rounds, replacing the previous 10th seat holder. But Fenrir had never acknowledged Petos' position as his equal, having stated that his promotion was nothing more than a substitution, as normally he wouldn't be able to become a Rounds because his achievements are weak.

### Children of Diablos

#### [Willow](Willow.md "Willow")

#### Zenon Griffey

Fenrir was Zenon Griffey's superior, and it was the Fenrir sect who controlled the hidden base where Alexia was captive in.

### Shadow Garden

#### Shadow / Suzuki Hope

#### [Zeta](Zeta.md "Zeta")

Fenrir plans to use his knowledge about Zeta as a bargaining chip towards Petos, when he noticed that Petos acted unusual at the mention of a golden colored Therianthrope operative within Shadow Garden's ranks.

#### [Victoria](Victoria.md "Victoria")

Fenrir notice that "The Saint" that had been discarded for her possession almost a year earlier had already joined Shadow Garden. Fenrir never expected that they already recruit her, he grew curious and commented on how the country would react upon the discovery, as the people used to revere her.

### Enemies

#### [Aurora](Aurora.md "Aurora")

When Fenrir heard the name Aurora from Claire, he wanted to confirm it by fighting.

The moment Fenrir changed his actual appearance, he was shocked when he heard Claire mention his former moniker, as he didn't think anyone in this era would know of his former moniker.

Fenrir had then confirmed about Aurora's whereabouts and asked her about the purpose she would intend to use Claire's body for.

#### Claire Kagenou

#### Alexia Midgar
