# Leaf Two

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Leaf%20Two](https://the-eminence-in-shadow.fandom.com/wiki/Leaf%20Two)

## Leaf Two

### Japanese

二葉（ふたば）

### Romaji

Futaba

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Whitish Blue

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Assassin

### Affiliation

Major Corporate Alliance
[Clovers](Clovers.md "Clovers")

## Debut

### Web Novel

Chapter 121

### Light Novel

Volume 3

### Manga

Chapter 35

### Anime

Episode 25

## Portrayal

### Japanese

[Takeo Ōtsuka](https://en.wikipedia.org/wiki/Takeo_%C5%8Ctsuka_(voice_actor) "wp:Takeo Ōtsuka (voice actor)")

Leaf Two (二葉（ふたば）, Futaba[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was one of the members of the [Clovers](Clovers.md "Clovers"), a small personal group under the Garter Corporation.

## Appearance

## Personality

## Chronology

### Great Trading Company Conflict

Leaf Two joined alongside with his fellow Clover in sabotaging Mitsugoshi Company. Leaf Two and the Clovers infiltrated the company's headquarters, and he was tasked with his men will be engaging in sabotage. Unfortunately, he encountered [Mitsugoshi's employee](Nu.md "Nu") and was killed. His head was delivered to a horrified Leaf One.

## Powers & Abilities

## Relationships

## Trivia

## References
