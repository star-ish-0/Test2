# Iris Midgar

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Iris%20Midgar](https://the-eminence-in-shadow.fandom.com/wiki/Iris%20Midgar)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | I refuse to allow any mischief in this kingdom. | ” |
| — Iris, Light Novel Volume 01 | | |

## Iris Midgar

- Light Novel
- Manga
- Anime
- Game

### Japanese

アイリス・ミドガル

### Romaji

Airisu Midogaru

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

20 (Game)

### Height

Unknown

### Hair Color

Red

### Eye Color

Red

### Birthday

September 5

## Personal Information

### Status

Alive

### Relatives

Klaus Midgar (Father)
Alexia Midgar (Younger Sister)
[Freya](Freya.md "Freya") (Ancestor)

## Professional Information

### Occupation

- First Princess of Midgar Kingdom
- Leader of Crimson Order
- Midgar Adacemy Student Council President (Formerly)

### Affiliation

Crimson Order
Knight Order (Formerly)
Midgar Academy for Dark Knights (Formerly)

## Debut

### Web Novel

Chapter 15

### Light Novel

Volume 1

### Manga

Chapter 4

### Anime

Episode 1

### Game

Episode 3

## Portrayal

### Japanese

[Yoko Hikasa](https://en.wikipedia.org/wiki/Yoko_Hikasa "wp:Yoko Hikasa")

### English

[Patricia Duran](https://en.wikipedia.org/wiki/Patricia_Duran "wp:Patricia Duran")

### French

Delphine Rivière

### Italian

Chiara Francese

### German

Maren Rainer

Iris Midgar (アイリス・ミドガル, Airisu Midogaru[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the first princess of the Midgar Kingdom and the leader of the Crimson Order. After her sister, Alexia, was kidnapped by the Cult of Diablos and rescued by Shadow Garden, she began investigating both organizations.[[1]](#cite_note-V1C2-1)[[2]](#cite_note-2)[[3]](#cite_note-3) However, bitter after being defeated by Shadow, she ends up becoming the Cult's unwitting pawn.[[4]](#cite_note-V2FC-4)[[5]](#cite_note-5)

## Appearance

Iris is a beautiful woman with delicate features and fiery red hair that reaches down to her back and red eyes. She is normally seen sporting a knight order uniform sans a cape; a dark violet royal uniform with light edges and black shoulder straps, as well as cuffs folded back one-third up her arm from the wrist. Part of her attire requires her to wear white gloves for her dressing, a black shirt with matching edges to her uniform, and a ruby-like gem with a single ribbon necktie that stretches down into her uniform. Iris wears white tights and knee-high heeled boots with single-tie laces at the collar which folds over, and she can normally be seen with her sword adorning her side on her waist belt.

After the Black Rose incident, Iris amended her attire to a more professional Crimson Order uniform, as well as adding a braid in her hair along with small jewelry down a lock of hair. She wears a gray uniform with black trims and a crimson interior. A black detachable cape with red lining rests on her shoulders, with two crimson braided cords connecting from the left breast pocket to the shoulder's rank strap. She sports a green-colored gem with a single dark velvet ribbon necktie that stretches down into her uniform, with red buttons with black borders. The right side of her uniform lifts a little to short the bottom of the waistcoat, colored black with red lining to match the cape. She retains her white gloves and trousers, but her knee-high heeled boots are recolored to match her uniform.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | My enemy is Shadow, and I'll mow down anyone who gets in my way. Even my own sister. | ” |
| — Iris Midgar to Alexia, Light Novel Volume 05 | | |

Iris is a brave, diligent, and prideful swordswoman who earnestly strives to fulfill her duty to protect her kingdom. She is revered as an exemplary warrior and princess by not only her people but the world as well. Ever since Iris was young, she was held in high regard for her abilities and accomplishments, which led to her people regarding her as the pride or icon of Midgar. She works diligently to uphold not only her father's but her people's expectations of her as a symbol of hope, protection, power, and victory.

Despite being a princess, Iris lacks the political and leadership skills to manage her organization, the Crimson Order. She admits that Alexia Midgar is smarter than her and implies that her own sister would do a better job with the organization. At times, Iris's stubbornness and pride prevents her from seeing that there are other beings in the world who are much stronger than her.

Following her impotence and the full emergence of Shadow Garden, Iris was left feeling inadequate and useless as she could not do much politically or physically. She felt the need to prove her worth and redeem herself at the Bushin Festival. However, the combination of her defeat by Shadow, the high expectations of her people, and the previous incidents crushed her mentally. Iris's loss to Shadow left her with a strong desire for revenge and an obsession with becoming stronger.

## Powers & Abilities

Iris is widely recognized as the strongest swordswoman within the Midgar Kingdom, having been the top student as the Midgar Academy for Dark Knights before her graduation.[CITATION NEEDED] However, she admits that her skills are nowhere near the level of legendary figures like [Beatrix](Beatrix.md "Beatrix"), who are regarded as the pinnacle swordsmanship.[CITATION NEEDED]

### Swordsmanship

From an early age, Iris has been recognized as a prodigy with the sword. During her time at the Midgar Academy for Dark Knights she was the strongest student without question and is arguably the greatest swordswoman in all of Midgar Kingdom.[CITATION NEEDED]

### Magic

As a member of the Midgar royal lineage, Iris possesses an incredible quantity and quality of magic even without contracting [Possession](Possession.md "Possession").[CITATION NEEDED] Iris has an average handling in her magic,[CITATION NEEDED] being able to use it aggressively when fighting seriously. In the anime, she can also use magic to allow her to stand on the surface on water.[[6]](#cite_note-AS1E20-6) She can also strengthen her body to tolerate or resist heavy damage.

Depending on the type of weapon she wields, Iris can release more magic for her benefit.[CITATION NEEDED] However, despite the prestige of her magic, she focuses more on the strength of her strikes rather than the refinement of the energy.[CITATION NEEDED]

### Physical Capabilities

Iris Midgar is in excellent physical shape, and both her strength and stamina are comparable to Beatrix's. She was able to keep up with Beatrix and Shadow during their fight across the city, although she distinctly fell behind at certain points and had to catch back up. Her strength in particular is notable during this fight for being able to slam Shadow into a nearby building from the street even after he blocked the attack, though Shadow did not appear to take significant damage from this. Additionally, during this fight she was able to withstand several of Shadow's attacks and continue fighting, though the degree to which Shadow was holding back is unknown and by the end of the battle Iris was unable to even grasp her sword properly. When not actively using her magic, Iris can run at estimated speeds fast enough to catch up to and surpass a full-speed steam train.[[6]](#cite_note-AS1E20-6)

### Intelligence

### Weapons and Equipment

- Longsword: During combat, Iris wields a longsword—in the anime, it is depicted closer to a broadsword.
- [Anime Only] Mithril Weapon: An artifact displayed in the VIP viewing box of the Midgar Kingdom capital's stadium.[[6]](#cite_note-AS1E20-6) The metal mithril possesses a 50% conductive rate of magic.[[7]](#cite_note-V1P-7)

## Trivia

- The name Iris refers to the Greek Goddess Iris from Greek mythology as both the personification of the rainbow and 'the messenger of the gods among themselves'.
  - In ancient times, Iris symbolizes faith, hope, wisdom and valor to which it is considered as a symbol of power and majesty and was dedicated to the Goddess Hera.
- Despite her mature and dignified image, she sleeps hugging a teddy bear and has bunny-print underwear.[[8]](#cite_note-MV2C7-8)
  - Iris also wears kitten-printed knickers as well. This was revealed by Alexia in the Light Novel.[CITATION NEEDED]
- The color of Iris' magic is red.[ANIME ONLY]
- Iris's initial reaction to the conclusion of the duel against Shadow differs depending on the adaptation. In the light novel and manga, she is puzzled by Shadow's parting words about a "true enemy" and questions his intentions.[[4]](#cite_note-V2FC-4) The anime portrayed it differently, instead choosing to reflect her later extreme viewpoint by having her outwardly express frustration and helplessness at being unable to defeat Shadow.[[6]](#cite_note-AS1E20-6)
- Iris' age is stated to be over 20 years.[NOT CANON: GAME ONLY]

## References

1. Volume 1 Chapter 2: Assuming the Role of a Side Character at School!
2. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
3. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
4. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
5. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
6. Anime Season 1 Episode 20: Advent of the Demon
7. Volume 1 Prologue: Preparing the Perfect Stage!
8. Manga Volume 2 Episode 7

## Site Navigation
