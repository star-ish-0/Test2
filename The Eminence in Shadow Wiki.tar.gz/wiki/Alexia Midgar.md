# Alexia Midgar

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Alexia%20Midgar](https://the-eminence-in-shadow.fandom.com/wiki/Alexia%20Midgar)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | Good Boy, Pooch. Now fetch! | ” |
| — Alexia Midgar, Light Novel Volume 01 | | |

## Alexia Midgar

### Japanese

アレクシア・ミドガル

### Romaji

Arekushia Midogaru

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

15

### Height

Unknown

### Hair Color

Platinum

### Eye Color

Red

### Birthday

April 6

## Personal Information

### Status

Alive

### Relatives

- [Freya](Freya.md "Freya") (Ancestor)
- Klaus Midgar (Father)
- Iris Midgar (Older Sister)

## Professional Information

### Occupation

- Second Princess of Midgar Kingdom
- Student at Midgar Academy for Dark Knights

### Affiliation

Crimson Order

## Debut

### Web Novel

Chapter 9

### Light Novel

Volume 1

### Manga

Chapter 3

### Anime

Episode 3

## Portrayal

### Japanese

[Kana Hanazawa](https://en.wikipedia.org/wiki/Kana_Hanazawa "wp:Kana Hanazawa")

### English

Olivia Swasey

### French

[Maeva Méline](https://en.wikipedia.org/wiki/Maeva_M%C3%A9line "wp:Maeva Méline")

### Italian

[Martina Felli](https://en.wikipedia.org/wiki/it:Martina_Felli "wp:it:Martina Felli")

### German

Leslie-Vanessa Lill

Alexia Midgar (アレクシア・ミドガル, Arekushia Midogaru[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the second princess of the Midgar Kingdom and a student at the Midgar Academy for Dark Knights. Cid fake confessed to her to boost his "mob" persona, only for her to accept to annoy her fiancé.[CITATION NEEDED] Though initially an act, she developed actual feelings for him over time and her proximity to him caused her to get caught in many incidents.[CITATION NEEDED]

## Appearance

Described as gorgeous by her peers, Alexia is a young girl with red-blackish eyes and long platinum white hair.[[1]](#cite_note-V1C2-1) She usually ties her hair in pig tails using a large black bow and is often seen wearing her academy uniform and white thigh-high socks with knee-high boots.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | You're welcome, my flawed pooch. Now fetch! | ” |
| — Alexia to Cid Kagenou, Light Novel Volume 01 | | |

Alexia on surface is shown to be a rather attractive and well-tempered young lady whenever she is in the academy, but whenever she is alone with Cid, she's quite spoiled and abrasive, looking down on him and thinking they could be swayed easily if offered money (Volume 1). A common move she makes is throwing her money on the ground and offering coins for people to be her 'pooch'.[CITATION NEEDED]

This stemmed from feelings of envy, being constantly compared to her sister, Iris.[CITATION NEEDED] However, after spending time as a couple with Cid, she started to show a kinder side, developing fondness and even respect for him. When she was kidnapped, Alexia expressed deep worry for him. Deep down, she is a good girl who will put her own life on the line to protect others that she cares for.[CITATION NEEDED] In a twist of fate, as Alexia focuses more on her future and self-growth, her older sister Iris is seen to regress into Alexia's old state of mind, with her becoming even more mentally unstable than Alexia ever was since Iris is the crown princess.[CITATION NEEDED] Seeing this change, Alexia decides to take a step in, and no matter how her older sister lashes out, she tries to show her that she is still loved and valued by her.[CITATION NEEDED]

After the events of Bushin Festival, Alexia chooses to no longer be a mere "bystander" and become strong enough to be able to stand up and fight for what she believes in, however, this time she changes her methods, and instead of just practicing with her sword Alexia wants to have full knowledge of everything regarding her kingdom, so she begins focusing more in studying various subjects (politics, economics, law, engineering, finance, even ancient linguistics) to cultivate her intelligence and be absolutely aware of why, when and how she wields her sword and protect others. She believes she needs to start by earning the right to stand in that place and realizes sometimes that road to that place starts in an area where you don't wield a sword.[[2]](#cite_note-2)

## Powers & Abilities

Alexia's magic and swordsmanship are noted to be "just average". However, through sheer effort, she managed to rise through the ranks to become one of the top students at Midgar Academy for Dark Knights. Also, as noted by her sister, she is quite skilled at politics but lacks any real power in that space.[CITATION NEEDED]

### Swordsmanship

Cid describes Alexia's fencing style as "orthodox", with nothing special about it, which earned her the nickname "Fencing Ordinaire." Because of this, she is considered "mediocre" by those comparing her to her sister, Iris who is considered the best in the entire Midgar Kingdom. In reality, Alexia's shortcomings were the result of her trying to replicate her sister, despite her fighting style not suiting her.[CITATION NEEDED]

However, after witnessing Shadow's swordsmanship, which is quite her ideal style, she was inspired and stopped trying to follow her sister's footsteps. Her hard work would eventually bear fruit, as her rapid growth became more noticeable. Regardless, Cid attitude towards her get better and better, before saying Alexia has somehow a good swordsmanship. Alexia's confidence of that she has basic "mediocre" swordsmanship has crumbled and faded away, touched by Cid approval, and the fact he accepts who she is.[CITATION NEEDED]

### Magic

Like her swordsmanship, Alexia's magical skills are noted to be "just average". Alexia's magic was originally light-yellow green in the anime and in the game, but during her confrontation with Rose Oriana her mana changes to light pink. This is explained that one's mental state changes the color of the mana. Calm mental states show off brilliant White, while delusional mental states show off as deep purple, almost black. Alexia has a fairly large reservoir of mana. A device that gives numerical values to magic displayed a 1303 (1238 [IN THE MANGA]).[[3]](#cite_note-3)

### Physical Capabilities

Alexia, like every magical knight, has developed a strong physical constitution in athletic abilities, mainly in her resistance, although this is not noticeable at first glance, being able to resist strong blows, at the normal level of a normal swordsman or magical knight.[CITATION NEEDED]

Although Alexia initially stated that she felt fruitful and everything since she did not have the physical development and natural talent of the sword, like her older sister Iris Midgar, after meeting Cid and then Shadow, she began to imitate the warm-ups so much. and Cid's stretching, and hard training Shadow's swordsmanship, which she was inspired by, as it closely resembles the "perfect and ordinary swordsmanship" style that she strongly yearns to achieve. This made that with the passing of the events of the story, Alexia further perfected her physical resistance until she was able to resist, for brief moments, a strong attack from Zenon, who he was, a very strong magical swordsman, candidate to be part of the round table of the Cult of Devils, (to date, Alexia's progress still continues).[CITATION NEEDED]

### Intelligence

In contrast to her lack of martial prowess, Alexia has been shown to be rather intelligent in interpersonal interaction, often capable of seeing through the larger picture and becoming suspicious enough on the likes of Zenon and "[Natsume](Beta.md "Beta")". When it comes to politics, Iris admitted to herself that Alexia is smarter and could be a better leader. However, upon learning the existence of the Cult of Diablos and Shadow Garden and the stronger individuals involved, Alexia humbles herself down and couldn't bear to just keep watching while not knowing anything. She acknowledges that she must also strengthen other areas aside from her swordsmanship. Since then, she has been reading books apart from training, hoping to become more knowledgeable and more helpful. [CITATION NEEDED]

### Strong Intuition

Alexia has a strong intuition and very good analysis, more than that of her sister Iris than any other magical swordsman, or magical knight, in normal terms, which allows her to feel and realize how strong an adversary or person can be, when he/she does not hide his/her abilities. When the Sanctuary infiltration incident occurred, Alexia, upon meeting [Alpha](Alpha.md "Alpha"), was able to realize that she is a very strong opponent, even than her own sister Iris Midgar.[CITATION NEEDED]

Although this ability can be learned but unlike the others, Alexia seems to have it innately, but still far from being compared to "warrior detection" abilities and specialties, such as those of [Beatrix](Beatrix.md "Beatrix") and Shadow's. The truth of this ability is that alongside Alexia's increasing Empathy, she can see the cause and effect of a person's actions.[CITATION NEEDED]

### Weapons and Equipment

## Trivia

- The name "Alexia" in Greek means man's defender or helper.[CITATION NEEDED]
- In the anime and game, Alexia's mana is light yellow green. It later changes its color to pink, during her confrontation with Rose Oriana.[CITATION NEEDED]

## References

1. Volume 1 Chapter 2: Assuming the Role of a Side Character at School!
2. Episode 26
3. Volume 5 Chapter 5: Terrorists Attack the School…Again!!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • **Alexia Midgar** • Christina Hope • [Isaac](Isaac.md "Isaac") • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |
