# Chi/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Chi/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Chi/Relationships)

[Main](Chi.md "Chi")

[Chronology](Chi-Chronology.md "Chi/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

Chi is steadfastly loyal to Shadow, aware of his secret identity as Cid Kagenou. It was his methodology that developed a cure for [Possession](Possession.md "Possession") and provided her a new purpose against the Cult for their conspiracy against her nearly taking her life.

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

The two originally did not get along very well, mainly because of her previous history working for the cult. During Chi's interrogation, Alpha continually questioned everything Chi had done her entire life up until that point, continually pointing out that she was in reality, turning a blind eye to all of the cult's atrocities in the name of keeping the peace while Chi continually denied the accusations, stating that it was the only way to keep everyone alive. However, the two would eventually make up after Chi is forced to realize the true gruesomeness of the cult's actions.

Chi as such, respects and obeys Alpha's orders as the one who directs everything by being the second in command, when her Lord Shadow is not present, in addition to having some security by having her as one of those who helped her, along with Epsilon.

#### [Beta](Beta.md "Beta")

Chi has aided Beta in a secretary capacity with information gathering and attending to her while she was in the Midgar capital branch of Mitsugoshi.

#### [Gamma](Gamma.md "Gamma")

Chi met Gamma while she was in a remote village of the Madlid region, she was shown to be surprised by Gamma's lack of sword skills. She also defended Gamma along with Eta thinking they were just innocent children.

#### [Delta](Delta.md "Delta")

Chi, like Nu, would serve Delta her lunches and dinners as the therianthrope rested at Mitsugoshi HQ.

#### [Epsilon](Epsilon.md "Epsilon")

Chi is aware about her fake slime body but pretends not to notice it as she cares about her.

#### [Eta](Eta.md "Eta")

Chi met Eta while she was in a remote village of the Madlid region. Eta was shown to be fascinated of Chi due to her connection to the Cult and intended to use her as a test subject much to Chi's horror.

### Numbers

#### [Lambda](Lambda.md "Lambda")

Chi and Lambda were once contemporaries in Velgalta, but Lambda was sooner recruited by Shadow Garden and became Chi's instructor upon defecting to Shadow Garden.

#### [Nu](Nu.md "Nu")

Chi is Nu's junior within Shadow Garden. Nu joined at Rank 93 while Chi joined at Rank 111. Both have a positive and professional working relationship, especially when Chi works at Mitsugoshi HQ and assists Nu with her duties under Gamma.

#### [Omega](Omega.md "Omega")

Both have shown a slight display of friendship when in their civilian dress. Chi would be joined by Omega in aiding Nu under Alpha and Gamma's command, overseeing and reviewing their asset overview at Mitsugoshi.

## Enemies

### Cult of Diablos

### Sergey Gorman

## Others

### Claire Kagenou

### Annerose Nichtsehen

## References
