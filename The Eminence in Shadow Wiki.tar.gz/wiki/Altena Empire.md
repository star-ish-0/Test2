# Altena Empire

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Altena%20Empire](https://the-eminence-in-shadow.fandom.com/wiki/Altena%20Empire)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Altena_Empire?action=edit).

## Altena Empire

### Japanese

アルテナ帝国（ていこく）

### Romaji

Arutena teikoku

## Location Information

### Leader

Unknown Emperor

### Status

Active

### Affiliates

Velgalta Empire
The City-State Alliance (state member)

### Type

Vassal State

### Government

Unknown

### Location

Unknown

### Inhabitants

Humans (Predominantly)

## Debut

### Web Novel

Chapter 63 (Mentioned)

### Light Novel

Volume 2 (Mentioned)

### Manga

Chapter 20 (Mentioned)

Altena Empire (アルテナ帝国（ていこく）, Arutena teikoku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the empire where the Altena imperial family lives and the birthplace of Mundane Mann.

## History

## Known Residents

- Mundane Mann (Deceased)

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • **Altena Empire** • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
