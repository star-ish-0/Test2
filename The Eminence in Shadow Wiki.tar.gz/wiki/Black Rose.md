# Black Rose

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Black%20Rose](https://the-eminence-in-shadow.fandom.com/wiki/Black%20Rose)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

- The Black Rose in the Manga.
- Black Rose in Episode 11 of second season's anime

1/2

The Black Rose (黒（くろ）キ薔薇（ばら）, Kuroki Bara[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a legendary phenomenon that is considered dangerous because it once destroyed the Oriana Kingdom, but the true identity of Black Rose is an artificial portal gate to [another world dimension](Realms.md "Realms") that was originally created by Lord Laugus.[[1]](#cite_note-V4C3-1)[[2]](#cite_note-2)

## Overview

The Black Rose is a gateway that facilitates the connection between two worlds, allowing them to collide and become intertwined, thereby enabling each world to exert influence upon the other.

## Background

Legend has it that it was used by the Oriana Kingdom, which was on the brink of extinction due to the Velgalta Empire's invasion and wiped out 100,000 soldiers in one night. However, the real story is that the Black Rose By mere coincidence it was opened, which open the gate that connects the demon world, And the other worlds, like the one Cid lives in now, the reason why 100,000 Velgalta soldiers were annihilated was because monsters flowed from the demon world through Black Rose and attacked the Velgalta soldiers. However, after a short time, the monsters also began to attack the Kingdom of Oriana, so if nothing was done, it would be its inevitable destruction.

During the destruction of the kingdom of Oriana, the demon King called [Ragnarok](Ragnarok.md "Ragnarok") appeared, which is the demon that reigned over the fourth infernal world of demons, for which reason, he was classified as an existence, practically as dangerous, as the demon king [Diablos](Aurora.md "Aurora").

But the agitation ended the Cult of Diablos, he decided to intervene in closing the door "the so-called Black Rose", achieving in the process, repel the demon Ragnarok in the process of closing the Black Rose, with the aim of taking advantage of the foundations of the kingdom of Oriana, and obtaining a pawn country under his command.

With the Cult stewardship of the "Black Rose" and to ensure that the Kingdom would survive in perpetuity, they decide to make a pact with the Kingdom to give the Cult fair compensation, which is the Royal Blood and the majority of the Kingdom's tax revenue, resulting in the Kingdom to heavily invest on the arts so it could entertain them. Furthermore, the Cult is manipulating the Church to persecute Dark Knights as a way to prevent Oriana from gaining the strength and the manpower to rebel against the Cult.

## Chronology

### Investigation of Mr. Laugus

### Oriana's "Black Rose" Civil War Wedding Incident

### Return to Earth

## Trivia

- In the Light Novel, Black Rose is referred to as a catastrophe. While in the Web Novel, Black Rose is referred to as a symbol of justice for the Oriana Kingdom.
  - Cid Kagenou tries to make an imitation of Black Rose by releasing his magic into the night sky that looks exactly like Black Rose, when Cid is with the "Vow of Black Rose" troop.
    - It appears that in one episode of the anime, there is an easter egg about the Web Novel Black Rose story.[[3]](#cite_note-WN172-3)
- According to [Mordred](Mordred.md "Mordred"), despite the Cult of Diablos holding ownership of the Black Rose, their authority over it remains limited, primarily because they lack precise control over the specific demonic [realms](Realms.md "Realms") to which the gate connects.[[1]](#cite_note-V4C3-1)

## References

1. Volume 4 Chapter 3: Crashing the Ceremony!
2. Master of Garden Event Stories: Truth Seekers, Episode 6
3. Chapter 172: Vow of Black Rose

## Site Navigation
