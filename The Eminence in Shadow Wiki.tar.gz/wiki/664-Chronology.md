# 664/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/664/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/664/Chronology)

[Main](664.md "664")

[Relationships](664-Relationships.md "664/Relationships")

Image Gallery

## Chronology

### Red Moon Incident

664 participated in the assault on the red tower in the Lawless City along with 665 and 666, who were led by [Beta](Beta.md "Beta"), to collect a sample of the progenitor vampire's blood for research with [Possession](Possession.md "Possession") and help their lord Shadow if necessary.

When [Crimson](Crimson.md "Crimson") resurrected the vampire queen, [Elisabeth](Elisabeth.md "Elisabeth"), they immediately moved to aid Shadow's injured and anemic sister, Claire Kagenou—a team comprised of 664, 665, 666, and [Beta](Beta.md "Beta"). The group held back the vampire queen while protecting Claire, buying time until Shadow could aid them.

But then the girls cooperated with the 2 rulers of the other towers, [Yukime](Yukime.md "Yukime") and [Juggernaut](Juggernaut.md "Juggernaut"), along with the guidance of [Mary](Mary.md "Mary"), the ancient vampire slayer, they all stood up against Elisabeth. In the battle, they all received severe injuries from Elisabeth. Claire got up and confronted Elisabeth, holding her back, until Shadow appears and prepares to face the vampire queen.

At the end, Shadow attacks her with his opposite ultimate attack, "I Am Recovery Atomic", which heals everyone and destroys the red tower.

### Great Trading Company Conflict

During the dispute between the Mitsugoshi Company and the Major Corporate Alliance, when it became known that there was another faction involved in the plot that was trying to cause the collapse of banknote credits. along with 665 and 666 were dispatched by [Alpha](Alpha.md "Alpha") and [Gamma](Gamma.md "Gamma"), to find out the places of distribution and transportation of gold through secret caravans. But when they were about to find out who they were, they were confronted by a man named John Smith, (without knowing that he was their lord, Shadow), immediately ordered the team to turn back. The team refused and decided to attack him, but one by one they were defeated and immobilized by John Smith and his magical steel threads. They then withdraw due to John's warning, and then they informed Gamma and Alpha about their failure and provided information about what happened.

### Oriana's "Black Rose" Civil War Wedding Incident

During the civil war of the Oriana Kingdom, 664 along with 665 and 666, were called by [559](Victoria.md "Victoria") to the Oriana Kingdom for an infiltration mission to see and investigate some ancient ruins at the Saisho Stronghold that the Cult of Diablos was investigating. While they remained hidden, the Queen Reina, Rose's mother, was there with the cult group to which 559 found irrelevant and prepared to strike down the queen and 40 First Children of Diabolos. But 666 got in the way to avoid the death of her mother, resulting in 559 branding her as a traitor and prepares to kill everyone in the cult without caring about 666's situation. Then 664 and 665 are forced to attend 559, resulting the death of all the cult group with she, 665, and 559 are seriously injured. Only [one](Kouadoi.md "Kouadoi") cult lieutenant left, but their lord, Shadow comes to their rescue.

Shortly after that, 664 tries to explain the innocence of 666 to her lord Shadow and correct the misunderstanding judged by 559. But, when 665 informs them of Duke Perv Asshat and Rose's arranged marriage to be held in the capital, Shadow gets angry and says that he will not forgive Rose Oriana (without her knowing that Shadow didn't know that 666 and Rose are the same person).

When the "Black Rose" was activated and hundreds of Magical Beasts appeared, 664 and [665](665.md "665") set out to help 666 in their battle against the invading beasts. Since despite everything, they wanted her not only as their partner but also as a friend.

### The Academy Disappearances

## References
