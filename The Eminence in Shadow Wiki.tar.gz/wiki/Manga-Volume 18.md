# Manga/Volume 18

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2018](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2018)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_18?action=edit).

## Manga Volume 18

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

N/A

### ISBN JP

ISBN 978-4041173879

### ISBN EN

N/A

### Release Date

May 25, 2026 JP

## Volume Information

### Pages

144

Publication Order

| Previous | Next |
| --- | --- |
| Volume 17 | Volume 19 |

This is the eighteenth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

我が名はジャック・ザ・リッパー　悪の刃で悪を断つ者――…

異世界に転生し、あらゆる物事に陰から介入し
実力を示す「陰の実力者」設定をエンジョイしているシド。
『十三の夜剣』のメンバーは、
連続殺人鬼『ジャック・ザ・リッパー』により一人ずつ粛清されていく――。
夜剣達は殺人鬼への報復として、地下闘技場へ誘い込むが…
そこにアレクシアやクリスティーナ達も…！！

血濡れの道を征く、驚愕の第18巻！！。[[1]](#cite_note-1)

## Summary

## Chapters

- Episode 70
- Episode 71
- Episode 72
- Episode 73

## Characters

:   In order of appearance:

## References

1. [The Eminence in Shadow (18). Kadokawa](https://www.kadokawa.co.jp/product/322601000496/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • **Volume 18** • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
