# Golden Leopard Clan

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Golden%20Leopard%20Clan](https://the-eminence-in-shadow.fandom.com/wiki/Golden%20Leopard%20Clan)

Golden Leopard Clan was a [Therianthrope](Therianthrope.md "Therianthrope") clan made up of Golden Leopards.

## Overview

## History

## Known members

- [Zeta / Lilim](Zeta.md "Zeta") (Only living member)

## Trivia

## References
