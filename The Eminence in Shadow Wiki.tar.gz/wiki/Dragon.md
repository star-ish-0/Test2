# Dragon

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Dragon](https://the-eminence-in-shadow.fandom.com/wiki/Dragon)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Description

Dragons are ancient, legendary beings that have roamed the world for over 10 million years. They possess great strength, and were once considered the sole rulers of the realm.

The amount of dragons roaming around the world is unknown, this is because they are so rare that people even  started to think of them as myths and folkslore.

## History

### 10 Million years ago

Before magic even existed in the realm,creatures called Ancient Wyrms used to roam the world. But around 10 million years ago, a collision between realms occurred, allowing magic to flow into the realm for the first time.

The Ancient Wyrms had to adapt to this new magic, but most of them failed. However, those who were able to adapt to the introduction of magic, obtained great strength and abilities, those are what we now call Dragons.

### Current time

After millions of years being the rulers of the realm, the Dragons, who had the power of immortality and great strength, started to get bored due to not having any natural predators or threats. This led to many Dragons wandering away into remote places of the world, which is the reason why Dragons are considered beings of myths.

The remains of Dragon bones that couldn’t adapt to the magic can also be found around and used for research. An example of this is the “Earth Dragon” bones that were used to complete Sherry’s artifact.

## Dragon Classification

### True Dragon

Dragons that are original to the realm and were able to successfully adapt to magic.

- The Mist Dragon
- [Malak the Malevolent](Malak.md "Malak") [Original]
- Unnamed Hotsprings Dragon (Anime-Only)

### Realm Dragon

Dragons that are from a different realm. They have a different kind of magic and their abilities may be different than those of the True Dragons.

- [Nidhogg](Nidhogg.md "Nidhogg")

### Artificial Dragon

Dragons that have been created or cloned by humankind using unknown methods.

- [Malak](Malak.md "Malak") (Clone)

## Power & Abilities

These are the abilities that dragons share in common, not counting any ability or power that's unique to a specific dragon. Any unique ability will be included in the dragon's specific page.

### Immortality

Dragons, after adapting to magic, were able to become immortal and regenerate any kind of attack done to them.

The Mist Dragon has a theory of how a Dragon may actually be able to die: To start finding out how to kill a dragon,you must first find its roots in history. However,this is only a theory, since he doesn’t know himself if those roots even exist in the first place. Untill more info about this is released, Dragons are fully immortal.

## Trivia

- According to Rose Oriana, there has not been any recorded act or subjugation attempt of Dragons in the last 100 years of human history. They are said to only be seen rarely once in a blue moon.

- In The Eminence in Shadow Season 2 Episode 12, the Ancient Wyrms are depicted as dinosaurs. Although this is unique to the anime, it remains the only existing interpretation of the Ancient Wyrms so far.

- As of  August 27th 2025, a new dragon, the Whirlpool Dragon, has been mentioned, however, there has not been any confirmation of its looks or classification.

## References

## Site Navigation
