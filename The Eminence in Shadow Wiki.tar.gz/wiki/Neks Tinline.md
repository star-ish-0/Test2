# Neks Tinline

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Neks%20Tinline](https://the-eminence-in-shadow.fandom.com/wiki/Neks%20Tinline)

## Neks Tinline

## Characteristics

### Race

Human

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Spellsword

Neks Tinline is a magic swordman who participated in the goddess's trial.

## Appearance

## Chronology
