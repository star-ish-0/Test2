# Loki

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Loki](https://the-eminence-in-shadow.fandom.com/wiki/Loki)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Loki?action=edit).

|  |  |  |
| --- | --- | --- |
| “ | “It’ll be fine. “Shadow Trapping Jaw” will succeed.” | ” |
| — Loki talking to Gray, Light Novel Volume 6 - Chapter 4 | | |

## Loki

### Japanese

ロキ

### Romaji

Roki

## Characteristics

### Race

Unknown

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Knight of Rounds

### Affiliation

Cult of Diablos

## Debut

### Light Novel

Volume 5 (Mentioned)

Volume 6 (Full Appearance)

### Manga

Chapter 62 (Mentioned)

Loki (ロキ, Roki[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is an executive leader of the Cult of Diablos, being a seat member in the Knights of Rounds.

## Appearance

## Personality

## Chronology

### Background

Loki is a Seat member in the Knight of Rounds from the Cult of Diablos. Every year, he takes a drop of "Beads of Diablos" to maintain his strength and ageless immortality. In the past, Loki and his faction had been engaged in a feud with [Fenrir](Fenrir.md "Fenrir")'s faction for a long time.[CITATION NEEDED]

### United on the Verge of Cult's Total Annihilation

Loki attended the "Round Table Committee" council meeting along with the Knights of Rounds members present this year (except [Fenrir](Fenrir.md "Fenrir")) after the failed operation in the Oriana Kingdom to discuss the topic of the Cult's recent losses and decided that Shadow Garden must be eliminated by stating that they become a formidable threat after considering their blunder with the result of their failure operation mission and the destruction of their base of operation facilities, including the [Sanctuary](Sanctuary.md "Sanctuary") at [Lindwurm](Lindwurm.md "Lindwurm") that used to be the sealing place of the [Diablos](Aurora.md "Aurora")' left arm, even many of their member have been killed, including two [Rounds](Mordred.md "Mordred") member, leaving 3 vacant seats position in the Rounds.

With the release of the demon's left arm, the Cult was beginning to run out of Beads of Diablos that would grant immortality to the "Knights of Rounds", which made this intolerable and the Cult "Rounds" members desperation grow increased thus they were in a great hurry to revive Diablos' other body parts. Hence, they sent out aid to assist [Fenrir](Fenrir.md "Fenrir"), who was not present at the meeting with the mission to revive Diablos' right arm that was kept in the [Sanctuary](Sanctuary.md "Sanctuary") at the Midgar Academy, to resupply the Tears and needed to decide on whether or not the 3 vacant seats would be occupied, considering how many drops to be expectedly produced this year.

As a result, the number of drops has decreased even further with the amount produced not as much as in previous years, which is estimated to be around maybe nine to eight drops. Loki, who is hostile with Fenrir ignite their fellow Rounds by reminding them about the repeated failure of Fenrir and his faction which already become the problem for the Cult and make a decision that Fenrir will not take any of the Tears until his mission for reviving the right arm is success, which make an approval decision on Loki suggestion.

In the end, the Cult decided to stop factional strife and are now united for the first time in centuries in order to eliminate the threat from Shadow Garden until the remaining Knights of Rounds began to step in as they start to mobilize all of the organization's power into full force in response to Shadow Garden's harmful exploits against the Cult of Diablos whose actions will force the existence of their organization which had been hidden during its founding to rise to the surface and become known to the eyes of the world, even the Cult tried to set up an "operation" to eliminate Shadow with Loki as its leader as Shadow is considered their greatest threat due to his unreasonable strength.

### The Academy Disappearances

[Fenrir](Fenrir.md "Fenrir") tried to confirm his guess by asking [Petos](Petos.md "Petos") in the [Sanctuary](Sanctuary.md "Sanctuary") at Midgar Academy who was sent as an emissary at the time the [Diablos](Aurora.md "Aurora")' right arm releasing process was at 60% by mentioning Loki's name as he is the one who instigated the decisions that made for him, even he didn't like him become the "operation" leader.[[1]](#cite_note-V5C4-1)

### Assisting The Night Blades

After the fall of the [Fenrir](Fenrir.md "Fenrir") faction Brad Despoht negotiated deals with the Loki faction for power and resources for the Thirteen Nightblades[[2]](#cite_note-2) to which the Loki faction agreed and gave the Thirteen Nightblades an experiment subject that they recovered and enhanced named experiment 227 ([Millia](Millia.md "Millia"))[[3]](#cite_note-3) to help the nightblades defend themselves against Jack The Ripper.

## Powers & Abilities

Being one of the 12 knights of rounds Loki is one of the executive leaders of the Cult of Diablos and thereby receives the Beads of Diablos to gain ageless immortality and immense strength. Loki also has a faction of his own to run experiments[[4]](#cite_note-4) as well as to investigate Shadow Garden.

## Relationship

### Cult of Diablos

#### Knights of Rounds

#### [Fenrir](Fenrir.md "Fenrir")

Over the years Loki and his faction has had a long rivalry with Fenrir and his faction.[CITATION NEEDED]

#### Children of Diablos

#### [Gray](Gray.md "Gray")

### Shadow Garden

#### Cid Kagenou / Shadow

## Trivia

## References

1. Volume 5 Chapter 4: Peace in Our Time!
2. Volume 6 Chapter 3
3. Volume 6 Chapter 4
4. Seven Shadows Chronicles - Edge of the realm chapter 1

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | **Loki** • [Hel](Hel.md "Hel") • [Jormungandr](Jormungandr.md "Jormungandr") • [Fenrir](Fenrir.md "Fenrir") • [Mordred](Mordred.md "Mordred") • [Petos](Petos.md "Petos") • Jack Nelson • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • Sir Gaunt | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • [Jean](Jean.md "Jean") • Dark Spider • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • [Gray](Gray.md "Gray") • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • Reina Oriana • [Isaac](Isaac.md "Isaac") | |
