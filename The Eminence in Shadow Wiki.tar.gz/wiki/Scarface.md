# Scarface

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Scarface](https://the-eminence-in-shadow.fandom.com/wiki/Scarface)

## Scarface

### Japanese

スカーフェイス

### Romaji

Sukāfeisu

## Characteristics

### Race

Human

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Leader of the Scarface Gang

## Debut

### Light Novel

Volume 3

### Manga

Chapter 33

Scarface (スカーフェイス, Sukāfeisu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a bandit leader of the Scarface Gang.

## Appearance

Scarface has scars running all across his face.

## Personality

Scarface was very prideful of his skills and the gang that he established, even boasting that his crew could best a group of dark knights.

## Chronology

### History

Scarface formed a gang called the Scarface Gang composed of many skilled dark knights. Using their abilities, they terrorized noblemen and companies and received an international bounty of over a hundred million Zeni. One day while in the forest with his gang, he encountered two children, Cid and Claire Kagenou. He considered selling the girl and killing the boy but was interrupted by the sister's disapproval. After knocking out Claire, he faced off against Cid and got a clean slash on him. Surprisingly the boy did not fall to the slash and instead revealed his powers, slaying his crew members one by one. He was finally defeated when the Cid surpassed his limits into overdrive and overpowered him.

## Powers & Abilities

Scarface was a former dark knight with decent swordsmanship skills. He could deduce, in an instant, his opponents' weaknesses. For example, in his fight against Cid, he could easily evaluate that Cid was not as fast as he appeared and could only accelerate and decelerate spontaneously.

## References

## Site Navigation
