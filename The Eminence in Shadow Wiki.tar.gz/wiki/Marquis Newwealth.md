# Marquis Newwealth

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Marquis%20Newwealth](https://the-eminence-in-shadow.fandom.com/wiki/Marquis%20Newwealth)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Marquis_Newwealth?action=edit).

## Newwealth

### Japanese

ナリキン

### Romaji

Narikin

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Marquis

### Affiliation

Oriana Kingdom

## Debut

### Light Novel

Volume 4 (Mentioned)

### Anime

Episode 30

Newwealth (ナリキン, Narikin[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a Marquis from Oriana Kingdom.

## Appearance

## Personality

## Chronology

### Oriana's "Black Rose" Civil War Wedding

Marquis Newwealth attends a stage to witness the performance of a student by the famous pianist, [Shiron](Epsilon.md "Epsilon"). Upon seeing the performance, Newwealth complimented his ability to have caught Marquis attention and asked [Margaret](Margaret.md "Margaret") to invite Shiron's student to work as his pianist for an annual salary of at least seventy million Zeni, plus a concert given by the Marquis Newwealth attended by many of the biggest names in music.

## Powers & Abilities

Marquis Newwealth is one of the most influential nobles in the Oriana Kingdom.

## Relationships

### [Margaret](Margaret.md "Margaret")

## Trivia

## References

## Side Navigation
