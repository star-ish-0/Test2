# Manga/Volume 17

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2017](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2017)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_17?action=edit).

## Manga Volume 17

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

N/A

### ISBN JP

ISBN 978-4041167434

### ISBN EN

N/A

### Release Date

November 26, 2025 JP

## Volume Information

### Pages

144

Publication Order

| Previous | Next |
| --- | --- |
| Volume 16 | Volume 18 |

This is the seventeenth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

いずれ分かるよ　夜が来ればね――…。

異世界に転生し、あらゆる物事に陰から介入し
実力を示す「陰の実力者」設定をエンジョイしているシド。
学園テロ事件終結後のミドガル王国では
秘密結社『十三の夜剣』の一人が殺される事件が起きていた…！
シドは身の安全のために、クリスティーナやカナデと共同生活を送るが…。

悪が悪を断つ、震撼の第１７巻！。[[1]](#cite_note-1)

## Summary

## Chapters

- Episode 66
- Episode 67
- Episode 68
- Episode 69

## Characters

:   In order of appearance:

## References

1. [The Eminence in Shadow (17). Kadokawa](https://www.kadokawa.co.jp/product/322507000296/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • **Volume 17** • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
