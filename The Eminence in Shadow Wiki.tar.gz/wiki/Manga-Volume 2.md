# Manga/Volume 2

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%202](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%202)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_2?action=edit).

## Manga Volume 2

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041086834

### ISBN EN

ISBN 978-1975325206

### Release Date

September 24, 2019 JP
December 7, 2021 EN

## Volume Information

### Pages

144

### Chapters

4

Publication Order

| Previous | Next |
| --- | --- |
| Volume 1 | Volume 3 |

This is the second volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

When the foul-tempered Princess Alexia is captured by the Cult of Diablos, the Shadow Garden takes the stage, assaulting the cult’s hidden base. Crossing swords with the kidnapper, Cid gets the chance to make his true debut as an eminence in shadow (and show off his totally awesome secret technique). As the attack lights up the night sky over the capital, all will know of the hidden powers that lurk in the darkness![[1]](#cite_note-1)

「我が名はシャドウ。陰に潜み、陰を狩る者…」みたいな設定、満喫中!!
異世界に転生し、「陰の実力者」設定を楽しむシド。誘拐された性悪仲間（？）の王女を助け出すため、ディアボロス教団アジトへ向かう――！「さあ、プレリュードは僕が奏でよう――。」[[2]](#cite_note-2)

## Summary

### Kidnapping of Princess Alexia

## Chapters

- Episode 5
- Episode 6
- Episode 7
- Episode 8

## Characters

:   In order of appearance:

- [Delta](Delta.md "Delta") (Debut)
- [Alpha](Alpha.md "Alpha")
- Alexia Midgar
- Zenon Griffey
- Iris Midgar
- Cid Kagenou
- Sherry Barnett (Debut)
- Lutheran Barnett (Debut)
- [Glen](Glen.md "Glen") (Debut)
- Skel Etal
- Po Tato
- [Nu](Nu.md "Nu") (Debut)
- [Gamma](Gamma.md "Gamma") (Debut)
- [Rex](Rex.md "Rex") (Mentioned)

## References

1. [The Eminence in Shadow, Vol. 2 (manga). YenPress](https://yenpress.com/9781975325206/the-eminence-in-shadow-vol-2-manga/)
2. [The Eminence in Shadow (2). Kadokawa](https://www.kadokawa.co.jp/product/321905000548/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • **Volume 2** • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
