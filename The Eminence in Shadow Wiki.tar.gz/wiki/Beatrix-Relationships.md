# Beatrix/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Beatrix/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Beatrix/Relationships)

[Main](Beatrix.md "Beatrix")

[Chronology](Beatrix-Chronology.md "Beatrix/Chronology")

Image Gallery

## Family

### Unnamed Younger Sister

It's unknown what the relationship was with Beatrix and her younger sister prior to her death. But after her death, Beatrix would travel all over the world to find the daughter of her late sister.

### [Niece](Alpha.md "Alpha")

Beatrix appears to greatly care about the well-being of her niece (heavily implied to be [Alpha](Alpha.md "Alpha")), traveling the world in hopes of finding her and threatening anyone who might have some information on her whereabouts.

## Others

### Cid Kagenou / Shadow

The two had met during the Bushin Festival. Beatrix not only picked up Elf scent on Cid, but also sensed great power within the boy. She asked him if he met her niece to which he denied. When being asked about if any of the Bushin Festival's fighters had caught her interest, Beatrix declared it to be Cid, claiming that he'll be strong.

When she fought him as Shadow, Beatrix is strong enough to fight Shadow to some extent, but when Shadow started to get a bit serious, she could barely keep up with him but is still managing to hold her own in contrast to Iris who is getting tossed aside every time she tries to join the fight. Beatrix understands enough that Shadow fights without using magic and acknowledged him as an incredibly powerful warrior with his strength and skills, which she described as no different than nature itself.

However, the level of power Shadow possessed is still horrifying to her after he enveloped the entirety of the Midgar kingdom with his magical energy that looked like a dome as he readies his "I Am Atomic" attack. Luckily for them, it was just a bluff because he had no intention of killing them or everyone from the start and just disappeared. After their defeat against Shadow, Beatrix sets out on a journey of training to improve her swordsmanship from scratch and resumes her search for her niece.

In Master of Garden, the two meet again by chance to save two children from abductors. Beatrix began to develop feelings for Cid when the former was saved by him from an ambush.

### Iris Midgar

Beatrix met Iris when the former arrived at Midgar Kingdom, and she collaborated with the princess in hopes to find her niece. The two respected each other and worked together in taking down Shadow. However, even with the joint effort of the two former champions, they were unable to defeat him.

In the anime, following the fight against Shadow, it is that implied Beatrix's respect for Iris as a fellow warrior has diminished quite considerably due to her giving in to emotions and having a complete mental breakdown thus taking the loss poorly. Knowing how much it broke her; she sternly advised the princess not to be obsessed in fighting Shadow.
