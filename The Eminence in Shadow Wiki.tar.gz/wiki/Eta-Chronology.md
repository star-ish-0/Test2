# Eta/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Eta/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Eta/Chronology)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Eta/Chronology?action=edit).

[Main](Eta.md "Eta")

[Relationships](Eta-Relationships.md "Eta/Relationships")

Image Gallery

## Volume 1

### Assault on Viscount Grease's Base

After her master's elder sister, Claire Kagenou was abducted by Viscount [Grease](Grease.md "Grease") from the Cult of Diablos, Eta participated in the assault on the secret base where Claire was being held, along with her lord and the rest of the Seven Shadows. They managed to rescue Claire after they eliminated all Cult members and the leader of the branch base. Afterward, Eta would join her sisters in leaving Shadow for a duration to expand their influence to keep apace with the Cult's power.[[1]](#cite_note-V1C1-1)

## Volume 2

### Bushin Tournament

At the beginning of the Bushin Festival, Eta, [Gamma](Gamma.md "Gamma") [Nu](Nu.md "Nu"), [Chi](Chi.md "Chi") and [Omega](Omega.md "Omega") change Cid's face using a slime base and mechanical alterations. With Shadow in the disguise that suits his needs, she retired to resume sleeping, wheeled off on a box dolly.[[2]](#cite_note-2)[ANIME ONLY]

By the end of the festival, Eta communicated with the other Shadow Garden members in Oriana Kingdom using Morse code. Establishing a coded covert communications network across the continent.[[3]](#cite_note-3)

## Volume 3

### Red Moon Incident

Eta was theorizing about the similarity between the [Possession](Possession.md "Possession") and the [Vampire](Vampire.md "Vampire") Progenitor's blood, and informed [Beta](Beta.md "Beta") to look for information in the Crimson Tower of the Lawless City. Afterward, they started preparing an operation because their master intended to go there.[[4]](#cite_note-V3C2-4)

After the [Blood Queen](Elisabeth.md "Elisabeth")'s rampage ended, Beta was able to recover the sample of Progenitor's blood and had already collected information from the tower's library to study further of her own theory's research of Possession.[[5]](#cite_note-V3C3-5)

The research was proven successful as [Alpha](Alpha.md "Alpha") was able to use the 'Red Mist Form' technique. Able to use use it against John Smith later,[[6]](#cite_note-V3C6-6) and [Zeta](Zeta.md "Zeta") using 'Black Mist Form' during her fight with Delta.

### Great Trading Company Conflict

Following the events of [Delta](Delta.md "Delta")'s disappearance, Eta was given an encrypted message by Shadow from [Beta](Beta.md "Beta") written in an alien language (Japanese). After Eta decoded the message, it was discovered that the message was Shadow's explanation on his "betrayal" and the deciphered parcel was forwarded to [Alpha](Alpha.md "Alpha") and the other Seven Shadows.[[7]](#cite_note-V3CE-7)

## Volume 4

### Oriana's "Black Rose" Wedding

In the anime, hearing an urgent report from the Oriana Kingdom that the Black Rose has been activated, Eta tries to suggest to Alpha to send a ship, but fears that the capital will probably fall before it arrives. However, Alpha calms Eta down by saying that Shadow is there to save Oriana from the Cult of Diablos.[[8]](#cite_note-8)

### Return to Earth

After Beta returned from her adventure in [another world](Earth.md "Earth") with Shadow, she brought an alien inhabitant from that world back with her. Alpha subsequently placed the Otherworlder under Beta's protective custody out of fear of what Eta would do if she got her hands on the alien.[[9]](#cite_note-V4CE-9)

## Volume 5

### The Midgar Academy Mist Terrorist Attack

## Volume 6

### Tales from Shadow Garden HQ

## References

1. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
2. Episode 15
3. Episode 20
4. Volume 3 Chapter 2: Storming the Crimson Tower!
5. Volume 3 Chapter 3: Pursuing the Blood Queen!
6. Volume 3 Chapter 6: Circulating Counterfeit Cash!
7. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fakes Bills!
8. Episode 32
9. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
