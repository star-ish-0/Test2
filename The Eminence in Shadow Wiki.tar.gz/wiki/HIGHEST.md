# HIGHEST

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/HIGHEST](https://the-eminence-in-shadow.fandom.com/wiki/HIGHEST)

## HIGHEST

## Information

### Artist(s)

[OxT](http://www.oxt-music.com/)

### Composer(s)

Tom-H@ck

### Arranger(s)

KanadeYUK

### Lyrics

hotaru

### Release date

October 26, 2022

HIGHEST is the opening theme performed by OxT for the first season of the anime adaption The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Lyrics

### TV Size

- [Kanji](#)
- [Romaji](#)
- [English](#)

この全て今賭けて

ただ理想に届くまで この手伸ばして

目の前に伸びる選択肢

善と悪との歯車は行く

ただ一つだけの結末へ

何もかも偶然の Choice

そしてまた次への合図

可能性の限界まで

その行く先を見つめて

Only one 他には要らない

To the one だけ見据えてたい

譲れはしない信念と決意

この胸に秘めて

Highest, highest, I'm going on

真実より真相の 陰を行け

Highest, highest, I'll carry on


是が非でもさあ 望むなら 孤高に貫け

Kono subete ima kakete

Tada risō ni todoku made kono te nobashite

Me no mae ni nobiru sentakushi

Zen to aku to no haguruma wa iku

Tada hitotsu dake no ketsumatsu e

Nanimokamo gūzen no Choice

Soshite mata tsugi e no aizu

Kanōsei no genkai made

Sono yukusaki o mitsumete

Only one hoka ni wa iranai

To the one dake misuetetai

Yuzure wa shinai shin'nen to ketsui

Kono mune ni himete

Highest, highest, I'm going on

Shinjitsu yori shinsō no kage o ike

Highest, highest, I'll carry on


Ze ga hi demo sā nozomunara kokō ni tsuranuke

Now, betting everything I have

Until I reach my ideal, I reach out my hand

Options are spreading out before me

The gears of good and evil turn

Heading towards only one conclusion

Everything is just a random choice

And move on to the next signal again

Until I reach the limit of possibility

I stare at that destination

Only one, I don't need anything else

To the one, I just want to keep my focus

I won't give in my belief and determination

I keep them hidden in my heart

Highest, highest, I'm going on

Rather than the truth, go on the shadows of truth

Highest, highest, I'll carry on


if that's what I want, aim for the highest no matter what

### Full Version

- [Kanji](#)
- [Romaji](#)
- [English](#)

この全て今賭けて

ただ理想に届くまで この手伸ばして

目の前に伸びる選択肢

善と悪との歯車は行く

ただ一つだけの結末へ

何もかも偶然の Choice

そしてまた次への合図

可能性の限界まで

その行く先を見つめて

Only one 他には要らない

To the one だけ見据えてたい

譲れはしない信念と決意

この胸に秘めて

Highest, highest, I'm going on

真実より真相の 陰を行け

Highest, highest, I'll carry on

是が非でもさあ 望むなら 孤高に貫け

盤面上に映す現在地

表と裏で連なる策略

全貌など見えないままで

今はただ静観の Choice

来るべき時への Lie

最後尾の分岐まで

まだその姿潜めて

In the light 誰も知らない

In the night 誰より強い

覚悟と思想 宿した欲望

この胸に秘めて

Highest, highest, I'm going on

称賛のない栄光の道を行け

Highest, highest, I'll carry on

光よりも頂へ 孤独を抱いて

目の前に伸びる選択肢

迷わずに今歯車は行く

望んだ通りの結末へ

I'll keep trying for my belief

例え何が起きようと揺るがない

Highest, highest, I'm going on

真実より真相の 陰を行け

Highest, highest, I'll carry on


是が非でもさあ 望むなら 孤高に貫け

Kono subete ima kakete

Tada risō ni todoku made kono te nobashite

Me no mae ni nobiru sentakushi

Zen to aku to no haguruma wa iku

Tada hitotsu dake no ketsumatsu e

Nanimokamo gūzen no Choice

Soshite mata tsugi e no aizu

Kanōsei no genkai made

Sono yukusaki o mitsumete

Only one hoka ni wa iranai

To the one dake misuetetai

Yuzure wa shinai shin'nen to ketsui

Kono mune ni himete

Highest, highest, I'm going on

Shinjitsu yori shinsō no kage o ike

Highest, highest, I'll carry on

Ze ga hi demo sā nozomunara kokō ni tsuranuke

Banmen jō ni utsusu genzaichi

Omote to ura de tsuranaru sakuryaku

Zenbō nado mienai mama de

Ima wa tada seikan no Choice

Kitarubeki toki e no Lie

Sai kōbi no bunki made

Mada sono sugata hisomete

In the light dare mo shiranai

In the night dare yori tsuyoi

Kakugo to shisō yadoshita yokubō

Kono mune ni himete

Highest, highest, I'm going on

Shōsan no nai eikō no michi o ike

Highest, highest, I'll carry on

Hikari yori mo itadaki e kodoku o daite

Me no mae ni nobiru sentakushi

Mayowazu ni kon haguruma wa iku

Nozonda tōri no ketsumatsu e

I'll keep trying for my belief

Tatoe nani ga okiyō to yuruganai

Highest, highest, I'm going on

Shinjitsu yori shinsō no kage o ike

Highest, highest, I'll carry on


Ze ga hi demo sā nozomunara kokō ni tsuranuke

Now, betting everything I have

Until I reach my ideal, I reach out my hand

Options are spreading out before me

The gears of good and evil turn

Heading towards only one conclusion

Everything is just a random choice

And move on to the next signal again

Until I reach the limit of possibility

I stare at that destination

Only one, I don't need anything else

To the one, I just want to keep my focus

I won't give in my belief and determination

I keep them hidden in my heart

Highest, highest, I'm going on

Rather than the truth, go on the shadows of truth

Highest, highest, I'll carry on

if that's what I want, aim for the highest no matter what

The current location is shown on the board

A chain of strategies front and back

Without being able to see the overview

Right now, I simply observe quietly

A lie leading to the appointed time

Until the fork at the very end

Keeping yourself hidden

In the light, no one knows

In the night, stronger than anyone

My determination and desire filled with my ideology

I keep them hidden in my heart

Highest, highest, I'm going on

Go on the road of fame without praise

Highest, highest, I'll carry on

Aim for the top, rather than light

Along with loneliness

Options are spreading out before me

Without hesitation, the gears turn now

To the ending I hope for

I'll keep trying for my belief

No matter what, I won't be shaken

Highest, highest, I'm going on

Rather than the truth, go on the shadows of truth

Highest, highest, I'll carry on


if that's what I want, aim for the highest no matter what

## Characters

:   In order of appearance:

- Cid Kagenou/Minoru Kageno
- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Delta](Delta.md "Delta")
- [Epsilon](Epsilon.md "Epsilon")
- [Lambda](Lambda.md "Lambda")
- [Gamma](Gamma.md "Gamma")
- [Nu](Nu.md "Nu")
- [Omega](Omega.md "Omega")
- [Chi](Chi.md "Chi")
- [Zeta](Zeta.md "Zeta")
- [Eta](Eta.md "Eta")
- Alexia Midgar
- Sherry Barnett
- [Aurora](Aurora.md "Aurora")
- Iris Midgar
- Rose Oriana

## Videos

HIGHEST

Music Track

TVアニメ『陰の実力者になりたくて！』ノンクレジットオープニング：OxT「HIGHEST」

Opening Visual

## Trivia

- The ending still of Shadow and the Seven Shadows would change each arc to reflect the location of events.
  - Episodes 1-5 had them atop the Clocktower overlooking the Midgar Royal Capital city.
  - Episodes 6-9 had them atop a building overlooking the Academy's inferno.
  - Episodes 10-14 had them atop the water dam overlooking Lindwurm at night.
  - Episodes 15-19 had them atop the stadium overlooking the Bushin Festival under a lightning storm.
- Lambda, Nu, Chi, and Omega make disguised cameos in the anime opening.
  - Lambda in a school uniform riding the escalator ahead of a disguised Epsilon.
  - Nu standing left of student councilwoman Gamma reading a report.
  - Omega and Chi on marker boards away from Gamma, but both of their faces are away from the viewer.
- HIGHEST was featured in a crossover event between The Eminence in Shadow and the DJ-themed rhythm and adventure game D4DJ Groovy Mix. The event lasted on the English servers from February 26th 2:00 AM UTC to March 4th 7:59 AM UTC.[[1]](#cite_note-1)

1. [D4DJ Groovy Mix English Twitter](https://x.com/D4DJ_game_EN/status/1761209333017362617) (23/04/2024)
