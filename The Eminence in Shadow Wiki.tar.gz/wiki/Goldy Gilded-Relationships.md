# Goldy Gilded/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Goldy%20Gilded/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Goldy%20Gilded/Relationships)

Main

Chronology

Image Gallery

### Mundane Mann / Shadow

After assessing Mundane's strength, Goldy deemed him to be a weakling and thought he would be easy to defeat. However, he was shocked when he somehow dodged his attack and acted as if he did not even notice it. This seeming disrespect enraged Goldy to the point that he tried to murder his opponent only to be taken down with a single attack.[[1]](#cite_note-V2C5-1) Goldy would later learn that Mundane was the infamous Shadow.[[2]](#cite_note-2)

### [Quinton](Quinton.md "Quinton")

Despite having to know each other for a short time, the two bonded and quickly became friends. When the former veteran was defeated by the hands of the White Demon, the formerly known "Undefeated Legend" tried escaping the Lawless City effectively abandoning him.[[3]](#cite_note-:0-3) Alas, he too would ultimately be taken down the anarchic nature of the town and became a slave alongside his friend.[[4]](#cite_note-:1-4)

### Annerose Nichtsehen

In the past, Goldy had a match three times with swordswoman from Velgalta and always forfeit his match against her. Goldy didn't realize that Annerose knew the real reason he had earned the title "Undefeated Legend".[[1]](#cite_note-V2C5-1)

### White Demon

Of the two Bushin competitors that went to the Lawless City, Goldy recognizes the former Knight by name. By the time he recognized the watchdog, he was too late when Quinton was easily taken down.[[3]](#cite_note-:0-3)

## References

1. Volume 2 Chapter 5: A Battle to Attract Only MVPs!
2. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fakes Bills!
3. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
4. Volume 3 Chapter 1: Lawless City Bandit Hunting!
