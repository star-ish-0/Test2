# Laugus

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Laugus](https://the-eminence-in-shadow.fandom.com/wiki/Laugus)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Laugus?action=edit).

## Laugus

### Japanese

ラワガス

### Romaji

Rawagasu

## Location Information

### Leader

Unknown

### Status

Active

### Affiliates

Unknown

### Type

Academic City

### Government

Unknown

### Location

Unknown

### Inhabitants

Humans

## Debut

### Web Novel

Chapter 29 (Mentioned)

### Light Novel

Volume 1 (Mentioned)

### Manga

Chapter 8 (Mentioned)

### Anime

Episode 9 (Mentioned)

Laugus (ラワガス, Rawagasu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is an academic city.

## History

Laugus is originally the second laboratory of a certain esteemed scientist with his undeniable abilities named Lord Laugus was a mad scientist which also known for his brilliance and apparently was the first chancellor of the college town that shares his name.

Thus, any other brilliant minds began to gather around him and then technology advanced until grew into a city which began to take shape that known as the college town, Laugus.

## Military

## Location

## Layout

## Inhabitants

- Sherry Barnett

## Trivia

According to Wikipedia **Laugus**, also spelled [Lugus](https://en.wikipedia.org/wiki/Lugus) is an alternate spelling of the name of the Norse god that the character [Loki](Loki.md "Loki") is named after. Likely indicating the location of the Knights of Round member [Loki](Loki.md "Loki").

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • **Laugus** • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
