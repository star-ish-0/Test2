# Midgar Kingdom

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Midgar%20Kingdom](https://the-eminence-in-shadow.fandom.com/wiki/Midgar%20Kingdom)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Midgar Kingdom

### Japanese

ミドガル王国（おうこく）

### Romaji

Midogaru ōkoku

## Location Information

### Leader

Klaus Midgar

### Status

Active

### Affiliates

Oriana Kingdom (Allied until Volume 5)

### Type

Country

### Government

Monarchy

### Location

Unknown

### Inhabitants

Humans
Shadow Garden
Cult of Diablos

## Debut

### Web Novel

Chapter 2

### Light Novel

Volume 1

### Manga

Chapter 1

### Anime

Episode 2

Midgar Kingdom (ミドガル王国（おうこく）, Midogaru ōkoku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the kingdom where the Midgar royal family resides and the [Fenrir](Fenrir.md "Fenrir") Sect faction territory. It is also the home of Cid Kagenou, otherwise known as Shadow.

## Geography

The Midgar Kingdom's territory borders with Oriana Kingdom and The City-State Alliance.

## History

The Midgar Kingdom is powerful, home to many formidable dark knights, such as Iris Midgar. Furthermore, Midgar's royal capital boasts being home to the Midgar Academy, one of the most prestigious dark knights' academies on the continent.

The Midgar Kingdom are using Royal Bushin method, which is a relatively new fighting style and a deviation
from traditional Bushin. Traditional Bushin method was originally already the most popular style in Midgar, so there was some resistance at first between the traditional supporters and the trailblazers. But thanks to Princess Iris, it’s now being recognized as the second most popular style in this country, behind only the traditional Bushin method.

## Military

Midgar Kingdom pride themselves for having the most powerful military in the world, which earning the attention of the Velgalta Empire.

After the incident of the Second Princess Alexia Midgar's kidnapping, the First Princess herself had founded a special force called the Crimson Order which consisted of strong knights in order to protect the kingdom from all threats with Iris Midgar as its commander.

## Featured Locations

- Midgar Academy for Dark Knights and Midgar Academy of Science
- Holy Land, [Lindwurm](Lindwurm.md "Lindwurm")
- [Alexandria](Alexandria.md "Alexandria") (Former Capital)

## Inhabitants

### Royal Family

- [Freya](Freya.md "Freya") (Founder; Deceased)
- Klaus Midgar (Current King)
- Iris Midgar (First Princess)
- Alexia Midgar (Second Princess)

### Officials

- Zenon Griffey (Deceased)
- [Glen](Glen.md "Glen") (Deceased)
- Marco Granger
- [Jean](Jean.md "Jean") (Deceased)
- [Adder](Adder.md "Adder")
- [Gray](Gray.md "Gray")

### Other

- Lukreia Crowley (Deceased)
- Garter Kikuchi

## Trivia

- The name Midgar in the kingdom itself refers to the name [Midgard](https://en.wikipedia.org/wiki/Midgard "wp:Midgard") from Norse Mythology, which is a concept in referring to the world inhabited by humans as the "home of men" being the realm of humankind that is in the center of all the other 8 realms which are supported and united by the [world tree](https://en.wikipedia.org/wiki/Yggdrasil "wp:Yggdrasil").
  - Interestingly, Midgar Kingdom itself has been in control by the [four](Fenrir.md "Fenrir") [top](Loki.md "Loki") [executive](Hel.md "Hel") [members](Jormungandr.md "Jormungandr") within the "Knights of Rounds" from the Cult of Diablos who operate behind the scenes under the same name related to Norse Mythology.
- Until the current date, none of all the other residents and inhabitants of Midgar, including the royal family themselves are aware that the ancient capital of their kingdom's past, [Alexandria](Alexandria.md "Alexandria") still exists till present day and considers it to be just a myth.
- Midgar Kingdom's capital in the anime is inspired by 3 cities; namely Florence, Italy; Melbourne, Australia; and possibly London, United Kingdom.[CITATION NEEDED]

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • **Midgar Kingdom** • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
