# Crimson

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Crimson](https://the-eminence-in-shadow.fandom.com/wiki/Crimson)

|  |  |  |
| --- | --- | --- |
| “ | The Red Moon…isn’t ready yet… | ” |
| — Crimson, Light Novel Volume 03 | | |

## Crimson

### Japanese

クリムゾン

### Romaji

Kurimuzon

## Characteristics

### Race

[Vampire](Vampire.md "Vampire")

### Gender

Male

### Age

1000+

### Height

Unknown

### Hair Color

Red

### Eye Color

Red

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- True Monarch (Lawless City)
- Adviser

### Affiliation

Lawless City

## Debut

### Web Novel

Chapter 99

### Light Novel

Volume 3

### Manga

Chapter 28

### Anime

Episode 21

## Portrayal

### Japanese

[Tomokazu Sugita](https://en.wikipedia.org/wiki/Tomokazu_Sugita "wp:Tomokazu Sugita")

### English

Dickie Sanders

### French

Valéry Schatz

Crimson (クリムゾン, Kurimuzon[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the [true](Yukime.md "Yukime") [Monarch](Juggernaut.md "Juggernaut") of the Crimson Tower in the Lawless City, attemping to manipulate the figurehead Monarch, [Elisabeth](Elisabeth.md "Elisabeth"), to fulfill his own long-cherished wish of restoring the [Vampire](Vampire.md "Vampire") race's status as the rulers of the world.

## Appearance

Crimson was a tall and stout vampire man who possesses a stern and handsome face. He has red hair that is slicked to the side, bloodshot eyes, and slightly pale skin.

He was dressed in a long black dress, a gold-accented black robe with a large, crimson inside collar, and a white ruffled tie. He also wore accessories in the form of a dark red jewel necklace.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Let us paint the world in blood once more. On this night so befitting us, a scarlet night of blood and terror... | ” |
| — Crimson, Episode 22 | | |

Crimson was a Vampire supremacist who looked down on those that he deemed weak and beneath him. He particularly hated mankind after they took advantage of his race's weaknesses to hunt them down to near extinction. Hence, he desired world conquest and planned to have mankind be reduced to nothing more than livestock.

On the other hand, Crimson had no qualms manipulating his own kind for his own purposes, the most infamous action being when he corrupted Elisabeth by using the same tactics he derided the humans for using against the vampires. In addition to having pitifully begged for his life when Shadow overwhelmed him showing that for all his power and arrogance, Crimson was nothing short of a bully that picked on others and cowered when things became too much for him.

## Chronology

### Background

Crimson was used to be [Elisabeth](Elisabeth.md "Elisabeth")'s second subordinate after [Mary](Mary.md "Mary") who wanted to restore the glory days of [Vampire](Vampire.md "Vampire") since humans had hunted their race to near extinction after discovering their weakness, in fact he was secretly very disgusted with his master's efforts and ideology in creating a "Haven" where humans and vampires live side by side and can coexist with the other races.

To make this happen, Crimson intends to incite the vampires who have the same thoughts as him after being cornered by humanity for a long time to launch a rebellion with his plan to make Elisabeth be affected by the taste of blood and utilize the power of the Progenitor.

At one time when Crimson traded shifts with Mary to bring meals to Elisabeth's room, who at that time was suppressing her thirst to drink blood on the night of the rising Red Moon, he cunningly mixed human blood into her meals which made Elisabeth go out of control under the Red Moon's influence and at the same time Crimson start leading a riot along with his vampire sympathizers by devouring all humans in the land that his master had built, leading to the destruction of three countries followed by countless deaths for three full days. When the Red Moon finally went down, the Blood Queen and her kin abruptly withdrew and hid themselves, waiting until the day when humans forget about them entirely.

Following the event, Crimson intends to revive the Progenitor to use his power to fulfill his ambition in subjugating [humanity](Human.md "Human") again by seizing the coffin containing Elisabeth's body from Mary and the Crimson's respect forgives Mary by letting her live after protecting the Blood Queen, which he hopes for Mary's presence as ally in a thousand years when the Red Moon rises.

Later, Crimson kept the Blood Queen's coffin in his master castle which would later be called the Crimson Tower and rule the city that was once "Haven" has turned into a place of horrid atrocities with all evil in the world gather in the city that which will eventually be known as the Lawless City while he awaits the time to revive the Vampire Progenitor.[[1]](#cite_note-1)

While carrying out his planning to resurrect Elisabeth to cull humanity and put their kind under the foot of vampire race, Crimson sets his minions to kill off the humans in the city and spread terror of destruction to the surrounding countries outside the Lawless City. However, in order to establish a position of power in the city, Crimson made Elisabeth a monarch in name only while he acted behind the scenes by keeping the Blood Queen's long thousand-year slumber a secret from public and blocking anyone who wanted to climb the Crimson Tower to withhold the truth hidden.[[2]](#cite_note-V3P-2)

Four years ago, Crimson one-sidedly defeated the White Demon with opposing intent until the challenger begged for his life after cutting off his right arm with his power which made Crimson ultimately make the White Demon to work as a watchdog for the Crimson Tower and ordered him not to let a single person enter the tower.

### Red Moon Incident

## Powers & Abilities

Crimson was a high-ranking [Vampire](Vampire.md "Vampire") which has a powerful strength and exceptional recovery ability.

### Vampiric Dexterity and Ability

### Night Vision

### Vampire Noble

### Regeneration

### Power of the Red Moon

### Special techniques:

#### Red Mistform

#### Blood Arrows

#### Vampire Curse

## Relationships

### [Elisabeth](Elisabeth.md "Elisabeth")

### [Mary](Mary.md "Mary")

Mary is the second in command of the "Blood Queen", Elisabeth and Crimson superior. Crimson make an excuse to her after showing his genocidal goals and his manipulation of his fellow vampires, as he states that he wants Elisabeth to help him slaughter and subjugate humanity as revenge for horrific vampire executions.

### White Demon

Crimson thoroughly brings the White Demon down to his knees and forces him to be his eternal servant.

### [Yukime](Yukime.md "Yukime") & [Juggernaut](Juggernaut.md "Juggernaut")

Crimson is all too familiar with the two monarch of the Lawless City as he was suffered bitter losses at their hands many times before. Although he’s loath to admit it, both of them are a fair bit more powerful than he is.

Crimson assured about his certain victories against both of them, after his queen is already reborn along with the Red Moon influence.

### Shadow

After hearing Shadow name from his servant and claim that he may well pose the biggest threat to him after he’s taken out a number of ghouls, as well as the vampires reinforcements on his own, Crimson decide to fight him if he become interference in his plans.

When Crimson finally confronts Shadow, he is about to monologue only for the latter to slash him many times over before he could finish a full sentence. After being beaten within an inch of his life by Shadow, he tries to make a deal with him. Unfortunately, Shadow doesn't care and kills him for good.

## Trivia

- Crimson is the only villain so far not to be associated with the Cult of Diablos.

## References

1. Episode 22
2. Volume 3 Prologue: Heading to the Lawless City over Fall Break!

## Side Navigation
