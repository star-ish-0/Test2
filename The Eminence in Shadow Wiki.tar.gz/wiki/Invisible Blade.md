# Invisible Blade

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Invisible%20Blade](https://the-eminence-in-shadow.fandom.com/wiki/Invisible%20Blade)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

The Invisible Blade (魔剣（まけん）インビジブル, Maken Inbijiburu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a long-lost elven artifact. As the name suggests, the sword is invisible and cannot be seen by the naked eye.[[1]](#cite_note-V4C3-1)

## History

The blade originally belonged to the Elven Kingdom; however, it was eventually stolen and now rests in the hands of [Mordred](Mordred.md "Mordred").[[1]](#cite_note-V4C3-1)

## Known Users

- [Mordred](Mordred.md "Mordred")

## Trivia

- While in the Light Novel and the Manga, it was unknown what happened to the invincible sword, since it was presumed destroyed along with Mordred's body,[[2]](#cite_note-2) in the anime and Game, it was confirmed that said weapon was recovered by [Beta](Beta.md "Beta") and [Epsilon](Epsilon.md "Epsilon"), after defeating Mordred.[[3]](#cite_note-:0-3)
- While in the light novel and manga, it is noted that the sword itself is invincible,[[1]](#cite_note-V4C3-1) in the anime and game, it is not, but instead, it performs magical attacks, impossible to see.[[3]](#cite_note-:0-3)
- Although the weapon as such is invincible, it has been shown that it can be seen by beings or people who have the ability to see it, Shadow being one of them.[CITATION NEEDED]

## References

1. Volume 4 Chapter 3: Crashing the Ceremony!
2. Manga: chapter 46
3. Episode 32
