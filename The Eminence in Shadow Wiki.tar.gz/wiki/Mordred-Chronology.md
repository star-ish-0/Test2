# Mordred/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mordred/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Mordred/Chronology)

[Main](Mordred.md "Mordred")

[Relationships](Mordred-Relationships.md "Mordred/Relationships")

Image Gallery

## Synopsis

### Background

Mordred was a 9th Seat Knight of Rounds from the Cult of Diablos, also named himself as the Knight Beyond Man and The Transcendent Spellsword. Every year, he takes a drop of "Beads of Diablos" to maintain his strength and immortality. At some point, Mordred managed to acquire the Invisible Blade from the elven capital through unknown means. Mordred and his faction operate in the Oriana Kingdom.

Learning about the Oriana Kingdom's current king's treason for cutting his ties with the Cult and building a force to rebel against the Cult by forging an alliance with the Midgar Kingdom also sending his daughter to attend their academy in secret with hope to protect her from harm, they decide to brainwash him to become their puppet king by ordering Perv Asshat to drug the king considering his actions with the help from Queen Reina.

At that time, Mordred was persuaded by Perv to make him a candidate for occupying the vacant 12th seat of the Rounds, if his faction can help him succeed in his mission given by the Cult. Thinking that gaining control of the Black Rose's ownership would improve his standing in the Rounds, Mordred agreed and promised on helping Perv Asshat in nominating his legitimate candidacy in exchange for Perv's backing support in the Cult’s upcoming internal power struggle.

Before the king became the Cult's puppet, he did one final act; he took possession of the Ring of Succession, which was actually the key to the "Black Rose", then he recorded his last will and testament in the Ring along with all evidence of Perv and Cult's crimes. Also, he altered the Ring to transfer control over his daughter and by marrying her is the only way to gain dominion over the Ring. After that, the king hid the Ring from the Cult.

While Perv Asshat was visiting the Midgar's Royal Capital with the objective to retrieve Rose Oriana under the pretense of their engagement, Mordred searched the Ring's hiding place.

### Bushin Festival Tournament

In the anime, Mordred then heard about the report of Perv's failed mission in securing Rose Oriana, due to Shadow's interference during the Bushin Festival tournament and conveyed his disappointment, to the point where he was forced to beg his superior’s forgiveness for his failure. Perv also told his superiors that as long as the Cult holds the royal family, Rose won't be able to stay hidden for long. Plus Oriana's situation is already in chaos and turmoil with the loss of their king, Perv is sure that Rose can't ignore it and will definitely come back.

Mordred tells Perv to take care of Oriana Kingdom's business first, while waiting for the news about the "Ring's" hiding place and postponing search for Rose Oriana for the time being. Also, Mordred hoped for Perv not to disappoint him too much, before he goes to the meeting with his fellow Rounds, finally deciding to get serious about crushing Shadow Garden considering the destruction of the [Sanctuary](Sanctuary.md "Sanctuary") at [Lindwurm](Lindwurm.md "Lindwurm").[[1]](#cite_note-1)

Mordred finds the "Ring's" hiding place, which is the Saisho Stronghold after being captured two days ago. Then, he orders Perv to retrieve the Ring first by bringing Queen Reina along with 40 First Children, led by 4 Named Children, among them is [Kouadoi](Kouadoi.md "Kouadoi").

### Oriana's "Black Rose" Civil War Wedding Incident

After hearing the news that Perv has obtained the "Ring of Succession" and Princess Rose, Mordred immediately prepares to pull all the necessary strings for his 12th seat position, which he promised to Perv. Before the wedding, he telepathically contacts Perv and congratulates him by telling him that the preparations have been completed and expects great things from him and not to let him down, to which he replied yes, unbeknownst that the "Ring of Succession" has gone missing.

During the wedding after Rose activates the Ring and then a recording of the king's projection appears with the information that exposes the Cults' crimes and defeats Perv, Mordred decides to reveal himself after killing Perv Asshat and Queen Reina for just a little cleanup, also opens the now unlocked "Black Rose", letting loose hordes of Magical Beast upon the capital in order to kill everyone in Oriana so that the Cult can take control of what's left of the kingdom. Shadow Garden then make their move to suppress the outbreak and two "Seven Shadows" [Epsilon](Epsilon.md "Epsilon") and [Beta](Beta.md "Beta") confront Mordred to check "their answers on a few things" before they kill him.

Mordred did not seem to care about their response because he did not want to waste his time on them as he pulls something from his pocket and hurls it into the Black Rose to summon [Ragnarok](Ragnarok.md "Ragnarok"), Grand Ruler of the Fourth Realm. Suddenly, Shadow appears and cuts one of Ragnarok’s wings. Mordred begins to praise him for his sudden strike and mocks him that he has angered Ragnarok, before Shadow cuts him off and mocks him back and he begins fighting against Ragnarok to the death outside the capital.

While Shadow fights Ragnarok, Mordred fights against Beta and Epsilon in the triangle position. Then, in the blink of an eye, Mordred decides to strike at both of them before they leap backward at the same time, only able to wound the cheek of the legendary Faithful, Epsilon. Mordred compliments them for dodging his strike until Beta reveals his secret, which is the Invisible Blade from the long-lost Elven Artifacts and Beta accuses him of stealing the sword that was supposed to be kept in the Elven Capital and tells him to return the sword he stole, which makes Mordred mock them for trying to take the sword away from him before Epsilon suddenly strikes him down by throwing her attack filled with magic, much to his shock.

Despite his efforts, Mordred feels a twist in humiliation after fighting the two Seven Shadows, only for him to struggle. After that, Mordred decides to end the fight and have a conversation with them to check their answers about the "Black Rose", the Magical Beasts and Diablos at his confidence that Ragnarok will defeat Shadow. Mordred tells them there are countless other worlds beyond their own in entire other dimensions, which he calls [Realms](Realms.md "Realms"). With the worlds orbiting around and spinning as the years go by until they collide, the impact sends rifts across the worlds, with two different worlds becoming linked and each exerting influence on the other.

Even Mordred says that this world has no magic, and humans are not the original inhabitants, because this world is making contact with the Realm in another world and the Cult is doing research for their working theory that this world and the Realms interact with each other on a cyclical basis and exert influence over each other. [Beta](Beta.md "Beta") questions him whether [Diablos](Aurora.md "Aurora") also came from one of these other worlds. However, he claims that her assumption is false, and that Diablos was a genuine inhabitant of their world and tells her that the demon isn’t the true, original Diablos, which is the organism that became the basis for Diablos and theorize that Diablos called the original in from the First Realm which is higher than the Fourth Realm. Then, Mordred checks both the Seven Shadows' last answer about the "Black Rose" which Beta confirms that it’s a gate that can connect to this world to Realms.

Mordred praises them for their correct assumption about the "Black Rose" and tells the real story of the "Black Rose" when accidently opened also poured magical beasts over Oriana Kingdom during the siege of Velgalta Empire, which was a stroke of misfortune for both nations. Even with the Velgaltan soldiers dead, the gate still kept summoning magical beasts and began to consume Oriana, and the Kingdom would have been quite literally obliterated, if someone or something did not appear, to intervene and close the door. Due to this, it was back then, Beta said that the Cult of Diablos decided to make the Kingdom of Oriana their puppet; Mordred replies that the Cult was the one who closed the door and saved the kingdom with the administration of the Black Rose to make sure that the kingdom would survive in perpetuity if the kingdom gives the Cult a sufficient compensation, which is the Royal Blood.

Mordred tells Rose Oriana that it was her blood that the Cult wanted, which even for a royal was blessed with incredible amounts of magic and as per their agreement, the kingdom would turn her over to the Cult when she was still a baby. But her father, the King, foolishly refused them. Beta also added that the Cult's compensation is not just royal blood from the Kingdom. The other compensation is that Oriana were to give a majority of their tax revenue to the Cult, resulting in the kingdom to heavily invest on the arts so it could entertain them. On top of that, the Cult was manipulating the Church to persecute the Dark Knights as a way for the Cult to prevent Oriana from gaining the strength and manpower to rebel against the Cult, which basically became a puppet kingdom. Beta tells Rose that the King wanted to break the cycle by forging an alliance with the Midgar Kingdom, in order to fix his twisted nation from within, and tried to secede from the Cult, but they killed him and confirmed the reason Rose was allowed to study at Midgar Academy for Dark Knights was to get her somewhere safe from harm.

Mordred calls Rose's father, the King as a fool and tells her that with the gates of the "Black Rose" still open despite its unstable state, the Cult will take direct control of the Oriana Kingdom. However, Rose Oriana, who hates the Cult, says that she will not let that happen and will continue her father's cause by rebuilding the kingdom with her own hands. He laughs at her statement and wishes that Oriana Kingdom will burn to the ground by [Ragnarok](Ragnarok.md "Ragnarok") until suddenly Ragnarok's right arm falls at the place Mordred fought against Beta and Epsilon, hitting his left arm.

Despite noticing the arm, Mordred still believes Shadow can't bring down [Ragnarok](Ragnarok.md "Ragnarok") when Ragnarok's body parts flying one after the other have been gathered at the same place, much to his surprise. Beta calls him a fool because Shadow had him dancing in the palm of his hand this whole time and adds every piece of clue about the many Shadow Garden forces being gathered here, the "Black Rose" reaction and how did Rose Oriana have the "Ring of Succession" which is the key of Black Rose.

Mordred now realizes that Shadow knew everything from the very start and wanted to observe the Cult's movement until he planned on destroying the Black Rose in its entirety. He also sees Ragnarok's remains fall right in front of his eyes along with Shadow. Mordred becomes disillusioned about the power of the Shadow Garden being so much stronger than the Fourth Realm itself. Then, Mordred's hollow laugh escapes from his throat because of the outcome and decides to consume Ragnarok’s flesh, absorbing its power until his body begins to change and strikes Shadow with his upgraded power form.

Shadow sees Mordred's state and calls him a failed experiment and taunts him that [Ragnarok](Ragnarok.md "Ragnarok") was stronger than him also mocks him about merging with too much power without intellect, much to his rage. While Shadow was still looking at the sky with his back Mordred says the darkened sky heralds the end and hears the nascent monarch’s cry to Mordred, Shadow's powerful magic began to gather in his right hand.

His magic finally gathers in his obsidian sword, spiraling through the air and drawing an elaborate pattern over the weapon’s blade. Mordred could only be shocked by his magic, which no human could have possibly possessed this much massive power before Shadow kills him with his Atomic attack.

### Post-Mortem

Following his death, Mordred's severed head is teleported to [Earth](Earth.md "Earth") where it is found by Akira Nishino. The scientist intended to use it in his experiments but was assassinated by [Yuuka](Yuuka.md "Yuuka") before he could do so. Sometime later, [Beta](Beta.md "Beta") recovered Mordred's head, after his master Shadow resolved Akane Nishino's magical disorder, and then Beta threw Mordred's head to the ground, destroying it in the process, to reopen the Black Rose, and thus, both Shadow and Beta returned again to the other world, taking Akane Nishino with them under cover, as a "special subject".

## References

1. Episode 20
