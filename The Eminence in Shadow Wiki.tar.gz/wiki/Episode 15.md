# Episode 15

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2015](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2015)

## The Strongest Weakest Man

### Kana

最強最弱の男

### Romaji

Saikyō Saijaku no Otoko

## Special Title

### English

The Eminence in Shadow Wants To Ride the Big Wave!

### Kana

陰の実力者はビッグウェーブに乗っかりたい！

### Romaji

Kage no Jitsuryokusha wa Bigguwēbu ni Nokkaritai!

## Episode Information

### Season

1

### Episode

15

### Air Date

January 11, 2023 JP
April 3, 2023 EN

### Adapted From

Volume 2 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Kanichi Katou

### Storyboard

Susumu Nishizawa

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Epsilon ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Your Lie, Your Wish | Unseen Intentions |

The Strongest Weakest Man (最強最弱の男, Saikyō Saijaku no Otoko[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the fifteenth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Only the strongest warriors can advance in the prestigious Bushin Festival, but one contestant proves himself a feeble and mundane man with no talent. Why is he competing?[[1]](#cite_note-1)

ブシン祭の開催が迫り、シドは謎の実力者として大会に現れる妄想に胸躍らせていた。その一環として見るからに弱そうな魔剣士ジミナ・セーネンに変装。街で騒動に巻き込まれる。[[2]](#cite_note-2)

## Summary

At noon atop the clocktower, Cid uses his eminent sense to hear various background extras give exposition regarding the Bushin Festival, reminding Cid of what he must do. As the Festival is an international and interracial contest of strength, Cid must accomplish one of his bucket list's top items, to act weak but defeat his opponents to shock the crowd with how strong he is. Cid aims to play the dark horse that wins while being underestimated, aiming to ride the big wave that has come to town.

At Mitsugoshi HQ, [Gamma](Gamma.md "Gamma") heads to the throne room and is met by a surprise visit from Cid. After getting cleaned by her attendants following another stumble, Cid asks her to help him with a disguise to enter the Bunshin Festival, to which Cid states he can't tell her when she asks why. Once her staff amass a trove of items, [Eta](Eta.md "Eta") readies a machine as Gamma explains the process of how to create a realistic face mask shaped however he would want it. After Gamma applies the special slime gel, [Nu](Nu.md "Nu") shows him pictures of different faces catalogued, and Cid notes he wants to look weak much to her confusion, as Eta is carted off. Gamma suggests "Mundane Mann" as he was a lazy Dark Knight with no skill, disowned by his noble parents, who died an remarkable and undiscovered death. Enjoying his backstory and similar bone structure, Cid agrees, and [Chi](Chi.md "Chi") powers the machine via a pedal generator to be turned into Mundane. With his new face applied, Cid changes his posture to look like his new character, and alters his voice to be unrecognizable to his real self. Gamma offers a variety of cheap second-hand items to dress his new persona with, but trips on nothing and falls to the bottom of the stairs with another nosebleed.

In the capital, other contestants spot Annerose Nichtsehen, who summoned [an ancient warrior](Borg.md "Borg") at the Goddess's Trial. She sees Cid as "Mundane" with cheap gear and a sickly body, advising him that as he is an amateur he should not participate in the Bunshin Festival. Mundane tells her to not judge a book by its cover and that he doesn't need her help. He walks away smiling that his disguise works. He is immediately accosted by [Quinton](Quinton.md "Quinton"), telling him to take her advice as he fought in several Bunshin Festivals, advising weaklings like Mundane how it's better if he just go home. Cid plays his Mundane persona to state that he is at least stronger than Quinton, angering him to pick up and brutalize him into an alley. "Mundane" still states Quinton is weak, angering him into a raging goon, as Cid contemplates how the melee combat of the world is unsophisticated, thinking of numerous counters to Quinton's assault. But as he has no intention of fighting just yet, he lets Quinton beat him up.

Although Quinton talks a big game, Annerose admonishes him to stop lest she intervene, so Quinton ceases and leaves. She apologizes to Mundane, and while she could have stopped the fight sooner, she decided to let Quinton beat him up so that he could quit and not get injured in the festival. As Mundane comments he's fine, having tasted his blood after some time, Annerose is surprised that he isn't hurt. She introduces herself and Cid introduces his psuedonym, "Mundane Mann." Later, Cid stands in line to apply as Mundane, muttering to himself as he gestures theatrically as he continues on about his plan to himself before answering his call to apply.

Cid meets with Skel Etal for lunch at MagRonald's, as Skel wants to win some money through betting on tournament outcomes. Explaining that the preliminaries are first and only the strongest will proceed to the main tournament, Skel tells Cid the favorites to win. However, Cid is deep in thought as he wants to show his powers only at the end, wondering how to defeat the stronger opponents without revealing his powers. Asking Skel the most likely to win, Iris Midgar is the favorite as she's looking to be the first repeat winner in ages, but there's also Rose with buzz being she might be the first Bushin champion from Oriana Kingdom. As Skel requests funds for wagers, Cid distracts him with a souvenir from [Lindwurm](Lindwurm.md "Lindwurm"), countering that Skel doesn't need money if he's so sure he'll win; Cid orders three sandwiches to go.

Outside, Cid thinks over the fights with the favorites and how he'd have to win those before he has a surprise encounter with Rose. Seeing he went to MagRonald's Tuna King shop, she explains she went with Alexia and [Natsume Kafka](Beta.md "Beta") the other day for some good food. Rose discloses that she is going to meet her father as he will be introducing her fiancé, Perv Asshat; a name both acknowledge is cringe. Rose explains that she is princess to the land of art and culture, but disappointed the expectations of many upon deciding to become a knight, following her inspiration after a young boy rescued her as a child, and was inspired by him to pick up the sword. She still refuses to abandon her ideals and that may cause her to betray more people, so she asks Cid if he will keep believing in her and Cid affirms he will. Rose thanks him, and Cid gifts her a Tuna King sandwich as she leaves, advising her to relax a little.

During the next morning's prelim match, Cid and Skel are watching as Skel explains that he is gathering data to make better bets. He continues to explain how he can calculate the odds, but still needs some money to make the odds 100%. Cid ignores him, but Goldy Gilded shows behind Skel, having found him fascinating as Skel excitedly recognizes him. Goldy explains he also tabulates data to help him win. When the next match is Gonzales Machom versus Mundane Mann, Cid leaves needing to take a dump, and Goldoh analyzes the fight to explains how you can get general idea of a fighter's strength beforehand. As Gonzales has a glint in his eyes, an arrogant smile, and large figure from heavy musculature, this means he is an experienced tough fighter, and Goldy quantifies his battle power at 1,364. Conversely, Goldy sees Mundane Mann as astoundingly inept, wondering how he even made it to the third round. With his weak face, build, and aura, Goldy tabulates his battle power at a measly 33.

Although Goldoh expects Gonzales to win in less than a second, and Skel is impressed with the analysis, Gonzales falls down the second after the fight starts and onlookers assume Gonzales tripped and fell. Thus, Mundane is announced as winner, which disappoints the crowd, while Annerose saw how Mundane landed two quick punches on Gonzales's chin. Despite the wrong outcome, Goldy acts like he "knew" this outcome of Mundane winning and tells Skel that you can win by betting on those with higher battle power or find the weak ones to bet on their opponents. In tomorrow's fourth match, Mundane will be facing Goldy, who leaves just as Cid returns and Skel begs him to give over all of his life's savings so bet on Goldy, but Cid refuses. Looking into the crowd, Cid smiles noticing Annerose's reaction saying she thinks Mundane's win wasn't a fluke; as Cid continues to refuse Skel's begging for money.

Early the following morning, Skel fervently knocks on Cid's door and shows him the newspaper stating that Rose stabbed her fiancé, Perv Asshat, before she ran away. Staring at her picture in the newspaper, Cid asks himself why would she do it.

## Characters

- Cid Kagenou
- [Gamma](Gamma.md "Gamma")
- [Eta](Eta.md "Eta")
- [Chi](Chi.md "Chi")
- [Omega](Omega.md "Omega")
- [Nu](Nu.md "Nu")
- Mundane Mann (Mentioned)
- Annerose Nichtsehen
- [Quinton](Quinton.md "Quinton")
- Skel Etal
- Rose Oriana
- Alexia Midgar (Cameo)
- [Beta](Beta.md "Beta") (Cameo)
- Raphael Geerk Oriana (Mentioned)
- Perv Asshat (Mentioned)
- Goldy Gilded
- Gonzales Machom

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第15話予告≪ノーマルVer.≫「最強最弱の男」

TVアニメ『陰の実力者になりたくて！』第15話予告≪スペシャルVer.≫「陰の実力者はビッグウェーブに乗っかりたい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e015>
2. <https://shadow-garden.jp/1st/story/#story15>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • **Episode 15** • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
