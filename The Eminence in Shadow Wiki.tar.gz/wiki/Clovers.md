# Clovers

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Clovers](https://the-eminence-in-shadow.fandom.com/wiki/Clovers)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Clovers?action=edit).

## Clovers

### Japanese

四（よ）つ葉（は）

### Romaji

Yotsuba

## General Information

### Leader(s)

[Gettan](Gettan.md "Gettan") (Founder & Superior)
Garter Kikuchi (Employer)
Leaf One

### Status

Defunct

### Affiliates

Garter Corporation

### Base of Operation

Midgar Kingdom

## Debut

### Web Novel

Chapter 119

### Light Novel

Volume 3

### Manga

Chapter 34

### Anime

Episode 24

Clovers (四（よ）つ葉（は）, Yotsuba[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) were a four-man team formed from the most capable members within the Garter Corporation's personal army.[[1]](#cite_note-V3C5-1)

## Overview

Clovers numbered only four people and had been mobilized in response to Mitsugoshi Company's rapid expansion (namely, sabotaging the distribution chain, attacking travelling salesman, and conduct a raid on the supply carriage carriers to Mitsugoshi).

They were tasked by their superior, [Gettan](Gettan.md "Gettan") to infiltrate the Mitsugoshi's headquarters. Ultimately, their group efforts failed, as each of them met their demise.

## History

Clovers was a personal mercenary group created by [Gettan](Gettan.md "Gettan") and regarded as being the strongest enforcement group within the Garter Corporation’s employ, which are currently affiliated with Major Corporate Alliance.[CITATION NEEDED]

They are operating in Midgar Kingdom by trying to disrupt Mitsugoshi Company's business progress on the market.[CITATION NEEDED]

## Strength

Clovers are a powerful group consisting of individuals are capable of bringing down an entire nation's army.[CITATION NEEDED]

According to [Gettan](Gettan.md "Gettan"), all members of the Clovers were powerful dark knight to consider them as masters, even though their skills wouldn't be good enough to enter the Cult of Diablos's upper echelons.[CITATION NEEDED]

## Membership

## Chronology

### Great Trading Company Conflict

After receiving the news that one of the Clovers had died during a mission, Gettan dispatched the remaining Clovers to raid Mitsugoshi's headquarters with the intention of stealing their money and manufacturing details.[[1]](#cite_note-V3C5-1)

Being in the middle of an infiltration during a raid on Mitsugoshi's base, the Clovers members have been given their respective tasks and then split up in carrying out the mission. Leaf One's task is to collect secret documents alone, then Leaf Two and his men will carry out sabotage, while Leaf Three will loot and kidnap important personnel.[CITATION NEEDED]

However, their mission failed because the Clovers along with Garter's private troops and rear guard did not return after they were all killed by Shadow Garden's high ranking members.[CITATION NEEDED]

## Known Members

- Leaf One
- Leaf Two
- Leaf Three
- [Leaf Four](Zabra.md "Zabra")

## Trivia

- Clovers are reference to the quatrefoil mutation of the common clover which is an omen and symbol of good luck.
  - But ironically does not refer to all the Clovers members, because their luck soon ran out the moment, they tried messing with Mitsugoshi Company which is the front of Shadow Garden.
- The name of the Clovers group members each call themselves with a code name for those who can match the Four-Leaf Clover theme.
- In the manga, all four members in the Clovers have facial tattoos as a sign of rank according to their number.[[2]](#cite_note-2)[MANGA ONLY]

## References

1. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
2. Manga Volume 9 - Chapter 35

## Site Navigation
