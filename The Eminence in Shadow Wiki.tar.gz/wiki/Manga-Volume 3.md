# Manga/Volume 3

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%203](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%203)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_3?action=edit).

## Manga Volume 3

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041093269

### ISBN EN

ISBN 978-1975325220

### Release Date

June 25, 2020 JP
March 22, 2022 EN

## Volume Information

### Pages

160 JP
162 EN

### Chapters

4

Publication Order

| Previous | Next |
| --- | --- |
| Volume 2 | Volume 4 |

This is the third volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

The Midgar Academy for Dark Knights is occupied by terrorists posing as the Shadow Garden! Faced with a stressful, high-intensity hostage situation…Cid is having the time of his life! Whether it’s being the first student struck down as an example or swooping in dramatically from the rooftops in the nick of time, there’s no better opportunity for him to show off his prowess as a shadowy mastermind![[1]](#cite_note-1)

「さあ、来い　モブ式奥義はまだ四十六も残っているぞ――！」
異世界に転生し「陰の実力者」設定を楽しむシド。学園が「シャドウガーデン」を騙る謎の集団に占拠され、生徒会長・ローズをかばって斬られてしまうが――!?強大な力と重度の勘違いで切り抜ける最強譚、第３弾！[[2]](#cite_note-2)

## Summary

### Midgar Academy Terrorism

## Chapters

- Episode 9
- Episode 10
- Episode 11
- Episode 12

## Characters

:   In order of appearance:

- Alexia Midgar
- Cid Kagenou
- Rose Oriana (Debut)
- Sherry Barnett
- Lutheran Barnett
- Po Tato
- Skel Etal
- [Glen](Glen.md "Glen")
- Marco Granger (Debut)
- [Rex](Rex.md "Rex") (Debut)
- [Nu](Nu.md "Nu")
- Lukreia (Mentioned)
- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Delta](Delta.md "Delta")
- [Gamma](Gamma.md "Gamma")

## References

1. [The Eminence in Shadow, Vol. 3 (manga). YenPress](https://yenpress.com/9781975325220/the-eminence-in-shadow-vol-3-manga/)
2. [The Eminence in Shadow (3). Kadokawa](https://www.kadokawa.co.jp/product/321912000561/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • **Volume 3** • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
