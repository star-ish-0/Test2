# Episode 11

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2011](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2011)

## The Goddess' Trial

### Kana

女神の試練

### Romaji

Megami no Shiren

## Special Title

### English

The Eminence in Shadow Wants to Actually Do Something Like an Eminence in Shadow!

### Kana

陰の実力者は陰の実力者っぽいことをしたい！

### Romaji

Kage no Jitsuryokusha wa Kage no Jitsuryokusha-poi Koto wo Shitai!

## Episode Information

### Season

1

### Episode

11

### Air Date

December 14, 2022 JP
March 6, 2023 EN

### Adapted From

Volume 2 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Mio Inoue

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Gamma ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| The Sacred Land, City of Deception | The Truth Within the Memories |

The Goddess' Trial (女神の試練, Megami no Shiren[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the eleventh episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

The curtain rises on the Goddess’ Trial. When Cid is unwittingly called into the arena, he transforms into Shadow and faces none other than Aurora, the Witch of Calamity.[[1]](#cite_note-1)

古代の戦士を蘇らせて戦う『女神の試練』が開幕。闘技場に駆り出されたシドは、シャドウに変身し、どさくさに紛れて参加。対戦相手として蘇ったのは、災厄の魔女アウロラだった。[[2]](#cite_note-2)

## Summary

At a Mitsugoshi hotel in [Lindwurm](Lindwurm.md "Lindwurm"), Cid recounts how he has things he likes and things he doesn't like, and one thing he likes is hot springs. Unexpectedly, Alexia is already there, and while initially flustered, she sees he hasn't looked at her and calms down to apologize for slashing him. As Cid wonders why she is in Lindwurm, Alexia explains that she is a special guest for the Goddess' Trial. Alexia asks Cid the same question, as he answers a friend invited him telling him there was a fun event, and guesses the Goddess' Trial is the event.

Alexia elaborates how the Goddess's Trial is an annual fighting ritual, where ancient warriors are awakened from the Sanctuary to compete against modern challenges. Hearing Cid's curiosity, Alexia tells him that one needs to request participation in advance and that the ancient warriors only answer the call of the few challengers they deem worthy. As hundreds test their luck annually, only about ten actually get to battle, as the Wandering Swordsman [Venom](Venom.md "Venom") managed to summon [Olivier](Olivier.md "Olivier") a few years ago, but still lost. Alexia continues how she isn't there to fight but to audit the archbishop, who was found murdered. Alexia tries to tease more information is classified and recommends Cid join the Crimson Knights so she can tell him more about it, but Cid isn't interested.

Adding some stretches and posturing herself, Alexia expected Cid to be ogling her, but finds he isn't even looking. Cid notes that he tends to not look at people at hot springs, so that everyone feels more comfortable while bathing. Although he would appreciate if she stops glancing at his "Excalibur," Alexia retorts that "Excalibur" is more of a mere "worm." However, Cid stands up to state that she shouldn't judge a book by its cover, shocking Alexia and retorting that what she thought was a worm was a sword still contained in its sheath. As Alexia struggles to wonder what he means, Cid exits the bath and slaps himself with the towel, espousing that when the holy sword is unsheathed, its sparkling blade is set free to sets off on a quest. Cid leaves Alexia puzzled and alone, standing soon after to replicate the towel trick he demonstrated.

The new acting archbishop, Jack Nelson, cancels the audit with Alexia by explaining that she was there investigating the previous archbishop, and now the Church will be investigating his murder. Alexia leaves angered, knowing that the key evidence will be destroyed before she can receive approval from the King. At Lindwurm's colosseum, the Goddess' Trial is commencing, with Rose and Alexia seated next to [Beta](Beta.md "Beta") in her Natsume Kafta personality. Seeing her person and acting, Alexia is annoyed at how well liked Natsume is and believes those like her are the most corrupt on the inside. Concurrently, Beta gets cheers from the crowd with her attire and looks at Alexia with a snear of superiority, secretly annoyed how she used Cid and also believes Alexia is corrupt on the inside. As Natsume waves to the crowd, Alexia stomps on her foot while smiling like nothing happened, fueling a new antagonism for the two.

With the welcome ceremony complete, Nelson activates a hidden switch to activate the barrier. Once the Trial starts, the first contender is from Oriana Kingdom: Toppe Batterius. Two people from the audience sitting behind Cid explain that you can't leave the barrier around the arena until either a contestant or summoned warrior is defeated. With a hefty participation fee and the likelihood you may even get killed, it seems worth it should you win and get a commemorative medal, which will easily let you join any knight order in the world. Although Toppe challenges a warrior, none answer and his turn is over. After him comes Neks Tinline from the Midgar Knight Order, but none answer him as well. Cid really wants to go with Shadow and show his skills, making people wonder who he is. Next, Stihl-Aint Hapnin from the [Laugus](Laugus.md "Laugus") Vigilante Corps comes forth, but he and many more subsequent challengers are unable to summon anyone. Cid contemplates playing a weakling to win a tournament undetected, before realizing he hasn't seen [Alpha](Alpha.md "Alpha") since he arrived. Across Lindwurm, Shadow Garden members infiltrate the populace and survey the city in preparation for their mission. Come sunset, Alpha rendezvous with [Epsilon](Epsilon.md "Epsilon"), their time is now and they move.

After nightfall, Cid is getting bored and hopes the trial ends soon, as the only contender to summon anybody was Annerose. In that moment, the announcer reveals the next challenger is from the Midgar Academy for Dark Knights, Cid Kagenou. The bored Cid initially dismisses the name sounding like a background character, before he realizes that's his name. As Nelson is impressed a student would make the attempt, Natsume is befuddled in surprise, while Rose is revealed to have done so to show off Cid's worth. Cid wonders how he should come out, considering the ancient warriors are usually matching the strength of the challenger, possibly revealing he is quite strong. But if he refuses and if the Academy finds out, he may get expelled and wonders what his sister would say. So, Cid decides to use option three.

As Cid is a no show and Nelson isn't surprised, Cid creates a distracting light above the arena and then jumps in as Shadow. Cid elects option three and confuse the matter, making people forget about Cid as their fixated-on Shadow. As Nelson makes preparations to apprehend him, Shadow channels his magic and the Sanctuary automatically conjures a door. A mysterious woman then appears after Shadow, shocking Jack as he didn't activate any summons, and Natsume recognizes the woman as [Aurora](Aurora.md "Aurora"), the Witch of Calamity. However, with minimal information about her due to the chaos and destruction that came after her, Natsume asks Jack if he disclose more about Aurora. Falling for her feminine wiles, Jack states Aurora's name is known to a select few, even in the church. Nelson finished that Shadow is unfortunate to summon her, as she is the most powerful witch in all of history. Alexia disagrees, stating that if the Sanctuary summoned Aurora as a worthy opponent, then Shadow's powers must have reached the level of one capable of destroying the world.

As Shadow and Aurora face each other, the smile in excitement, with Shadow seeing she feels a battle is a conversation between opponents. Aurora does a slight dance motion, conjuring streams of blood to attack Shadow, astonishing the crowd as they both enjoy their battle. While Nelson maintains Shadow is at a loss, Natsume claims Aurora has yet to land a hit with her spears, asking Alexia for confirmation. Alexia does corroborate, noting how no ordinary Dark Knight can manage against her, but Shadow is still observing her and dodging her attacks. As Shadow is enjoying himself, thankful "Violet" has given him the first decent conversation he's had in a good long while, he sees that she is restricted from using her full power. A shame she's hindered, Shadow then defeats Aurora with a single slash, much to her own joy fighting him before disappearing into light. Shadow wishes he could have fought her at her full strength before leaving, shocking everyone that he won. But to everyone's surprise, Nelson included, the barrier then breaks and a magic door appears in the middle of the arena. A magic seal the expands across the whole of the city, with Alpha and [Delta](Delta.md "Delta") observing the spell.

## Characters

- Cid Kagenou
- Alexia Midgar
- [Drake](Drake.md "Drake") (Mentioned)
- Nelson
- Klaus Midgar (Mentioned)
- [Beta](Beta.md "Beta")
- Rose Oriana
- Toppe Batterius
- Neks Tinline
- Stihl-Aint Hapnin
- [Chi](Chi.md "Chi")
- [Omega](Omega.md "Omega")
- [Epsilon](Epsilon.md "Epsilon")
- [Alpha](Alpha.md "Alpha")
- Annerose Nichtsehen (Cameo)
- [Borg](Borg.md "Borg") (Cameo)
- Claire Kagenou (Vision)
- [Venom](Venom.md "Venom")
- [Aurora](Aurora.md "Aurora")
- [Delta](Delta.md "Delta")

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第11話予告≪ノーマルVer.≫「女神の試練」

TVアニメ『陰の実力者になりたくて！』第11話予告≪スペシャルVer.≫「陰の実力者は陰の実力者っぽいことをしたい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e011>
2. <https://shadow-garden.jp/1st/story/#story11>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • **Episode 11** • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
