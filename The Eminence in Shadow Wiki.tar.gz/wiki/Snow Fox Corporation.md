# Snow Fox Corporation

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Snow%20Fox%20Corporation](https://the-eminence-in-shadow.fandom.com/wiki/Snow%20Fox%20Corporation)

## Snow Fox Corporation

### Japanese

雪狐（ゆききつね） 商会（しょうかい）

### Romaji

Yukikitsune Shōkai

## General Information

### Leader(s)

[Yukime](Yukime.md "Yukime") [Founder & President]

### Status

Active

### Affiliates

White Tower
Shadow Garden

### Base of Operation

Lawless City

## Debut

### Web Novel

Chapter 114

### Light Novel

Volume 3

### Manga

Chapter 34

Snow Fox Corporation (雪狐（ゆききつね） 商会（しょうかい）, Yukikitsune Shōkai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a company founded by [Yukime](Yukime.md "Yukime") that operates outside the Lawless City. The company gained notoriety for blatantly plagiarizing and selling knock-offs based on Mitsugoshi's products.[[1]](#cite_note-V3C4-1)

## History

The company was founded by Yukime after she became the ruler of the White Tower, serving as a legitimate business that operates out of the Lawless City. By capitalizing on the popularity of Mitsugoshi's products among the aristocracy, the company began plagiarizing their designs by producing knock-offs despite being unable to replicate their quality.[[1]](#cite_note-V3C4-1)

## Chronology

## Known Personnel

### Founder & President

- [Yukime](Yukime.md "Yukime")

### Employees

- [Natsu](Natsu.md "Natsu")
- [Kana](Kana.md "Kana")

### Associates

- John Smith

## Trivia

## References

1. Volume 3 Chapter 4: I’ll Destroy It All and Start from Scratch!

## Site Navigation
