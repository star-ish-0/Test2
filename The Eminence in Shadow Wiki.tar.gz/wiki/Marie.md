# Marie

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Marie](https://the-eminence-in-shadow.fandom.com/wiki/Marie)

## Marie

### Japanese

マリー

### Romaji

Marī

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

18

### Height

Unknown

### Hair Color

Purplish Red

### Eye Color

Purplish Red (Novel)
Green (Anime)

### Birthday

September 25

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Lawless City Prostitute (Formerly)
Bartender

### Affiliation

Snow Fox Corporation (Formerly)
Oriana Kingdom (Citizen)

## Debut

### Web Novel

Chapter 94

### Light Novel

Volume 3

### Manga

Chapter 28

### Anime

Episode 21

## Portrayal

### Japanese

[M.A.O](https://en.wikipedia.org/wiki/Mao_Ichimichi "wp:Mao Ichimichi")

### English

[Emi Lo](https://en.wikipedia.org/wiki/Emi_Lo "wp:Emi Lo")

Marie (マリー, Marī[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a former prostitute from the Lawless City. After Shadow saved her during the "Red Moon Incident", she fled from the city and is currently a citizen of the Oriana Kingdom, where she now owns a tavern and manages it as a bartender.

## Appearance

Marie is a very beautiful young girl, with beige hair and green eyes and having white skin. In her second meeting with Shadow, she wore black lingerie in contrast to the color of her skin.

## Personality

Marie has shown to be professional if a little naive. Despite being one of Lawless City's leading prostitutes, she's actually a sweet girl, although she does hope one day she could leave the life of a prostitute. Unlike most people, Marie is one of the few people who saw Shadow as a hero.

## Chronology

### Background

When Marie reached the age of 13, she was sold to become a prostitute from the Lawless City and spent five years working in a brothel until became one of the leading prostitutes in the red-light district. Although she’s made a name for herself among the red-light district’s sex workers, she isn’t at the top of the pack, as her madam once told her that she could become number one if she set her mind to it. But instead, Marie had been considering leaving her life as a prostitute.

### Red Moon Incident

Light Novel/Manga
During the Red Moon incident, Marie is one of many attacked by the [Ghouls](Ghouls.md "Ghouls") and [Vampire](Vampire.md "Vampire"). She survived her first encounter with them after Shadow slaughtered all of the Ghouls, saving most of her co-workers. Shadow also gave her a warning about the starting rampage as the time of the "Red Moon" was near before he leaves. While her senior informs her that Shadow was a wanted criminal, Marie didn't believe it and she thanks him while she looks up uneasily at the red moon.

As the crisis worsened, she was saved by Shadow a second time and after he advised her to leave the city, Marie finally decided to gather all her belongings and used the opportunity to flee the city. Earning her freedom once more, Marie thought about repaying Shadow for saving her life one day.[[1]](#cite_note-V3C1-1)

Anime/Game

### Oriana's "Black Rose" Wedding Chaos

Marie would go to the Oriana Kingdom and set up a tavern there at the First Fort Stronghold town, where she would garner the lust of multiple men. While servicing a young teenage boy, a group of Oriana soldiers barged into her tavern demanding Marie for her money, otherwise they would have her sleep with them as an alternative payment. Marie offered what little money she had left in order to protect the boy from their wrath when he tried to defend her.

A while later, Marie's worry over making her payments were dashed when she heard her windows being opened. She looked out and found Shadow, who left before Marie could respond and she noticed the money she offered to the soldiers returned to her on the ground. Crying tears of joy, Marie realized that Shadow had looked out for her yet again.[[2]](#cite_note-V4CP-2)

## Powers & Abilities

Marie doesn't display any combat capabilities nor magical abilities, making her dangerously vulnerable. However, she has shown herself a capable businesswoman, saving the funding she needed to escape life as a prostitute and opened her own inn after becoming an Oriana citizen.

### Charms

Her life as a prostitute allowed her to be mentally prepared to offer herself to men and how to deal with unruly customers. When Marie opens her tavern, her charms as a popular prostitute remain seductive, as it is obvious that the customers are more interested in her than buying drinks.

## Relationships

### [Yukime](Yukime.md "Yukime")

As Marie's madam, Yukime held her contract when she was sold to the brothel. However, instead of abusing Marie for profit, Yukime took great care and attention to ensure Marie was healthy and fit, especially since Marie was among her top earners. When the Red Moon incident forced Marie to flee, Yukime did not pursue her nor did she issue a bounty of return, as she allowed Marie's freedom being satisfied by Shadow's protection of all her girls during the incident.

### Fellow prostitutes

Having been among them for five years, Marie has a standing history with the girls of the red-light district. This is in part due to their protections under Yukime, thus allowing them to befriend one another and rely on each other to better survive their conditions.

### Cid Kagenou / Shadow

The two encountered one another at the Lawless City when the Red Moon incident occurred, as Shadow had slain the Ghoul that attempted to attack her, saving her life. Even though she thought Shadow was really scary, she didn’t see him as a villain. What she did feel from him was that he possessed a powerful will.

Unlike her fellow prostitutes who viewed Shadow as a threat from the wanted posters, Marie saw him as the only one protecting them from the Ghouls and Vampires. Marie is extremely grateful towards Shadow for saving her life on multiple occasions, implying she developed romantic feelings for him.

After leaving her old life and starting a business running a tavern, Marie was helped again as Shadow returned her money stolen by soldiers. Grateful once more, Marie only wished to one day repay Shadow for what he'd done for her.

## Trivia

- In the Anime and Game, Marie as a prostitute in her room had the money she was saving and the book "Kage no Jitsuryokusha", written by [Natsume Kafka](Beta.md "Beta") in her drawer.

## References

1. Volume 3 Chapter 1: Lawless City Bandit Hunting!
2. Volume 4 Prologue: It's Time for a War in the Oriana Kingdom!

## Image Gallery

## Site Navigation
