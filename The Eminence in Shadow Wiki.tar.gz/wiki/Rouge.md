# Rouge

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Rouge](https://the-eminence-in-shadow.fandom.com/wiki/Rouge)

## Rouge

### Japanese

ルージュ

### Romaji

Rūju

## Characteristics

### Race

Human

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Honey Yellow

### Eye Color

Honey Yellow

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Rose Oriana (Descendant)

## Professional Information

### Occupation

Hero

### Affiliation

The Heroes
Cult of Diablos

## Debut

### Game

Apocrypha: Chapter 2 Part 3

Rouge (ルージュ, Rūju[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the Heroes that took part in the battle against the [Demon Diablos](Aurora.md "Aurora"). She is the ancestor of Rose Oriana.

## Appearance

## Personality

## Chronology

### Requiem for Scattered Shadows

## Powers & Abilities

## Relationships

### [Olivier](Olivier.md "Olivier")

### [Lily](Lily.md "Lily")

### [Freya](Freya.md "Freya")

### [Duet](Duet.md "Duet")

### [Pente](Pente.md "Pente")

### [Nonna](Nonna.md "Nonna")

### [Sarasa](Sarasa.md "Sarasa")

## Image Gallery

## Trivia

## References

## Site Navigation
