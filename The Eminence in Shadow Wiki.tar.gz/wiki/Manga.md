# Manga

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga](https://the-eminence-in-shadow.fandom.com/wiki/Manga)

The manga adaptation of the original The Eminence in Shadow Light Novel is published by [Kadokawa Shoten](https://en.wikipedia.org/wiki/Kadokawa_Shoten "wp:Kadokawa Shoten") in Japanese and serialized in Comp Ace magazine, licensed in English by [Yen Press](https://yenpress.com/9781975325183/the-eminence-in-shadow-vol-1-manga).

The original story is written by Aizawa Daisuke. The original character design is illustrated by Touzai, and the manga is drawn by SAKANO Anri.

## Synopsis

Cid Kagenou has a dream. Not of being some typical protagonist or the Final Boss-he has his eyes set on becoming a hidden mastermind working in the shadows! Now that he’s been reborn in another world, Cid has been hard at work building the perfect stage to act out his long-desired role. The only issue? His imaginary adversaries and plot devices seem to actually exist in this new realm…and he alone is left in the dark![[1]](#cite_note-1)

## Volumes

- [Japanese](#)
- [English](#)

Volume 1

Volume 2

Volume 3

Volume 4

Volume 5

Volume 6

Volume 7

Volume 8

Volume 9

Volume 10

Volume 11

Volume 12

Volume 13

Volume 14

Volume 15

Volume 16

Volume 17

Volume 18

Volume 1

Volume 2

Volume 3

Volume 4

Volume 5

Volume 6

Volume 7

Volume 8

Volume 9

Volume 10

Volume 11

Volume 12

Volume 13

Volume 14

Volume 15

## Promotional Videos

『陰の実力者になりたくて！』コミックス8〜10巻連続刊行CM（CV：山下誠一郎）

## References

1. [Yen Press: The Eminence in Shadow, Vol. 1 (Manga)](https://yenpress.com/9781975325183/the-eminence-in-shadow-vol-1-manga)
