# Butcher

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Butcher](https://the-eminence-in-shadow.fandom.com/wiki/Butcher)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Butcher?action=edit).

## Butcher

### Japanese

ブッチャー

### Romaji

Butchā

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Affiliation

Thirteen Nightblades

## Debut

### Light Novel

Volume 6

### Manga

Chapter 72.1

Butcher (ブッチャー, Butchā[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), was an associate of the Thirteen Nightblades who was hired by Korrupt White to fight and kill Jack The Ripper however he failed to do so as he was instantly kicked in the face by Jack The Ripper killing him in an instant.

## Appearance

## Personality

## Chronology

### Bloody Midgar Serial Murder Terror

## Relationships

## Powers & Abilities

## Trivia

## References

## Site Navigation
