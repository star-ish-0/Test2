# Haitani

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Haitani](https://the-eminence-in-shadow.fandom.com/wiki/Haitani)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Haitani

### Japanese

灰谷（はいたに）

### Romaji

Haitani

## Characteristics

### Race

[Human](Human.md "Human") (Earthling)

### Gender

Male

### Age

Possibly in 30s

### Height

Unknown

### Hair Color

Brown

### Eye Color

Brown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Knight Commander

### Affiliation

[Messiah](Messiah.md "Messiah")

## Debut

### Light Novel

Volume 4

### Manga

Chapter 51

Haitani (灰谷（はいたに）, Haitani[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the Knight Commander of the human settlement [Messiah](Messiah.md "Messiah") in post-apocalyptic Japan.

## Appearance

Haitani appeared to be a man possibly in his 30s with brown hair and tanned skin from the side effects of awakening. He dons over a grey business suit with a white shirt and red tie.

## Personality

As Knight Commander of the Messiah, he takes a professional approach and manages other members on a daily basis.

## Chronology

### Background

Haitani started out as a corporate big shot before quitting and starting a business of his own. After Japan became ruin because of a Magical Beasts that suddenly appear 3 years ago, he became a knight order commander from [Messiah](Messiah.md "Messiah").[[1]](#cite_note-V4C5-1)

### Return to Earth

Haitani would first be introduced in emergency meeting he held regarding dozens of mangled magical beasts and the destroyed Nishino Elementary where he showed photos of. He noted that no one in the area was capable of pulling such feats. Yuudai Saejima was in denial and demanded proof, while everyone deduced that the Original Knight was responsible much to Akane's horror. However, Haitani concluded that there was another Knight of her caliber before the meeting came to a halt due to a magical beast attack. During the attack, Haitani tried to stop Akane from sacrificing herself and would almost be too late before the Black Knight appeared to save her while killing off the remaining beasts. Haitani concluded that the Black Knight was responsible for destroying the elementary as well as the mangling of multiple magical beasts and hoped that he would not be their enemy.[[1]](#cite_note-V4C5-1)

The following day, Yuudai would be discovered dead with the autopsy indicated that he was murdered. [Yuuka](Yuuka.md "Yuuka") accused Akane of the murder and ordered her to stay in her room on behalf of Haitani who was investigating the murder. Minoru stepped in to Akane's defense and point out that the slashed-up corpse was sloppy and Akane wouldn't have done it. Later on, Minoru found conclusive evidence of Akane's innocence and the wary Yuuka attempted to have him assassinated. This would fail when Minoru revealed himself as the Shadow and kill off the assassins just after he heard the alarmed that the Stampede attack has arrived.[[2]](#cite_note-V4C6-2)

During the Stampede, everything would unravel with the murder of Akira Nishino, [Natsume](Beta.md "Beta") revealing herself, and Haitani and his squad overwhelmed. Haitani was overwhelmed to the point that he concluded the Stampede was a losing battle and decided to prepare the evacuation order of the Messiah's habitants. This order would be proven redundant as the Black Knight appeared once more to wipe off the remaining beasts. Upon witnessing the knight's atomic attack, Haitani would open the gates to where Akane and Yuuka were and realized he's terrified of his overwhelming strength. He asked why the Black Knight is at the Messiah and what he wanted with the expectation of being ignored. To his surprise, the Black Knight gave Haitani and the other members an answer they could not understand. When Haitani ask who he was, Black Knight replied that his name is Shadow until he left, pondering Haitani to what he meant. After Shadow and Beta returned to the Other World alongside Akane, Haitani and the remaining habitants of the Messiah were left to fend for themselves with their fates being ultimately unknown due to Yuuka's sabotage and Akira's death.[[3]](#cite_note-V4E-3)

## Powers & Abilities

Three years prior to the Invasion by magical beasts, Haitani was a corporate big shot before starting his own business. He awakens early on and has saved the Messiah on more than a few occasions.

### Weapons and Equipment

Like many Knights of the Messiah, Haitani carries a katana imbued with his magic in the battlefield. In the manga, he dual wields a katana and kodachi. two very traditional Japanese weapons also imbued with his magic.

## Relationships

### [Messiah](Messiah.md "Messiah")/[Arcadia](Arcadia.md "Arcadia")

#### Akane Nishino

Aware of her identity of the Original Knight, He deduced that there was another knight capable of her abilities during their meeting.[[1]](#cite_note-V4C5-1) He was also skeptical enough to hold judgement off of Akane and investigate when she was accused of Yuudai's death.[[2]](#cite_note-V4C6-2) Haitani seems to be the one of few people in the Messiah that Akane genuinely respects.

#### Yuudai Saejima

Commanding officer of Yuudai and the Messiah, Haitani would give orders for him follow. However, Haitani was unaware that he was a mole for the Alliance even after his death.[[2]](#cite_note-V4C6-2)

#### [Yuuka](Yuuka.md "Yuuka")

Haitani was unaware that she was the spy who was sabotaging the Messiah and responsible for the murder of Yuudai. Like other members Yuuka performed orders made by him per infiltration for the Alliance.

#### Akira Nishino

Scientist for the Messiah, not much is known about their interactions. It can be assumed that Haitani would manage Akira's research and was unaware that he was also responsible for the destruction of Arcadia.[[3]](#cite_note-V4E-3)

### Others

#### Black Knight

Like others of the Messiah, Haitaini was terrified when he concluded that there was another knight that could be on the same caliber as the First Knight. He would even be too terrified to move when he witnessed his atomic attack. Like other members of the Messiah except Akane, Haitani is unaware of the Black Knight true identity.[[3]](#cite_note-V4E-3)

## Trivia

## References

1. Volume 4 Chapter 5: Sneaking Around in Japan, Just like the Old Days!!
2. Volume 4 Chapter 6: Something Smells Fishy... But an Eminence in Shadow Always Cracks the Case!
3. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
