# Episode 20

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2020](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2020)

## Advent of the Demon

### Kana

魔人降臨

### Romaji

Majin Kōrin

## Special Title

### English

The Eminence in Shadow Still Wants to Shine from the shadows!

### Kana

陰の実力者はやっぱり陰で活躍したい！

### Romaji

Kage no Jitsuryokusha wa Yappari Kakete Katsuyaku Shitai!

## Episode Information

### Season

1

### Episode

20

### Air Date

February 15, 2023 JP
May 8, 2023 EN

### Adapted From

Volume 2 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

N/A

### Ending

N/A

Episode Navigation

| Previous | Next |
| --- | --- |
| Dancing Puppet | Lawless City |

Advent of the Demon (魔人降臨, Majin Kōrin[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the twentieth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation, and the finale of the first season.

## Synopsis

- [English](#)
- [Japanese](#)

Provoked by the fight between Shadow and Beatrix, Iris joins the fray. An intense battle progresses across the Royal Capital. Meanwhile, Rose runs into Alpha...[[1]](#cite_note-1)

シャドウとベアトリクスの戦いに触発されたアイリスは、魔剣を手に参戦。王都各地で激しいバトルを繰り広げる。いっぽうシャドウに生かされたローズは、アルファと遭遇し…!?[[2]](#cite_note-2)

## Summary

As Iris lay defeated by Mundane Man under the pouring rain, he redirects his attention and sees Rose Oriana in VIP seating. He makes his way over as Iris sits up, and Mundane Mann breaches into the VIP seating to reveal himself as Shadow. Reflecting on recent events, Shadow's bounty, the terror attack on the Academy, her encounter with [Alpha](Alpha.md "Alpha"), the explosion during Alexia's kidnapping, culminating in the reveal of his disguise as Mundane. Iris screams in a rage as Shadow begins to clash with [Beatrix](Beatrix.md "Beatrix"), destroying the VIP seating as the impact of their battle forces the stadium spectators to evacuate. King Klaus Midgar is informed that the battle between Shadow and Beatrix may leave the copnfines of the stadium. The king asks about Perv Asshat, learning that he is heading towards the outskirts on a carriage directly running back to Oriana Kingdom, without stopping at the embassy. The Midgar Knights are taking care of the body of King Oriana, as King Klaus orders that they return him to Oriana Kingdom through the Marquess, [Grant](Grant.md "Grant"). A guard notes she is the leader of the anti-chancellor faction, explaining such a move would fuel civil war, but the King is aware and notes how they need to prepare themselves as the darkness that has been lurking since ancient times has taken a deeper hue.

In the devastated VIP seating, Iris arrives to claim something to use against Shadow. Atop the stadium, Shadow battles with Beatrix and finds interest in her skills. To test her, he starts manipulating his presence to get behind her with ease, while she barely manages to notice him in time and block his attacks. Beatrix realizes that he shifts his presence to escape her notice, similar to how she cannot focus on every drop of the rain. As he tells beatrix they're only getting started, Iris arrives stating she wants to join the fight, drawing a mythril blade with ancient runes, surprising Shadow that she intends to use an [ancient artifact](Artifacts.md "Artifacts"). She asks if he considers it cheating, but he's fine with it, only amused that she would resort to what he sees as a crutch. The annoyed Iris imbues the blade with her mana, becoming a large fire sword to swing at Shadow, who easily dodges while complementing the good visuals fit for a festival spectacular. Beatrix attempts to attack him with a flank, but Shadow easily counters and continues to fight her, with Iris joining Beatrix to fight Shadow.

While Claire continues to search for her brother, Rose escapes to an alleyway. Uncertain if she should return to Oriana Kingdom to ally with the anti-chancellor faction, [Alpha](Alpha.md "Alpha") arrives. As the two clash with Shadow around the royal capital, Iris manages to push him towards a construction site on a building, where Shadow takes two crowbars to effortlessly block attacks from both Iris and Beatrix, noting that crowbars indeed have potential. As they keep on fighting, they end on top of a train, where Shadow tells them to be careful to not fall. Furthering their conflict around the city, demolishing buildings in their wake, the trio take their fight to a moving train, as Shadow invites them to continue while twirling the crowbars, asking only that they not fall off. Back in the alley, Alpha gives Rose two choices: continue fighting alone or fight alongside Shadow Garden. When Rose asks Alpha if they intend to save Oriana Kingdom, Alpha explains that they won't do anything to assist her as she is right now. So if she wishes to save her kingdom, Rose must show her's and the kingdom's worth, and after a moment of thinking, Rose accepts the offer to join Shadow Garden. Welcoming her, Alpha coats Rose in her own Slime Bodysuit to facilitate their escape.

While they fight atop a speeding train, Iris demands to know who he is and grows infuriated by his non-answer in his "Mundane Mann" voice. As Beatrix inquires having met Shadow before, he states he remembers powerful opponents, asking if they are strong enough to remember. Jumping into the river, Shadow uses "[the witch's](Aurora.md "Aurora") secret art" to control the water, which Beatrix recognizes as a vampire attack. While Iris evaporates his attack, he notices that magic doesn't flow well in ordinary water before kicking Iris in the face into the river. Surprisingly, Beatrix attacks and breaks his crowbars. At the train station, Annerose laments Mundane not arriving and takes her leave to continue her journey, smiling in promise to see him again someday.

Atop the clock tower, Beatrix can now easily block his surprise attacks after getting used to it. Congratulating her, Shadow notes her sword skill almost equals Shadow Garden, yet invites her to learn proper magic from him. As Iris attacks wildly, but Shadow blocks the inelegant attack with his fist. Regrouping against Shadow, he tells the duo that he cannot be defeated with borrowed power. Iris tells Beatrix she'll make a sacrifice play to allow her the chance to strike. Shadow invites them to try, and Iris attacks Shadow as a lightning strike bathes them in blinding light. Abandoning her sword in an attempt to grapple him, the disappointed Shadow knees her as Beatrix finishes charging her attack. But as she pounces, Shadow throws his blade up and dodges her attack to move in for a melee counter. Beatrix attempts to kick him in defense, but he takes her off foot and grapples her to [suplex](https://en.wikipedia.org/wiki/Suplex) Beatrix into Iris on the floor. Shadow stomps both of them with enough force to crack the stonework beneath, catching his blade as it returns.

As Shadow attempts to leave, Iris demands he returns as both girls struggle to stand back up. Iris then tells him that every knight within the city should have been mobilized by now, as he has turned the whole Midgar Kingdom into his enemy and he has nowhere to run to. However, to their confusion and shock, Shadow starts laughing maniacally before calming down. In a serious tone, Shadow asks Iris who is running, to where, and why would he ever run, expanding his magic reach to the periphery of the royal capital. As Iris and Beatrix are stunned to see the reach of his magic, a hovering Shadow states that the playtime is over. Concurrently, Princess Alexia Midgar continues training regardless of the situation in the capital, proclaiming whether she should die and reincarnate, she is determined to choose the same path again. Meanwhile, a frightened Iris drops the mythril sword, as a flamboyant Shadow calls their attention to witness his ultimate attack. But as Shadow starts casting his "I Am Atomic" attack, his life flashes before him and he instead leaves the spell incomplete. This time using the spell for show, all Shadow did was dispel the stormy weather overhead. Seeing no destruction but a clear sunny sky, Beatrix accepts that she lost the battle and sheathes her sword, while Iris drops to her knees and bawls in frustration.

Over in [Laugus](Laugus.md "Laugus"), an obsessed Sherry reads the newspaper how "the demon Shadow" was chased away by Iris and Beatrix following his terrorist attack on the royal capital. Now guilty of killing her father, Rose is still missing and a fugitive. Meanwhile, much remains unknown about the secret society of Shadow Garden, aligned with "the demon," Shadow, as the Knight Order rallies to apprehend him as the principle offender. Still vengeful, Sherry stabs the newspaper image of Shadow, swearing to uphold her vendetta upon him, while laughing in a mad fit as her room is adorned with dozens of copies of Shadow's wanted poster. While in Oriana Kingdom, [Mordred](Mordred.md "Mordred") communicates through a monitor disguised as a mirror to convey his disappointment with Perv, who begs his superior’s forgiveness for his failure. Perv also informs his superior that Rose can't stay hidden so long as the Cult controls the royal family. And now that Oriana has lost of their king, turmoil is bound to come and Perv is certain that Rose won't ignore it, certain that she will return home. On the monitor, Mordred retorts that Perv had better hope he is correct, and orders Perv not to disappoint him again.

At the royal capital train station, Beatrix readies to leave the city, disappointed she couldn't find the one she was looking for. But as she advises Iris to not take her defeat too seriously, as there are many things mortals can't defeat and she is still very young. However, Iris tells Beatrix not to worry as she isn't capable of staying still. Beatrix understands and accepts her choice, taking her leave on the train and laments not accomplishing her journey. However, she acknowledges some nice things as she pulls out an origami crane made from the wrapper of the burger Cid gifted her. She continues her journey, reminding herself to take her time and keep trying. As the Knights hunt for Shadow, [Gamma](Gamma.md "Gamma") uses the Mitsugoshi to rebuild the destroyed buildings within the capital. [Nu](Nu.md "Nu") reports to [Beta](Beta.md "Beta"), who surmises that Shadow is actively involving himself to distract Midgar from Oriana Kingdom. [Eta](Eta.md "Eta") has worked out [a specialized communication method](https://en.wikipedia.org/wiki/Morse_code) for their people in Oriana, while personnel are sent to keep tabs on the Major Corporate Alliance. With the new school term, Cid inquires about Skel as Po explains he took a long-term job. Po also tells Cid that he was outside the city when the Demon Shadow covered the capital in magic, regretting being outside as he'd have "comforted" the frightened girls who would have needed reassurance.

In the Kagenou lands, Mr. Kagenou wants to celebrate Claire's victory, but is reprimanded by Mrs. Kagenou for neglecting Cid. In the Kagenou Mitsugoshi store, Rose and Alpha resupply before heading deep into the woods, surprising Rose as magical beasts infest the region. Alpha explains that when Shadow visited the mountains, he battled and defeated the Mist Dragon, who then dubbed Shadow ruler of this realm and bathed him in dragon's breath. Alpha reveals the ancient city of [Alexandria](Alexandria.md "Alexandria"), Shadow Garden's secret headquarters, and takes Rose to [Lambda](Lambda.md "Lambda") as a new recruit. Alpha orders Lambda to train her and takes her leave. Lambda then calls upon [664](664.md "664") and [665](665.md "665"), assigning the new recruit to them to form their squad and renames Rose as Number 666. As they must abandon all attachments to their past life, Lambda shreds Rose's clothing, telling her that she is now nobody and must cast away everything to become a pure, unadulterated soldier. Horrified, Rose watches as the burger wrapper Cid gave her is shredded as well, wailing in utter despair. Back at the underground ruins, Shadow plays Moonlight Sonata once more as feathers descend about. He recites how everything has been going according to his designs, but "the hour of awakening" draws near. After finishing his play, Shadow leaves while a sole black feather lands on the piano keyboards.

## Characters

- Cid Kagenou
- Iris Midgar
- Rose Oriana
- [Beatrix](Beatrix.md "Beatrix")
- Klaus Midgar
- Perv Asshat
- Raphael Geerk Oriana (Mentioned)
- [Grant](Grant.md "Grant") (Mentioned)
- Claire Kagenou
- [Alpha](Alpha.md "Alpha")
- Annerose Nichtsehen
- Alexia Midgar
- Sherry Barnett
- [Mordred](Mordred.md "Mordred") (Cameo Screen Image)
- Goldy Gilded
- [Quinton](Quinton.md "Quinton") (Voice)
- Marco Granger
- [Gamma](Gamma.md "Gamma")
- [Nu](Nu.md "Nu")
- [Beta](Beta.md "Beta")
- [Eta](Eta.md "Eta")
- [Epsilon](Epsilon.md "Epsilon")
- [Chi](Chi.md "Chi")
- [Omega](Omega.md "Omega")
- [Delta](Delta.md "Delta")
- Po Tato
- Skel Etal
- [Zeta](Zeta.md "Zeta")
- Mr. Kagenou
- Mrs. Kagenou
- Mist Dragon (Mentioned)
- [89](89.md "89") (Cameo)
- [559](Victoria.md "Victoria") (Cameo)
- [Lambda](Lambda.md "Lambda")
- [664](664.md "664")
- [665](665.md "665")

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第20話予告≪ノーマルVer.≫「魔人降臨」

TVアニメ『陰の実力者になりたくて！』第20話予告≪スペシャルVer.≫「陰の実力者はやっぱり陰で活躍したい！」

## Trivia

- This episode marks the anime debut of [Lambda](Lambda.md "Lambda").
- Eta invents [a telegraph network](https://en.wikipedia.org/wiki/Electrical_telegraph), typing "To be continued" in morse code.

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e020>
2. <https://shadow-garden.jp/1st/story/#story20>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • **Episode 20** | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
