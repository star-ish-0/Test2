# The City-State Alliance

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/The%20City-State%20Alliance](https://the-eminence-in-shadow.fandom.com/wiki/The%20City-State%20Alliance)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/The_City-State_Alliance?action=edit).

## City State Alliance

### Japanese

都市（とし）国家群（こっかぐん）

### Romaji

Toshi Kokka-gun

## Location Information

### Leader

Unknown

### Status

Active

### Affiliates

Unknown

### Type

Archipelagic States

### Government

Unknown

### Location

In the Northwestern edge of the Midgar Kingdom

### Inhabitants

Humans

## Debut

### Light Novel

Volume 6 (Mentioned)

The City-State Alliance (都市（とし）国家群（こっかぐん）, Toshi Kokka-gun[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a group of archipelagic states located in the north-westernmost part of the Midgar Kingdom, in the straits of the Velgalta Empire.

## Overview

The City-State Alliance is centered on the Trade City Grazheim, and it works as a vital tourist attraction.[[1]](#cite_note-1) Grazheim, also known as the City of Happiness, is known as the core of The City-State Alliance's trade, as well as housing a number of tourist resorts.[[2]](#cite_note-2) Grazheim has also been mentioned to be home to the real estate guild.[[3]](#cite_note-3) Grazheims Tourism District works as a trade and logistics hub, and the Academic District is not only home to Jugang ruins which are under the control of the Sacred State Orum, [[4]](#cite_note-4) but also to the Sacred State Orum itself.[[5]](#cite_note-5)

The Holy State of Orum is home to the Holy Teachings, as well as a cathedral which is the faith's center and it is a popular tourist attraction.[[6]](#cite_note-6) The Holy Teachings who believe in the Goddess Beatrix have believers all over the world, its primary church is located in Orum.[[7]](#cite_note-7)[[8]](#cite_note-8)

Another member of the City-State Alliance is the Altena Empire, an elf-governed territory and a vassal state under the domain of the Velgalta Empire.[[9]](#cite_note-:0-9) The Velgalta Empire Empire took advantage of a political divide and took the chance to invade, leaving Altena with no choice but to surrender.[[9]](#cite_note-:0-9)

Last up we have the Academic City of Laugus, the city was founded by a man called Lord Laugus who was its first Chancellor.[[10]](#cite_note-10) Laugus also has a partnership with Grazheim's Academic District.[[11]](#cite_note-11) Laugus has been stated before to be a hub for cutting-edge technology and artifacts.[[12]](#cite_note-12)

## Military

The Holy State of Orum is home to the Templars, a group of holy warriors who punish and root out heretics. Taught radical ideologies and dark knight fighting techniques deep in the Jugang Ruins, their strength and zealotry present a significant fighting force.[[13]](#cite_note-13)[[14]](#cite_note-14) They enforce the Church's will and enact inquisitions—investigating and prosecuting suspected heretics. Their ability to dictate enemies of The Holy Teachings is a large factor as to why no country had dared deny Orum a place in the international scene.[[15]](#cite_note-15)

## Location

- Jugang Ruins

## Layout

## Trivia

## References

1. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 1-11: Deal! Arranged Booking, Episode 4: Sponsor's Intent
2. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 1-12: Natsume & Shiron Hang Out!, Episode 1: City-State Duo
3. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 3: Secret of Sacra, Chapter 3-4: Influencers Ahoy!, Episode 2: Problematic Property
4. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 1-12: Natsume & Shiron Hang Out!, Episode 2: Fleeting Vacance
5. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 1-11: Deal! Arranged Booking, Episode 4: Sponsor's Intent
6. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 1-12: Natsume & Shiron Hang Out!, Episode 2: Fleeting Vacance
7. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 3: Secret of Sacra, Chapter 3-2: The Hero Revealed!, Episode 2: Church and Heroes
8. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 1-14: The Garden on the Eve of Battle!, Episode 3: Garden's Enemy
9. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 3: Secret of Sacra, Chapter 3-4: Influencers Ahoy!, Episode 2: Problematic Property
10. The Eminence in Shadow: Master of Garden, Event Stories, Truth Seekers, Episode 3
11. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 1-12: Natsume & Shiron Hang Out!, Episode 1: City-State Duo
12. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 2: Sturm of Velgalta, Chapter 2-6: The Garden Heads North, Episode 5: Journey to the North
13. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 1-13: Visions... Zeta and the Prophet, Episode 1: Spy Request
14. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 2: Sturm of Velgalta, Chapter 2-1: Operation: Rescue & Recover, Episode 1: Zeta's Departure
15. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 1-11: Deal! Arranged Booking, Episode 4: Sponsor's Intent

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • **The City-State Alliance** • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
