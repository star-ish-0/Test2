# Freya

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Freya](https://the-eminence-in-shadow.fandom.com/wiki/Freya)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Freya?action=edit).

Relationship

Gallery

## Freya

### Japanese

フレイヤ

### Romaji

Fureiya

### Aliases

Human Hero

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Platinum

### Eye Color

Red

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Cid Kagenou (Male Descendant)
Claire Kagenou (Descendant)
Rose Oriana (Descendant)
Iris Midgar (Descendant)
Alexia Midgar (Descendant)

## Professional Information

### Affiliation

Cult of Diablos

## Debut

### Web Novel

Chapter 182

### Anime

Episode 29 (Mentioned)

### Game

Apocrypha: Chapter 1

Freya (フレイヤ, Fureiya[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the Three Heroes who defeated the demon [Diablos](Aurora.md "Aurora") and earned the sobriquet Human Hero. In reality, she was a human test subject and pawn of the Cult of Diablos. Her engagement with the demon was not out of any altruism or selflessness but coercion and servitude.[[1]](#cite_note-V2C2-1)[[2]](#cite_note-MOG-SSC_P3C3E2-2)

## Appearance

Freya is described to have silver hair and bright red eyes. Her appearance is very similar to Alexia Midgar, her descendant.

## Personality

Freya approaches circumstances in a rational manner around subordinates and team members. Often functioning as a leader, she gives concise instructions but abdicates the moral responsibility for the well-being of others. Instead, she conducts herself in a merciless manner for gratification and efficiency.[[3]](#cite_note-MOG-AP_P1C1E3-3)[[4]](#cite_note-MOG-AP_P1C2EA9-4)

## Chronology

## Powers & Abilities

### Swordsmanship

After awaking, Freya's avatar displayed praiseworthy strength and "beautiful" swordsmanship, but it was merely an echo of the past. Although the blow was powerful, it lacked intent.[WEB NOVEL ONLY][[5]](#cite_note-WN181-5)[[6]](#cite_note-WN182-6) During Shadow Garden's exploration of the past, the real Freya demonstrated combat skills comparable to the other Seven Shadows.[[7]](#cite_note-MOG-AP_P1C2EA7-7)

### Magic

As one of the Three Heroes, Freya's power is amplified through the stable Diablos Cells within her body.[[1]](#cite_note-V2C2-1) Such magic was strong enough to bemuse strong warriors when she appeared as a mere projection.[WEB NOVEL ONLY][[5]](#cite_note-WN181-5) She has further demonstrated magical abilities outside of body augmentation. Through the assistance of an artifact acting as a catalyst, she can manifest chains to immobilize and restrain targets.[[8]](#cite_note-MOG-AP_P1C2EB1-8)

## Trivia

- The character of Freya has never debuted in the light novel. Her only adaptation appearances are in the web novel, anime, and game.[[5]](#cite_note-WN181-5)[[9]](#cite_note-S2E9-9)
- Freya shares a name with the Goddess [Freyja](https://en.wikipedia.org/wiki/Freyja "wp:Freyja") from Norse mythology.
- Both Freya and [Olivier](Olivier.md "Olivier") are depicted as men due to the Cult of Diablos's distortion of history.
- In the Web Novel, Freya was sealed away within the Oriana Kingdom to guard one of Diablos's fingers.[[5]](#cite_note-WN181-5)

## References

1. Volume 2 Chapter 2: Investigating the Sanctuary!
2. Seven Shadows Chronicles, Part 3: Secret of Sacra, Chapter 3-2: The Hero Revealed!, Episode 2: Church and Heroes
3. Apocrypha, Part 1: Requiem for Scattered Shadows, Chapter 1: Millennium Past, Episode 3-1
4. Apocrypha, Part 1: Requiem for Scattered Shadows, Chapter 2: Heroes of Time, Episode A9
5. Web Novel: Chapter 181
6. Web Novel: Chapter 182
7. Apocrypha, Part 1: Requiem for Scattered Shadows, Chapter 2: Heroes of Time, Episode A7-3
8. Apocrypha, Part 1: Requiem for Scattered Shadows, Chapter 2: Heroes of Time, Episode B1
9. Episode 29

## Site Navigation
