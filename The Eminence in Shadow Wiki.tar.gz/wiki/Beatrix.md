# Beatrix

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Beatrix](https://the-eminence-in-shadow.fandom.com/wiki/Beatrix)

[Chronology](Beatrix-Chronology.md "Beatrix/Chronology")

[Relationships](Beatrix-Relationships.md "Beatrix/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | This is a good hand. I’m sure you’ll grow stronger. | ” |
| — Beatrix to Cid, Light Novel Volume 02 | | |

## Beatrix

### Japanese

ベアトリクス

### Romaji

Beatorikusu

### Aliases

War Goddess

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

+100 (Game)

### Height

Unknown

### Hair Color

Platinum

### Eye Color

Blue

### Birthday

January 21

## Personal Information

### Status

Alive

### Relatives

- [Olivier](Olivier.md "Olivier") (Ancestor)
- Unnamed Younger Sister †
- King Anorion (Half-brother) †
- [Alpha](Alpha.md "Alpha") (Niece)
- Lalanoa Hinoizumino (Niece)

## Professional Information

### Occupation

Swordswoman

## Debut

### Web Novel

Chapter 78

### Light Novel

Volume 2

### Manga

Chapter 24

### Anime

Episode 16

### Game

Episode 16

## Portrayal

### Japanese

[Mikako Komatsu](https://en.wikipedia.org/wiki/Mikako_Komatsu "wp:Mikako Komatsu")

### English

[Allison Sumrall](https://en.wikipedia.org/wiki/Allison_Sumrall "wp:Allison Sumrall")

### French

Sophie Planet

### Italian

Gea Riva

Beatrix (ベアトリクス, Beatorikusu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the first champion of the Bushin Festival, hailed as the War Goddess (武神（ぶしん）, Bushin[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) for her unrivaled mastery of swordsmanship. She is also heavily implied to be the long-lost aunt of [Alpha](Alpha.md "Alpha"), whom she is currently searching for.[[1]](#cite_note-V2C7-1)

## Appearance

Beatrix is an [elf](Elf.md "Elf") with well-refined features and a defined figure. She is always seen carrying a sword by her side. She has long platinum hair, blue eyes, and pale skin. Cid notes that she bears a such striking resemblance to Alpha that no one would be blamed for assuming they are related.[[1]](#cite_note-V2C7-1)

Her attire consists of a gray robe with tattered edges, a white bikini top, and a gold accented black short skirt. She wears a leg stocking on her right leg while her left leg is mostly bare, except for two straps. For accessories, she dons black gloves, a jewel-adorned hairband, and a necklace featuring a sapphire-like gem.[[2]](#cite_note-V2CF-2) In the [Anime](Anime.md "Anime") and Game, her clothes change a bit, she wears shorts instead of a skirt.[[3]](#cite_note-AS1E20-3)

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Do you know of any elves who look like me? | ” |
| — Beatrix to Cid Kagenou, Light Novel Volume 02 | | |

Beatrix is ​​shown to be a mature person but is typically passed off as stoic individual that is socially awkward and with an aloof attitude. This confuses others and makes them question whether her title is a true testament or exaggeration initially. Her tactless nature may be seen by others as someone who speaks her thoughts out loud without filter, but she is still polite to those that engages with her.[[4]](#cite_note-V2C8-4)

Beatrix has a degree of self-confident and seems to have a determined attitude as seen by her unyielding desire to achieve her goals by finding her niece. Beatrix, like Shadow, also feels a strong attraction to face off against powerful opponents when she is able to find them. She is not above teaming up with others to defeat larger threats as shown by her alliance with Iris Midgar.[[4]](#cite_note-V2C8-4)[[2]](#cite_note-V2CF-2)

Beatrix maintains her friendly, kind and loving presence with people she likes, and is intuitive enough to avoid the possibility of death in combat when faced with very strong enemies.[[2]](#cite_note-V2CF-2)

In political matters and other people's family problems, Beatrix stays out of it or shows no interest in it, even if the situation sounds serious. In the incident of Rose Oriana murdering her father in front of everyone at the Bushin Festival, Beatrix witnessed everything and heard everything, including the sinister confessions Perv Asshat said. She remained still without flinching until Shadow revealed himself to everyone.[[4]](#cite_note-V2C8-4)

## Powers & Abilities

Known as the War Goddess, Beatrix's, the first champion of the Bushin tournament, strength is a legend among the denizens of the other world. Many hold her power and abilities in high regard. This veneration includes royals and nobles. Princess Iris Midgar vocalized her respect and admiration for Beatrix's swordsmanship, while Duke Perv Asshat considered her reappearance a potential threat to the Cult of Diablos.[[1]](#cite_note-V2C7-1)[[2]](#cite_note-V2CF-2) The Cult likewise believe that she has inherited the blood of the three heroes and awakened some of that potential power without suffering from possession.[ANIME ONLY][[5]](#cite_note-5) Only Shadow has been identified as one who defeated her without difficulties.[[2]](#cite_note-V2CF-2)

### Swordsmanship

Beatrix's bladed combat is described as the "apex of swordsmanship," earning her the title of the legendary elven swordmaster.[[2]](#cite_note-V2CF-2) In their first encounter at the Bushin Festival, her longsword proficiency stalemated Shadow and forced him to revert his blade to its accustomed length.[[2]](#cite_note-V2CF-2) Shadow likewise complimented her skills, expressing that her technique is comparable to his and Shadow Garden members’ swordsmanship.[ANIME ONLY][[3]](#cite_note-AS1E20-3) These skills surpass many dark knights, including users of the Royal Bushin Style.[[1]](#cite_note-V2C7-1)

### Magic

Beatrix demonstrates the traditional magical application of enhancement. Although her magic control feats surpass the average dark knight, it lacks potency compared to other combat capabilities—a sentiment articulated by Shadow.[[2]](#cite_note-V2CF-2)[[3]](#cite_note-AS1E20-3) Despite the perceived misuse of her magic, Beatrix reveals defensive and offensive magical techniques. Exemplifying her offensive techniques is an attack that reflects and shares similarities to Earth’s martial art, Iaidō. Beatrix sheathes her sword, channels magic into the blade, and draws it from the sheath to unleash a powerful and fast slash.[ANIME ONLY][[3]](#cite_note-AS1E20-3) Another magical ability she has is walking on water.[ANIME ONLY][[3]](#cite_note-AS1E20-3)

### Physical Capabilities

Beatrix possesses supernatural senses, especially in sight and smell. Despite not having the inborn advantages of [therianthropes](Therianthrope.md "Therianthrope"), her nose can distinguish the specific scent of elves—even the lingering presence on other races.[[4]](#cite_note-V2C8-4)

In combat, Beatrix's strength and speed exceed the average Midgar Kingdom dark knight. Each strike discharges enough force to generate shock waves that temporarily parted heavy rain and knocked down multiple buildings. Observers of her battles can only conclude that Beatrix's skills lie at the “apex.” Even while outmatched by agile attacks, Beatrix demonstrated reactions that can block a few attacks from mere instinct and ameliorate some kinetic force.[[2]](#cite_note-V2CF-2)

Concerning durability, Beatrix exhibits high resistance to physical attacks and magically amplified damage. When Shadow slammed her body into the ground, her consciousness remained intact enough to attempt a counterattack. The second attack of this exchange deeply embedded her into a wall, but she recovered and desired to continue their duel.[[2]](#cite_note-V2CF-2)

### Intelligence

Beatrix displays superior intelligence in survival and combat, but other areas remain unknown. A warrior’s instincts to perceive a fighter’s strength, potential, and emotion dwell within her; however, it can be a hindrance when a combatant reacts contradictory, or attacks lacks intent. This limitation is best represented by Cid’s inconsistent behavior while embodying his mob persona or Shadow’s mastery of no-mind combat.[[2]](#cite_note-V2CF-2)

### Weapons and Equipment

- Long Sword: In the Light Novel and [Manga](Manga.md "Manga"), Beatrix often carries an ornate, double-edged longsword with gold fittings and black and blue accents. In the anime, she carries a long, straight sword similar to a katana.

## Trivia

- The name Beatrix is derived from the word Viatrix, the feminine form of Viator meaning "[voyager or traveler](https://en.wikipedia.org/wiki/Beatrix#:~:text=Beatrix%20is%20a%20Latin%20feminine,word%20beatus%20or%20%22blessed%22.). " In Late Latin, its spelling was influenced the Latin word beatus meaning "blessed."
  - It also means "she who brings happiness" in [Latin](https://www.mamanatural.com/baby-names/girls/beatrice/).
- Beatrix's age is stated to be over 100 years.[NOT CANON: GAME ONLY][[6]](#cite_note-6)
- In a dating scene, Beatrix pondered on how strong the child she and Cid would sire.[NOT CANON: GAME ONLY][[7]](#cite_note-7)
- Beatrix shares a name with the Goddess Beatrix, the claimed one true deity from the Holy Teachings church.[[8]](#cite_note-V1CP-8)
- The color of Beatrix's magic is a bright white.[ANIME ONLY][[3]](#cite_note-AS1E20-3)

## References

1. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
2. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
3. Episode 20
4. Volume 2 Chapter 8: Lay Your Eyes on My True Powers!
5. Episode 19
6. [Cid was Surprised at Beatrix's Age?!](https://the-eminence-in-shadow.fandom.com/wiki/File:Beatrix's_age,_according_to_in-game_quotes.png)
7. [Beatrix wants to have a kid with Cid Kagenou.](https://the-eminence-in-shadow.fandom.com/wiki/File:Quotes_of_game_-_Beatrix_wants_to_have_a_child_with_Cid.png)
8. Volume 2 Prologue: To Lindwurn, The Sacred Land!

## Site Navigation
