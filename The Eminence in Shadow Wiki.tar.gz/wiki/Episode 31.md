# Episode 31

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2031](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2031)

## Determination

### Kana

決断

### Romaji

Ketsudan

## Special Title

### English

The Eminence in Shadow wants to be flexible to deal with the untouchable guys!

### Kana

陰の実力者はあかんヤツにも臨機応変に対処したい！

### Romaji

Kage no Jitsuryokusha wa akan yatsu ni mo rinki ōhen ni taisho shitai!

## Episode Information

### Season

2

### Episode

11 (31)

### Air Date

December 13, 2023 JP & EN

### Adapted From

Volume 4 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

Grayscale dominator

### Ending

Polaris in the Night (Omega ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Caged Bird | HIGHEST |

Determination (決断, Ketsudan[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the eleventh episode of the second season, and the thirty-first episode of [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

With Princess Rose’s hands tied as Perv has taking her mother hostage, the Eminence in Shadow must move to free the captive himself.[[1]](#cite_note-1)

ローズの“足かせ”を外すために、人質となったレイナ王妃の居場所を探るシド。
シャドウとしてローズの前に姿を現し、所在を掴んだ王妃のもとへ連れていくのだが……。[[2]](#cite_note-2)

## Summary

On a clandestine operation, Zeta, one of the Seven Shadows, is in an undisclosed location reviewing data on the Black Rose. As her numbered Shadow operatives clash with Cult members, she notes the enemy is struggling, but observes a critical absence: "the Night Beyond Men" (Mordred) is nowhere to be seen. More importantly, the artifact they were searching for has already been taken. She concludes that this likely means "the end of Orianna," but resigns herself to the will of their lord, Shadow.

At the Oriana Kingdom Palace, Cid (in his apprentice persona) drinks tea while listening to Epsilon (as the pianist Chiron) perform. He summarizes his understanding of the situation: Princess Rose's hands are tied because the perverted noble, Duke Perv Asshat, has taken her mother, Queen Reina, hostage. Cid finds Rose's hesitation annoying but decides to solve the problem simply: he'll use his "Shadow moves" to free the hostage, removing Rose's shackles and pushing her one step closer to becoming the "legendary tyrant" he envisions.

Cid is then intercepted by Margaret, Rose's personal maid. She fusses over Cid, claiming she was distraught after losing him the previous day. She mentions a "creepy guard" (likely one of Cid's earlier, crude Shadow impersonations) who was stalking her but has since been formally accused of stealing food and removed. Margaret vows to protect Cid from both the stalker and "that woman who claims to be your teacher"—Epsilon.

Epsilon (as Chiron) overhears this and confronts Margaret, leading to a tense, passive-aggressive argument over Cid. Cid slips away and begins playing a piano. Epsilon finds him and comments on the nobility's nonchalant attitude despite being on the verge of war. She explains that Oriana's nobility historically hates violence but adores the arts because of fear surrounding the Black Rose legend.

Cid's interest is piqued by the mention of the Black Rose, especially after a cutaway shows a group called the "Black Rose Brotherhood" rallying. When Cid expresses a desire to see a real Black Rose, Epsilon warns it's dangerous. Cid, internally praising Epsilon's dramatic flair, decides his priorities are first finding Queen Reina.

Meanwhile, Cid eavesdrops on Queen Reina and Duke Perv Asshat. The two are in a romantic embrace. The queen asks why they can't reveal their love. Perv says they only need to wait until after the wedding, when Rose will "disappear." Reina, showing her true nature, confirms Perv will kill Rose and then marry her. Perv affectionately agrees, calling her "Pookie-poo." Cid is disgusted, feeling the story has devolved into a daytime soap opera and resolves to course-correct it.

Later, Princess Rose tries to speak with Margaret, but the maid coldly dismisses her. Alone, Rose laments that Margaret will never smile at her again but vows to save her mother for her father's sake. Suddenly, she senses a presence and turns to find Shadow (Cid) sitting in her room, drinking her tea. She asks if he's come to kill her for her betrayal, but Shadow simply says, "Come. I will show you the truth at last."

Shadow leads Rose to spy on her mother. They witness Queen Reina and Perv in a private moment. Reina gleefully admits to drugging her husband, the king, turning him into a "lovely puppet." Perv laments that Rose killed the king before he could be more useful, and Reina agrees that Rose should have been killed first. Rose, hearing this, suffers a complete mental breakdown, vomiting from the shock. Shadow tells her she must accept the truth. He urges her to "Rise, tyrant" and unleash the blade of rebellion. But Rose passes out from the trauma.

Back in her chambers, Rose wakes up. She cringes, replaying the horrific scene in her mind—her mother's betrayal, her father's murder—and almost vomits again. Sobbing, she wishes to go back to happier days and calls out for Cid.

On the palace grounds, Cid (as himself) is playing a piano that has mysteriously appeared. Rose, on her balcony, sees him and desperately asks him to run away with her to a faraway world. She confesses she murdered her father, was betrayed by her mother and her people, and betrayed her organization, but says Cid is the only one who stayed with her. Cid, oblivious to her emotional plea, talks about how he divides the world into things that matter and things that don't, dedicating all his time to what matters. He says the world is too bright, causing people to lose sight of what's truly important. The moonlight, he suggests, provides the perfect illumination. He asks Rose: "In this world lit by the moon, what is it that you see?"

Later, as Cid prepares for a bath, he realizes he's lost the Ring of Succession. He worries it was stolen, but shrugs it off, figuring he spends money as fast as he makes it. He reflects that he did what he could to convince Rose and believes she will "pull herself up and raise the banner of rebellion."

Epsilon appears, offering to scrub his back. Cid internally notes how her "slime body" has evolved to look incredibly realistic. He tells Epsilon there was a "slightly unexpected development" but that he gave Rose "the key." He confidently predicts the "banner of rebellion" will rise on its own in three days, at the wedding.

Three days later. Violence erupts in the capital as soldiers fire on protesters demanding the wedding be canceled. Duke Perv Asshat, preparing for his wedding to Rose, panics when he opens the ring case and finds the Ring of Succession missing. He is contacted by Mordred (the 9th seat of the Knights of Rounds) via a magical mirror. Mordred congratulates him, saying all arrangements are complete and the "12th-seeded rounds" will be his after the ceremony. After the transmission ends, Perv panics but reassures himself he can delay the ring exchange.

At the wedding ceremony. The officiant asks Perv if he takes Rose to be his wife. He agrees. But when asked if she takes him, Princess Rose declares: "I do not."

Chaos erupts. Rose confesses openly: "I murdered the king, betrayed my kingdom, and swore allegiance to a shadowy organization. I do not excuse myself. I accept everything. My guilt, my mistakes, all of it. But before it's over, I want to make things right. Duke Perv Asshat, I pronounce you guilty!" She accuses him of manipulating the king, defiling the queen, and plotting a coup.

Perv claims she has no proof. Rose admits she doesn't, but says she doesn't need it. Perv threatens the hostage queen, but before he can act, a magical recording begins to play. It is the late King Girk's final confession. He reveals he was being slowly drugged into losing his mind by Duke Perv Asshat. He says the kingdom is under the control of a massive organization. He leaves the kingdom to Rose, proclaiming: "Rose Oriana will be your new leader. No matter what may happen, I want you to believe in her."

The crowd turns. They hail Princess Rose and denounce Perv as a traitor. Just as Rose pronounces him guilty, Mordred appears. He dismisses Perv as an incompetent ally. He addresses Rose as the "new ruler of the Oriana kingdom," congratulating her on the "key succession ceremony" because "the possessor of the key and the user of the device do not need to be the same person." He declares that all he needed was for the signal to reach its destination.

Mordred unleashes the Black Rose. A monstrous, eldritch entity manifests. "This is the truth behind the legend," Mordred announces. "The monster that wiped out 100,000 Vel'Kalten troops in a single night. Meet the Black Rose." He declares it's time to eliminate all witnesses, invoking the cult's indelible law. "Now come forth, Grand Ruler of the Fourth Realm, Ragnarok!" A colossal beast, Ragnarok, appears and begins laying waste to everything.

As the slaughter begins, Shadow (Cid) watches from afar. He coolly observes the Black Rose blooming in the sky, the bat (likely Ragnarok) enveloped in flames, and the band of light raising the earth. He notes these things are rare—but unsightly. The episode ends with Shadow preparing to intervene.

## Characters

- [Zeta](Zeta.md "Zeta")
- [Epsilon](Epsilon.md "Epsilon")
- Cid Kagenou
- [Margaret](Margaret.md "Margaret")
- [Kevin](Kevin.md "Kevin") (Mentioned)
- [Quinton](Quinton.md "Quinton")
- Goldy Gilded
- Reina Oriana
- Perv Asshat
- Rose Oriana
- Raphael Geerk Oriana (Mentioned/Flashback)
- [Beta](Beta.md "Beta")
- [Victoria](Victoria.md "Victoria")
- [Mordred](Mordred.md "Mordred") (Debut)
- [Ragnarok](Ragnarok.md "Ragnarok") (Debut)

## Promotional Videos

「陰の実力者になりたくて！ 2nd season」 第11話予告≪ノーマルVer.≫「決断」

『陰の実力者になりたくて！ 2nd season』 第11話予告≪スペシャルVer.≫「陰の実力者はあかんヤツにも臨機応変に対処したい！」

## Trivia

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e031>
2. <https://shadow-garden.jp/story/#story11>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • **Episode 11** • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
