# Kana

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kana](https://the-eminence-in-shadow.fandom.com/wiki/Kana)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Kana?action=edit).

## Kana

### Japanese

カナ

### Romaji

Kana

## Characteristics

### Race

[Therianthrope](Therianthrope.md "Therianthrope") (Cat Therianthrope)

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Black

### Eye Color

Gold

### Birthday

February 9

## Personal Information

### Status

Alive

### Relatives

[Natsu](Natsu.md "Natsu") (Sister)

## Professional Information

### Occupation

Servant

### Affiliation

Snow Fox Corporation

## Debut

### Web Novel

Chapter 112

### Light Novel

Volume 3

### Manga

Chapter 33

### Anime

Episode 21

## Portrayal

### Japanese

[Madoka Asahina](https://en.wikipedia.org/wiki/Madoka_Asahina "wp:Madoka Asahina")

### English

[Kira Vincent-Davis](https://en.wikipedia.org/wiki/Kira_Vincent-Davis "wp:Kira Vincent-Davis")

Kana (カナ, Kana[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of [Yukime](Yukime.md "Yukime")'s closest aides and sisters with [Natsu](Natsu.md "Natsu").

## Appearance

Kana is a beautiful Therianthrope woman with black cat ears and black tail. She usually wears a kimono.

## Personality

Kana is a childish person. However, she will act proper when in service to Yukime, not wanting to discredit her patroness.

## Chronology

### Great Trading Company Conflict

Kana and her sister, Natsu, occasionally greet Shadow whenever he comes to discuss with Yukime. They also try to seduce him as ordered by their mistress to tie Shadow to their group. When Shadow posing as "John Smith" arrives at the hideout, Natsu and Kana inform him of Yukime's disappearance.

## Powers & Abilities

Kana is skilled at charming men with her body and beauty.

## Relationships

### [Yukime](Yukime.md "Yukime")

Kana displays great respect and loyalty to her mistress, Yukime, shown when she abodes to her orders to seduce Shadow to which she did without hesitation.

### [Natsu](Natsu.md "Natsu")

Kana and Natsu are sisters, serving Yukime as both have lived a clean and healthy life in her service. Whenever Natsu is unavailable, Kana will continue with an assignment by Yukime.

### Shadow (John Smith)

Kana met John Smith when he was Shadow and aided in a secretarial role while the two plotted their counterfeiting operation. When he erupted at the news of Gettan ambushing Yukime, she was shocked to see how much power John Smith truly had.

## Trivia

## References

## Image Gallery

## Site Navigation
