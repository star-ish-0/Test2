# Darling in the Night

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Darling%20in%20the%20Night](https://the-eminence-in-shadow.fandom.com/wiki/Darling%20in%20the%20Night)

## Darling in the Night

## Information

### Artist(s)

The Seven Shadows

### Composer(s)

Ayato Shinozaki
Ryosuke Tachibana

### Arranger(s)

Ayato Shinozaki
Ryosuke Tachibana

### Lyrics

Karasuya Sabō

### Release date

November 30, 2022

Darling in the Night is the ending theme song for the first season of the anime adaptation The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). The song was performed by the voice actresses of the Seven Shadows: Asami Seto, Inori Minase, Suzuko Mimori, Ai Fairouz, Hisako Kanemoto, Ayaka Asai, and Reina Kondo.

## Lyrics

- [Kanji](#)
- [Romaji](#)
- [English](#)

:   明けない夜なんてないっていうけれど
:   明けなくていいと そう思ってた

:   隠したい傷跡だって
:   忘れたい記憶もみんな
:   太陽は全部照らし出すから

:   流星をさがし
:   彷徨ってたんだよ
:   あなたと出会う時まで

:   空に瞬くあの星が
:   繋いだ希望の道の先へ行こう
:   もう迷わずに進める
:   暗い夜を超える祈りを追いかけてく

:   たとえまだ届かなくたって
:   伝えたいから
:   「ありがとう」
:   Ha

:   弱い心 人は闇に喩うけど
:   光がなんで正しいのだろう?

:   強く正しく輝いて
:   全ての闇が消えたなら
:   どんな瞳も焼かれちゃうのに

:   優しい月夜に
:   泣いていたんだよ
:   あなたの手を取る時まで

:   空に瞬くあの星と
:   願いが紡いだ夢の先へ行こう
:   もう怖がらずに行ける
:   影の中にある強さを知っているから

:   例えまだちっぽけな自分でも
:   伝えたいから
:   「ありがとう」

:   やがて明けて消えてしまう夜でも
:   望まれもしない闇の中にでも
:   宝石よりきれいな希望があるよ
:   見上げてごらん 夜の星を

:   空を駆け抜けてく星と
:   確かに繋ぐよ希望の星座を
:   もう迷わずに進める
:   暗い夜導く光を届けに行こう

:   たとえまだ届かなくたって
:   伝えたいから
:   「ありがとう」

:   akenai yoru nante nai tte iukeredo
:   ake nakute ī to sō omotteta

:   kakushitai kizuato datte
:   wasuretai kioku mo minna
:   taiyō wa zenbu terashidasukara

:   ryūsei o sagashi
:   hōkō tte tandayo
:   anata to deau toki made

:   sora ni mabataku ano hoshi ga
:   tsunaida kibō no michi no saki e ikō
:   mō mayowazu ni susumeru
:   kurai yoru o koeru inori o oikaketeku

:   tatoe mada todokanakutatte
:   tsutaetaikara
:   "arigatō"
:   Ha

:   yowai kokorojin wa yami ni ukedo
:   hikari ga nande tadashī nodarō ?

:   tsuyoku tadashiku kagayaite
:   subete no yami ga kietanara
:   donna hitomi mo yakarechaunoni

:   yasashī tsukiyo ni
:   naiteita ndayo
:   anata no te o toru toki made

:   sora ni mabataku ano hoshi to
:   negai ga tsumuida yume no saki e ikō
:   mō kowagarazu ni ikeru
:   kage no naka ni aru tsuyo sa o shitteirukara

:   tatoe mada chippokena jibun demo
:   tsutaetaikara
:   "arigatō"

:   yagate akete kieteshimau yoru demo
:   nozomare mo shinai yami no naka ni demo
:   hōseki yori kireina kibō ga aruyo
:   miagete goran yoru no hoshi o

:   sora o kakenuketeku hoshi to
:   tashika ni tsunaguyo kibō no seiza o
:   mō mayowazu ni susumeru
:   kurai yoru michibiku hikari o todoke ni ikō

:   tatoe mada todokanakutatte
:   tsutaetaikara
:   "arigatō"

:   They say there's no night that won't end
:   I didn't have to wake up, I thought so

:   Even the scars I want to hide
:   All the memories I want to forget
:   'Cause the sun lights it all up

:   Looking for meteors
:   I was wandering
:   Until I meet you

:   That star twinkling in the sky
:   Let's go beyond the road of hope that connects us
:   Proceed without hesitation
:   I'm chasing a prayer that transcends the dark night

:   Even if it hasn't arrived yet
:   Because I want to tell you
:   "Thank you"
:   Ha

:   Weak hearts are likened to darkness
:   Why is the light right?

:   Shine strong and justly
:   If all darkness disappears
:   No matter what kind of eyes you have, they'll burn

:   On a gentle moonlit night
:   I was crying
:   Until I take your hand

:   With that star twinkling in the sky
:   Let's go beyond the dreams that our wishes have spun
:   I can go without fear
:   Because I know the strength in the shadows

:   Even if I'm still small
:   Because I want to tell you
:   "Thank you"

:   Even if the night fades away
:   Even in the darkness that is not desired
:   There's hope more beautiful than jewels
:   Look up at the stars at night

:   With the stars running through the sky
:   I will certainly connect the constellations of hope
:   Proceed without hesitation
:   Let's go and deliver the light that guides us through the dark night

:   Even if it hasn't arrived yet
:   Because I want to tell you
:   "Thank you"

## Ending Versions

【アルファ-CV-瀬戸麻沙美 Ver.】『陰の実力者になりたくて！』ノンクレED：「Darling in the Night」

Alpha (Asami Seto) Ver.

【ベータ-CV-水瀬いのり Ver.】『陰の実力者になりたくて！』ノンクレED：「Darling in the Night」

Beta (Inori Minase) Ver.

【ガンマ-CV-三森すずこ Ver.】『陰の実力者になりたくて！』ノンクレED：「Darling in the Night」

Gamma (Suzuko Mimori) Ver.

【デルタ-CV-ファイルーズあい Ver.】『陰の実力者になりたくて！』ノンクレED：「Darling in the Night」

Delta (Fairouz Ai) Ver.

【イプシロン-CV-金元寿子 Ver.】『陰の実力者になりたくて！』ノンクレED：「Darling in the Night」

Epsilon (Hisako Kanemoto) Ver.

【ゼータ-CV-朝井彩加 Ver.】『陰の実力者になりたくて！』ノンクレED：「Darling in the Night」

Zeta (Ayaka Asai) Ver.

【イータ-CV-近藤玲奈 Ver.】『陰の実力者になりたくて！』ノンクレED：「Darling in the Night」

Eta (Reina Kondo) Ver.

【七陰 Ver.】「陰の実力者になりたくて！ 2nd season」 第8話ノンクレジットエンディング：「Darling in the Night」

Seven Shadows Ver.

## Characters

:   In order of appearance:

- [Alpha](Alpha.md "Alpha") - Episode 2, Episode 10, Episode 18, Episode 28
- [Beta](Beta.md "Beta") - Episode 3, Episode 12, Episode 28
- [Gamma](Gamma.md "Gamma") - Episode 4, Episode 11, Episode 16, Episode 28
- [Delta](Delta.md "Delta") - Episode 5, Episode 13, Episode 19, Episode 28
- [Epsilon](Epsilon.md "Epsilon") - Episode 6, Episode 15, Episode 17, Episode 28
- [Zeta](Zeta.md "Zeta") - Episode 7, Episode 9, Episode 28
- [Eta](Eta.md "Eta") - Episode 8, Episode 14, Episode 28

## Trivia
