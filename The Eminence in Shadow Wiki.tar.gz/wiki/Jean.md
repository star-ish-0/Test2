# Jean

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Jean](https://the-eminence-in-shadow.fandom.com/wiki/Jean)

|  |  |  |
| --- | --- | --- |
| “ | That was just a cover identity. I’m actually a Named Child—Jean, the Wicked Smile. | ” |
| — Jean, to Claire Kagenou, Light Novel Volume 05 | | |

## Jean

### Japanese

ジャン

### Romaji

Jan

### Aliases

Wicked Smile

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- First Children (Named Child)
- Viscount (Public Cover)
- Fourth Division Captain (False Identity)

### Affiliation

Cult of Diablos
Knight Order (Undercover)

## Debut

### Light Novel

Volume 5

### Manga

Chapter 57

Viscount Jean (ジャン, Jan[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a captain of the third Knight Order's fourth company and a Named Child of the Cult of Diablos, nicknamed Wicked Smile (暗黒（あんこく）微笑（びしょう）, Ankoku Bishō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). Ordered by [Fenrir](Fenrir.md "Fenrir") to kidnap possessed Midgar Academy for Dark Knight students, he nearly captured a magically exhausted Claire Kagenou but was thwarted and killed by [Zeta](Zeta.md "Zeta").[[1]](#cite_note-V5C1-1)

## Appearance

## Personality

|  |  |  |
| --- | --- | --- |
| “ | It seems like this is my lucky day. I will be able to bring a great gift to [my master](Fenrir.md "Fenrir"). | ” |
| — Jean, Light Novel Volume 05 | | |

## Background

Jean was a Viscount who is the fourth company captain of the third group of Knight Order in Midgar Kingdom who joins the Cult of Diablos and is given the position of First Child until he receives Named, the Wicked Smile, also becoming part of the [Fenrir](Fenrir.md "Fenrir") faction.[CITATION NEEDED]

At one point around the time between 2 years ago, Jean briefly met Claire Kagenou who is a student at the Academy who was on probation in the Knight Order and investigated her because he was curious about her abilities which were considered quite impressive at the Midgar Academy for Dark Knights.[CITATION NEEDED]

## Chronology

### The Academy Disappearances

During the Academy's winter break, Jean was given the task by [Fenrir](Fenrir.md "Fenrir") to secretly kidnap Academy students who had symptoms of [Possession](Possession.md "Possession") and bring them to the [Sanctuary](Sanctuary.md "Sanctuary") so that they could be put into a tube to begin the releasing process of the Demon Diablos' right arm, but most of them failed due to Shadow Garden's interference so that the Cult was only able to capture 4 students.[CITATION NEEDED]

On the day of the Academy's new school year, Jean meets Claire Kagenou again when she is looking for a way out of the Sanctuary after defeating the ghosts of past heroes and intends to capture her with Jean continuously attacks Claire until she faints until suddenly Jean is hit by a strong attack from Claire looked like a red tentacle that he had never seen before from which that the attack even injured his cheek, causing the mask to disguise his face to be damaged and Jean's unveiled face was shown to Claire after seeing him.[CITATION NEEDED]

When Claire saw Jean's unexpected actions which even insulted his true identity of the Named Child as "Wicked Smile" in her heart when he revealed it, Jean also didn't expect that Claire had such an interesting power, even though previously she didn't have this much power which made Claire realized what he had said until Jean intended to investigate Claire further by capturing her alive.[CITATION NEEDED]

Still on the fight, Jean saw that Claire had run out of magic power when he realized that the red tentacles around her had lost their strength, until Jean, with a very dark and gloomy smiling expression just like his title name, felt that he was lucky because Jean thought he had caught Claire and then brought her before Fenrir as a great gift.[CITATION NEEDED]

While wanting to paralyze Claire, Jean was suddenly blocked by [Zeta](Zeta.md "Zeta"), who approached Claire through the cracks she had made and repelled Jean's sword attack with a strange black mist from which the impact of her extraordinary attack is so strong that it made Jean bounce, then threw Claire into the gap until the crack closed tightly as if it had disappeared which made Claire manage to get out of the Sanctuary, until leaving Jean and Zeta are the only one inside the subspace dimensional world.[CITATION NEEDED]

When Jean was preparing to come face to face with Zeta because her arrival had dared to disturb his mission until he asked if she is one of the higher ups of Shadow Garden, knowing her great strength and her expression which seemed quite confident, Zeta only replied to Jean about his awareness of the secret of Claire's red tentacles.[CITATION NEEDED]

With Jean firmly confirming the question regarding Claire's inner strength, Zeta, who had confirmed the answer, immediately directed her terrifying magic power at Jean, who himself did not expect her opponent's hidden magic power. Hearing Zeta's last words that Jean could be left alive if he didn't realize Claire's [secret](Aurora.md "Aurora"), Jean, who already knew the secret in question, felt that his body had received an unpredictable power until suddenly black tears came out of his eyes and then black mist came out from every hole in his body, until finally Jean's body exploded, leaving nothing behind and becoming black liquid.[[1]](#cite_note-V5C1-1)

## Powers & Abilities

Jean was the most powerful warriors as a Named Child, considering "First Children" who have provided exceptional contributions to the Cult.[CITATION NEEDED] Jean possessed stronger physical strength and magical powers compared to the average knight, from which the Cult granted him a name, also mentally stable.[CITATION NEEDED]

## Trivia

## References

1. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | [Loki](Loki.md "Loki") • [Hel](Hel.md "Hel") • [Jormungandr](Jormungandr.md "Jormungandr") • [Fenrir](Fenrir.md "Fenrir") • [Mordred](Mordred.md "Mordred") • [Petos](Petos.md "Petos") • Jack Nelson • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • Sir Gaunt | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • **Jean** • Dark Spider • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • [Gray](Gray.md "Gray") • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • Reina Oriana • [Isaac](Isaac.md "Isaac") | |

]]
