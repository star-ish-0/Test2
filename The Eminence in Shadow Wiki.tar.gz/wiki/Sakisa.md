# Sakisa

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sakisa](https://the-eminence-in-shadow.fandom.com/wiki/Sakisa)

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Sakisa?action=edit).

## Sakisa

### Japanese

サキサ

### Romaji

Sakisa

## Characteristics

### Race

Elf

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Black

### Eye Color

Red

### Birthday

Unknown

## Personal Information

### Status

Alive

## Debut

### Light Novel

Volume 7

Sakisa (サキサ[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the knight of [Otoutrion](Otoutrion.md "Otoutrion") in the war of succession. He is stated to have studied under Sword God about 100 years ago but no one remembers him.[[1]](#cite_note-1)

## Appearance

## Personality

## Chronology

## Relationships

## Powers & Abilities

## Trivia

## References

1. Volume 7 Chapter 4

## Site Navigation
