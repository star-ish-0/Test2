# Chi

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Chi](https://the-eminence-in-shadow.fandom.com/wiki/Chi)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Chronology](Chi-Chronology.md "Chi/Chronology")

[Relationships](Chi-Relationships.md "Chi/Relationships")

Image Gallery

## Chi

### Japanese

カイ

### Romaji

Kai

### Aliases

No. 22
Karen von Herzog
Shooting Star (Formerly)
No. 111 (Formerly)

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

23

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Emerald Green

### Birthday

May 4

## Personal Information

### Status

Alive

### Relatives

House Herzog (slain)

## Professional Information

### Occupation

- Numbers
- Matriarch of the Herzog Barony [Relinquished]
- Member of the Velgalta's Seven Blades (Formerly)
- First Children (Named Child) (Formerly)

### Affiliation

Shadow Garden
Mitsugoshi Company
Velgalta Empire (Formerly)
Cult of Diablos (Defected)

## Debut

### Web Novel

Chapter 30 (Mentioned)
 Chapter 186

### Light Novel

Volume 1 (Mentioned)
Volume 6 (Full Appearance)

### Manga

Chapter 66.2

### Anime

Episode 11

### Game

Seven Shadows Chronicles: Chapter 19

## Portrayal

### Japanese

Mayu Minami

### English

Kalin Coates

### French

Amandine Bataille

### Italian

Emanuela Cardani

Chi (カイ, Kai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Χί), formerly known as Karen von Herzog (カレン・フォン・ヘルツォーク, Karen fon Herutsōku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a member of Shadow Garden, being one of the Numbers. Once a Baroness and head of the Herzog Family, she was formerly one of the Velgalta's Seven Blades and a Named First Child of the Cult of Diablos, titled Shooting Star (流星（ながせ）, Nagase[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), until she defected to join Shadow Garden. She was initially codenamed No. 111 before rising to her current rank.

## Appearance

Chi is an elf with emerald-green eyes, an athletic build, and a modest chest. Chi has short, jaw-length blonde hair in an asymmetrical cut which has right-side directed curtain bangs, under which is a single, decorated braid reaching down to her collar. bone. As her bangs cover her right eye, this is due to her wearing a two-strap eyepatch, which conceals where the eye that was gouged out by Sergey Gorman.

As a member of Shadow Garden, she wears a dark slime bodysuit with subtle gold trimming to contrast her dark colors along her figure, providing a veiled opening at the sternum for ease of body temperature and a gold-edged chevroned collar. Her bodysuit also sports a stylized military-inspired jacket with wrist-length sleeves, with simple gold lined cuffs and minor frills at the cusp of the sleeves, compared to a rib length torso above a narrow belt. Her jacket's gold decorations include a short shoulder cape which reaches down to her posterior, adorned with golden shoulder pads to display her position among the Numbers. Her waistline has a guard lining around the femoral section of both legs, with both attachments tied by a V strapping to a strap around her upper thigh. Her boots are formed into a military design with two thick golden chevron cuffs, thin gold chevron lining at the cap-toe, golden lined midsoles between short-lifted outsoles at the heels of the boots. The design of her suit is near identical to Omega's, but her counterpart doesn't have a shoulder cape.

She sometimes decides to dress more in men's clothes, since according to her, it helps her to collect information in different details, other than what she likes as woman.

## Personality

Chi has a serious and stern demeanor but is surprisingly shy and blushes often. She was abandoned like the others in Shadow Garden when stricken with [Possession](Possession.md "Possession") and became loyal to their cause of destroying the Cult of Diablos.

Chi, formerly known as Karen von Herzog, was a former member of the Velgalta's Seven Blades. She was also a First Child of the Cult of Diabolos. When she was stricken with Possession, she ran to a remote village in the region of Madlid chased by another member of the Velgalta's Seven Blades, Sergey Gorman.

Chi, like Rose Oriana, has shown that she has a lot of pride and sentiment; thus, it hurts her a lot when said pride is trampled on. When she began her Physical Skills and Swordsmanship testing days, by fighting Alpha, as a test opponent, she believed that she could still stand out and assert her pride, as one of the Velgalta's Seven Blades. Alpha, despite being younger and seemingly possessing less magical prowess, managed to overcome Chi. Alpha explained to her that while Chi indeed held a formidable title due to her strong abilities and magical power, these attributes were only superior to knights and ordinary magical warriors. Upon hearing Alpha's remarks, Chi broke into loud sobs in the presence of all Shadow Garden members. She realized that the sole remaining aspect she held dear was now rendered useless, compelling her to discard her entire past and start anew.

However, later on, when she realizes the scope of her previous actions in the name of the Cult of Diablos. She began to regret everything she had done and became hellbent on setting things right. While active on Shadow Garden missions, Chi is steadfast in her duties, executing her objectives to their fullest, with the sole exception being when she is shown an exceptionally grewsome scene, at which she is known to lose her composure.

When Chi is in her civilian dressing, she is seen to be friendly toward citizens and her coworkers, [Omega](Omega.md "Omega") especially as the two are partners.

### Web Novel

Chi is a quiet person; she only responds to orders from her superiors with short sentences or only responds with nods. She behaved like that not because she was disobedient to her superiors, but because she was a social phobic person.

She experiences anxiety and fear in social interactions, as evident when Shadow issued a direct order and Chi responded by trembling in fear. However, Shadow swiftly alleviated this by softening the atmosphere, offering her advice in a comforting manner.

## Powers & Abilities

Before defecting to Shadow Garden, Chi was the most powerful warriors as a Named Child, considering "First Children" who have provided outstanding contributions to the Cult of Diablos which even earned her the title of Velgalta's Seven Blades. Thanks to her exceptional prowess and combat ability, Chi quickly rose through the ranks and making her one of the double-digit Numbers, which she is given a Greek name.

### Physical Abilities

Chi, like many before and after her joining, trained daily to improve upon her physical prowess. Such is necessary to be ready for a fight or to retreat to safety. This includes self-defense, martial arts, and strength training.

### Swordsmanship

Prior to the joining Shadow Garden, Chi had very strong magical and swordsmanship skills, being a "Named Children" of the Cult of Diablos.[CITATION NEEDED] Shortly after being rescued and healed by the members of Shadow Garden, After being retrained, Chi's abilities increased strongly, along in part with her use of magic, which made her one of the reasons why she was named, to the Numbers of Shadow Garden.

In the story of the Game, it is seen that Chi, when she was a member of the Cult, and one of the Velgalta's Seven Blades, of the Velgalta empire, Karen dominated in strong terms, the handling of the Spear.

### Magic

Chi is an expert in magic, as a former member of the Diablos Cult, and being a Named Child, she had great magic power, upon being cured of her possession, she gained strong control of magic, since she maintained her slime suit during the magic distortion effects of the Holy [Sanctuary](Sanctuary.md "Sanctuary") infiltration. Such is a requirement given Epsilon's renown within Shadow Garden for her refined magical control.

### Weapons and Equipment

- Slime Bodysuit: A standard issue in Shadow Garden, with Chi's having notable decoration to express higher rank and authority within the command structure compared to the rank-and-file.
- Slime Weapons:

## Trivia

- Chi (pronounced Kai) is the 22nd letter of the Greek alphabet (Xχ). This derivation was confirmed in a [director's tweet](https://twitter.com/yaduka301/status/1605584881190203393) about Chi's illustration—her official light novel debut is in Volume 6.
- Chi's character was mentioned before being officially debuted in the sixth light novel. [Nu](Nu.md "Nu") reported that a defector supplied information regarding the Cult in the first light novel[[1]](#cite_note-V1C5-1)
- Despite being women, Chi and Omega like to dress up as men occasionally. According to the two, this is so they can have other means of information gathering, unlike other Shadow Garden members. Although sometimes, they cross-dress their clothes for fun.[CITATION NEEDED]
- Various fan translations mistranslated Chi's sex and erroneously introduced her as a male. Her appearance in the anime helped clarify the confusion, and subsequent revisions occurred on some websites.[[2]](#cite_note-WNC187-2)[[3]](#cite_note-3)

## References

1. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
2. Web Novel: Chapter 187
3. Independently Verified by Staff

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • **Chi** • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
