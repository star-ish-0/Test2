# Akira Nishino

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Akira%20Nishino](https://the-eminence-in-shadow.fandom.com/wiki/Akira%20Nishino)

## Akira Nishino

### Japanese

西野（にしの）アキラ

### Romaji

Nishino Akira

## Characteristics

### Race

[Human](Human.md "Human") (Earthling)

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Black

### Eye Color

Black

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Unnamed Mother †
Unnamed Father †
Akane Nishino (Younger Sister)

## Professional Information

### Occupation

Scientist

### Affiliation

[Arcadia](Arcadia.md "Arcadia") (formerly)
[Messiah](Messiah.md "Messiah")

## Debut

### Light Novel

Volume 4

### Manga

Chapter 49

Akira Nishino (西野（にしの）アキラ, Nishino Akira[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the older brother of Akane Nishino and the head scientist of the human settlement [Messiah](Messiah.md "Messiah") in post-apocalyptic Japan.

## Appearance

Akira was a tall and slim man around in its late 20s to early 30s with medium-length dark blue hair and olive green eyes covered by black glasses.

He is described to wear an outfit consisting of a long-sleeved black shirt donned over his white coat per his occupation, long black pants, and a pair of shoes of the same color.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | You're guests of [Messiah](Messiah.md "Messiah") now. | ” |
| — Akira to Cid Kagenou, Light Novel Volume 04 | | |

Akira was the type of person who expresses his feelings through his facial expressions. When he didn't like something, he would put on an annoying face. He is actually friendly towards everyone, but on the contrary if he meets new people, he seems unfriendly.

Akira was an ambitious and unyielding researcher as he was shown to be obsessed with studying magic and unlocking its secrets and will do anything if that meant he can understand and control it. While a brilliant man, his intellect is overweighed by his arrogance. His belief that he can control any situation, especially the tampering of unpredictable magical energy caused him to completely ignore the potential consequences.

Despite claiming everything he had done was for the good of humanity, his condescending attitude towards others, his use of human test subjects, and the lack of remorse for the harm he caused proved otherwise.[[1]](#cite_note-V4E-1)

In short, Akira Nishino was a madman who would sacrifice anything and anyone to satisfy his scientific endeavors, even doesn't hesitate to use his own sister, Akane Nishino as a guinea pig for his experiment.

## Background

Akira Nishino born into the Nishino family and the brother of Akane. At some point in his life, prior to the death of Minoru Kageno in Cid's past life, Akira had punched him for meddling in his affairs causing the former to vow to vandalize Nishino University.

### The Birth of the Original Knight

At some point following Japan being invaded, Akira took part in a project at [Arcadia](Arcadia.md "Arcadia") to create warriors in battling the monsters using his younger sister, Akane Nishino as a test subject. The project succeeded and Akane gained magical abilities and became who people refer to as "The Original Knight". While the project was a success, he was not satisfied with the results and still experimented on his sister to further develop her powers. This however was backfired horribly as Akane lost control of her powers and she went on a rampage that destroyed Arcadia, killing many people in the process.

He decided to make her forget by burying the memory of her trauma of the event which caused by Akane deep inside her mind. The now amnesiac Akane and Akira fled and took refuge with another group called Messiah, whose base was set up at Nishino University.[[1]](#cite_note-V4E-1)

## Chronology

### Return to Earth

Akira is first seen reprimanding Akane for going out on her on but acknowledged what she was able to achieve at the abandoned hospital. With [Yuuka](Yuuka.md "Yuuka"), when Shadow and Beta (as Minoru and Natsume) woke up at the [Messiah](Messiah.md "Messiah") infirmary. There, the two determined that Minoru cannot recall his memories and Natsume is muted. It was decided that Akane and Akira took them under their care respectively with Akira running multiple experiments on Natsume under ulterior motives.[[2]](#cite_note-V4C5-2)

### Death

Later on, just when the alarm for a magical beast stampede went off, Akira panicked and assumed it was orchestrated by the Alliance while running off with the Brute's head and Natsume before Yuuka appeared and gun down the pair. Mortally wounded, Akira was shocked and surprised to see Natsume stood up and survive before looting the research facility. He assumed she was the spy for the Alliance before Natsume revealed herself as Beta of Shadow Garden before being left to ponder about, she meant before his death.[[1]](#cite_note-V4E-1)

## Abilities

Akira was just an ordinary human with no magical powers whatsoever. However, he has shown himself to be a genius scientist by Earth standards, capable of experimenting with magic and creating the "Original Knight".

## Relationship

### Akane Nishino

Despite being siblings, the two had a tense relationship. Any familial love he had for his sister was completely non-existent as not only did he use her power to gain political advantage but also experimented on her without hesitation.[[1]](#cite_note-V4E-1) When Akane went missing, Akira did not bother searching for her and instead went off to find a new test subject for his experiments.[[3]](#cite_note-V4C6-3)

### [Yuuka](Yuuka.md "Yuuka")

Fellow member of the Messiah and co-worker, Yuuka was aware of Akira's involvement in the destruction of Arcadia and vowed vengeance on him and his sister. Akira was unaware of Yuuka's undercover status for the Alliance until he alongside [Natsume](Beta.md "Beta") was gunned down by her.

### [Natsume](Beta.md "Beta")

After 'Natsume' was brought to Messiah by Akane, Akira took custody of the presumed "Awakened" person and was ecstatic to discover that she had even more magical potential than the "First Knight". While intending to experiment on her, he was mortally wounded by [Yuuka](Yuuka.md "Yuuka") before he got the chance. In his final moments, Akira was shocked when Natsume got up after seemingly being killed by Yuuka and looted his laboratory, introducing herself as [Beta](Beta.md "Beta") from Shadow Garden.

### Minoru / The Black Knight

Their interactions are few but however, Akira earned Shadow's ire in his past life when he punched him for meddling in his affairs and vowed to vandalize Sakurazaka University. However, this would not come to fruition due to the latter's death.

### [Mordred](Mordred.md "Mordred")

Akira found Mordred's severed head and intended to use it in his experiments by injecting Natsume with his blood. However, he was assassinated by Yuuka, who then stole the head, before he got the chance.

## Trivia

- The name Akira (アキラ) means "bright, clear, or intelligent" (明, 亮).
- Akira's surname Nishino (西野) means "west" (西) (Nishi) and "field, wilderness" (野) (no).

## Reference

1. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
2. Volume 4 Chapter 5: Sneaking Around in Japan, Just like the Old Days!!
3. Volume 4 Chapter 6: Something Smells Fishy... But an Eminence in Shadow Always Cracks the Case!

## Side Navigation
