# Zabra

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Zabra](https://the-eminence-in-shadow.fandom.com/wiki/Zabra)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Zabra?action=edit).

## Zabra

### Japanese

ザブラ

### Romaji

Zabura

### Aliases

Leaf Four

## Characteristics

### Race

[Therianthrope](Therianthrope.md "Therianthrope") (Wolf Therianthrope)

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Black

### Eye Color

Purple

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

- Unnamed Father
- Sara (Younger Sister) (Killer)
- Unnamed Hundreds of Siblings

## Professional Information

### Occupation

Assassin

### Affiliation

Major Corporate Alliance
[Clovers](Clovers.md "Clovers")

## Debut

### Web Novel

Chapter 119

### Light Novel

Volume 3

### Manga

Chapter 35

### Anime

Episode 24

## Portrayal

### Japanese

[Taito Ban](https://en.wikipedia.org/wiki/Taito_Ban "wp:Taito Ban")

### Italian

[Jacopo Calatroni](https://en.wikipedia.org/wiki/it:Jacopo_Calatroni "wp:it:Jacopo Calatroni")

Zabra (ザブラ, Zabura[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), also known as Leaf Four (四葉（よつば）, Yotsuba[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was [Delta](Delta.md "Delta")'s older brother and a member of the [Clovers](Clovers.md "Clovers"), a small personal group under the Garter Corporation.

## Appearance

In the manga, Zabra was a young adult [Therianthrope](Therianthrope.md "Therianthrope") Wolf male with short black hair and long dog ears. He adorned a black-hooded assassin outfit and had three scars on his face in the shape of a claw mark, marking him as a member of the Clovers.

In the anime, he wears a matching green tank top and pants with a black leather belt that wraps all around his waist and left thigh. He also wears a dog tag neck chain, massive weighted gauntlets with knuckle dusters and a zigzag hairclip on his tail as accessories. In terms of physique, Zebra is taller, more muscular with visible abs and lacks the scar marks.

## Personality

Zabra seemingly looked like a vicious assassin at first. However, when backed into a corner, he would reveal his true, cowardly personality and desperately beg for mercy. This sheer cowardice was an oddity amongst Therianthrope, who would be more than happy to die fighting to the last breath.

In his final mission as an assassin, Zabra was envious of his younger sister who became stronger than him and had the best chance at being the next chieftain of their tribe.

## Chronology

### Great Trading Company Conflict

Zabra and his men were ordered to attack Mitsugoshi Company's carriage under the guise of bandits. But before commencing, they were attacked by assailants resulting in all of their deaths except him. Zabra recognized [Delta](Delta.md "Delta") as his long-lost sister, Sara, and tried appeasing her. He desperately tried to use their familial connection to bargain for mercy and he suggested her to become a concubine for the "Legendary Wolf" [Gettan](Gettan.md "Gettan"), but this only sealed his fate as this moment of weakness was considered a taboo among their tribe. As his efforts to save himself didn't work, Delta executed him without hesitation.[[1]](#cite_note-V3C4-1)

## Relationships

### Sara

In the past, Zabra was envious of his younger sister's strength. Upon reuniting years later when she ambushed his squad, he would bargain for his life by having her reinstated into their tribe although this was an empty promise. However, Sara became enraged by his cowardice and killed him, stating that she does not need a "weak brother" as a result of their family's law that the weak must die and might makes right.

## Trivia

- Zabra originally held the fourth position according to his debut appearance in the novels and anime, unlike in the manga where he holds third place in [Clovers](Clovers.md "Clovers"), switching places with the current Leaf Three.[ZABRA MANGA ONLY][[2]](#cite_note-MC35-2)
- Zabra's fan-translated name in the Web Novel, "Olé" in japanese is オレ (Ore), which means “me”.
  - Zabra's web novel name "Olé" is a Spanish interjection used to cheer on or praise a performance commonly used in bullfighting and flamenco dance.

## References

1. Volume 3 Chapter 4: I'll Destroy It All and Start from Scratch!
2. [Manga](Manga.md "Manga"): Chapter 35

## Site Navigation
