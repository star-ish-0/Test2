# Rose Oriana/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Rose%20Oriana/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Rose%20Oriana/Relationships)

Main

Chronology

Image Gallery

## Family

### Raphael Geerk Oriana

Raphael was the father of Rose and the recent king of the Oriana Kingdom, who Rose deeply loved and admired. Yet with Oriana Kingdom's cultural disdain for swordsmanship notwithstanding, Rose's decision to enroll in the Midgar Academy for Dark Knights did not change his adoration for her.[[1]](#cite_note-1)[[2]](#cite_note-2) Upon discovering that her father had been brainwashed into a puppet by Duke Perv Asshat, Rose attacked the perpetrator but failed, fleeing until she could find a way to save her father. However, once she understood that Raphael would be forced to cause a war between Oriana and Midgar, Rose regretfully had to mercy kill her father.

After doing so, Rose's immeasurable guilt had led to constant nightmares about him hating her. Her guilt dissipated after learning how much Raphael loved her and the sacrifices he made to ensure her safety from the Cult of Diablos. Rose vowed to continue her father's mission and purged the cult from the kingdom.

### Reina Oriana

Rose was very protective of her mother, even going so far as to defect from Shadow Garden when the Cult of Diablos seemingly took her mother as a hostage. Unfortunately, she became heartbroken when she learned that she was one of the Cult's collaborators. Still, Rose was horrified when she witnessed her mother be cut down by [Mordred](Mordred.md "Mordred") before the cult leader began his attempted cover-up.

## Shadow Garden

### Cid Kagenou / Shadow / John Smith

Rose is deeply in love with Cid Kagenou. When they first met, she started to develop a deep respect for his perseverance during their candidacy battle for the Bushin Festival in spite of the injuries he had seemingly received unaware they were faked injuries. During the terrorist attack, he quickly interceded an attack meant for her, and she cried after Cid's perceived death, which she interpreted as an act of his love for her. After the attack ended, she learned that he was still alive and ran straight to his hospital bed to hug his hand while thanking him for saving her. This was the impetus for her harboring romantic feelings for Cid, as she stated he earned her love.

Since then, Cid became one of Rose's most important emotional motivations, as she constantly showers him with affection and holds his hand, ignorant of his attempts to shake her. She also works hard to show everyone, including her father, of Cid's worth as her betrothed. After joining Shadow Garden, she was not as fazed that her clothes were torn compared to when Cid's "gift" was destroyed in front of her eyes, emotionally damaging her. During the Civil War in Oriana Kingdom, when a depressed Rose was forced to marry Perv Asshat, Cid was once more the one that inspired Rose to rebel as he had left the Black Rose key in her room which she mistook for a proposal ring.

As for his Shadow persona, Rose had long admired him ever since she encountered him as a child when he rescued her from kidnappers, which also developed her love for swordsmanship. Her admiration increased when she listened to Shadow's playing Moonlight Sonata as she fled her pursuers. When Shadow prevented her suicide attempt in the Bushin Festival, she thoroughly believed that Shadow was the hero, "the sole light" as he were, fighting for justice against the Cult's darkness.

At the Bushin festival, after Shadow had saved her from Chancellor Perv's men, Rose recognized that she had met him before in their childhood as he had saved her from bandits under the alias "Fancy Bandit Slayer." Shadow, himself expressed some surprise they met before, It was that rescue which motivated her to get stronger to defend herself and his beautiful sword style which inspired her to take up the sword for her art form. After abandoning Shadow Garden, Rose regretted never repaying Shadow's goodwill but was surprised when he tried helping her, which revealed her mother's treachery and sparked her resolve to lead her nation to betterment. Following the Oriana Kingdom Operation, Rose briefly deduced that Cid was Shadow, but ultimately refuted her conclusion as her overthinking things, but may have likely figured it out had she stayed in service under Shadow Garden.

After her mother's betrayal and Oriana's civil war, despite being blamed for everything and losing her entire family, Rose stated that the only thing left in her life was her love for Cid Kagenou, without fully elaborating such to the public. While she still had that and until Rose can mature, Cid would become the only motivation giving her the strength to continue.

Although, despite her love for Cid, she doesn't really know him, nor him her, as both almost entirely misunderstand each other; as Rose misinterpreted Cid's whims to "look cool" or be the first nobody to die by taking a hit intended for her, as signs of admirable willpower and love for her. Meanwhile, he misinterpreted her musings of their rocky path as lovers to be her attempt to convert him to her religion, and believed her mercy killing her father was actually her making ruthless grab for power. As Rose reclaimed her self-assurance to be a just ruler of her land, with a strong goal of one day marrying Cid, he believed that she was on the path to becoming a bloody tyrant that he would enjoy killing to be a shocking twist to the "main characters."

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

Like the rest of the numbers, Rose is respectful of Alpha due to the elf's leadership and providing Rose the chance to challenge the Cult of Diablos. Having a respectful subordinate-master relationship, Alpha holds Rose in high esteem because she believes that Rose is a fundamental piece in Cid's plans against the cult. This is in part due to Shadow gifting Rose a part of his power, a blessing only eight others received before her. After reclaiming Oriana Kingdom from the Cult, Rose struggled to restore order and stability for the public and was beyond grateful for Alpha's covert commands to supply the citizens by way of the Snow Fox Corporation. While Oriana was branded as a heretic state, Alpha reassured Rose of her nation's security, attesting to Shadow's design to save her people, and swore the Cult's destruction to continue Shadow Garden's pledge to Rose.

#### [Beta / Natsume Kafka](Beta.md "Beta")

Rose first met Beta in her public persona as Natsume Kafka, Rose's favorite author. Rose admires Beta's Natsume persona and the original stories she's published in her short career. The two would form an alliance after the Sanctuary revelations with the Cult's origins, but Beta has yet to reveal her true identity. This is evident as Beta would hide her face when leading 664, 665, and 666 (Rose) during the Red Moon Incident into the Crimson Tower to research vampire progenitor blood and demon possession. Rose also trusts Beta as a senior, listening to her guidance during the confrontation with Mordred amid the Black Rose activation.

#### [Gamma / Luna](Gamma.md "Gamma")

Rose frequented the Mitsugoshi Company stores and associated restaurants as they are popular within the youth circles of royal peerage from Midgar to Oriana and beyond. Following the encounter with John Smith, Rose as 666 reported to Gamma and Alpha, indicating Rose is privy to Mitsugoshi being a public front for Shadow Garden. While their relationship isn't well explored, it can be deduced that Rose has respect for Gamma given her business acumen, intelligence, and leadership prowess as Alpha's sub-commander.

#### [Delta](Delta.md "Delta")

Upon witnessing her fight, Rose came to feel only pity for the [Therianthrope](Therianthrope.md "Therianthrope")'s opponents. While in Shadow Garden, Rose only knew Delta was among the executive ranks of the organization but had little to no interaction.

#### [Epsilon / Shiron](Epsilon.md "Epsilon")

Before joining Shadow Garden, Rose had immense respect for Lady Shiron, the revered and acclaimed pianist and composer. This is due to Shiron's original music like Moonlight Sonata, the Turkish March, and more. After joining Shadow Garden, she was not aware that Shiron was Epsilon's public persona, as she was astonished that Cid became her "apprentice" and pondered what he must have done to achieve such an honor. Working under Epsilon, Rose was lied to about her mother's safety as they didn't want to burden her, and both were shocked to learn Reina Oriana was a Cult's conspirator. However, after Shadow showed her the truth and taking a few days to process, Rose didn't not hold the decision against Epsilon. During the Black Rose incident, Rose fought alongside Beta and Epsilon, heeding her senior's guidance as they worked together to battle Mordred and the minion beasts of [Ragnarok](Ragnarok.md "Ragnarok").

#### [Eta](Eta.md "Eta")

Rose's interactions with Eta are not well-known, and she likely is unaware of Eta's lacking a concept of empathy. Given her relationship with the other Seven Shadows, Rose likely knows the Seventh Shadow heads research and development, given the data compiled from the Crimson Tower and the many advanced technologies she produced from the Shadow Wisdom. Rose also learned Eta designed the construction for most, if not all, of the properties for Mitsugoshi and Shadow Garden.

### Numbers

#### [Lambda](Lambda.md "Lambda")

Rose learned her combat under Lambda, who emotionally devastated Rose by destroying Cid's wrapper. Rose's combat skill grew exponentially due to her endowment by Shadow and Lambda's instruction, utilizing Lambda's training as 666 on missions. While Rose likely held some initial resentment over the wrapper, she more so respects Lambda's tutelage as she gave Rose the strength she needed.

#### [Nu](Nu.md "Nu")

Nu's service as Gamma's direct subordinate had her relay commands to 664, 665, and 666 for their mission to investigate the counterfeit bills in the capital. Rose's interactions with Nu were limited, but it can be inferred that Rose respects her while not fully knowing her character.

### Members

#### [Victoria](Victoria.md "Victoria") (559)

Victoria was Rose's superior during the first Oriana Kingdom operation, as well as another saved directly by Shadow. They did not get along from the beginning, mostly due to Victoria's distain of her and uncertainty as to why Shadow gave his power to Rose. This eventually culminated in Victoria branding Rose a "traitor" when she deviated from the mission to save her mother, to which Rose retaliated with criticism of Victoria's leadership, citing that she did not even bother to explain their objective and 559 charging into battle to take whatever the Cult had seized. Ultimately, their animosity was one of the reasons for the operation's failure. While Rose was a hostage in Oriana, Victoria did whatever she could to petition Shadow to kill Rose, but Shadow refused her and instead revealed the Queen's treachery to Rose.

After Perv Asshat and Mordred's death, Victoria nonetheless gave Rose another chance, but warned the new queen that she would kill her should she complicate their mission again. With the reconstruction of Oriana Kingdom underway, the pair resumed their relationship in a manner more opposing than originally antagonistic. Rose is unaware of Victoria's membership in Zeta's splinter faction.

#### [664](664.md "664") & [665](665.md "665")

Following her induction into Shadow Garden, Rose was assigned to a team that comprised herself, 665, and 664; the lattermost being assigned as the team leader. She developed a close camaraderie with her teammates, working well during their time together, if not on a rocky start due to Rose's rushing through some missions. Rose was later overjoyed that the two came to her aid in protecting the Oriana Kingdom from the magical beasts emerging from the Black Rose phenomenon. After Rose became the new queen of the Oriana Kingdom, 664 and 665 were sent by Shadow Garden to serve as her bodyguards, disguised as maids. Like Rose, her teammates share a negative view of Victoria.

## Friends

### Alexia Midgar

Due to their royal backgrounds, Rose and Alexia usually get along and tend to have a friendly relationship, this has led them to form an alliance in order to protect the people who are important to them-- along with Natsume. They are unaware that they are really love rivals for Cid.

When Rose fought against Alexia when she and Natsume were looking for her, Rose realized that Alexia was influenced by Shadow after seeing that she was copying his sword technique. This made Rose love Alexia in the end, and she had to defeat her friend with sheer magical force.

With Oriana branded a heretic state, it is unlikely the two will be able to reunite in the near future.

### [Margaret](Margaret.md "Margaret")

Margaret was Rose's personal maid. The two were very close since childhood. However, their friendship took a negative turn when Margaret learnt that Rose had murdered her father, which led to their kingdom undergoing a civil war. She had despised Rose ever since but continued to serve her as her maid when she returned to Oriana.

Their friendship was restored after Margaret learned the full truth of Rose's actions, the reasons behind the king's declining health, and the princess coming to her aid to protect her from a Magical Beast. Margaret tearfully apologized to Rose and wished to resume their friendship.

## Cult of Diablos

### Perv Asshat

Rose was hesitant to have Perv as her fiancé and tried to petition her father for Cid instead. Finding Perv brainwashed her father, Rose's uncertainty turned to hatred upon this discovery. By wearing the ring Cid "left" for her, which was the king's last will in a hologram recording, Rose exposed Perv's malicious acts and cleared her name to the audience in attendance.

### [Mordred](Mordred.md "Mordred")

Rose had originally heard of Mordred from the intelligence reports within Shadow Garden, knowing he was the Ninth Seat of Rounds and held incredible power. When she met him during the Black Rose event, Rose learned about Mordred's involvement with her father's deterioration. She also learned that he had manipulated the Oriana Kingdom for the Cult's machinations, from Alpha and Beta. As such, Rose held incredible hatred for Mordred. When the fighting concluded, Rose was satisfied when Shadow ended Mordred and worked to legally undo what she could regarding the Cult's influence in Oriana.

## Others

### Iris Midgar

Their interactions were few and brief, but due to her status as Student Council President and royal background, Rose was the only known witness Iris spoke to when the Academy was terrorized by Cult members posing as Shadow Garden. Her testimony confirmed both organizations existence and forced Iris to investigate them and ponder whether Shadow is an enemy or not. During the Bushin Festival, Iris was suspicious of Duke Perv Asshat.

### Claire Kagenou

The two encountered each other when Cid was held for interrogation for a week and Rose had to stop Claire from causing destruction trying to free her brother.

## References

1. Volume 2. Chapter 7: Showing Off a Smidgen of My Strength!
2. Volume 4. Chapter 3: Crashing the Ceremony
