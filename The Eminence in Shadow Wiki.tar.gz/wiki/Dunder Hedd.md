# Dunder Hedd

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Dunder%20Hedd](https://the-eminence-in-shadow.fandom.com/wiki/Dunder%20Hedd)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Dunder_Hedd?action=edit).

## Dunder Hedd

### Japanese

デクノ・ボウ

### Romaji

Dekuno Bō

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Earl Haushold Hedd † (Father)

## Professional Information

### Occupation

Midgar Academy Student

### Affiliation

Midgar Academy for Dark Knights
Thirteen Nightblades

## Debut

### Light Novel

Volume 5 (Unnamed)
Volume 6

### Manga

Chapter 69

Dunder Hedd (デクノ・ボウ, Dekuno Bō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), was a nobleman of the Midgar Kingdom.

## Appearance

## Personality

## Chronology

### The Midgar Academy Mist Terrorist Attack

### Bloody Midgar Serial Murder Terror

## Relationships

### Earl Haushold Hedd

### Eliza Despoht

## Powers & Abilities

## Trivia

## References

## Site Navigation
