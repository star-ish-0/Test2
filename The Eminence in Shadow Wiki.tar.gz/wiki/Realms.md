# Realms

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Realms](https://the-eminence-in-shadow.fandom.com/wiki/Realms)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Realms (魔界（まかい）, Makai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the name referred to all parallel worlds that exist outside the world where Cid Kagenou and the others live, where there are countless other worlds beyond entire other dimensions.

## Overview

Countless worlds, known as Realms, orbit a central point akin to a star system or galaxy, with Cid's world being among them. These Realms vary greatly, encompassing worlds of ice, poison, and flame, a desolate world devoid of light and color, and worlds inhabited by monsters. All worlds, except for the one where Cid resides, are collectively referred to as the Realms.

As each world rotates at varying speeds over the years, there are times when worlds may collide, sending shockwaves across them. These collisions can link two different worlds, allowing them to exert influence over each other.

The existence of monsters and magic in Cid's world is due to a collision with a demon world 10 million years ago, which allowed monsters and magical powers to seep into their world. This event also gave rise to the concept of being spirited away, as it caused inhabitants to drift into other realms.

In Cid's previous life, the real world was not spared from chaos; the incursion of monsters and the influx of magical power resulting from the clash with the demon world led to the downfall of Japan and the wider world. Consequently, Akane Nishino and others residing in Japan acquired magical abilities due to the monster invasion.

In the concept of parallel worlds, "hell" is categorized from minor to major. The closer one of these worlds is to the central point around which they revolve, the greater the level of danger and threat posed by the creatures that inhabit and rule it.

## History

The Cult of Diablos conducted a geological survey and discovered that 10 million years ago, dragons ruled the world, which was devoid of magic. However, a collision with a magical realm resulted in magic infusing their world, drastically affecting the ecosystem. Unable to adapt to magic, dragons declined, and humans, who could harness magic, prospered in their stead.

The Cult's theory posits that their world and the Realms interact cyclically and exert mutual influence. They have observed that beings from other Realms, such as Magical Beasts, are essentially animals from another world that have evolved due to magic. These beasts operate on a logic fundamentally different from ours, defying all natural laws. This suggests that magical beasts may not be the only foreign entities in their world. Consequently, there are numerous mysteries surrounding all species on the planet, and the Cult's theory even suggests that humans may not be native to this world, possibly originating from another Realm.

## Background

When the Cult of Diablos noticed that the "Black Rose" had accidentally opened, unleashing magical beasts upon the Oriana Kingdom during the Velgalta Empire's siege, it was an unfortunate turn for both nations. Realizing that the "Black Rose" was a portal connecting their world to other realms, the Cult of Diablos intervened, closing the gate and saving the Oriana Kingdom.

Under the Cult's stewardship of the "Black Rose," a pact was formed to ensure the perpetual survival of the Oriana Kingdom. In exchange for fair compensation, the Cult would receive "Royal Blood" and a significant portion of the kingdom's tax revenue. This led the Kingdom to invest heavily in the arts to entertain the Cult. Additionally, the Cult manipulated the Church to persecute Dark Knights, preventing Oriana from amassing the strength and manpower to rebel, effectively turning it into a puppet kingdom.

## Known Realms and Rulers

- [Earth](Earth.md "Earth")
- Other World
- First Realm - Diablos
- Fourth Realm - [Ragnarok](Ragnarok.md "Ragnarok")
- Twelfth Realm - [Nidhogg](Nidhogg.md "Nidhogg")

## Trivia

- Cid Kagenou had lived fifteen years after his reincarnation but it was only three years since Minoru's death when he returned to Earth in Volume 4, meaning time passes by five times slower than on earth.
- According to [Mordred](Mordred.md "Mordred"), although the Cult of Diablos was investigating the "realms", neither do they know how many parallel dimensions there are, or who lives in the center of this rotation of parallel worlds as Mordred even believes that the plane of the Gods lives in the center of this rotation.[[1]](#cite_note-V4C3-1)
  - Also, the parallel worlds revolve around many "realms" above, the world where they and the rest of the races live, that is, many demonic worlds, among other worlds that are not.
- According to what is understood, although the other world is in a higher position than the others, according to the members of the Cult of Diablos, this at the same time, became a type of central crossroads, between the other worlds, since although its The world is far from the others, since they are rotating and changing position one from the other, it is possible to be able to see or even travel to parallel worlds closer to the center, than you think and vice versa.
- From the names of the rulers that have been known so far, it seems likely that the Cult of Diablos named the rulers based on Norse Mythology and there would likely be other Mythologies.

## References

1. Volume 4 Chapter 3: Crashing the Ceremony!

## Site Navigation
