# Light Novel/Volume 4

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%204](https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%204)

## Light Novel Volume 4

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Touzai

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4047358782

### ISBN EN

ISBN 978-1975341848

### Release Date

February 26, 2021 JP
June 7, 2022 EN

## Volume Information

### Pages

384 JP
282 EN

### Chapters

9

## Adaptations

### Manga

Volume 10, Chapter 40 - Volume 14, Chapter 55

### Anime

Episode 1 & Episode 29 - Episode 32

Publication Order

| Previous | Next |
| --- | --- |
| Volume 3 | Volume 5 |

This is the fourth volume of the light novel series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

THE DOOR OF DARKNESS IS CAST OPEN—THE WORLD ADVANCES TO A NEW FIELD

The specter of war hangs thick in the air of the Oriana Kingdom, where Princess Rose is expected to wed Duke Perv. This supposed marriage cannot and will not stand, though, as it would throw a major wrench in a certain shadowbroker’s plans. Not one to miss an opportunity for sleuthing, Cid makes his way to the royal capital to put a stop to the ceremony, but are there even bigger schemes at work behind this unholy matrimony?[[1]](#cite_note-1)

「風がーー泣いている」　シリーズ累計100万部突破!!

父を殺め、国に背いたローズは、母・レイナ王妃を守るため、ドエム公爵の軍門に下った。
戦争の気配が濃厚に漂う芸術の都・オリアナ王国では、ローズとドエムの結婚が噂されている。

「許さんーーッ」

結婚なんて絶対にさせない。
たとえ親が許しても、僕が許さない。
なぜなら……

「ローズが『覇王』になれば僕の『陰の実力者』プレイが捗るのだから!!!!!」[[2]](#cite_note-2)

## Summary

### Oriana's "Black Rose" Civil War Wedding Incident

During a mission in her home country, Rose Oriana finds out her mother is a hostage to Duke Perv, abandoning her mission and comrades from Shadow Garden and is then forced to marry him. Once Cid hears that she's getting married to Perv, he gets annoyed and frustrated that she will be handing over the throne to him once they get married and goes to confront her over her reason to marry. For that, he infiltrates the Oriana palace by playing the part of a music student of Epsilon, who has been acclaimed as a genius musician in Oriana by playing some of the songs taught to her by Cid.

Once inside, Cid is stopped by Perv who questions his identity and requests that he play a song on the piano to confirm his identity as the genius musician apprentice. He then plays Moonlight Sonata and awes every single person in the venue. Before leaving he steals a ring Perv kept in his pocket inside a box, planning to sell it to earn money.

Cid, as Shadow, saves Victoria, Shadow Garden member 559, the only other member of Shadow Garden directly helped by Cid, aside from the 7 Shadows and Rose Oriana. Victoria reports that Rose Oriana, operative 666, has betrayed them.

He then finds Rose by asking her maid, who wanted to garner favor and recruit him as a musician to her household, and questions her about what they talked about before. Cid tries to convince her by mentioning his often-undermined dream (being an eminence in shadow) while Rose believes he is speaking of their future together, to which she cries and sends him out. Soon after, Perv shows up, once more reminding her of her mother's hostage situation and threatening her. They leave and Cid silently drops from the ceiling, having heard the entirety of the situation. Going to investigate, he finds out the truth: her mother wasn't a hostage, but Perv's lover and also participated in poisoning the king. Cid then appears to Rose as Shadow, showing her the truth. Rose, unable to take it, collapses. Once she wakes up, she is confused and feels betrayed but manages to recompose herself thanks to Cid playing Moonlight Sonata for her at her Window and supporting her. Cid leaves, and Rose picks up something left at the place he was, assuming he left it for her: Perv's Ring.

Back with Epsilon, Cid contemplates where he lost the ring, regretting not being able to make money out of it.

At the wedding, Rose says she does not accept Perv as her husband, claiming to know the truth, and wears the ring Cid gave her. A projection from the late king Oriana is shown, surprising everyone. The ring was a key to a "weapon" that permitted Oriana to win an impossible war in the past, it belonged to the Oriana Royal Family and was being searched for by the Diablos cult, which acquired it after controlling the king. The king reports that he is being poisoned and will fall at the hands of the hidden enemy(cult), implicating that even his wife may be involved, and entrusts the Oriana Kingdom's future to Rose.

After the Ragnarok is activated, Mordred, the 9th seat of the cult, eliminates Perv, who messed up and fights the members of Shadow Garden. Shadow faces the Giant Bat (Demon King?) of another dimension called Hell. Shadow manages to kill it without injuries aside from a little burnt hair, saving Oriana. After the bat's death, Mordred absorbs his power. Shadow kills him and a dark portal opens up. Shadow "entrusts his body to darkness" going inside the portal, followed by Beta.

### Return to Earth

The portal closes and Cid, who wanted to say something cool while disappearing and jumped in the portal, and Beta, who followed him, find themselves in a post-apocalyptic Japan, years after Cid's past self, Minoru Kageno's death. Cid makes brief stop to his old home, where he finds it in ruins. Remembering that both his parents lived in the US with his dog, he is relieved they might be okay. Cid pretends to have learned Japanese in a matter of seconds after arriving in Japan, astonishing Beta. Cid realizes he is in danger of Beta learning of his old life. They're attacked by monsters, easily defeating them. After detecting human life nearby, they pretend to be unconscious.

The group of humans who found him is led by Nishino Akane, Cid's former schoolmate whom he rescued from kidnapping as the Stylish Bandit Hunter Slayer with a crowbar. It has been 3 years since Cid's death, and it was revealed that, for some reason, Akane blamed herself for it. Also, she and Cid appeared to have had a more complex relationship, where they knew deep secrets about each other, such as Cid's secret life as a bandit hunter. In the infirmary, Cid tells Beta to pretend to be mute and not able to comprehend words, which she couldn't. Akane's older brother, the chief researcher who studies Awakening, the phenomenon called demonic possession in the other world, offers to help treat her condition. Cid tells her to keep an eye on him. In a matter of days, Beta manages to learn the language, as well as to use technological devices to the point that she's able to converse almost perfectly, despite her not-so-perfect accent. Meanwhile, Cid plays the role of a weak boy with amnesia, Minoru, who gets helped and protected by Akane. Akane protected him because he reminded her of Cid and was reminded of her guilt regarding his death and that she couldn't forget him. An invasion occurs, and Cid becomes Shadow and slays the monsters easily. Everyone is dumbfounded. There was a spy in the group, it was the doctor who lost her husband due to Akane and her brother. Looking for revenge, she infiltrated the base and helped their enemies. She kills Akane's brother and causes her magic power to go berserk, being killed in the process with Akane becoming a monster guided by destructive instincts. Shadow stops it. When she is about to fall unconscious, Cid says: "Be careful not to be kidnapped next time" and she realizes her Minoru is still alive and saved her. Beta finds a way to go back home, using Mordred's head to open the portal once more. Cid goes back. Beta tries to take the computer and electronics with her to the other world, but the portal is too small to pass the huge bag she is carrying. She then decides to take Akane instead, so that she would help her reproduce the technology over there, leaving everything and shoving Akane in the bag.

## Chapters

Note: The chapter count does not include the Appendix, which contains character profiles and 'The Chronicles of Master Shadow Complete Version: Volume 4.'

- Prologue: It's Time for a War in the Oriana Kingdom!
- Chapter 1: Putting the Kibosh on Rose Oriana's Wedding!
- Chapter 2: Begin Operation: Obstruction!
- Chapter 3: Crashing the Ceremony!
- Auxiliary Chapter: Rise of the Fancy Hoodlum Slayer!
- Chapter 4: Lurking in the Darkness in Fantastical Japan!
- Chapter 5: Sneaking Around in Japan, Just like the Old Days!!
- Chapter 6: Something Smells Fishy... But an Eminence in Shadow Always Cracks the Case!
- Epilogue: Behold, a Full-Fledged Eminence in Shadow!
- Appendix

## Characters

:   In order of appearance:

- Rose Oriana (No. 666)
- [No. 664](664.md "664")
- [No. 665](665.md "665")
- [No. 89](89.md "89") (Mentioned)
- [Victoria (No. 559)](Victoria.md "Victoria") (Debut)
- [Kouadoi](Kouadoi.md "Kouadoi") (Debut)
- Reina Oriana (Debut)
- Cid Kagenou
- [Delta](Delta.md "Delta") (Mentioned)
- [Marie](Marie.md "Marie")
- [Epsilon](Epsilon.md "Epsilon")
- Perv Asshat
- [Margaret](Margaret.md "Margaret") (Debut)
- Earl Parton (Mentioned)
- Marquis Newwealth (Mentioned)
- [Kevin](Kevin.md "Kevin") (Debut)
- Raphael Geerk Oriana (Projection)
- [Mordred](Mordred.md "Mordred") (Debut)
- [Beta](Beta.md "Beta")
- [Ragnarok](Ragnarok.md "Ragnarok") (Debut)
- [Aurora](Aurora.md "Aurora") (Mentioned)
- [John](John.md "John") (Mentioned)
- Akane Nishino (Debut)
- Akira Nishino (Debut)
- [Yuuka](Yuuka.md "Yuuka") (Debut)
- Vice Commander Yuudai Saejima (Debut)
- [Commander Haitani](Haitani.md "Haitani") (Debut)
- [Alpha](Alpha.md "Alpha")
- [Zeta](Zeta.md "Zeta") (Mentioned)
- [Eta](Eta.md "Eta") (Mentioned)

## Illustrations

- [English](#)
- [Japanese](#)

Table of Contents (EN)

Title Page (EN)

Victoria’s Profile (EN)

No.665 & No.666’s Profile (EN)

Minoru Kageno’s Profile (EN)

Akane Nishino’s Profile (EN)

Victoria’s Profile (JP)

No.665 & No.666’s Profile (JP)

Minoru Kageno’s Profile (JP)

Akane Nishino’s Profile (JP)

## Trivia

- From Volume 4 onwards, the story of the light novel is different from the web novel.

## References

1. [YenPress. The Eminence in Shadow, Vol. 4 (light novel) (EN)](https://yenpress.com/9781975341848/the-eminence-in-shadow-vol-4-light-novel/)
2. [Kadokawa. The Eminence in Shadow 04 (JP)](https://www.kadokawa.co.jp/product/321909000343/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • **Volume 4** • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
