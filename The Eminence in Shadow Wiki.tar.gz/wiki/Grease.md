# Grease

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Grease](https://the-eminence-in-shadow.fandom.com/wiki/Grease)

|  |  |  |
| --- | --- | --- |
| “ | Even if your gang of twats becomes stronger, you’ll never defeat them. The darkness of this world… is a deeper abyss than your wildest dreams! | ” |
| — Grease, Light Novel Volume 01 | | |

## Grease

### Japanese

オルバ

### Romaji

Oruba

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Late 30s

### Height

Unknown

### Hair Color

Gray

### Eye Color

Blue

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

[Millia](Millia.md "Millia") (Daughter)

## Professional Information

### Occupation

- Viscount
- Royal Guard (Formerly)[[1]](#cite_note-V1C1-1)

### Affiliation

Midgar Kingdom
Cult of Diablos

## Debut

### Web Novel

Chapter 5

### Light Novel

Volume 1

### Manga

Chapter 2

### Anime

Episode 2

## Portrayal

### Japanese

[Rikiya Koyama](https://en.wikipedia.org/wiki/Rikiya_Koyama "wikipedia:Rikiya Koyama")

### French

Emmanuel Gradi

### Italian

Ruggero Andreozzi

### German

Stefan Lehnen

Grease (オルバ, Oruba[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a Viscount who used to be a Royal Guard of Midgar Kingdom and a secret member of the Cult of Diablos, who joined the organization to get a cure for [his daughter's](Millia.md "Millia") condition. He was later killed by Shadow, after abducting Claire Kagenou.

## Appearance

Grease was a middle-aged man in his late thirties with a piercing gaze and a well-built body as he wore aristocratic clothing with his gray hair slicked back.[[1]](#cite_note-V1C1-1) In the anime, he wears a black cape under his clothes.

After taking the drug, his body size had doubled in size with the amount of magic in his body exponentially increasing which made his skin turn black, his muscles bulge, and his eyes glow red.

In the Manga after taking one pill, Grease's muscles increased and his veins were visible all over his body to the point where all other clothes except for his shirt, pants and boots were torn. After taking two pills his muscles grow bigger and his shirt would rip, but his pants and boots would still remain.

In the Anime after taking one pill, Grease's left eye turns red and his veins are visible all over his body. After consuming all the pills in the bottle, his muscles increased to the maximum, his skin turned brown and the skin on the side of his right hand darkened and his flesh expanded which had also merged with the sword. The sword was very large, black and long and there seemed to be a long red vein in the middle of the huge sword.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | I'll use this life to teach him the truth about the darkness of this world. | ” |
| — Grease, Light Novel Volume 01 | | |

Grease was an arrogant and prideful man, demonstrating this hot-headed behavior when he yelled at his subordinate due to the slightest disrespect to his pride. Cursed by his powerlessness, he was easily provoked by Shadow's 'ignorance' in facing the Cult, going as far as sacrificing his life to show him the 'truth.' Despite this, Grease seemed to be a loving father, longing for [his deceased daughter](Millia.md "Millia") moments before his death.[CITATION NEEDED]

## Chronology

### Background

Grease was a Viscount who used to be a Royal Guard in the Midgar Kingdom and has a wonderful life being a father to his daughter, [Millia](Millia.md "Millia"). Grease once attended a Bushin Festival at the capital from about 2 years ago and fought First Princess Iris Midgar who was an Academy graduate in his first round, but ended in defeat. Since then, he has been obsessed with becoming strong by seeking power.[[1]](#cite_note-V1C1-1)

The same year, his daughter was found out to have [Possession](Possession.md "Possession") much to his horror. This caught the attention of the Cult of Diablos who abducted his daughter and approached Grease and forced him to work for them.[CITATION NEEDED]

### Claire Kagenou's Abduction

Ordered by the Cult, Grease abducts Claire under the suspicion that she inherited the blood of the heroes. Beginning his interrogation, he was recognized and mocked by Claire for his depressing defeat against Princess Iris in the first round of the Bushin Festival. Feeling humiliated, he tries to scare her by aiming his kick at the stone wall next to the Kagenou heiress' head who was unexpectedly able to dodge it. Grease compliments Claire on being able to move despite being restrained by Magic Sealing Chains, to which she replies that being taught is important for how to use magic which makes Grease comment that her father taught her well how to learn her magic, but Claire explains that she learned everything from her brother.

Without further ado, Grease then asked Claire if she had any issues with her physical condition from having difficulty starting to controlling magic and feeling pain until her body turned dark with rot. Claire confirmed that she experienced these symptoms, but stated their disappeared after her brother's treatment. Hearing this, Grease confirmed his belief that Claire is "Compatible" and grew interested in her brother, but upon Claire hearing that, she freed herself from her chains and struck Grease on his nose. She declared with hostility, that she will kill him if he does anything to her brother. Grease then knocked her unconscious and was then informed of invaders in their facility by one of his men.

Exiting the cellar, Grease found his men massacred by seven women clad in black. After questioning the mysterious figures, he discovered that they are an organization by the name of Shadow Garden, with the knowledge of the Cult of Diablos' existence and their top secrets. Grease is surprised and wonders how they know about the organization's name as well as its secrets which shouldn't be revealed and tried to fight against [Alpha](Alpha.md "Alpha"), only to be utterly overwhelmed. Understanding that he won't be killed until he provides information about the Cult for them, Grease decides to retreat from the fight and informs the Cult's headquarters about the existence of the mysterious group. Seeing that he is overwhelmed, Grease takes a red pill causing his body to enlarge and increasing his magic capacity, allowing him to escape the Seven Shadows through a secret trapdoor.

Escaping through a lower level of the facility, he was faced with Shadow', the "Leader" of the newfound organization. Grease attacks Shadow, who easily blocks his attack. Shadow then attacks Grease and starts cutting him, causing Grease to wonder if he ever was that overwhelmed in battle before. Sensing the overwhelming difference in strength, Grease tells him no matter how strong he is, the darkness in the world is much deeper, but Shadow states he will just dive deeper.

After hearing his statement, Grease consumed more red pills to strengthen himself to bridge the gap in technique with pure power, wanting to show Shadow that people are worthless, fragile and powerless. Despite this, Grease was easily overwhelmed by Shadow as he manages to block his attacks until he using a large amount of magic and cuts down Grease in a single stroke. As Grease falls, he notes he was powerless against the darkness, but maybe not Shadow as he remembers his daughter moments before he dies.[[1]](#cite_note-V1C1-1)

## Legacy

## Powers & Abilities

As an aristocrat, Grease had some influence shown by his moderate amount of subordinates. Grease used to be a Royal Guard and possessed some physical strength and magical power on par with the "Second Children" of the Cult of Diablos.[CITATION NEEDED]

### Swordsmanship

### Weapons and Equipment

- Sword
- Beads of Diablos (he uses the pills to make himself more powerful and become a Third Awakening)

## Relationship

#### [Millia](Millia.md "Millia")

Millia is his daughter. Grease deeply loves Millia as she was the only family he had left after his wife's passing.[[2]](#cite_note-2)

## Trivia

- He was originally named "Olba" in Japanese, but the official [Yen Press](https://en.wikipedia.org/wiki/Yen_Press_LLC "wikipedia:Yen Press LLC") translation renamed him "Grease".

## References

1. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
2. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!

## Site Navigation
