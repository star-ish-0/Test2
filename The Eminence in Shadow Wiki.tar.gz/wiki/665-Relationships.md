# 665/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/665/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/665/Relationships)

[Main](665.md "665")

[Chronology](665-Chronology.md "665/Chronology")

Image Gallery

## Shadow Garden

### [664](664.md "664")

She has sympathy and trust with 664, although they have opposite behaviors since more than once 664 scolds her for her sleepy and semi-distracted, and cheerful way of working. When they communicated their failure in the mission to [Alpha](Alpha.md "Alpha"), 664 began to argue with the 666. But Alpha orders them to leave quietly and 665 takes them by force.

In the anime, 665 and 664 have a comedic routine where the latter has to keep the former's focus away from eating all the time.

### Rose Oriana

She has an optimistic and cheerful affection for Rose. Even when she saw her make a disobedient decision before her teammates, [559](Victoria.md "Victoria") and [664](664.md "664"), 665 still supported her with joy and everything.

### Shadow / John Smith

She has respect, loyalty, and some form of admiration for her lord, Shadow, for the way he makes his skills look so beautiful. As she is not one of the Numbers, she is not privy to her master's secret identity.

When 665 faced John Smith without knowing that it was Shadow, she was amazed by the beautiful way in which he moved the magical steel threads that she almost did not pay attention that they were enemies.

### [Alpha](Alpha.md "Alpha")

665 has a well-earned and dedicated respect for Alpha. When [664](664.md "664") and 666 started fighting in front of her, [Alpha](Alpha.md "Alpha") told them to leave and 665 complied by forcing her two companions to leave with her.
