# Gettan/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Gettan/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Gettan/Relationships)

[Main](Gettan.md "Gettan")

[Chronology](Gettan-Chronology.md "Gettan/Chronology")

Image Gallery

### Cult of Diablos

#### Zenon Griffey

#### Lutheran Barnett

#### [Mordred](Mordred.md "Mordred")

In the Web Novel, Gettan met with [Mordred](Mordred.md "Mordred") when the Cult of Diablos are trying to capture the Spirit Foxes and the Great Wolves tribe for the experiment and he forced him to join the Cult.[[1]](#cite_note-WN138-1)

### Subordinate

#### Garter Kikuchi

Even though Gettan was hired to work for Garter, his behavior towards him was not like a boss-subordinate relationship.

#### [Clovers](Clovers.md "Clovers")

### Enemies

#### [Yukime](Yukime.md "Yukime")

Yukime was Gettan's ex-fiancé. However, their bond was shattered after he revealed that he was behind the attack on their village and was about to kill her in anger had the "Stylish Thief Slayer" not appeared. Afterward, Yukime became obsessed with getting revenge on him and, years later, confronted him at the climax of the Great Trading Company Conflict. However, he still defeated her and almost killed her yet again. Fortunately, "John Smith" came to her rescue and proceeded to beat him to death. In his final moments, Gettan was remorseful for how things turned about between them and requested John to take care of her.

#### John Smith

Gettan actually met "John" long ago when the latter prevented him from harming [Yukime](Yukime.md "Yukime"). Ever since his fateful run-in with him as a "Stylish Bandit Slayer", he constantly has phantom pains and rubs the scarred eyelids over his empty eye sockets. Since then, Gettan became deeply envious of that man's power, wishing he had it so that he could save those he loved.

Present day, the two met again but both sides don't recognize each other. Due to how he seemingly came to Yukime's aid, Gettan believed John Smith was Yukime's new lover much to his anger and jealousy. Gettan tried to attack John to prevent [Yukime](Yukime.md "Yukime") from being stolen from him again only to be outmatched by the masked man.

It's only after being defeated that Gettan realized that John and the individual that bested him years ago were one and the same. Accepting death, Gettan entrusted [Yukime](Yukime.md "Yukime")'s safety to John.

## References

1. Chapter 138: The Man Who Is Burning With Revenge
