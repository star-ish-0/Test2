# Manga/Volume 10

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2010](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2010)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_10?action=edit).

## Manga Volume 10

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-1975376857

### ISBN EN

ISBN 978-1975376857

### Release Date

November 25, 2022 JP
July 23, 2024 EN

## Volume Information

### Pages

144

### Chapters

4

Publication Order

| Previous | Next |
| --- | --- |
| Volume 9 | Volume 11 |

This is the tenth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

After years of the Mitsugoshi group quietly using Cid’s Shadow Wisdom to reshape the world from behind the scenes, the time has finally come to pay the piper. The quagmire of a credit collapse threatens Shadow Garden and the Cult of Diablos alike in an economic disaster orchestrated by one man—Super Elite Agent John Smith! (Don’t tell anyone, but it’s Cid in disguise.) Weaving a web of betrayal from the threads of chaos laid throughout the market, Cid finally succeeds in entangling his enemy, but in the wake of his treachery, will things ever be the same between him and the girls…?[[1]](#cite_note-1)

金貨を横目に「計画通りだな…崩壊が始まった…」って呟きたかった――。

異世界に転生し、あらゆる物事に陰から介入し実力を示す「陰の実力者」設定をエンジョイしているシド。
勢力争いに巻き込まれたミツゴシ商会を救うため、シャドウガーデンメンバーにも正体を隠し、ユキメとともに暗躍していた。
シドが市場に張り巡らせた混乱の糸は少しずつ敵を絡めとり、ついに勢力争いの黒幕と対峙する――!!

「この裏切りはすべてミツゴシを救うためだった」計画達成なるか!? いつも通りの勘違いも、いつも通りに炸裂する異世界異聞奇譚、夢想の第10巻!![[2]](#cite_note-2)

## Summary

## Chapters

- Episode 38
- Episode 39
- Episode 40
- Episode 41

## Characters

:   In order of appearance:

## References

1. [The Eminence in Shadow, Vol. 10 (manga). YenPress](https://yenpress.com/titles/9781975376857-the-eminence-in-shadow-vol-10-manga/)
2. [The Eminence in Shadow (10). Kadokawa](https://www.kadokawa.co.jp/product/322205000505/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • **Volume 10** • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
