# Gonzales Machom

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Gonzales%20Machom](https://the-eminence-in-shadow.fandom.com/wiki/Gonzales%20Machom)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Gonzales_Machom?action=edit).

## Gonzales Manchom

### Japanese

ゴンザレス・マチョム

### Romaji

Gonzaresu Machomu

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Brown

### Eye Color

Brown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Swordsman

## Debut

### Web Novel

Chapter 67

### Light Novel

Volume 2

### Manga

Chapter 21

### Anime

Episode 15

Gonzales Machom (ゴンザレス・マチョム, Gonzaresu Machomu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a swordsman who participated in the Bushin Festival Tournament.

## Appearance

## Chronology

### Bushin Festival Tournament

Gonzales is a swordsman who participate as a contestant and Mundane Mann's opponent in the third qualifying round. But, he was instantly defeated in a fight with Mundane.

In the anime, it seemed to the audience that he stumbled and fell, but in reality, Mundane hit him on the chin to which he fainted and was knocked over with a foot sweep.

Only Annerose Nichtsehen was able to confirm it (although it was only the moment when his right hand moved, vaguely).

## Powers & Abilities

Gonzales as surprising agility given his brawny build, he can easily close the gap between him and his opponent.

## Relationships

### Mundane Mann

### [Quinton](Quinton.md "Quinton")

## Trivia

## References

## Site Navigation
