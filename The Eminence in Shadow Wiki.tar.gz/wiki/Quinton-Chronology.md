# Quinton/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Quinton/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Quinton/Chronology)

[Main](Quinton.md "Quinton")

[Relationships](Quinton-Relationships.md "Quinton/Relationships")

Image Gallery

### Background

A veteran of the Bushin Festival competition. Although records of his participation are sparse, he has had some success as he boasts about his participation in past iterations of the tournament.

### Bushin Festival Tournament

Quinton travelled to Midgar and participated in the country's Bushin Festival. Quinton saw a weak person who Annerose Nichtsehen tried warning but ignored when he stopped him to explain that he fought several times at the competition and each of them had weaklings like him, so it was better off that he took the advice to heart and not participate. Instead of taking the advice, the unassuming man replied that he is at least stronger than the veteran which angered him. In response to the insult, he picked him up and pummeled him into an alley and tried forcing him to apologies. The man stated that he is still weak, further enraging the veteran into pummeling him even further until Annerose stopped him warning the veteran that she'll be his opponent if he continues.[[1]](#cite_note-V2C4-1) Quinton also witnessed the match between his friend Gonzales Machom against Mundane Mann, the man he beat before on the qualifying thirds round and was surprised that Mundane won the fight as he was sure that Mundane was using an artifact.[[2]](#cite_note-2)

Curious about this dark horse, he, along with Annerose watched to analyze Mundane's match against Goldy Gilded on the qualifying fourth round. To their surprise and the shock of the entire audience, Mundane easily won. While everyone and Quinton pondered to how this had happened, the Velgaltan swordswoman explained that she did notice the methods Mundane did that allowed him to win his match. Unfortunately, this is met with laughter by the veteran as he found them to be unrealistic and chose not to believe in Annerose's analysis and left stating that if Mundane keeps winning, he will eventually face him and show him what he is made of. Eventually, Quinton's match against Mundane began on the qualifying final round the veteran being easily defeated.[[3]](#cite_note-V2C5-3)

In the anime, after the Bushin Festival, Quinton followed Goldy to the train station and calls out to him when he thought that he was running away.[[4]](#cite_note-4)

### From Dark Knight to Slave

Quinton teamed up with Goldy and traveled to the Lawless City in order to face the [Blood Queen](Elisabeth.md "Elisabeth") of the Red Tower. When they arrived at the building, they encountered the tower's watchdog. The two arrogantly fought the man to no avail as Quinton was cut down by the watchdog's blade to which Goldy realizing that the watchdog was the White Demon. Goldy immediately fled, abandoning his friend but alas, he did not get as far when the residents of the Lawless City started attacking him.[[5]](#cite_note-:0-5)

Captured and brutalized, Quinton alongside Goldy was enslaved. When Cid Kagenou and Claire Kagenou were passing by, they tried begging for their help but ultimately and miserably failed. After the siblings left, someone brought the pair too much to their horror.[[6]](#cite_note-:1-6)

## References

1. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
2. Episode 15
3. Volume 2 Chapter 5: A Battle to Attract Only MVPs!
4. Episode 20
5. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
6. Volume 3 Chapter 1: Lawless City Bandit Hunting!
