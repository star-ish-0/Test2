# Episode 23

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2023](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2023)

## The Hour of Awakening

### Kana

覚醒の刻

### Romaji

Kakusei no Toki

## Special Title

### English

The Eminence in Shadow Wants Savings to Last for Lifetime!

### Kana

陰の実力者は一生暮らせる貯金箱が欲しい！

### Romaji

Kage no Jitsuryoku-sha wa isshō kuraseru chokin-bako ga hoshī!

## Episode Information

### Season

2

### Episode

3 (23)

### Air Date

October 18, 2023 JP & EN

### Adapted From

Volume 3 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

Grayscale dominator

### Ending

Polaris in the Night (Nu ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| The Haven | Mask of Falsehood |

The Hour of Awakening (覚醒の刻, Kakusei no Toki[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the third episode of the second season, and the twenty-third episode of [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

The night the red moon rises, the Blood Queen Elisabeth makes her return. [[1]](#cite_note-1)

女王の間に辿り着いたクレアが、エリザベートから致命傷を受けてしまう。駆けつけたベータたちも血の女王には歯が立たない。最悪な状況の中、クレアに異変が起こる。[[2]](#cite_note-2)

## Summary

Cid makes his shadow broker appearance, but all potential audience members are dead. He dejectedly looks between a [bisected vampire](Crimson.md "Crimson") and a decapitated black-haired man, seeking the rumored [Blood Queen](Elisabeth.md "Elisabeth"). The dusty fallout does not deter the black swordsman from cogitating possible plot explanations. It could be a “group battle scenario”, or the “final boss” is in another part of the tower. Cid decides to explore possible contingencies, starting with checking the basement for the sleeping potentate. The germinating red grotesque remains hidden as Cid departs, searching for plot developments.

Immediately after Cid’s withdrawal, Claire and [Mary](Mary.md "Mary") reach the top of Crimson Tower. Both start shouting the names of their rescue targets. Mary sees something and warns the unguarded Claire. Her dilatory reaction proves fatal as a red tendril pierces Claire’s chest. Mary has no time to mourn her new companion; the Blood Queen has blossomed into life and chooses Claire as her first meal. The Ancient Vampire Slayer collapses in despair, painfully aware of what follows. Salvation arrives in the form of a four-women Shadow Garden cell.

[Beta](Beta.md "Beta") swiftly decollates the Blood Queen as [664](664.md "664") secures Claire; 666 and [665](665.md "665") provide additional cover. 664 confirms Claire is still breathing, but expresses concern about the effectiveness of mere emergency first aid. Beta watches the detached head return to the deceptively frail-looking body and concludes retreat is not an option. Shadow, likely engaged in other matters of importance, has left Beta to confront the awakened queen. The elf is determined to protect her master’s sister and knows he has entrusted this mission to her. Beta orders 664 to tend to Claire and the other two to cover her assault. Exploding shurikens and arm dismemberment appear effective, but Mary warns that her queen rouses slowly. A burst of magical energy supports those words as Beta wonders if the Blood Queen’s magic capacity surpasses [Alpha's](Alpha.md "Alpha").

The recently arrived [Yukime](Yukime.md "Yukime") has judged the fight is beyond her capabilities, but [Juggernaut](Juggernaut.md "Juggernaut") decides to throw himself into the fray. Juggernaut’s only contribution is adding a new body-shaped crater into a wall. The Blood Queen attacks en masse with renewed force. Beta’s slime shield only delays the attack as blood projectiles injure all present allies. The silver-haired elf acknowledges that they are outmatched and orders 666 to retreat with Claire. 666 announces intentions to fight, but Beta reminds her that she has future ambitions. The deteriorating situation is aggravated further by merging tumors on previously cured [possessed](Possession.md "Possession"). Beta and the numbers all suffer from regressing symptoms, but Claire devolves the fastest.

Claire awakens on a medical cot, mysteriously removed from her last location and wearing clothing reminiscent of a school gym uniform. She turns her head towards a quiet voice and sees a purple-haired woman with deep violet eyes. Violet Eyes explains that “he'' cured her possession; worrying about it is wasted energy, but she is now losing control. Claire asks many questions and demands to know whose the mysterious “he “. The purple-haired girl equivocates and starts discussing the theory of evolution. Claire’s annoyed face compels the circumlocutory woman to arrive at her point. Traits that get separated by blood can be a result of adaptation. Progenitor vampires and the possessed are such an example, and the two types of blood reunited within Claire’s body. Claire does not have complete control, but she is willing to help her. A mark appears on Claire’s left hand to assist in this management. Violet Eyes finally confesses her name after Claire’s continued cross-examination, and her name is [Aurora](Aurora.md "Aurora"). Aurora admits that she is helping her because of Shadow. Before Claire could ask any more, reality shatters and reveals Crimson Tower again.

Aurora, now possessing Claire’s body, is ecstatic about temporary freedom. The Blood Queen attacks and throws deadly blood projectiles at the purple woman. Aurora calmly stops the red missiles and reverses the trajectory. All of them tear apart the Blood Queen, but regenerative powers make quick work of her shredded body. Blood projectile meets blood projectile as explosions cover the sky. Aurora attempts atomic magic, but Claire’s body can not take the strain. Her efforts to stall prove effective and Shadow takes center stage with a bang.

Shadow glistens from the Red Moon’s illumination. It is as if his slime bodysuit is laced with thousands of gold coins. A shout from Shadow initiates the battle. Instantly, red and black missiles cover the sky. Shimmering gold light surrounds the ebony swordsman’s composed defense. Beta questions why he is not counterattacking, but she realizes his purpose is to protect everyone. Shadow’s stoic statement: “I can’t afford to lose a single one.” adds to Beta’s infatuation. She cheers on her savior as Shadow switches to offense. A giant burst of magical energy signals the start, and, in an instant, Shadow is face-to-face with the monarch. The Blood Queen’s face, apathetic throughout the fight, warps into a smile and requests his name. The warrior ignores Mary's protests, and Elisabeth prepares for death. Shadow's reply booms across the sky. “I… Am… Recovery Atomic.” [Ghouls](Ghouls.md "Ghouls"), wounds, and Elisabeth’s unconscious mind are all healed by the mysterious man’s spell.

On the way back to the Midgar Kingdom, Cid reflects there is one thing that it did not cure. Claire’s chuunibyou delusions. She has now wrapped her hand with bandages and confessed to Cid that she has a hidden power. He did not dismiss it and promised to stand by her as he knew how it would end. It will leave you empty and be a painful reminder of reality. The one positive thing was he managed to save a few hundred zeni. He now knows that Lawless City has infinite potential as a piggy bank. After Cid returns to the Midgar Kingdom, he boards a train and changes to his Shadow persona, and confronts Yukime, who followed him from the Lawless City.

## Characters

- [Crimson](Crimson.md "Crimson") (Corpse)
- Cid Kagenou/Lord Shadow
- Skel Etal
- Po Tato
- [Mary](Mary.md "Mary")
- Claire Kagenou
- [Elisabeth](Elisabeth.md "Elisabeth") (Debut)
- [Beta](Beta.md "Beta")
- [664](664.md "664")
- [665](665.md "665")
- Rose Oriana (No. 666)
- [Yukime](Yukime.md "Yukime")
- [Juggernaut](Juggernaut.md "Juggernaut")
- [Aurora](Aurora.md "Aurora")
- [Quinton](Quinton.md "Quinton")
- Goldy Gilded
- [Claudia](Claudia.md "Claudia")
- [Marie](Marie.md "Marie")
- [Eta](Eta.md "Eta") (Mentioned)

## Promotional Videos

「陰の実力者になりたくて！ 2nd season」 第3話予告≪ノーマルVer.≫「覚醒の刻」

『陰の実力者になりたくて！ 2nd season』 第3話予告≪スペシャルVer.≫「陰の実力者は一生暮らせる貯金箱が欲しい！」

## Trivia

- Claire's dream sequences were different from the Light Novel/Manga as in the anime, Claire woke up in an infirmary wearing a gym uniform.
  - The name tag on the shirt of the Gym uniform that Claire was wearing reads "Claire" (くれあ, Kurea[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) in [Hiragana](https://en.wikipedia.org/wiki/Hiragana).
  - The shorts that Claire was wearing were Japan's [Buruma](https://en.wikipedia.org/wiki/Bloomers#Bloomers_in_Japan) shorts. That were formerly used in Japan's Pysical education classes in the 1990s.
- The scene where Aurora shows a photo of Cid healing Claire of her Demon Possession was anime-only content based on LN and manga information.
- The screen saver on the laptop is a reference to Microsoft Windows 95.
- The placement of the mark on Claire's hand was different compared to the Light Novel/Manga, as it was placed on the back of her right hand. In the anime, the mark is placed on the back of her left hand.
  - The mark from the Light Novel/Manga was also a circle, while it was a red geometric pattern with chemistry sequence down to her forearm in the anime.
- Aurora's use of a school environment in the dream setting was likely lifted from some connection to Cid, as the architecture resembled a Japanese school, yet the computer technology had this world's language script.
  - Aurora's laptop gives a presentation on the Progenitor and Possessed blood conflicting within Claire's body, ending in native script reading "WARNING." The letter placements and pattern can match the script to an English letter conversion.

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e023>
2. <https://shadow-garden.jp/story/#story3>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • **Episode 3** • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
