# Lutheran Barnett

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lutheran%20Barnett](https://the-eminence-in-shadow.fandom.com/wiki/Lutheran%20Barnett)

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | You say you don’t fear opposing the entire world as your enemy? Mighty arrogant of you, Shadow! | ” |
| — Lutheran to Shadow, Light Novel Volume 01 | | |

## Lutheran Barnett

- Lutheran
- Sir Gaunt

### Japanese

ルスラン・バーネット

### Romaji

Rusuran Bānetto

### Aliases

Sir Gaunt

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Early 50s

### Height

Unknown

### Hair Color

Gray

### Eye Color

Gray

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Sherry Barnett (Foster Daughter)

## Professional Information

### Occupation

- 6th seat of the Knights of Rounds (Former)
- Named Child
- Assistant Principal of Midgar Academy for Dark Knights (undercover)

### Affiliation

Midgar Kingdom
Cult of Diablos

## Debut

### Web Novel

Chapter 22

### Light Novel

Volume 1

### Manga

Chapter 7

### Anime

Episode 6

## Portrayal

### Japanese

[Hōchū Ōtsuka](https://en.wikipedia.org/wiki/H%C5%8Dch%C5%AB_%C5%8Ctsuka "wp:Hōchū Ōtsuka")

### English

[David Matranga](https://en.wikipedia.org/wiki/David_Matranga "wp:David Matranga")

### French

Patrick Noerie

### Italian

Claudio Moneta

### German

Alexander Pelz

Lutheran Barnett (ルスラン・バーネット, Rusuran Bānetto[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the Assistant Principal of the Midgar Academy and Sherry's adoptive father. In truth, however, he was the former 6th Seat of the Knights of Rounds. Seeking to reclaim his position, he orchestrated an attack on the Academy under the alias "Sir Gaunt" (痩（やせ）騎士（きし）, Yase Kishi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) to recover an Artifact that could cure his terminal illness whilst framing Shadow Garden, only to be thwarted and killed by Shadow.[CITATION NEEDED]

## Appearance

Lutheran was a middle-aged man. He had black slicked-back hair with grey streaks. In the light novel, he has a beard.[[1]](#cite_note-:0-1)

In his guise as "Sir Gaunt", he hides his face with a mask and dressed jet-black cloaks on the novel and manga. While in the anime, he wears a full suite of menacing-looking dark plate armor with a red cape that conceals his identity and voice.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | That’s why I had to kill her. I started stabbing her from her extremities inward, until I impaled her heart and twisted my blade. | ” |
| — Lutheran reveals his true nature when he explains how he killed Lukreia Crowley to Cid Kagenou, Light Novel Volume 01 | | |

While Lutheran was viewed as a humble and kind man in the public with a close relationship with his adopted daughter, Sherry, who he always tried to support her activities and encourage social interactions, this was all a façade to cover up his true nature, as the real Lutheran was a heartless power-hungry yet pitiful person.

Having been the 6th Seat Knight of Rounds in his peak before he was demoted due to his illness, he was completely obsessed with regaining his former glory.[CITATION NEEDED] He is also highly manipulative as he used Sherry, and her late mother as means to achieve his goals. He even expressed his pride in having killed Sherry's mother, making him a true psychopath which even disgusted Cid to the point that he called his action "unpleasant".[CITATION NEEDED]

Despite his malicious and selfish side, Lutheran retained a bit of honor and respect for the handling of the sword; and that of the others since when he was in front of Shadow, he confessed that he must understand that just like others, when one goes the way of the sword, they cannot stop. When he obtained that sensation of power and glory, this led Lutheran to do anything to recover his glory regardless of who he manipulates or kills, selfishly and sadistically.[[2]](#cite_note-:2-2)

## Powers & Abilities

Being the former 12th Seat of the Knights of Rounds, Lutheran still possessed least amount of influence within the Cult of Diablos and still considered one of the organization's most powerful top executives.[CITATION NEEDED] As Assistant Principal, Lutheran also held authority over the Academy.

### Swordsmanship

As a former Bushin Festival champion and Rounds Knight, Lutheran was highly efficient in handling the sword. And despite his illness, it did not deter him from practicing; however, it had taken its toll when it had gradually exacerbated until he used the Eye of Avarice.

### Weapons and Equipment

- Sword
- Beads of Diablos
- Eye of Avarice

## Trivia

- His first name was originally named as "Ruslan" in Japanese, but the official [Yen Press](https://en.wikipedia.org/wiki/Yen_Press_LLC "wp:Yen Press LLC") translation renamed him as "Lutheran". Ruslan is still used in the unofficial web novel translation.

## References

1. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
2. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | [Loki](Loki.md "Loki") • [Hel](Hel.md "Hel") • [Jormungandr](Jormungandr.md "Jormungandr") • [Fenrir](Fenrir.md "Fenrir") • [Mordred](Mordred.md "Mordred") • [Petos](Petos.md "Petos") • Jack Nelson • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • **Sir Gaunt** | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • [Jean](Jean.md "Jean") • Dark Spider • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • [Gray](Gray.md "Gray") • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • Reina Oriana • [Isaac](Isaac.md "Isaac") | |

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | **Lutheran Barnett** • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • Alexia Midgar • Christina Hope • [Isaac](Isaac.md "Isaac") • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |
