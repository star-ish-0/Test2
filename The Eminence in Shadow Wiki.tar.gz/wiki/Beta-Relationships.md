# Beta/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Beta/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Beta/Relationships)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Main](Beta.md "Beta")

[Chronology](Beta-Chronology.md "Beta/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

Beta initially had trouble being a member of Shadow Garden. A lack of direction made killing repulsive and caused nightmares. Cid attempted to soothe her anxieties by telling her stories from Earth. The individual attention and fantastic tales ended up being so uplifting that she became capable of enduring hardships as long as they were for the sake of Shadow Garden—the extension of him.[[1]](#cite_note-:V1C1-1) Although she continues to speak respectfully, Beta's feelings have changed from timidity to obsession with Cid and his shadow broker activities. She carries around a notebook in which she writes about his exploits.[[2]](#cite_note-:V1C3-2) The maniacal fanaticism can likewise manifest as antagonistic action towards other women. Outside of same-sex quarrels, she expresses a willingness to kill anyone who even dares to mock Cid.[[3]](#cite_note-:V2C2-3)[[4]](#cite_note-:V4C6-4)

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

Fellow elven member and leader of the "Seven Shadows"; Alpha is the person who recruited Beta into Shadow Garden. In fact, they already knew each other before this, as they are childhood friends before they each developed [Possession](Possession.md "Possession") and were exiled. As a result, Beta's loyalty to Alpha is second only to the Shadow. Beta often acts as something of a secretary to Alpha.

In the spinoff "Kage-Jitsu", the two tried to reenact Cid's torture when he was being "interrogated" by Cult members posing as Knights.

#### [Gamma](Gamma.md "Gamma")

Very little has been seen of the relationship between Beta and Gamma, but it can be said that they get along quite well, with Beta often helping her and sometimes even replacing her in her duties as president of Mitsugoshi.

#### [Delta](Delta.md "Delta")

Fellow member of the Seven Shades; Beta professed that Delta's like a little sister to her when she was presumed dead from tracking down John Smith (Cid).[[5]](#cite_note-5)

#### [Epsilon](Epsilon.md "Epsilon")

Fellow elven member of the "Seven Shadows"; Epsilon views Beta as a rival for Shadow's affections due to her jealousy towards her naturally voluptuous figure. Beta, on the other hand, is oblivious to the slim elf's obvious resentment toward her, only being bothered by the latter's comments about Shadow seemingly giving her more attention. Despite their rivalry, the two can work together during missions just fine.

In the Anime, Epsilon's jealously towards Beta is demonstrated in both her and Cid's flashback regarding the silver haired elf. In Epsilon's flashback, Cid taught her about slime magic and told her to change her fate and take hold of the truth. Epsilon interpreted the statement as a reference to her body and used Beta's developing body as reference.

In Cid's flashback, the preteen taught the elven stories and literature but was astonished and peeved that she would later gain notoriety without knowing that she plagiarizes them. During the flashback, the slim elf humorously cameoed as she enviously watched her through the windows.[[6]](#cite_note-6)

#### [Zeta](Zeta.md "Zeta")

Fellow member of the "Seven Shadows"; Beta is unaware that she alongside [Victoria](Victoria.md "Victoria") is working behind her and the other members' backs by creating her own sub-faction within Shadow Garden loyal solely to her.

#### [Eta](Eta.md "Eta")

A fellow member of the "Seven Shadows"; Beta acknowledges Eta's intelligence, turning to her to "decipher" Shadow's message written in Japanese. Unfortunately, she does not seem to trust her morals, taking custody of Akane out of fear of what the scientist would do to the Earthling if she got her hands on her.[[7]](#cite_note-:2-7)

### Numbers

#### [Lambda](Lambda.md "Lambda")

#### [Nu](Nu.md "Nu")

#### [Sigma](Sigma.md "Sigma")

#### [Chi](Chi.md "Chi")

#### [Omega](Omega.md "Omega")

### Members

#### [Victoria](Victoria.md "Victoria") (559)

Beta worked with Victoria during the Oriana Kingdom Operation though they have not interacted with each other.[[8]](#cite_note-8) However, she alongside other members of the organization is unaware of her true allegiance to Zeta and that they are working behind their backs in hopes of immortalizing their master.

#### [664](664.md "664") & [665](665.md "665")

Beta worked with 664 and 665 during both the Blood Moon Incident[[9]](#cite_note-9) and the Oriana Kingdom Operation.[[10]](#cite_note-10)

#### Rose Oriana (666)

Beta first met Rose under her 'Natsume' guise, whose stories the latter is a big fan of. Following the Holy Ground Infiltration, they allied with Alexia to uncover the truth behind the Cult of Diablos.[[11]](#cite_note-:3-11) Later, during the God of War Tournament, when Rose was resolved to euthanize her brainwashed father, Beta respected her choice.[[12]](#cite_note-12) Afterward, Rose joined Shadow Garden, thus making Beta her superior, though she remains unaware that she and Natsume are the same person. It's unknown if Beta was aware that Rose has romantic feelings for her master, Cid.

#### Akane Nishino / "Akane Nishimura" (712)

Beta brought Akane with her to the other world from [Earth](Earth.md "Earth") after having to abandon her looted Earth tech, due to them not fitting through the portal. While she initially intended to pawn her off to someone else, Beta took custody of Akane under Alpha's orders. She is unaware Akane knowing her master's previous life.[[7]](#cite_note-:2-7)

## Others

### Claire Kagenou

Beta is aware of Claire's importance to Cid, which is why she usually gives high priority to matters involving her. Beta and the other members of Shadow Garden usually refer to Claire with the title of mistress as a sign of respect, the only exception to this being Alpha.[[13]](#cite_note-13)

### Mist Dragon

### Alexia Midgar

Beta despises Alexia for having previously forced Cid into a "romantic" relationship with her, viewing the princess as her love rival. As a result, upon their first meeting, Beta was uncharacteristically condescending toward her and held back her anger when Alexia constantly stomped on her foot.[[14]](#cite_note-:1-14) While they later agreed to an alliance with Rose to uncover the truth behind the Cult of Diablos, they still have an obvious dislike toward each other.[[11]](#cite_note-:3-11) Also, whilst working together, Beta would constantly annoy Alexia by acknowledging the latter's jealously of her more developed body.

After the incident regarding Rose and her kingdom, Alexia decided not to contact the author when she recollected her strained relationship with the former princess and that the author was good for nothing.

### [Mary](Mary.md "Mary")

### Skel Etal & Po Tato

## References

1. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
2. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
3. Volume 2 Chapter 1: Fun Times at the Goddess's Trial!
4. Volume 4 Chapter 6: Something Smells Fishy... But an Eminence in Shadow Always Cracks the Case!
5. Volume 3 Chapter 6: Circulating Counterfeit Cash!
6. Episode 10
7. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
8. Volume 2
9. Volume 3 Chapter 3: Pursuing the Blood Queen!
10. Volume 4 Chapter 3: Crashing the Ceremony!
11. Volume 2 Chapter 3: When Things Get Boring, It's Time for Explosives!
12. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
13. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
14. Cite error: Invalid `<ref>` tag; no text was provided for refs named `:1`
