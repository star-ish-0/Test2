# Jack Nelson

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Jack%20Nelson](https://the-eminence-in-shadow.fandom.com/wiki/Jack%20Nelson)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | I am Nelson the Avaricious, the 11th Seat of the Knights of Rounds. | ” |
| — Nelson, Light Novel Volume 02 | | |

## Jack Nelson

### Japanese

ジャック・ネルソン

### Romaji

Jakku Neruson

### Aliases

The Avaricious
Baldy

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

1000

### Height

Unknown

### Hair Color

Gray (Balding)
Brown (Youth)

### Eye Color

Brown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- 11th seat of the Knights of Rounds
- Named Child
- Acting Archbishop (undercover)

### Affiliation

Cult of Diablos

## Debut

### Web Novel

Chapter 46

### Light Novel

Volume 2

### Manga

Chapter 15

### Anime

Episode 11

## Portrayal

### Japanese

[Mugihito](https://en.wikipedia.org/wiki/Mugihito "wp:Mugihito")

### English

James Belcher

### French

Jean-Luc Atlan

### Italian

Cesare Rasini

Jack Nelson (ジャック・ネルソン, Jakku Neruson[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the acting archbishop who's secretly the 11th Seat Knight of Rounds of the Cult of Diablos and the leader of the faction operating in [Lindwurm](Lindwurm.md "Lindwurm"), as well as one of the scientists responsible for inventing the Beads of Diablos. He was killed by Shadow when the latter blew up the [Sanctuary](Sanctuary.md "Sanctuary") to destroy [Diablos](Aurora.md "Aurora")' left arm.

## Appearance

Nelson was an elderly fat man with brown eyes, thick eyebrows and mustache. Nelson is in fact over a thousand years old, due to his experimentation. Even his appearance has a little to no changes when compared to the past him in [Hero Olivier](Olivier.md "Olivier")'s memories. The only notable difference is that he had a bald head with hair that only grows from the back, which he has lost his hair overtime, allegedly due to stress where he was always being called as "Baldy" by Alexia Midgar, [Aurora](Aurora.md "Aurora") and Cid Kagenou.

By the time [Alpha](Alpha.md "Alpha") finished explaining the main ingredients for making the Beads of Diablos and revealed his true affiliation, Nelson eyes are glowing red in a flash.[[1]](#cite_note-V2C2-1)

As Archbishop's official, he wears a neat appearance wearing a long-sleeved white shirt with brown and gold accents, a white collared robe with light blue and gold accents, white gloves, gray trousers, and a pair of shoes. He also wears accessories in the form of a red diamond ring.

During his battle against [Alpha](Alpha.md "Alpha") and [Delta](Delta.md "Delta"), his clothes have not changed in the novel/manga version, but in the anime, he is dressed in something like a body suit during battle.[[2]](#cite_note-2)

## Personality

|  |  |  |
| --- | --- | --- |
| “ | You will regret baring your fangs against the Cult. | ” |
| — Nelson, to Shadow Garden, Light Novel Volume 02 | | |

To the public, Nelson presented himself as a humble and benevolent archbishop who takes joy in his duties.[CITATION NEEDED] However, there are times when his true personality came to the service as he shown to be acted arrogantly and arbitrarily when he did everything to cover up his crimes.[CITATION NEEDED] Even with cruelty he did not hesitate to order several paladins, even the hero [Olivier](Olivier.md "Olivier") to kill his enemy.[CITATION NEEDED] He was also shown to be lecherous, easily giving up vital intelligence when [Beta](Beta.md "Beta") easily seduced him with her body as he took an opportunity to ogle at her chest.[CITATION NEEDED]

Like many high-ranking members of the cult, Nelson is a delusional psychopath completely convinced of his invincibility.[CITATION NEEDED] When pushed into a corner, however, he underwent a villainous breakdown, repeatedly trying to justify to himself why he was losing.[CITATION NEEDED]

In the anime, Nelson gives the impression of a hard-working person, such as complaining at every opportunity and being confused by [Alpha](Alpha.md "Alpha")'s behavior when she tries to retreated during the battle. He also possessed a severe superiority complex, claiming to have gone bald from the stress of having to deal with his "idiotic" comrades and being forced to work because of his immortality.[[3]](#cite_note-3)

## Powers & Abilities

Despite holding the 11th Seat position in name only due to him being a researcher rather than a warrior, Nelson was still stronger than the average swordsman.[CITATION NEEDED] His fighting style seemed to consist of him making multiple copies of himself to overwhelm his opponents through raw numbers by exploiting the [Sanctuary](Sanctuary.md "Sanctuary") functions.[CITATION NEEDED] As acting Archbishop, Nelson held great influence within the Church and had the right to command the [Paladin](Paladin.md "Paladin").[CITATION NEEDED]

### Physical Prowess

Nelson's physical abilities are quite weak since he used to be a researcher, not a warrior. His combat power is no more than that of an ordinary magic swordsman, rendering him too useless to be ever able to participate in a fight. So, Nelson only relies too much on his cloning skill coupled with the power of [Sanctuary](Sanctuary.md "Sanctuary"), although he can still fight with his longsword.[CITATION NEEDED]

### Regenerative Ability

Nelson was able to acquire this ability because consuming many Beads of Diablos for centuries. When Nelson’s cheek is torn by [Delta](Delta.md "Delta")'s attack with her fangs, he seems unconcerned as he wipes the blood from his face as the wound from the attack has already healed.[CITATION NEEDED]

### Swordsmanship

Nelson's swordsmanship is mediocre. This was shown when he used his clone ability, Nelson and his clones were capable enough to swing his longsword to fight against Alpha and Delta.[CITATION NEEDED]

### Equipment

Nelson wields a longsword that is about the same height as his shoulders.[CITATION NEEDED]

### Special Techniques:

#### Magic Cloning

Nelson can create replicas of himself or another. However, due to the limit of his brain power, he cannot control multiple clones very effectively. These clones are weak when they were easily cut down by [Delta](Delta.md "Delta").

### Sanctuary Power

By using the [Sanctuary](Sanctuary.md "Sanctuary") power which absorbs the magical power of intruders and converts it into its power, Nelson can fight when he enters the defense system creating numerous duplicates of itself and [Olivier](Olivier.md "Olivier") to fight against two of the Seven Shadows, [Alpha](Alpha.md "Alpha") and [Delta](Delta.md "Delta"), including Shadow himself. However, their natural power which is supposed to be restrained and shouldn't have been able to control or manipulate their magic is no match for the Sanctuary's restrictive conditions system.

### Memory Recall

Nelson who is a member of the Cult of Diablos has an access code to summon Three Heroes. He summons [Olivier](Olivier.md "Olivier") to fight [Alpha](Alpha.md "Alpha") and [Delta](Delta.md "Delta"), which in the end they retreat due to the [Epsilon](Epsilon.md "Epsilon") team's investigation being completed and uses the power of Sanctuary to summon the incalculable number of Oliviers to eliminate Shadow.

### Enemy Detection

Using the Sanctuary's abilities, Nelson can detect intruders within the area.

## Trivia

- He is the only Cult's Knights of Rounds member to learns [Alpha](Alpha.md "Alpha")'s identity as [Olivier](Olivier.md "Olivier")'s descendant and Shadow's true identity, although he never noticed it.[CITATION NEEDED]
- Due to being one of the oldest members of the cult, Nelson hardly made himself public before the people, since in this way, he avoided raising suspicions about his age as such and his time as in the church.[CITATION NEEDED]

## References

1. Volume 2 Chapter 2: Investigating the Sanctuary!
2. Episode 13
3. Episode 12

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | [Loki](Loki.md "Loki") • [Hel](Hel.md "Hel") • [Jormungandr](Jormungandr.md "Jormungandr") • [Fenrir](Fenrir.md "Fenrir") • [Mordred](Mordred.md "Mordred") • [Petos](Petos.md "Petos") • **Jack Nelson** • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • Sir Gaunt | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • [Jean](Jean.md "Jean") • Dark Spider • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • [Gray](Gray.md "Gray") • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • Reina Oriana • [Isaac](Isaac.md "Isaac") | |
