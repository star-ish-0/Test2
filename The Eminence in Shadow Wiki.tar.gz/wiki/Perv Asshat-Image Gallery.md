# Perv Asshat/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Perv%20Asshat/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Perv%20Asshat/Image%20Gallery)

Main

Chronology

Relationships

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Doem's supposed marriage.

Character design.

Attacked by Rose.

Realization to Beatrix.
