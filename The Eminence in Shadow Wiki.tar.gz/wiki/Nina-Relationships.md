# Nina/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Nina/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Nina/Relationships)

[Main](Nina.md "Nina")

[Chronology](Nina-Chronology.md "Nina/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

Despite operating outside the Shadow Garden organization, Nina holds a profound fondness and deep respect for Cid Kagenou, much like her counterparts within the Shadow Garden. Recognizing Cid as Shadow, she willingly takes on a variety of tasks and requests assigned by him, including whimsical ones like handling his homework and collecting information. This commitment reflects Nina's high regard for Cid's words, aligning her sentiments with those of the other Shadow Garden girls. Placing Cid in a position of greater respect than even Claire and her master, Zeta, Nina acknowledges him as the master of her own master and the master of all Shadow Garden. Notably, Zeta, her master, also shares this stance and does not tolerate any disrespect toward Cid or Claire, even when it comes from Nina.

Beyond her organizational duties, Nina assumes a role akin to a personal maid or assistant for Cid. She goes the extra mile, preparing cheat sheets to help him excel in exams, treating him to luxurious meals, and readily undertaking any task he assigns. Cid reciprocates Nina's fondness, expressing his liking and profound respect for her. He once remarked that discovering Nina Senpai as his sister's friend, who treats him well and holds him in high regard, was the first time he felt glad to be his sister's brother.

Nina's demeanor towards Cid is a blend of shyness and genuine care. While she outwardly refers to him as "ototo-kun" or little brother, maintaining a polite tone, her private interactions reveal a different dynamic. Within her group or in private moments with Cid, she addresses him as "master" or "sama," demonstrating a heightened level of respect and care.

### [Zeta](Zeta.md "Zeta")

Nina respects and obeys Zeta well as her subordinate, even though she is affiliated outside of the Shadow Garden organization, yet operates as a covert agent exclusively to Zeta's command. Per her orders, Nina is a planted operative at the Midgar Academy meant to be friends with Claire and recently to be of service to Cid upon his enrollment.

### [Mu](Mu.md "Mu")

### [Victoria](Victoria.md "Victoria")

Nina and Victoria are contemporaries under Zeta's exclusive command, but the two seemingly have opposite personalities. Unlike Victoria, Nina isn't cold and abrasive while encountering others, but is routinely chipper and outgoing when with being social; such as befriending Claire or helping Cid or interacting with her classmates. However, it is unclear if such a jovial persona is her standard or a façade for her undercover work for Zeta.

## Midgar Academy for Dark Knights

### Claire Kagenou

Ever since she was ordered to supervise Cid Kagenou's older sister, Nina has apparently become very close to Claire by helping her whenever she can, in order to look after her and ensure no Cult member gets their hands on her. In order to do so, Nina has since become Claire's friend at the academy.

However, despite Nina's loyalty towards Zeta, her friendship with Claire is genuine as seen when she became extremely worried when Claire was in pain when Zeta forcibly merges the right arm into Claire.

### Alexia Midgar

Nina has been shown to have a degree of trust from Alexia. As when the princess wanted to help Claire understand Aurora, Nina was ready to help Alexia helping Claire. Despite Alexia's "relationship" with Cid, Nina seems to genuinely care for someone she would call a friend.
