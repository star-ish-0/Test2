# Maximilian

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Maximilian](https://the-eminence-in-shadow.fandom.com/wiki/Maximilian)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Maximilian?action=edit).

|  |  |  |
| --- | --- | --- |
| “ | I'm Maximilian the Ruthless. There's no point in remembering my name. You'll all die here. | ” |
| — Maximilian, to [Nu](Nu.md "Nu") and Claire Kagenou, Masquerade | | |

## Maximilian

### Japanese

マクシミリアン

### Romaji

Makushimirian

### Aliases

Ruthless
Owl

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Early 20s

### Height

Unknown

### Hair Color

Silver Gray

### Eye Color

Purple

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Named Child

### Affiliation

Cult of Diablos

## Debut

### Web Novel

Chapter 149

### Game

Masquerade

## Portrayal

### Japanese

[Yuma Uchida](https://en.wikipedia.org/wiki/Yuma_Uchida "wp:Yuma Uchida")

Maximilian (マクシミリアン, Makushimirian[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a Named Child of the Cult of Diablos, known by the epithet Ruthless (冷徹（れいてつ）, Reitetsu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). Intending to increase his influence, he set an elaborate trap to eradicate the remnants of the Perv Asshat faction in his "purge" plan. Posing as Shadow, Maximilian assumes the pseudonym Owl (フクロウ, Fukurō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) to incriminate the shadowbroker in the carnage. The plan's success was brief; his plot and life ended after [Nu](Nu.md "Nu") and Claire's interference. Borrowing Claire's body, [Aurora](Aurora.md "Aurora") dealt the final blow.[[1]](#cite_note-1)[GAME ONLY]

## Appearance

## Personality

|  |  |  |
| --- | --- | --- |
| “ | This is a purge. I have plenty of time to kill each one of you slowly. | ” |
| — Maximilian, Masquerade | | |

## Chronology

### Masquerade

## Powers & Abilities

### Physical Prowess

### Swordsmanship

### Magic

### Special Techniques:

#### Ruthless Kaleidoscope

## Trivia

## References

1. Master of Garden Auxiliary Chapter: Masquerade

## Site Navigation
