# Paladin

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Paladin](https://the-eminence-in-shadow.fandom.com/wiki/Paladin)

Paladin (聖騎士, Sei Kishi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) were holy knights tasked with protecting the Church.

## Overview

Paladins are knights who embody the justice they believe in, serving the Goddess Beatrix and receiving a chosen knight's baptism by the Church.

## Templars

Unbeknownst to the public, the Church also established a covert sub-branch with radical ideologies called the "[Templars](Templars.md "Templars")," answering directly to the Church itself.

The Templars are a clandestine assassination group under Church authority, leading the Inquisition from their base in Orum. Throughout history, they've hunted and punished heretics, functioning as an execution squad eliminating those labeled heretics or possessed, all in the name of purifying in honor of Goddess Beatrix from the shadows.

The Templars represent a dark chapter in the Church's history, composed of fiercely trained soldiers indoctrinated with radical teachings through harsh training. Led by the secretive Saint [Victoria](Victoria.md "Victoria"), they operated as a murderous group hidden within church dogma.

## History

When Beta was younger, she once fought alongside a Paladin to save a "Compatible" from Demon Possession, recalling the intense struggle. However, with her current strength, she's determined never to witness such a disgraceful scene again.

## Powers & Abilities

In terms of pure fighting power, Paladins' strength is considered incomparable to that of any average knight.[[1]](#cite_note-V2C1-1) However, they are completely outmatched by elite Shadow Garden members.

Paladins boast superior magic resistance and strong magical defenses against physical attacks, thanks to their rigorous advanced combat training.

## Trivia

## References

1. Volume 2 Chapter 1: Fun Times at the Goddess's Trial!

## Side Navigation
