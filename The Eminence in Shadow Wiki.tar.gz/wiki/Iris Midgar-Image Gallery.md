# Iris Midgar/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Iris%20Midgar/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Iris%20Midgar/Image%20Gallery)

Main

Chronology

Relationships

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Incognito Date: Iris Midgar

Crimson Spirit: Iris Midgar

Innate Sword: Iris Midgar

Bashful Santa: Iris Midgar

Game Event: A Gift from Miss Santa!
