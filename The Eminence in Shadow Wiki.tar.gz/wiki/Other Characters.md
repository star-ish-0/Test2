# Other Characters

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Other%20Characters](https://the-eminence-in-shadow.fandom.com/wiki/Other%20Characters)

## The Three Oji-sans

The Three Oji-sans are members of the Vow of Black Rose and comrades of Cid Kagenou.

### Personality

These three men were motivated by their desire to be wealthy and famous. Despite that, they have shown to be very kind to Cid when he was part of their group.
