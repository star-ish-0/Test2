# The Eminence in Shadow Movie: Lost Echoes

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/The%20Eminence%20in%20Shadow%20Movie%3A%20Lost%20Echoes](https://the-eminence-in-shadow.fandom.com/wiki/The%20Eminence%20in%20Shadow%20Movie%3A%20Lost%20Echoes)

## The Eminence in Shadow: Lost Echoes

### Kana

陰の実力者になりたくて！残響編

### Romaji

Kage no Jitsuryokusha ni Naritakute! Zankyōhen

## Episode Information

### Air Date

2027

### Adapted From

Volume 4 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kato Kanichi

Episode Navigation

| Previous |
| --- |
| HIGHEST |

The Eminence in Shadow: Lost Echoes (陰の実力者になりたくて！残響編, Kage no Jitsuryokusha ni Naritakute! Zankyōhen[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is an upcoming film from the [anime adaptation](Anime.md "Anime") of The Eminence in Shadow.
The film was announced on December 20, 2023, following the conclusion of the [second season](Anime.md#Season_2 "Anime") of the anime. It was revealed at AnimeJapan 2026 and is set to open in Japanese theaters in 2027.

## Synopsis

- [English](#)
- [Japanese](#)

「陰の実力者」に憧れた少年は、

道半ばで命を失い、
シド・カゲノーとして異世界に
転生した。
新たな世界で陰に潜み、陰を狩る者――
シャドウを演じ、
闇の教団を倒すべく「シャドウガーデン」を
率いて（おふざけで）暗躍する日々。
しかし世界の闇たる「ディアボロス教団」は
実在し、彼の知らぬところで「シャドウガーデン」は教団との抗争を繰り広げていた。

教団最高幹部の一人・モードレッドを下したシャドウは、突如開いた別世界へのゲートへと吸い込まれてしまう。
追いかけてきたベータと共に辿り着いた場所——それは、かつて影野ミノルとして生きた“日本”だった。
魔獣によって荒廃した世界。人類に残された拠点「メシア」。
そして、前世の同級生・アカネとの邂逅。
変わり果てた故郷・日本で、シャドウは何を為すのか……。

己の真実から、目を背けるな——[[1]](#cite_note-1)

## Summary

## Characters

- Cid Kagenou
- [Beta](Beta.md "Beta")
- Akane Nishino

Characters below may be out of order of appearance:
- [Yuuka](Yuuka.md "Yuuka")

...

## Promotional Videos

「劇場版 陰の実力者になりたくて！ 残響編」特報

PV #1

『劇場版 陰の実力者になりたくて！ 残響編』特報第2弾｜2027 ROADSHOW

PV #2

## Trivia

- [xXSilverHairedElfBabeXx](Beta.md "Beta") was banned from the [Messiah](Messiah.md "Messiah") intranet message-boards for posting death threats against FallenAngelOfRebellion because he mocked the Black Knight in a message board post.

## References

1. <https://shadow-garden.jp/#story>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| **The Eminence in Shadow: Lost Echoes** | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
