# Perv Asshat/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Perv%20Asshat/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Perv%20Asshat/Relationships)

Main

Chronology

Image Gallery

## Cult of Diablos

### [Mordred](Mordred.md "Mordred")

9th seat of the Round Knights and direct superior. Perv was never truly loyalty to him and would've switched allegiances to another member of the Round Knights if it served his goals. Nevertheless, he was able to garner his support in elevating him into the 12th seat under the conditions of his help in the upcoming internal power struggle within the Cult.[[1]](#cite_note-V4C3-1) He was demonstrated to be frightful of the Knight when he reported his botched attempt in capturing Rose and grew paranoid at the consequences of further failure.[[2]](#cite_note-:2-2) On the day of his wedding, he hid the case that contained the Ring of Succession Cid stole out of fear of incurring the Knight's wrath. His paranoia was proven true when he was ultimately beheaded by him after he witnessed his expose.[[1]](#cite_note-V4C3-1)

### Zenon Griffey

Fellow candidate for the 12th seat. Zenon was the prime candidate for the position after the Cult's leadership acknowledged his abilities. After being annihilated by Shadow however, other members within the Cult such as Lutheran and Perv himself had sought after the position.[[3]](#cite_note-3)

It is unknown whether Zenon knew Rose as a student or her engagement with his fellow candidate.

### Lutheran Barnett

The original 12th seated member of the Round Knights and fellow 2nd children.[[4]](#cite_note-4) In the event of his death, Perv was set to take his vacant seat after garnering conditional support from the 9th seat. Alas like Zenon, he too was foiled by Shadow and was ultimately killed after his incompetency leaked the Cult's existence.[[1]](#cite_note-V4C3-1)

### Reina Oriana

One of his collaborators in seizing Oriana. During his infiltration within the kingdom, it was at an unspecified time that he attracted her support in conspiring against her kingdom even helping him brainwash her husband. Although she saw him as her lover and even going as far to use her own daughter to get closer to him, it was revealed that he saw her as nothing more than a useful pawn and implied that he would've brainwash her like her husband or have her killed.[[5]](#cite_note-V4C2-5)

## Enemies

### Oriana Kingdom

#### Raphael Geerk Oriana

King of Oriana. In his last moments of consciousness, Raphael was able to send his daughter to Midgar for refuge and record his memo before the Cult ordered Perv to brainwash him. He saw the king as no more than a valuable asset in his elevation until Rose killed him.[[6]](#cite_note-V2CF-6) Angered by this inconvenience, he was forced to stop the civil war within his kingdom by attempting to coerce his daughter into marrying him.[[1]](#cite_note-V4C3-1)

#### [Grant](Grant.md "Grant")

Leader of the Anti-Chancellor faction. The Grant was Perv's political archenemy within the kingdom when he tried seizing it. much of their interactions is yet to be elaborated upon however, it is implied that the Grant saw through his scheming and tried stopping him from usurping Raphael's throne.[[2]](#cite_note-:2-2)

### Midgar Kingdom

#### Iris Midgar

Perv held a semi-hostile relationship with Iris. From their brief interactions from the Bushin Festival Tournament, the princess did not like him and politely asked him to leave her be. Initially harboring suspicion towards him, he playfully laughed off her antagonism and considered offing if her were to obstruct him.[[7]](#cite_note-V2C7-7)

#### Klaus Midgar

King of Midgar. Perv saw him as nothing but a mediocre king and plotted to have the brainwashed Raphael assassinate him in order for the Cult to install a puppet replacement. The plan on assassinating the king fell through Rose killed her father before he could follow through with the plan.[[6]](#cite_note-V2CF-6)

#### Alexia Midgar

Princess of Midgar. Alexia was a Rose's friend until the incident regarding Perv. Aware that the princess went to look after her, he sent several assailants to capture Rose. He ultimately failed when she was made into a member of Shadow Garden. Alexia witnessed the aftermath of her acquisition of Shadow's power and confronted her about the assailants' corpse.[[8]](#cite_note-8)

#### [Beatrix](Beatrix.md "Beatrix")

Perv had heard about the famed "Goddess of War" and was initially infuriated by her inadvertent suspicion. He was shocked to realize her presence at the festival and was left wary of her, concluding that he needed to be careful when she sensed something was off about Raphael despite the chancellor's attempts to hide the king's brainwashing.[[7]](#cite_note-V2C7-7)

### Shadow Garden

#### Cid Kagenou / Shadow (Mundane Mann)

Perv caught a glimpse of Cid at the Bushin Festival while in the deluxe suite but ignored the unassuming boy. Even when he saw him back Oriana, he didn't recognize his face and only saw him as [Shiron](Epsilon.md "Epsilon")'s apprentice. Paranoid of further failure, he tested him in hopes of both outing and humiliating him as an intruder. Touched by his performance of the "Moonlight Sonata", Perv admitted his mistake by Cid's performance and wanted to know his name without that realizing that he pocketed his Ring of Succession.[[5]](#cite_note-V4C2-5)

He was wary of Cid's alternate persona, Mundane Mann, and had his men investigate the contestant's past out of fear that he was to be a threat to his plans, Perv became more wary when they couldn't find anything about him, making him think Mundane may be from the Lawless City, a thought that made him nervous because he considered the possibility of him being a powerful individual with important connections and great influence in there. After the dark horse defeated Iris in one strike, he was not only left shock at the sight but also developed levels of jealousy at Mundane's strength.[[6]](#cite_note-V2CF-6)

On the other hand, Perv was terrified of Shadow after seeing his strength firsthand during the Bushin Festival after the latter revealed himself. He left Midgar and without stopping at the embassy out of fear of being targeted by the Shadow Garden's leader. When he lost the Ring of Succession on the supposed wedding day, he dismissed the idea that it was his doing believing that he would've just easily kill him for it.[[1]](#cite_note-V4C3-1)

#### [Epsilon (Shiron)](Epsilon.md "Epsilon")

Famous pianist and uncover agent for Shadow Garden. Perv was unaware of her true identity as Epsilon and allowed her to perform at his kingdom. Initially entrapped by his whimsical change in his security measures, her "apprentice" more than convinced him into believing that he wasn't an intruder, she was able to help him pocket the Ring of Succession before fleeing.[[5]](#cite_note-V4C2-5) Perv had a genuine respect for her as a pianist, considering her a genius pianist and her music far beyond their current time and was delighted to have her perform her music.

#### Rose Oriana (666)

Perv was initially Rose's fiancée chosen by King Oriana. However, in reality, Perv wanted to use Rose to elevate his standings within the Cult and become the 12th Knight of Round. Perv's first act of malice towards Rose was by presenting the princess her brainwashed father before framing Rose for attempted assault against him. He then blackmailed Rose to submit to him otherwise he'll command King Oriana to murder Klaus Midgar, resulting in a war between the two kingdoms.

To Perv's horror, Rose ultimately murdered her father, costing him and the Cult their ability to control the Oriana Kingdom. Combined with Rose escaping to Shadow Garden, Perv was reprimanded by his superiors. After her return to Oriana Kingdom and accepting to marry him, Perv constantly manipulated her under the belief her mother was held as a hostage and would murder her if she didn't behave and did what he told her to do. He also showed little to no respect to Rose, to the point of mistreating her. After learning she'd been crying, after her secret meeting with Cid in her chambers, Perv choked her because she didn't let him touch her. Perv's antagonism with Rose reached a breaking point when he tried to attack the princess in a murderous rage after he was exposed as a traitor to the Oriana Kingdom. He was easily defeated by Rose, leading to his death at the hands of Mordred.

## References

1. Volume 4 Chapter 3: Crashing the Ceremony!
2. Episode 20
3. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
4. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
5. Volume 4 Chapter 2: Begin Operation: Obstruction!
6. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
7. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
8. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
