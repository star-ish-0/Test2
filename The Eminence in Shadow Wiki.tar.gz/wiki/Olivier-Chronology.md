# Olivier/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Olivier/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Olivier/Chronology)

[Main](Olivier.md "Olivier")

Relationships

Image Gallery

## Synopsis

Centuries ago, originally Olivier was a normal elf until she was kidnapped by the Cult of Diablos, to perform an experiment with her and all the other children, boys and girls alike they had kidnapped and collected to implant Diablos Cells, in an attempt to create powerful soldiers to fight the Demon King Diablos. The experiments resulted in almost failure, since most of the children ended up dying, and a small group of girls survived because they could not tolerate the blood of the demon in their veins.

Luckily for the Cult, 3 girls survived the experiments, who turned out to be an Elf, a Therianthrope and a Human, Olivier was one of the other 2 surviving individuals. The cult carried out more experiments to make them stronger and powerful, creating weapons and equipment for them so that when they were adults and ready, they would go fight the Demon King Diablos.

It was historically recorded that years later, Olivier already prepared along with the other two heroes, which is the Therianthrope hero [Lily](Lily.md "Lily") and Human Hero ([Freya](Freya.md "Freya"); WN Only) went to exterminate the demon [Diablos](Aurora.md "Aurora") by order of the Cult, which resulted in the demon's defeat. During the battle, Olivier managed to cut off the demon's left arm with her sword, which was then sealed in the [Sanctuary](Sanctuary.md "Sanctuary"). In the end, she and the other two heroes were cursed by Diablos so that their descendants would be [possessed](Possession.md "Possession") with rotten bodies.

However, the truth was, Olivier was one of few people who are compatible with Diablos Cells. Hence, she was tasked by the Cult to gather more cells. Moreover, the Cult has already manipulated historical records globally and misgendered Olivier as a man, so that no one would be able to find out the real facts and try to investigate the truth.

In recent years, the Wandering Swordsman [Venom](Venom.md "Venom") managed to summon her via "Goddess's Trial" at [Lindwurm](Lindwurm.md "Lindwurm") but Olivier won the match.

### Sanctuary Infiltration

During the infiltration of the Holy Ground, the group consisting [Alpha](Alpha.md "Alpha"), [Delta](Delta.md "Delta") and [Epsilon](Epsilon.md "Epsilon") managed to infiltrate the [Sanctuary](Sanctuary.md "Sanctuary") with the help of their lord Shadow, along with [Beta](Beta.md "Beta") (disguised as Natsume Kafka), Rose, Alexia, and the Acting Archbishop Jack Nelson who was held as a hostage. There, Alpha reveals the truth of everything as well as her relation to Olivier, and how Olivier is misgendered as a man, but in reality, is a woman and how the cult distorts history. Later Nelson reveals his true identity and tries to kill everyone, but Delta and Alpha manage to confront him without problems.

During the confrontation, [Olivier](Olivier.md "Olivier") is summoned as a mindless puppet with great magical power by Nelson to eradicate the members of Shadow Garden. But they retreat before Olivier starts fighting them as [Alpha](Alpha.md "Alpha") dragging [Delta](Delta.md "Delta") away who was in battle euphoria, after having defeated more than a hundred of Nelson's magical copies.

Later, Olivier is ordered by Nelson to kill Cid who was there along with [Aurora](Aurora.md "Aurora")'s ghost. Cid manages to dodge her deadly strike, after receiving multiple wounds on his body. During the fight, numerous copies of Olivier appear, and in the end, he receives a fatal wound from the real Olivier. Cid who planned to get impaled by the real Olivier takes this moment to strangle [Olivier](Olivier.md "Olivier")'s neck and gets rid of the copies. Then he destroys the entire Sanctuary together with Olivier and Nelson with his atomic move.
