# Gamma/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Gamma/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Gamma/Chronology)

[Main](Gamma.md "Gamma")

[Relationships](Gamma-Relationships.md "Gamma/Relationships")

Image Gallery

## Background

### Past

Like with the rest of Shadow Garden, Gamma presumably contracted [Possession](Possession.md "Possession") at some point and was promptly cast out by her family and society until Cid stumbled upon her and subsequently healed her, after which she was taken into the organization by [Alpha](Alpha.md "Alpha").

## Volume 1

### First Assault on the Cult

Gamma took part in rescuing Claire alongside the "Seven Shadows". She and her team took care most of the guards, while Shadow killed Viscount [Grease](Grease.md "Grease"). After the successful rescue, they had to allow Claire to return home on her own and also hide their involvement. Gamma would leave her master, Cid Kagenou along with the other members to hunt down the Cult of Diablos.[[1]](#cite_note-V1C1-1)

### Midgar Academy Terrorist Attack

Gamma reintroduced herself to Shadow when he entered one of Mitsugoshi's stores, as she welcomed him before tripping down the steps. Gamma told him of her business success and the great fortune that she has procured from it, leaving him in amazement. Gamma was then rewarded by her leader on this venture with him showing off his power. Believing he came to inquire about the serial killers pretending to be Shadow Garden, she told him what they knew until Shadow informed them that he had a lead. An awestruck Gamma summoned [Nu](Nu.md "Nu") to assist him.[[2]](#cite_note-V1C4-2)

She then set up an operation to save the Midgar Academy for Dark Knights from a terrorist attack perpetrated by the Cult.[[3]](#cite_note-V1C6-3) After the school was saved, she and Alpha discussed their master's triumph over the terrorist leader, to which she gave a smile with respect for her master and noticed that Shadow was labelled as enemy to the kingdom and was wanted for mass murder, kidnapping, arson, and robbery. Gamma told [Alpha](Alpha.md "Alpha") that Shadow proclaimed how he would gladly accept the guilt for all crimes, but that wouldn't change anything and they would keep doing what they must. A reflective [Alpha](Alpha.md "Alpha") thought that they stood for righteousness, but it seemed Shadow doesn't see it that way and they must live up to his resolve. Then, [Alpha](Alpha.md "Alpha") ordered Gamma to assemble the available "Seven Shadows".[[4]](#cite_note-V1FC-4)

## Volume 2

### Bushin Festival Tournament

After the time of the [Sanctuary](Sanctuary.md "Sanctuary") operation mission has passed, Gamma is in Madlid City, the minor region on the outskirts of the Velgalta Empire. She is negotiating with [Rude](Rude.md "Rude"), a eldest son of a feudal lord to buy the property estate and open a second Mitsugoshi store because the Mitsugoshi Company had already opening their branch in the Velgalta's imperial capital.

Gamma isn't sure at first because the Mitsugoshi company was carrying out a reconstruction process in the Sacred Land, [Lindwurm](Lindwurm.md "Lindwurm") after their lord Shadow had destroyed the Sanctuary under the dam water by unleashed his Atomic Attack until there was nothing left which resulted the city being flooded.

But, Nu tells her that they found petroleum in the city which makes Gamma decide to buy every property in that street and she explains to Rude that she will redevelop the city if he's willing to meet their conditions and make it the greatest city in Velgalta Empire. Then, she ordered her employees to buy up all the necessary land downstream of the Nyle tributary and building a canal there.[[5]](#cite_note-V2C3-5)

After concluding the negotiation, Gamma receives news and tell Alpha that the Royal Chancellor Perv Asshat from the Oriana Kingdom will be visiting the Royal Capital of Midgar along with the King Raphael Geerk Oriana.[[6]](#cite_note-6)

When Cid visited Gamma once more, he ordered her to help him enter the Bushin Festival tournament, but under a disguised alias. She helped him by changing his appearance and identity to that of an ordinary looking man, using the alias "Mundane Mann".[[7]](#cite_note-V2C4-7)

## Volume 3

### Great Trading Company Conflict

Gamma and Shadow Garden decided the time had come to place their company on top of the business world. With Mitsugoshi Company currently holding a strong standing due to their innovative products and its creation of the popular banking notes, this led the Major Corporate Alliance to send their private army to sabotage the Mitsugoshi Company supply lines by attacking their carriages, but they were no match for Shadow Garden's well-trained forces and supplies kept running smoothly. Gamma controlled the flow of information to hide Shadow Garden's involvement, but the likelihood of exposure remained as they continued their conflict.

The Alliance also dispatched their best assassins, The [Clovers](Clovers.md "Clovers"), with the objective of gathering all confidential documents, money, and manufacturing details, before engaging in sabotage, pillaging, and kidnapping of important personnel without failure. However, Gamma battled and (surprisingly) defeated one of the Clovers with the help of [Nu](Nu.md "Nu") ([Chi](Chi.md "Chi") and [Omega](Omega.md "Omega") in the anime), and thus foiled the attempt.[[8]](#cite_note-V3C5-8)

Moments later after the attack, Gamma received word that there are counterfeits of the Alliance's currency have entered circulation and report to [Alpha](Alpha.md "Alpha"). Then, [Alpha](Alpha.md "Alpha") order Gamma to start spreading rumors and send [the](664.md "664") [Numbers](665.md "665") team to investigated it. After hearing the teams report about their failure mission when the team return because "John Smith" are intercepting them and knowing that John Smith is form other organization because his description is not from the Cult, Gamma the send [Delta](Delta.md "Delta") to deal with him.[[9]](#cite_note-V3C6-9)

Gamma greatly worried about [Delta](Delta.md "Delta") because she disappear during her track on "John Smith" and discover of her fur that has been ripped out, knowing that she already dead and report [Alpha](Alpha.md "Alpha") about [Delta](Delta.md "Delta") circumstance. Her worry grew worse when she learned that Shadow seemingly abandoned them, but this was undone when [Beta](Beta.md "Beta") told them the truth by bringing a translated message. Gamma expressed happiness that Shadow was still loyal to them and that [Delta](Delta.md "Delta") was alive, relieved that her master had covertly gathered funding for Mitsugoshi Company to survive the market collapse of trust.[[10]](#cite_note-V3E-10)

After Major Corporate Alliance collapsed, Mitsugoshi Company became the most successful business in the kingdom and their companies' position became more solid than ever in the capital. And with the elimination of their competitors, Mitsugoshi Company held an economic power more influential than the kingdom, which could collapse them should they fall.

## Volume 5

### The Academy Disappearances

## References

1. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
2. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
3. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
4. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
5. Volume 2 Chapter 3: When Things Get Boring, It's Time for Explosives!
6. Episode 14
7. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
8. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
9. Volume 3 Chapter 6: Circulating Counterfeit Cash!
10. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fakes Bills!
