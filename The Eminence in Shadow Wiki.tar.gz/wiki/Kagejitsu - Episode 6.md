# Kagejitsu - Episode 6

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%206](https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%206)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu_-_Episode_6?action=edit).

## Operation 6

## Special Title

### English

The Seven Shades want to recommend cute underwear!

### Kana

七陰はかわいい下着を勧めたい！

### Romaji

Shichi kage wa kawaī shitagi o susumetai!

## Episode Information

### Season

1

### Episode

6

### Air Date

November 30, 2022

### Adapted From

Light Novel

## Staff

### Director

Minoru Ashina

### Writer

Daisuke Aizawa

Episode Navigation

| Previous | Next |
| --- | --- |
| Operation 5 | Operation 7 |

Operation 6 is the sixth episode of the spin-off series [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu").

## Summary

Alpha mentions to Gamma that she wants to purchase clothing from a Mitsugoshi paper bag. Gamma questions why Alpha, who always wears private attire during missions, doesn't pay more attention to her underwear choices beyond just sports bras and shorts.

When Alpha admits she hasn't given it much thought, Gamma suggests she should consider wearing cuter or more fashionable underwear instead of only practical athletic wear. Alpha, confused by the concept, asks what advantage there is to expressing herself through underwear choices. Gamma struggles to answer this question.

Alpha apologizes for not understanding, explaining that being demon-possessed from a very young age affected "the sensitivity to be mindful of these things." Despite this, she decides to pay more attention and asks Gamma for recommendations.

Gamma enthusiastically produces a rack of hangers, mannequins, and a display case filled with various panties in different colors and designs. She suggests that Alpha, with her "beautiful contour," should show off her "body line" - a term Alpha has never heard before.

Alpha suddenly notices Zeta's tail sticking out from one of the changing cubicles. When confronted, Zeta emerges, and Gamma asks how long she's been hiding there. Zeta responds with exasperation that Gamma, as usual, took too long to notice her presence.

The conversation shifts when Gamma asks Zeta what kind of underwear she wears. Zeta reluctantly admits she doesn't wear any, which shocks both Alpha and Gamma. Blushing with her ears lying flat against her head, Zeta explains that it's normal for beastkin to go without underwear.

Alpha and Gamma both agree that this is "too daring."

---

This episode explores the Seven Shadows' different perspectives on clothing choices, personal expression, and cultural differences between humans and beastkin.

## Characters

- [Alpha](Alpha.md "Alpha")
- [Gamma](Gamma.md "Gamma")
- [Zeta](Zeta.md "Zeta")

## Trivia

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • **Episode 6** • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
