# White Demon

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/White%20Demon](https://the-eminence-in-shadow.fandom.com/wiki/White%20Demon)

|  |  |  |
| --- | --- | --- |
| “ | I think I’m pretty stupid, but…it’s always funny when I find someone even stupider than me! | ” |
| — White Demon, Light Novel Volume 03 | | |

## White Demon

### Japanese

白（しろ）い悪魔（あくま）

### Romaji

Shiroi Akuma

### Aliases

Watchdog

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

White

### Eye Color

Grey

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- Watchdog of The Crimson Tower
- Knight Captain (Formerly)

### Affiliation

Lawless City
Unknown Kingdom

## Debut

### Web Novel

Chapter 92

### Light Novel

Volume 3

### Manga

Chapter 27

### Anime

Episode 21

## Portrayal

### Japanese

[Jun Fukushima](https://en.wikipedia.org/wiki/Jun_Fukushima "wp:Jun Fukushima")

### English

[Chris Hutchison](https://en.wikipedia.org/wiki/Chris_Hutchison "wp:Chris Hutchison")

### French

Stéphane Ronchewski

White Demon (白（しろ）い悪魔（あくま）, Shiroi Akuma[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the Watchdog of the Crimson Tower at Lawless City. His task is to ensure that no one enters the Tower. Originally, he was the Knight Captain in an unknown kingdom. It was not until the day of the Red Moon, that the White Demon was killed in an instant, at the hands of Shadow, when he tried to prevent him from passing, to the Red Tower.

## Appearance

He is a tall lean man with dirty white hair. He has one arm, his left arm, with the other lost during his fight against in The Crimson Tower. His body is very thin and there is collar with a metal chain.

He wears a dirty hooded robe, if he doesn't move, he looks like a dirty pile of cloth piled up.

His physical appearance in general, at the age level, is around 35 to 30 years as such, since although he appears to be old, this is due to wear and tear, at the level of mental stress, among other things, that the White Demon, experienced during his times of slavery and torture, when he lost his battle against the vampires, and after a short time, he resigned himself to his services.

Despite his degraded state, the White Demon still maintains his strengths and physical abilities in good condition, despite the clothing he brings with him, among other things. So often, new people or rivals who know him misjudge him.

In the past, he used to wear a white uniform which casted the image of an ideal defender of the peace.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Killing was what gave my life meaning. It's what made me feel truly alive. | ” |
| — White Demon, Episode 22 | | |

The White Demon true nature was a psychopathic, bloodthirsty serial killer who only cares about killing people for his own sadistic pleasure. Ever since he was born, he’d taken joy in killing people when he felt the blood, the screams, and the looks of desperation on his victim faces made him feel alive.

After being beaten by [Crimson](Crimson.md "Crimson"), his misconceptions were shattered as he realized that he is not invincible and chose to stay away from those that were leagues above him.

## Chronology

### Early Life

He used to serve as a knight captain in an unknown kingdom. However, he secretly abused his position to murder civilians to see their scared and fearful reactions when he stalked his victims in the streets at night and had struck fear into countless hearts of the people in his kingdom. He was eventually discovered by one of his colleagues who caught him in the act, which in that moment he became the White Demon, leading him to massacre his entire knight order before fleeing. Then, once he escaped, he kept continue on his killing.

Four years ago, White Demon eventually making his way to the Lawless City. Feeling unbeatable, he challenges Crimson Tower, but got defeated by [Crimson](Crimson.md "Crimson") till a point he begs to live which caused him to become the Watchdog of Crimson Tower. After losing to Crimson, he made sure not to mess with people from Lawless City, especially the three Monarchs. Since then, his life purpose of freedom to kill was stolen from him, which he decides to waiting for an opportunity for his time until it will directly come to him.[[1]](#cite_note-V3C2-1)

### Red Moon Incident

During the Red Moon, [Quinton](Quinton.md "Quinton") and Goldy Gilded tried to step inside the tower to participate in the [Blood Queen](Elisabeth.md "Elisabeth") subjugation. He pulverized the Bushin veteran till a point of near death leaving Goldy to flee before being also capture by the city residents.[[2]](#cite_note-V3P-2)

When the Red Moon became worse, he waited for more swordsmen to come to satiate his bloodlust. However, the first two visitors were of two of the three monarchs, [Juggernaut](Juggernaut.md "Juggernaut") and [Yukime](Yukime.md "Yukime") whom he both let through knowing he couldn't win. When Shadow came after, the watchdog tried to kill him before realizing that the passerby bisected him into half until he hit the ground and sees the other half of his body.[[1]](#cite_note-V3C2-1)

## Powers & Abilities

The White Demon was a Knight who could easily slay his enemies and overwhelmingly strong enough to defeat experienced fighters, even Dark Knights who recognize him know they will not necessarily be match for him. He completely defeats [Quinton](Quinton.md "Quinton") and Goldy Gilded, all-powerful warriors and prolific participants of the Bushin Festival easily with only one arm.

### Weapons and Equipment

In the novel, White Demon uses a beautiful narrow single-edged sword that is longer than his height[[2]](#cite_note-V3P-2), while in the anime, he wields a double curved voulge.[[3]](#cite_note-3)

## Relationships

### Lawless City

#### [Elisabeth](Elisabeth.md "Elisabeth")

His master. As a result, for attempting to challenge the Monarch, the White Demon had to lose his arm and freedom as well as becoming the Watchdog of the Crimson Tower.

#### [Crimson](Crimson.md "Crimson")

When he tried to challenge Crimson, he was unable to lay so much as a finger on him until he was unilaterally defeated with his right arm has been severed and ended up having to plea for his life, making him to works as a Watchdog for the Crimson Tower.

#### [Juggernaut](Juggernaut.md "Juggernaut") & [Yukime](Yukime.md "Yukime")

Recognizing the two monarchs, the watchdog knew he would not stand a chance against them. Because of this, he decided to let them pass entering the Crimson Tower.

### Enemies

#### [Quinton](Quinton.md "Quinton")

Unaware of his infamy, the Bushin veteran underestimated the psychotic gatekeeper and was ultimately defeated. This defeat resulted in both his and Goldy's enslavement during the Red Moon incident.

#### Goldy Gilded

Of the two Bushin competitors that went to to the Lawless City, Goldy recognizes the former Knight by name. By the time he recognized the watchdog, he was too late when Quinton was easily taken down.

#### Shadow

Shortly after the two monarch enter the Crimson Tower, karma stroked the Watchdog as he underestimated the mysterious figure. This instance resulted in his death as the leader of Shadow Garden entered the tower, while thinking nothing of him.

## Image Gallery

## Trivia

- Due to the physical deterioration in part, plus the extras and other things, that he experienced in his first days as a slave of the vampires, the appearance of the White Demon, usually gives the impression that he is someone older, when the truth is not.

## References

1. Volume 3 Chapter 2: Storming the Crimson Tower!
2. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
3. Episode 21

## Site Navigation
