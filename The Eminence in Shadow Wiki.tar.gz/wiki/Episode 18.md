# Episode 18

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2018](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2018)

## Betting on a Moment

### Kana

刹那に賭ける

### Romaji

Setsuna ni Kakeru

## Special Title

### English

The Eminence in Shadow Wants To Stand Behind Your Back and Say That Line!

### Kana

陰の実力者は背後に回ってあのセリフを言いたい！

### Romaji

Kage no Jitsuryokusha wa Haigo ni Mawatte Ano Serifu wo Iitai!

## Episode Information

### Season

1

### Episode

18

### Air Date

February 1, 2023 JP
April 24, 2023 EN

### Adapted From

Volume 2 (LN)

## Staff

### Director

Yoshinobu Tokumoto

### Writer

Kunihiko Okada

### Storyboard

Yoshinobu Tokumoto

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Alpha ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Moonlight That Pierces the Darkness | Dancing Puppet |

Betting on a Moment (刹那に賭ける, Setsuna ni Kakeru[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the eighteenth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Cid and Claire receive an invitation to a tournament. At the festivities, Cid receives more attention than a background character desires.[[1]](#cite_note-1)

クレアからブシン祭のチケットを押しつけられたシド。会場に入ると隣席にはアイリスが。そうこうするうち本戦がスタート。再びジミナに変装したシドは、アンネローゼと対戦する。[[2]](#cite_note-2)

## Summary

Cid thinks to himself how when emotion sparks interpersonal conflict, time is usually a solution, but not with his sister. Shortly after coming to visit, Claire is choking Cid in his room, explaining that she was envisioning violent punishments for him and getting angrier with each second she was waiting for him. From this, Cid learns that some anger increases with time. Claire thinks he doesn't care, tightening her stranglehold wanting to see how long he holds his breath, but Cid corrects her that passing out is from halted blood flow not breathing. Claire doesn't mind since Cid broke his promise to go with Claire for their summer vacations, which he can't remember, as she states she is also angry that he keeps breaking his promises. As Cid tries to defuse the situation with guarantee of keeping his promise, she lets go of his throat and hands him a VIP ticket to the Bushin Festival, telling him be there and watch her as she will be replacing Princess Rose representing their school. Voicing herself as the next champion, Claire demands Cid be there to see her do it, strangling him a moment more to emphasize her severity.

Elsewhere, Alexia Midgar returns to where Natsume (Beta) was situated but finds she had already moved out from the landlady, with the excuse of traveling abroad for research. On the table, Alexia sees Beta had left her a dossier on relationships between Oriana Kingdom, the Church, and principle enterprises. But Alexia finds it insufferable she left her the details, before turning to see fireworks announce the next day of the Bushin Festival commencing across town. Alexia then grips her sword, voicing to an absent Natsume that she refuses her pity as she refuses to pity herself any longer. At the stadium, Cid goes to the Bushin Festival and finds his sister's ticket is a hyper-VIP seating. Escorted to his seat, Cid sees Iris Midgar and assumes he got it wrong. Iris realizes he is Claire's brother, explaining he is in the correct seat, while also explaining she plans to recruit Claire to her personal knight order when she graduates. Iris also apologizes to Cid for the Zenon Griffey incident, drawing people's attention, which worries Cid as it's not normal for a background character like him to be attended to be a named character in royalty.

When iris asks about Cid's friendship with Alexia, his attempt at explaining the relationship gets misunderstood but he drops it. Some students ask Iris if some competitor caught her eye, to which Iris notes Annerose, but Iris herself still intends to win the tournament. Cid wonders if there is someone else who caught her eye, suggesting Mundane Mann, as his upperclassmen in seating recognize him as Alexia's one-time boyfriend, and Iris explains he's Claire little brother. The two students explain that Mundane Mann is just fast and lucky with no skill, so Cid gets quietly excited that he cultivated Mundane's reputation to perfection. Iris explains that there is one more person who got her eye, an elf who was also the first Bushin Festival champion, although she won't be competing. The two students realize Iris is talking about [Beatrix](Beatrix.md "Beatrix"), but note that she haven't showed her face in public in over a decade. Cid recalls Beatrix, figuring she was strong but unaware that she was famous.

After Cid excuses himself and leaves, he feels the presence of someone strong, but is unable to reveal he knows it per his background character act, and [Beatrix](Beatrix.md "Beatrix") then shows herself after him, to which Cid acts surprised. Hefting a bundle of tuna king burgers, Beatrix wonders if he was ignoring her, but Cid denies it despite her probing. She asks him if he ran into an elf resembling like her since last time, but Cid denies it despite her probing again. Beatrix hoped she would find her as there are many people coming to the festival. Cid plays off that the festival is popular, then notes the bag of burgers Beatrix brought, and she explains she bought too many, so she gives one to Cid and he return the favor by gifting her one of his. Smiling, the two part ways.

In the VIP seating, Perv Asshat takes Cid's seat beside Iris, despite her telling him the seating aisle is reserved for students. Although he plays it off as showing them having a positive interaction, Iris tells him to knock it off considering his "engagement," as he calls it a lovers quarrel but Rose will return in due time. Perv explains that his king will be attending the festival tomorrow as he is ill today, as Iris informs him that father, King Klaus Midgar will be also be watching the fights starting tomorrow. As Perv then sees Annerose take to the arena, he had heard of her being in the middle of a training pilgrimage and would love to invite her to Oriana. Iris also states that a fencer of her caliber would be welcomed in Midgar, but Perv jests how such "avarice" is needless as Midgar Kingdom has plenty of dark knights, which Iris reminds him are part of their alliance between nations. As the next match readies, Perv asks Iris's opinion of Annerose's opponent, Mundane Mann. Iris states this is the first time she will see him fight, but while he doesn't look very strong, she isn't sure of Annerose's win as Mundane is a little unnerving. When asked why she thinks so, Iris clarifies that there is no uncertainty in his eyes, atypical for a weak fighter. Perv is interested, but he'd never have guessed such being ignorant of swordplay, yet despite Oriana's disdain for sword arts, Perv has some proficiency with a blade. As the fight nears, he is intrigued to see where it will go.

In their starting placements, Annerose plans to attack before Mundane can use his overwhelming speed to take an advantage. As the fight between them starts, Annerose immediately closes the distance to attack, but Mundane parries cleanly or dodges her attacks. She sees a chance to win and slashes him, but Mundane appears behind her as what she struck was just an after image. Without using any magic power, Mundane then quickly overpowers Annerose with blinding speed, sending her high to then strike her low. Surviving only due to Mundane now empowering his attack, Annerose realizes that her only option is to try and counterattack when he attacks. When Iris sees her stop, Perv comments on her plan to counterstrike. Annerose awaits and readies her counter, but Mundane stops mid-pace and dodges, which makes her realize he was still matching his attack to her and not the opposite. As Mundane then slashes, he defeats Annerose.

Recalling her words on his absolute confidence, Perv states that Iris was right. While she is surprised by the outcome, Iris is in disbelief that someone as strong as Mundane went unnoticed for so long. Perv asks if his fencing style comes from an established school, but Iris is uncertain despite his precise skill. Perv notes the next round would be Iris versus Mundane and wonders if she is confident in her victory. Iris states she can't match his beauty of swordplay, but it's not beauty that determines the winner as if this is all Mundane can do, then he won't be a match for her. However, there is a good chance that he is hiding something, which is why he disguised his stance and technique through the tournament to win his way up the ranks. Uncertain of his secret, Iris will cut him down regardless, as she hates to lose afterall.

Upon leaving, Perv orders his man to investigate Mundane, noting that it could be a problem if he is backed by the Lawless City. As his man wonders if Mundane is a part of Shadow Garden, Perv dismisses the idea because Mundane is a man, and he also doubts that Shadow Garden have any reason to make a scene at the Bushin Festival. Elsewhere, a bandaged Annerose finds and tells Mundane that she was completely defeated by him. She smiles as she explains that she left her country to become stronger, but she concludes she only did in her head and thanks him for the lesson. Extending a hand, Mundane replies that it was the first time he had to remove his shackles, telling Annerose she has nothing to be ashamed of, and the two shake hands. When she wonders how he became that strong, Mundane states he was a fool who abandoned everything in pursuit of strength. She invites him to enlist for government service in Velgalta and she can ensure a post worthy of him, but he declines as such is "too bright" for him. Annerose will resume her journey tomorrow, inviting him to see her again should he reconsider, grateful he showed her new heights to aspire to reach. Meanwhile, stadium security drag off Skel for accruing debt, as he barter's his friend's freedom for another chance to wager on the next match.

As the Bushin Festival resumes, Iris one-sidedly wins her match against her opponent by impacting him into a crater, with the overflow of magic disintegrating her sword afterward. Dead set on total victory, Iris is surprised to see Beatrix and follows her out the stadium. After introductions, Beatrix offers a burger for Iris to feel better, but Iris politely declines. At sunset, Cid is proud of himself having used some stylish sword skills he couldn't display as Shadow. Now that he had accomplished 70% of his plan at the Bushin Festival, Cid then wonders on how to finish it. The simple path is to win the tournament, but he could also go the epic route of defeating Iris to just disappear, stating his work is done. Or he wonders if he should get the evil route, acting like a shadowy assassin from a shadowy organization from the shadows to end her, to launch into unabashed combat. He returns home, finding Claire who notes how happy he is. Replying he is happy, Claire was waiting for him again and wondering if he had as much fun watching her match. Realizing what's going on, Cid then guesses he is dead.

Meanwhile, Rose Oriana takes shelter at the Midgar Academy, closed for reconstruction. Situating into a clean uniform, she holds onto the wrapper from the burger Cid gave her for moral support. Looking at her reflection in the broken mirror, she motivates herself for what she must do next.

## Characters

- Claire Kagenou
- Cid Kagenou
- Alexia Midgar
- [Beta](Beta.md "Beta") (Mentioned)
- Iris Midgar
- Zenon Griffey (Mentioned)
- [Beatrix](Beatrix.md "Beatrix")
- Perv Asshat
- Raphael Geerk Oriana (Cameo)
- Klaus Midgar (Mentioned)
- Annerose Nichtsehen
- Skel Etal
- Rose Oriana

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第18話予告≪ノーマルVer.≫「刹那に賭ける」

TVアニメ『陰の実力者になりたくて！』第18話予告≪スペシャルVer.≫「陰の実力者は背後に回ってあのセリフを言いたい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e018>
2. <https://shadow-garden.jp/1st/story/#story18>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • **Episode 18** • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
