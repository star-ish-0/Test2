# Klaus Midgar/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Klaus%20Midgar/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Klaus%20Midgar/Chronology)

Main

Relationships

Image Gallery

## Background

King Klaus served as a monarch of the Midgar Kingdom who later married and sired two children, Iris and Alexia. Klaus established a friendship with Raphael Geerk Oriana as they forged an alliance between both of their nations. At some unknown point, Klaus notice the Cult of Diablos existence and secretly fought their influence carefully because he understood the organization's history and their power which had been influential throughout the world.

## Klaus's Secret Political Maneuver

After his daughter Alexia Midgar is rescued from being kidnapped, Klaus learned that Zenon Griffey is the one responsible for his daughter kidnapping which exposing the Cult of Diablos existence to the public, along with the reveal of Shadow Garden which is a mysterious organization that openly opposes the Cult. Klaus then decides to take advantage of their attack to legally investigate their base to alleviate public concern.

But Klaus have to marked Shadow Garden as a renegade armed group and are wanted by the Kingdom after the terrorist incident in the Midgar Academy, so that his kingdom would not become a Cult's target while he was strategizing his next step.

As the events of the Goddess' Trial in [Lindwurm](Lindwurm.md "Lindwurm") were about to begin, Klaus intended to send his youngest daughter, Alexia to attend the event as a VIP guest and also investigate the dark rumors of the archbishop [Drake](Drake.md "Drake") regarding the corruption and missing orphans, as well as the relation with the Holy Church alongside the Crimson Order.

## Bushin Festival Tournament

After the incident at [Lindwurm](Lindwurm.md "Lindwurm"), Klaus was approach by his daughter, Iris Midgar, as she wanted to use the kingdom's authority to investigate the Holy Church. Even after hearing reports of suspicions of collusion between the the Holy Church and the Cult of Diablos, Klaus did not try to deal with it on the pretext that it was not a certainty with the facts at present and had no crucial evidence to justify a long-term investigation.

Furthermore, with the approaching of Bushin Festival event along with many honored guests from abroad to whom he must presently play host, Klaus think that this is certainly not a time where he can afford to present himself being antagonistic toward the Church for causing any undue turmoil. Also, Klaus wants to avoid upsetting his allies in Oriana and receiving a visit from their king. Iris is determined to get results and prove that she has power to stand up against the Divine Teachings, which Klaus often finds it tiresome to remind Iris of his words and also holds high expectations of her.[[1]](#cite_note-1)

Klaus going to the arena stadium to attend at the final tournament and meet King Raphael Geerk Oriana along with his Royal Chancellor, Duke Perv Asshat.[[2]](#cite_note-V2C8-2) Both rulers then watch the match between Iris and Mundane Mann until when Klaus saw his daughter defeat, he just sighed in disappointment and immediately left the stadium after her loss at the hands of Mundane.[[3]](#cite_note-:0-3)

Not long after leaving the VIP seating, Klaus is informed from his civil servant that King Raphael Oriana had been killed by his own daughter, Princess Rose Oriana and escape with the help from Mundane after he reveals his true appearance as Shadow which he currently doing engaged in battle against [Beatrix](Beatrix.md "Beatrix") that may go even outside of the stadium. Hearing this, Klaus suppose that he must consider invoking martial law.

Klaus asks about Perv and Raphael's body which he gets informed that Perv heading towards the outskirts on a carriage and is likely directly running back to Oriana Kingdom without stopping at the embassy, also the knight are securing Oriana's king body. King Klaus tells them to take good care of his body and return it to Oriana through Marquess [Grant](Grant.md "Grant"), who is the leader of the anti-chancellor faction.

When the civil servant think that the King action will be giving an low-key political move for helping the anti-Duke faction in Oriana to gain public support, Klaus explains that their nation needs time to make preparation to prepare themselves as the darkness that has been lurking since ancient times has taken a deeper hue and the Kingdom will be swallowed up in darkness if they unpreparedly decide to enter.[[4]](#cite_note-4)

## Great Trading Company Conflict

In the anime, Klaus looks concerned when he sees reports regarding the trade war between Mitsugoshi Company and the Major Corporate Alliance, especially the citizens' concern about the Alliance carrying out unauthorized inspections which have had an immeasurable negative impact on the market, due to rumors of counterfeit banknotes that have been circulating among citizens throughout the capital.

But unfortunately it was too late because counterfeit money had spread too far that causing public anxiety, which even led to inflation in the Midgar Kingdom's economy with the increasing circulation of money as counterfeit money increased the price of goods.[[5]](#cite_note-5)

Feeling that the situation could no longer be ignored, Klaus took action by sending the Knight Order to deal with the chaos for fear of a credit crisis, in order to prevent a market crash and ordering the arrest to all members of the Major Corporate Alliance, as the counterfeit money in circulation was the same as the banknotes they had made.

In order to calm the citizens' anxiety who want their gold coins back, Klaus orders Iris Midgar accompanied by the Crimson Order to arrest Garter Kikuchi, who is the leader of the Alliance, to check the contents of the MCA's bank vaults.[[6]](#cite_note-6)

## Bloody Midgar Serial Murder Terror

## References

1. Episode 14
2. Volume 2 Chapter 8: Lay Your Eyes on My True Powers!
3. Episode 19
4. Episode 20
5. Episode 26
6. Episode 27
