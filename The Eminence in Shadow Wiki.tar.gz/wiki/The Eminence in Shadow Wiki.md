# The Eminence in Shadow Wiki

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/The%20Eminence%20in%20Shadow%20Wiki](https://the-eminence-in-shadow.fandom.com/wiki/The%20Eminence%20in%20Shadow%20Wiki)

WARNING: This wiki contains spoilers from the original source material.

The Eminence in Shadow Wiki!

Welcome to The Eminence in Shadow Wiki

Your online source for information on the Web Novel, Light Novel, [Manga](Manga.md "Manga"), [Anime](Anime.md "Anime") and Game of
The Eminence in Shadow. We are currently editing:

*3,008* pages, *484* articles, *1,688* files, *29,582* edits with *8* editor(s)

About the Series

The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is an epic comedy action isekai about Cid Kagenou, a boy who dreams to enact his powers over the world while lurking in the shadows. With his organization, Shadow Garden, he forges a path through the darkness, all while remaining oblivious to the truth he's uncovered!
The series is written by Daisuke Aizawa and originally illustrated by [Touzai](https://www.pixiv.net/member_illust.php?id=16347608).
It began as a web novel posted on [Syosetu](https://ncode.syosetu.com/n0611em) in 2018 and was published as a light novel by [Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa"), later licensed by English publisher [YenPress](https://yenpress.com/series/the-eminence-in-shadow-light-novel).
The series has since been adapted into a manga, anime and game.

Social Media

[Official Website JP](https://shadow-garden.jp/) • [Official Twitter JP](https://twitter.com/Shadowgarden_PR) • [Official Discord JP](https://discord.com/invite/ft9kGVZXXk) • [Fan Discord EN](https://discord.com/invite/teis) • [Reddit EN](https://www.reddit.com/r/TheEminenceInShadow/)

Explore the World of The Eminence in Shadow

- [Characters](#)
- [Locations](#)

Shadow

[Alpha](Alpha.md "Alpha")

[Beta](Beta.md "Beta")

[Gamma](Gamma.md "Gamma")

[Delta](Delta.md "Delta")

[Epsilon](Epsilon.md "Epsilon")

[Zeta](Zeta.md "Zeta")

[Eta](Eta.md "Eta")

Claire Kagenou

Alexia Midgar

Rose Oriana

Sherry Barnett

[Aurora](Aurora.md "Aurora")

Iris Midgar

[Lambda](Lambda.md "Lambda")

[Nu](Nu.md "Nu")

[Victoria](Victoria.md "Victoria")

[664](664.md "664")

[665](665.md "665")

Akane Nishino

[Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku")

Information

[Getting Started](https://community.fandom.com/wiki/Help:Getting_Started "w:Help:Getting Started") • [Guides and Tutorials](https://community.fandom.com/wiki/Help:Contents "w:Help:Contents") • To Do • Community Portal



We're a collaborative community website that anyone, including you, can build and expand. Wikis like this one depend on readers getting involved and adding content. Check out any of the links above to get started, or ask the administrators if you'd like a bit of help or direction on where to start.

Synopsis

One big fat lie and a few twisted truths.

Even in his past life, Cid's dream wasn't to become a protagonist or a final boss. He'd rather lie low as a minor character until it's prime time to reveal he's a mastermind...or at least, do the next best thing-pretend to be one! And now that he's been reborn into another world, he's ready to set the perfect conditions to live out his dreams to the fullest. Armed with his overactive imagination, Cid jokingly recruits members to his organization and makes up a whole backstory about an evil cult that they need to take down. Well, as luck would have it, these imaginary adversaries turn out to be the real deal-and everyone knows the truth but him!

Source: [Yen Press](https://yenpress.com/9781975359058/the-eminence-in-shadow-vol-1-light-novel/)

Publication

Light Novels

Volume 1

Volume 2

Volume 3

Volume 4

Volume 5

Volume 6

Volume 7

Manga

Volume 1

Volume 2

Volume 3

Volume 4

Volume 5

Volume 6

Volume 7

Volume 8

Volume 9

Volume 10

Volume 11

Volume 12

Volume 13

Volume 14

Volume 15

Volume 16

Volume 17

Volume 18

Anime

[Season 1](Anime.md "Anime")

[Season 2](Anime.md "Anime")

Movie: Lost Echoes

Blu-ray/DVD

Volume 1

Volume 2

Volume 3

Volume 4

Advertisement

JOIN THE DISCORD

Latest Releases

- [Light Novel](#)
- [Manga](#)

- [English](#)
- [Japanese](#)

Volume 6 | February 4th, 2025

Volume 7 | April 1st, 2026

- [English](#)
- [Japanese](#)

Volume 15 | September 22nd, 2026

Next: Volume 16 | January 26th, 2027

Volume 18 | May 25th, 2026

Next: Volume 19 | November 25th, 2026

Helping Out

We're looking for people to help edit stubs and add [New Pages](https://community.fandom.com/wiki/Help:New_page "w:c:Community:Help:New page") to this wiki. If you have questions or would like a specific goal to focus on, feel free to contact the Administrators for help or check out the local Community portal!

Affiliations

|  |  |  |
| --- | --- | --- |
| [Discuss](https://animanga.fandom.com/f) [Wiki List](https://animanga.fandom.com/wiki/List_of_Anime_and_Manga_Wikia/Semantic_List "w:c:animanga:List of Anime and Manga Wikia/Semantic List") [Spotlight Request](https://animanga.fandom.com/wiki/Animanga_Wiki_talk:Spotlights "w:c:animanga:Animanga Wiki talk:Spotlights") | Fall Season 2026 Anime Wikis  TV Anime   - [A Returner's Magic Should Be Special Season 2](https://a-returners-magic-should-be-special.fandom.com/wiki/ "w:c:a-returners-magic-should-be-special") - [A Tale of the Secret Saint](https://a-tale-of-the-secret-saint.fandom.com/wiki/ "w:c:a-tale-of-the-secret-saint") - [A Wild Last Boss Appeared! Season 2](https://a-wild-last-boss-appeared.fandom.com/wiki/ "w:c:a-wild-last-boss-appeared") - [Ao Ashi Season 2](https://ao-ashi.fandom.com/wiki/ "w:c:ao-ashi") - [Battle Spirits [Re]: Zekkai no Kuu](https://battle-spirits.fandom.com/wiki/ "w:c:battle-spirits") - [Black Clover Season 2](https://blackclover.fandom.com/wiki/ "w:c:blackclover") - [Blue Box Season 2](https://blue-box.fandom.com/wiki/ "w:c:blue-box") - [Brave Saga Dandivine](https://bravesaga.fandom.com/wiki/ "w:c:bravesaga") - [Cardfight!! Vanguard: Divinez Unmei Seisen-hen](https://cardfight.fandom.com/wiki/ "w:c:cardfight") - [Chitose is in the Ramune Bottle Part 2](https://chiramune.fandom.com/wiki/ "w:c:chiramune") - [Diamond no Ace: Act II Second Season Part 2](https://diamondnoace.fandom.com/wiki/ "w:c:diamondnoace") - [Dragon Ball Super: Beerus](https://dragonball.fandom.com/wiki/ "w:c:dragonball") - [Firefly Wedding](https://firefly-wedding.fandom.com/wiki/ "w:c:firefly-wedding") - [From Far Away](https://from-far-away.fandom.com/wiki/ "w:c:from-far-away") - [FX Senshi Kurumi-chan](https://fxkurumi.fandom.com/wiki/ "w:c:fxkurumi") - [Gensou Suikoden](https://suikoden.fandom.com/wiki/ "w:c:suikoden") - [Hyouken no Majutsushi ga Sekai wo Suberu II](https://hyouken.fandom.com/wiki/ "w:c:hyouken") - [Keroro Gunso☆](https://keroro.fandom.com/wiki/ "w:c:keroro") - [Magic Knight Rayearth (2026)](https://magicknightrayearth.fandom.com/wiki/ "w:c:magicknightrayearth") - [Magical★Explorer](https://magiex.fandom.com/wiki/ "w:c:magiex") - [Magical Sisters LuluttoLilly Part 2](https://magical-sisters-luluttolilly.fandom.com/wiki/ "w:c:magical-sisters-luluttoLilly") - [Mahou Shoujo Ikusei Keikaku: Restart](https://mahou-shoujo-ikusei-keikaku.fandom.com/wiki/ "w:c:mahou-shoujo-ikusei-keikaku") - [Mission: Yozakura Family Season 2 Part 2](https://mission-yozakura-family.fandom.com/wiki/ "w:c:mission-yozakura-family") - [Nia Liston: The Merciless Maiden](https://nia-liston.fandom.com/wiki/ "w:c:nia-liston") - [Overgeared](https://overgeared.fandom.com/wiki/ "w:c:overgeared") - [Psyren](https://psyren.fandom.com/wiki/ "w:c:psyren") - [Ranma 1/2 (2024) 3rd Season](https://ranma.fandom.com/wiki/ "w:c:ranma") - [Reborn as a Space Mercenary](https://reborn-space-mercenary.fandom.com/wiki/ "w:c:reborn-space-mercenary") - [Reincarnated as a Sword Season 2](https://ten-ken.fandom.com/wiki/ "w:c:ten-ken") - [Reincarnated as an Aristocrat with Appraisal Skill Season 3](https://reincarnated-as-an-aristocrat-with-appraisal-skill.fandom.com/wiki/ "w:c:reincarnated-as-an-aristocrat-with-appraisal-skill") - [Sasaki and Peeps Season 2](https://sasaki-and-peeps.fandom.com/wiki/ "w:c:sasaki-and-peeps") - [Shinja Zero no Megami-sama to Hajimeru Isekai Kouryaku](https://shinjazero.fandom.com/wiki/ "w:c:shinjazero") - [So What's Wrong with Getting Reborn as a Goblin?](https://so-whats-wrong-with-getting-reborn-as-a-goblin.fandom.com/wiki/ "w:c:so-whats-wrong-with-getting-reborn-as-a-goblin") - [Tank Chair](https://tank-chair.fandom.com/wiki/ "w:c:tank-chair") - [The Apothecary Diaries! Season 3](https://kusuriya.fandom.com/wiki/ "w:c:kusuriya") - [The Detective is Already Dead Season 2](https://the-detective-is-already-dead.fandom.com/wiki/ "w:c:the-detective-is-already-dead") - [The Prince of Tennis II U-17 World Cup: Final Member Selection Match](https://princeoftennis.fandom.com/wiki/ "w:c:princeoftennis") - [The Ramparts of Ice Season 2](https://the-ramparts-of-ice.fandom.com/wiki/ "w:c:the-ramparts-of-ice") - [The Vermilion Mask](https://the-vermilion-mask.fandom.com/wiki/ "w:c:the-vermilion-mask") - [Toaru Anbu no ITEM](https://toarumajutsunoindex.fandom.com/wiki/ "w:c:toarumajutsunoindex") - [Tokyo Revengers: Santen Sensou-hen](https://tokyorevengers.fandom.com/wiki/ "w:c:tokyorevengers") - [Tougen Anki: Nikko Kegon no Taki-hen](https://tougen-anki.fandom.com/wiki/ "w:c:tougen-anki")   TV (Multiseason)   - [Bleach: Thousand Years Blood War Part 4](https://bleach.fandom.com/wiki/ "w:c:bleach") - [Meitantei Precure!](https://prettycure.fandom.com/wiki/ "w:c:precure") - [Onegai AiPri](https://pretty-series.fandom.com/wiki/ "w:c:pretty-series") - [Red River](https://anatolia-story.fandom.com/wiki/ "w:c:anatolia-story")   ONA   - [Cyberpunk: Edgerunners 2](https://cyberpunk.fandom.com/wiki/ "w:c:cyberpunk") - [Demons' Crest](https://demonscrest.fandom.com/wiki/ "w:c:demonscrest") - [Disney Twisted-Wonderland The Animation: Episode of Savanaclaw](https://twisted-wonderland.fandom.com/wiki/ "w:c:twisted-wonderland") - [Duel Masters LOST: Danzai no Shounen](https://duelmasters.fandom.com/wiki/ "w:c:duelmasters") - [Fool Night](https://fool-night.fandom.com/wiki/ "w:c:fool-night")   OVA   - [Magical Princess Minky Momo (OVA)](https://magical-princess-minky-momo.fandom.com/wiki/ "w:c:magical-princess-minky-momo")   Specials   - [My Happy Marriage Special](https://my-happy-marriage.fandom.com/wiki/ "w:c:my-happy-marriage")   Film   - [BanG Dream! Ave Mujica: Prima Aurora](https://bandori.fandom.com/wiki/ "w:c:bandori") - [Girls und Panzer das Finale Part 5](https://gup.fandom.com/wiki/ "w:c:gup") - [Made in Abyss: Mezameru Shinpi](https://madeinabyss.fandom.com/wiki/ "w:c:madeinabyss") - [Mahoutsukai no Yoru](https://typemoon.fandom.com/wiki/Mahoutsukai_no_Yoru "w:c:typemoon:Mahoutsukai no Yoru") - [Maebashi Witches: Majo Minarai no Emoemories](https://maebashi-witches.fandom.com/wiki/ "w:c:maebashi-witches") - [Rakuen Tsuiho: Kokoro no Resonance](https://rakuen-tsuiho.fandom.com/wiki/ "w:c:rakuen-tsuiho") - [Seishun Buta Yarou wa Dear Friend no Yume wo Minai](https://aobuta.fandom.com/wiki/ "w:c:aobuta") - [Soukou Kihei Votoms: Haiiro no Hexe](https://votoms.fandom.com/wiki/ "w:c:votoms") - [Takopi's Original Sin: Thank You, See You Tomorrow](https://takopis-original-sin.fandom.com/wiki/ "w:c:takopis-original-sin") - [The Apothecary Diaries! Movie](https://kusuriya.fandom.com/wiki/ "w:c:kusuriya")   [[Edit this list]](https://community.fandom.com/wiki/Template:Animangafooter/fall "w:Template:Animangafooter/fall") | [Anime / Manga Hub](https://animanga.fandom.com/wiki/ "w:c:Animanga") October [Spotlights](https://animanga.fandom.com/wiki/Animanga_Wiki:Spotlights "w:c:animanga:Animanga Wiki:Spotlights"):  [Magical★Explorer](https://magiex.fandom.com/wiki/ "w:c:magiex")  [Magic Knight Rayearth](https://magicknightrayearth.fandom.com/wiki/ "w:c:magicknightrayearth")  [Space Battleship Yamato](https://yamato.fandom.com/wiki/ "w:c:yamato") |
| [All](https://animanga.fandom.com/wiki/Category:Series_with_Wikis "w:c:animanga:Category:Series with Wikis") • [Action](http://community.fandom.com/wiki/Template:Animangafooter/action "Template:Animangafooter/action") • [Adventure](http://community.fandom.com/wiki/Template:Animangafooter/adventure "Template:Animangafooter/adventure") • [Comedy](http://community.fandom.com/wiki/Template:Animangafooter/comedy "Template:Animangafooter/comedy") • [Drama](http://community.fandom.com/wiki/Template:Animangafooter/drama "Template:Animangafooter/drama") • [Fantasy](http://community.fandom.com/wiki/Template:Animangafooter/fantasy "Template:Animangafooter/fantasy") • [Horror](http://community.fandom.com/wiki/Template:Animangafooter/horror "Template:Animangafooter/horror") • [Mecha](http://community.fandom.com/wiki/Template:Animangafooter/mecha "Template:Animangafooter/mecha") • [Memes](http://community.fandom.com/wiki/Template:Animangafooter/meme "Template:Animangafooter/meme") • [Mystery](http://community.fandom.com/wiki/Template:Animangafooter/mystery "Template:Animangafooter/mystery") • [Romance](http://community.fandom.com/wiki/Template:Animangafooter/romance "Template:Animangafooter/romance") • [Sci-fi](http://community.fandom.com/wiki/Template:Animangafooter/science_fiction "Template:Animangafooter/science fiction") • [Slice of Life](http://community.fandom.com/wiki/Template:Animangafooter/slice_of_life "Template:Animangafooter/slice of life") • [Sports](http://community.fandom.com/wiki/Template:Animangafooter/sports "Template:Animangafooter/sports") • [Supernatural](http://community.fandom.com/wiki/Template:Animangafooter/supernatural "Template:Animangafooter/supernatural") • [Manhwa](http://community.fandom.com/wiki/Template:Manhwafooter "Template:Manhwafooter") • [Manhua](http://community.fandom.com/wiki/Template:Manhuafooter "Template:Manhuafooter") |
