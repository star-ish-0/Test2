# Petos/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Petos/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Petos/Relationships)

[Main](Petos.md "Petos")

[Chronology](Petos-Chronology.md "Petos/Chronology")

Image Gallery

## Cult of Diablos

### Knight of Rounds

#### [Fenrir](Fenrir.md "Fenrir")

Fenrir notice that Petos normally wouldn't be able to become Rounds, due to his achievement being weak, stating that his promotion was nothing more than a substitute and never acknowledged Petos' position is equal to him.

## Enemies

### [Zeta](Zeta.md "Zeta")

For his role in the genocide of her people and special cruelty upon her family, Petos is the most hated man in Zeta's life. He also seeks to take her in to conclude his "achievement" and solidify his position within the Knights of Rounds.
