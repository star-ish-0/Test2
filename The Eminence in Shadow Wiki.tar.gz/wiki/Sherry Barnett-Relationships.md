# Sherry Barnett/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sherry%20Barnett/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Sherry%20Barnett/Relationships)

Main

Chronology

Image Gallery

## Cid Kagenou / Shadow

Sherry was Cid's upperclassman at Midgar Academy, when the two encountered one another after Cid passed Sherry his chocolate at random. Cid and Sherry had a friendly relationship, although Cid doesn't know that Sherry had developed genuine feelings for him. It was during the terrorist attack at the academy that Cid took serious interest in her, thinking she might be important to the "main plot".

One thing to note is that it's implied Cid genuinely did care for Sherry, as he constantly protected her from the terrorists. This was explicitly demonstrated when he was disgusted upon learning that Lutheran Barnett murdered Sherry's mother as he personally gave the villain the same painful death in retribution. Although, he did not tell the witnessing Sherry about her adoptive father's true nature, thinking it was better she kept her loving view of him and hating his alter-ego Shadow.

In the anime, she is seen to have developed an obsessive vendetta towards Shadow.[[1]](#cite_note-:1-1) The said scene is absent in the light novel.

## Lutheran Barnett

Lutheran was Sherry's stepfather and adopted her after her mother Lukeria's funeral while continuing the latter's work. While working undercover as assistant principal at Midgar Academy, he puts on the facade of a humble man with a close relationship with Sherry. In reality, Lutheran was power-hungry and exploited his stepdaughter and her late mother to further his own gain unbeknownst to her. Sherry deeply cares about her stepfather and is unaware of his misdeeds even after his death.

## Lukreia Crowley

Sherry's late mother, Sherry spent much of her childhood next to her while working. After her death, Sherry would continue her work spending the rest of her childhood with Lutheran as her stepfather.

## Alexia Midgar

Assumedly Alexia's former upperclassman, not much is known of their interactions aside from being entrusted to decipher a device founded from the Zenon incident and when she notably talked to the princess regarding Cid. Upon hearing that the two never dated in the first place, she was relieved and reiterated that they weren't dating much to her ire.

In the game, the princess alongside [Nu](Nu.md "Nu") has expressed jealousy towards the former student when two gave chocolates and cookies to each other respectively.

## Iris Midgar

Although a student, Iris has acknowledged her mechanical abilities and entrusted her with the device from a Cult of Diablos base during the Zenon incident. It is unknown whether the two interacted beyond the device.

## References

1. Episode 20
