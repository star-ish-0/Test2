# Episode 32

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2032](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2032)

## HIGHEST

## Special Title

### English

The Eminence in Shadow wants to be The Eminence in Shadow!

### Kana

陰の実力者は陰の実力者になりたくて！

### Romaji

Kage no Jitsuryokusha wa Kage no Jitsuryokusha ni Naritakute!

## Episode Information

### Season

2

### Episode

12 (32)

### Air Date

December 20, 2023 JP & EN

### Adapted From

Volume 4 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Ending

[HIGHEST](HIGHEST.md "HIGHEST")

Episode Navigation

| Previous | Next |
| --- | --- |
| Determination | Lost Echoes |

HIGHEST is the twelfth and finale of the second season and the thirty-second episode of [The Eminence in Shadow](Manga.md "Manga") [anime adaptation](Anime.md "Anime")

## Synopsis

- [English](#)
- [Japanese](#)

Let the banquet of slaughter begin in the season finale.[[1]](#cite_note-1)

シャドウが第四魔王「ラグナロク」を相手取る中、ベータとイプシロンはモードレッドと対峙していた。
戦いの中で、二人はこの世界に秘められたある“仮説”を聞き出す。[[2]](#cite_note-2)

## Summary

In the midst of chaos. Mordred, the Ninth Seat of Rounds, commands his monstrous summon, Ragnarok (the Grand Ruler of the Fourth Realm), to "crush them all." As the beast lays waste to the capital, a calm voice observes the scene: a rose blooming in the sky, a bat (Ragnarok) enveloped in flames, a band of light raising the earth. The voice notes these phenomena are rare but unsightly. It is Shadow (Cid) .
Elsewhere, Lady Alpha receives an urgent report that the Black Rose has been activated—"the destruction that precedes creation has begun." When asked if she wants to send a ship, she declines, confident that "it will all work out" because Shadow is there.

Shadow engages Ragnarok. Despite the monster's immense power, Shadow lands significant blows, surprising Mordred. Two figures then confront Mordred directly: Epsilon and Beta (introducing themselves as "Shadowgun" and lurking in the shadows to hunt shadows). They engage Mordred in combat.

Mordred initially mocks them as "lonely guinea pigs," but the girls quickly prove their skill. Beta notes that Mordred's "invisible sword strike" is the reason he's called the Knight Beyond Men. Mordred boasts that his fencing style cannot be seen by mortal eyes. However, Epsilon and Beta reveal they know the truth: his "invisible blade" is actually an ancient elven artifact—a sword forged by a dying elven swordsmith to defend their homeland. They accuse Mordred of bragging about a stolen achievement, adding that his armor and cape are also artifacts, calling him a coward. They declare they are taking the blade back.

Mordred attacks with the invisible sword, but Epsilon and Beta dodge and counter. They demand he share all his knowledge about the Black Rose, magical beasts, and the Cult of Diablos. Mordred, confident that Ragnarok will incinerate them, agrees to let them be "auditing students" of his wisdom in the brief moments before their death.

Mordred explains the cosmology of realms sayanig that outside their world exist countless other worlds in different dimensions, which they call realms (e.g., a world of ice, a world of poison, a world of flame, a world of death, a world of beasts with enormous magical power). These realms revolve around a single point (perhaps a god). Occasionally, realms collide, connecting and becoming one world. He cites evidence: before a certain period, magic did not exist in their world. A collision with another realm brought magic into their world, causing dramatic changes (e.g., the decline of dragons, the rise of humanoid races). He questions whether humans themselves came from other worlds, given their unique intellect. Some things have also gone out of this world into other realms—e.g., the vanished island kingdom of Atlantis. The demon Diablos was a product of their world, but the original creature that became the basis for Diablos was a visitor from the First Realm. The Black Rose is an artificial gate to another realm. The Oriana Kingdom once opened it by accident, destroying 100,000 Vel'Koz soldiers. Magical creatures spilled out, and the Cult closed the gate—demanding royal blood as payment. The king refused to offer infant Rose, which is why Oriana is now being destroyed.

Meanwhile, Princess Rose (now Queen Rose) organizes the defense. She orders Margaret to unlock an ancient cellar beneath the garden to shelter castle residents. Rose vows to rally the knights and protect her citizens, declaring she will carry on her father's legacy. Margaret addresses her as "Queen Rose" and obeys.

Back in the main battle, Shadow continues fighting Ragnarok. After a brutal exchange, Shadow defeats the Grand Ruler. A massive, severed arm of Ragnarok crashes down behind Mordred.

Mordred is in utter denial. He screams, "No! It's impossible! That was Ragnarok, the being of the greatest level of magic ever witnessed!" He calls it a "living wonder," the "greatest treasure of all the dimensions." He begins to question if he is dreaming, if the stress has broken his mind. He shoves his head into the remains of Ragnarok, desperately trying to convince himself it's all a nightmare.

Epsilon reports that they have exterminated all magical beasts in the area. Beta remarks that if Mordred had understood even a fraction of the wisdom of the shadows, this wouldn't have happened.

Shadow walks away from the defeated monster, musing that the fight was fun, like a video game boss, but notes that the main characters were total no-shows. He decides he needs to get closer to the main storyline.

Mordred, now fully unhinged, screams, "I'll kill you!" and fuses with the remains of Ragnarok. He flies up to attack Shadow directly.

Shadow delivers a monologue on nuclear fission recalling the ancient story of how humans, fascinated by lightning from the gods, sought to harness that power. After much research, they succeeded in creating nuclear fission—splitting the atomic nucleus to release a "buttload of energy" for explosive destruction. He calls it "the ultimate destruction raining down from a soundless world," the extreme he must eclipse. He thanks Mordred for reminding him why he started. "So this is it. I'm done playing." Mordred, terrified, asks, "What the hell are you?" Shadow replies: "I am atomic."

A blinding, planet-shaking explosion erupts. The light from Shadow's "I Am Atomic" shines across both the Oriana and Midgar kingdoms, and even reaches nearby planets—visible as a false dawn. Princess Rose watches the polar light dispel the darkness, but acknowledges it is "too much." Alpha and the other Shadows gaze in awe, whispering, "My lord and master."

The episode cuts to an entirely different scene: a modern Japanese high school. Akane Nishino, wakes up, realizing she must have fallen asleep. She is wearing a school uniform and is in her twenties, confused. A friend warns her not to go out at night because it's unsafe. But Akane insists she can't abandon her friends and wants to go "at least to pay my respects."

She reflects on a boy she despised—below average grades, below average athletics, exceedingly ordinary, nothing memorable. "And yet... looking at that moon reminds me of that day. Of him."

As she walks alone at night, she is ambushed by two thugs. One of them (heavily drugged and brainwashed) can't remember his own identity. They attempt to capture her alive for a client who wants to kill her personally. The thug leader mentions that their client is "the Great Savior" who has made many enemies.

Suddenly, a figure appears. The drugged thug recognizes him: "It's him! Stylish!" The other thug demands, "Who the hell are you?" The figure replies: "My name is Shadow. He who lurks in the shadows. In order to hunt the shadows." The thug, Akane, and others are repeating the name "Shadow" in awe and confusion, hinting at a deeper connection between Cid's Shadow persona and his original world.

## Characters

- [Mordred](Mordred.md "Mordred") (last appearance)
- [Ragnarok](Ragnarok.md "Ragnarok")
- Cid Kagenou/Lord Shadow
- [Nu](Nu.md "Nu")
- [Alpha](Alpha.md "Alpha")
- [Eta](Eta.md "Eta")
- Princess Rose Oriana (No.666)
- [Chi](Chi.md "Chi")
- [Omega](Omega.md "Omega")
- [Lambda](Lambda.md "Lambda")
- [Victoria](Victoria.md "Victoria")
- Reina Oriana (Corpse)
- Perv Asshat (Corpse)
- [Beta](Beta.md "Beta")
- [Epsilon](Epsilon.md "Epsilon")
- [Margaret](Margaret.md "Margaret")
- [664](664.md "664")
- [665](665.md "665")
- [Aurora](Aurora.md "Aurora") (Flashback)
- Raphael Geerk Oriana (Flashback)
- [Delta](Delta.md "Delta")
- Alexia Midgar
- [Gamma](Gamma.md "Gamma")
- [Yukime](Yukime.md "Yukime")
- [Zeta](Zeta.md "Zeta")
- Claire Kagenou
- [Elisabeth](Elisabeth.md "Elisabeth")
- [Mary](Mary.md "Mary")
- Skel Etal
- Po Tato
- [Quinton](Quinton.md "Quinton")
- Goldy Gilded
- [Marie](Marie.md "Marie")
- Akane Nishino

## Promotional Videos

「陰の実力者になりたくて！ 2nd season」 第12話予告≪ノーマルVer.≫「HIGHEST」

『陰の実力者になりたくて！ 2nd season』 第12話予告≪スペシャルVer.≫「陰の実力者は陰の実力者になりたくて！」

## Trivia

- The episode is a call back to episode 1 where a scene with Akane's return in the episode.
- [Beta](Beta.md "Beta") was not seen accompanying Shadow when he was absorbed by the Black Rose, which contradicts how it is narrated in the story as such of Volume 4.
  - In the spin off anime of Episode 29 Kage-Jitsu and in the game of Master of Garden, it would be confirmed that Beta later followed Shadow after he was absorbed by the Black Rose.

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e032>
2. <https://shadow-garden.jp/story/#story12>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • **Episode 12** | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
