# Delta/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Delta/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Delta/Image%20Gallery)

[Main](Delta.md "Delta")

[Chronology](Delta-Chronology.md "Delta/Chronology")

[Relationships](Delta-Relationships.md "Delta/Relationships")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Profile

Volume 1

Volume 2

The Boss has been detected

Delta and Zeta

Delta introduces the Boss to Pi

Delta in side-story

Teen Delta in her slime suit

White Slime Suit Delta

I Hunted It!: Delta

Waiting for Boss: Delta

Small Predator: Delta

Cheeky Teenager: Delta

Mischievous Witch: Delta

I Love Going Out!: Delta

Blasting Summer!: Delta

Demonic Fourth: Delta

Fourth Member: Delta

Game Event: Highest Dream II

Game Event: Apocrypha "Requiem for the Falling Shadows": Demonic Delta

Aggressive Maid: Delta

Twin Fangs of Fury: Delta & Zeta
