# Rex/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Rex/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Rex/Chronology)

[Main](Rex.md "Rex")

[Relationships](Rex-Relationships.md "Rex/Relationships")

Image Gallery

## Midgar Academy Terrorist Attack

Rex arrived at Midgar Kingdom and joined Lutheran Barnett to commit misdeeds throughout the capital, while claiming to be from the Shadow Garden, with their purpose to lure them out. When he heard the lost contact report of his men, he asks his superiors what's the next step, which he replied that its fine because he located the item, he need which is their priority to retrieving the item.[[1]](#cite_note-1)

Rex and the cult forces under Lutheran infiltrate and took over the Midgar Academy. While his fellow Children rounded up the students and killed anyone that opposed them, Rex headed to Sherry Barnett's study room to retrieve the Eye of Avarice's control unit. He found Sherry and was about to kill her when two Crimson Order knights intervened. Sherry escaped, while Rex defeated the knights.

Rex met up with Lutheran and informed him of what transpired, which upset him and he told Rex to quit playing around. Before Rex and his men immediately went out to search for the artifact, he informed Lutheran that several of his men had been killed, which Lutheran suggest that Shadow Garden have taken the bait. Rex then warned Lutheran to be careful. While walking through the school's premise, he watched as his men are being taken out by a student, much to Rex's shock.

Rex fought back against the interloper only to be overwhelmed by his incredible power. Rex wrongly deduced that the student might be using an artifact, having noticed wounds on the boy, also believed that he might be reaching his limit. He taunted the student hoping to get him to lose his composure. When it worked, Rex prepared himself only to be launched through a wall and crashed into a classroom.

Rex laughed, thinking he had won only to look around and find the corpses of multiple Children. Upon realizing that all these Children were killed by that student, Rex sweat in terror for the first time in his life. He only had a brief moment to muse about that boy's unlimited strength before said boy entered the room and eviscerated him.[[2]](#cite_note-V1C6-2)

## References

1. Episode 6
2. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
