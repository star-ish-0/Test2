# Slime

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Slime](https://the-eminence-in-shadow.fandom.com/wiki/Slime)

Slimes are a creature appearing within The Eminence in Shadow. Much about them is still unknown.

## Overview

Slimes are liquid magical creatures with a core at the center. They've appeared in the game as opponents but in universe they have not been explained extensively. Cid Kagenou has used their crushed cores to create his and Shadow Garden's slime weapons and bodysuit.[[1]](#cite_note-:0-1)

## Powers & Abilities

Slimes have high magic conductivity of an astonishing 99%, as told by Cid Kagenou.[[1]](#cite_note-:0-1) On top of that, they’re in a liquid state, which means they can change their shape at will. Their combat capabilities are still unclear.

## Trivia

## References

1. Volume 1 Prologue: Preparing the Perfect Stage!

## Site Navigation
