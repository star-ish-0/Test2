# Secondary

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Secondary](https://the-eminence-in-shadow.fandom.com/wiki/Secondary)

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Secondary?action=edit).

## Secondary

### Japanese

二次的な

### Romaji

Niji-tekina

## Characteristics

### Race

Elf

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Lord

## Debut

### Light Novel

Volume 7

Lord Secondary (?[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the second knight of [Otoutrion](Otoutrion.md "Otoutrion") in the war of succession.

## Appearance

## Personality

## Chronology

## Relationships

## Powers & Abilities

## Trivia

## References

## Site Navigation
