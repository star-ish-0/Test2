# Margaret/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Margaret/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Margaret/Relationships)

[Main](Margaret.md "Margaret")

[Chronology](Margaret-Chronology.md "Margaret/Chronology")

Image Gallery

### Rose Oriana

Margaret was Rose's maid and the two were very close. Rose often commented on her smile and derived great pleasure from it. However, their friendship took a sad turn when Margaret learned that Rose murdered her father which led to their kingdom undergoing civil war. She despised Rose ever since but still did her best to tend to her when she finally returned to Oriana.

Their friendship was restored after Margaret learned the full truth of Rose's actions and the princess came to her aid and protected her from a Magical Beast. Margaret tearfully apologized to Rose.

### Cid Kagenou

Margaret treated Cid with reverence after witnessing his beautiful piano skills. However, she saw Cid as a means to elevate her family's status and made many attempts to convince him to her side.

### [Shiron](Epsilon.md "Epsilon")

Margaret saw the renowned pianist and composer as her biggest obstacle in claiming Cid, thus the two would get into arguments.

### [Kevin](Kevin.md "Kevin")

Margaret hated Kevin for his obsessive habits towards her. When Kevin threatened Cid, Margaret had the guard framed for theft and fired.

### Parton & Newwealth

Margaret had a very good relationship with Earl Parton and Marquis Newwealth, to the point that they entrusted her with taking the student Shiron as their private pianist.
