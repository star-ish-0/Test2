# Omega/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Omega/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Omega/Chronology)

[Main](Omega.md "Omega")

[Relationships](Omega-Relationships.md "Omega/Relationships")

Image Gallery

## Chronology

### Background

Like the other girls descended from the heroes, Omega was discarded and abandoned by society until she was forgotten after succumbing to symptoms known as [Possession](Possession.md "Possession"). She was found and rescued by members of Shadow Garden alone in a dark back alley, malnourished with the curse spreading over her body. Shadow Garden cured her, elaborating the truth, earning her loyalty, and subsequently recruited her into the organization, being among the earliest recruited when Shadow Garden began their membership expansion.

At some point later, she rose through the ranks to become one of Shadow Garden's double-digit Numbers because her ability and strength are recognized by the Seven Shadows, to which she earns a "Numbers" Rank of Omega. Also, Omega established a strong and direct relationship with [Epsilon](Epsilon.md "Epsilon"), one of the original Seven Shadows, and worked together with [Chi](Chi.md "Chi").

### Sanctuary Infiltration

As the "Goddess's Trial" commenced in [Lindwurm](Lindwurm.md "Lindwurm"), Shadow Garden prepared for an infiltration mission, and Omega was present in the city. When Shadow suddenly made himself known to summon the memory of [Aurora](Aurora.md "Aurora") and concluding their battle with the result of Aurora's defeat along with the opening gate to [Sanctuary](Sanctuary.md "Sanctuary") at the same time, Omega was among the Shadow Garden contingent that followed [Alpha](Alpha.md "Alpha"), [Delta](Delta.md "Delta"), and Epsilon into the Sanctuary. Before entering the Sanctuary, Omega joined Chi by Epsilon's side as they are taking [Natsume Kafka](Beta.md "Beta") a "hostage" and entering the Sanctuary, along with the Acting Archbishop Jack Nelson.

Inside, Omega and Chi followed [Epsilon](Epsilon.md "Epsilon") with a unit of Numbers to collect and gather all intelligence from the memory world they found within the Sanctuary, confirming some theories on the Cult's origins, learning new details, and understanding their motives much better. While the Slime Bodysuits were malfunctioning due to proximity to the core, Omega and Chi apparently imagined that Epsilon's (fake) breasts fell off and reattached, but when Epsilon was looking at them, they said nothing.

As their investigation mission are complete along with the information they collect from the Sanctuary, [Alpha](Alpha.md "Alpha") ordered all Numbers to leave which Omega complied and following her order to leave the Sanctuary, leaving Acting Archbishop Nelson to battle Shadow. Then, Shadow Garden's team was outside, and Omega saw Shadow erased the Sanctuary using his "Atomic" spell. With the city flooded by the Sanctuary's destruction, Omega and Chi helped escorting Alpha and Epsilon out of [Lindwurm](Lindwurm.md "Lindwurm") with the intelligence they collected.

### Bushin Festival Tournament

When her master Cid Kagenou comes to the Mitsugoshi Company for asking help in disguising himself so that he can participate in the Bushin Festival without explaining his reasons, Omega is seen together with [Chi](Chi.md "Chi") in operating the face-making machine created by [Eta](Eta.md "Eta") when she is riding a bicycle that can activate a device for the facial profile changing machine to work.

Following the events of the Bushin Festival that has occur in Midgar Kingdom learning when her master Shadow appear to saved Princess Rose Oriana from Perv Asshat's capture after the events being communicated by Eta, Omega is seen together with Chi and [Epsilon](Epsilon.md "Epsilon") as the three of them started their infiltration mission in the Oriana Kingdom's capital. Curiously, Omega sees [Delta](Delta.md "Delta") up on the roof, surveying her surroundings in finding her lord.[[1]](#cite_note-1)

### Orianna Kingdom Civil War

## References

1. Episode 20
