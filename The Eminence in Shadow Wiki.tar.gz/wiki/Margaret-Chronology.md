# Margaret/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Margaret/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Margaret/Chronology)

[Main](Margaret.md "Margaret")

[Relationships](Margaret-Relationships.md "Margaret/Relationships")

Image Gallery

## Background

Margaret came from a middle-class noble family who had a relationship with Earl Parton and Marquis Newwealth who had worked as a veteran maid of the Oriana Kingdom who initially served as Princess Rose Oriana's personal servant. During her childhood with the Princess, Margaret initially saw Rose as a kind and intelligent person who is loved by everyone in the kingdom. At one point, Margaret is always stalked by a palace guard named [Kevin](Kevin.md "Kevin") who every time he staring creepily at her, much to Margaret's displeasure.

Despite their differences in status, Margaret and Rose grew up together until the two of them became best friends even though she saw that the princess always looked a little strange after Rose chose the art of swordsmanship on the royal tradition since returning from the Midgar Kingdom with the King Raphael Geerk Oriana. Even so, Margaret still supported Rose's decision when the Princess reached adolescence and attended the Midgar Academy for Dark Knights as a transfer student to strengthen the alliance between the two kingdoms.

Hearing the news that Rose unexpectedly had publicly killed her own father in Midgar who at that time was holding the Bushin Festival, Margaret resents the Princess for her actions in killing the King had caused chaos in Oriana, leading to a two-way civil war between the Royalist faction led by Marquess [Grant](Grant.md "Grant") and the Royal Chancellor faction led by Duke Perv Asshat.

### Oriana's "Black Rose" Civil War Wedding Incident

When the Oriana Kingdom that currently still in a state of war had entered winter, Margaret is given the task of looking after Princess Rose Oriana who had returned after reportedly disappearing with the help of Shadow who helped her escape at the Bushin Festival and labeled a fugitive for the murder of the King who is currently in the princess' personal room because of her relationship with Rose that she complied with the task much to Margaret's detest.

Four days later, Margaret along with other royal servants served [Shiron](Epsilon.md "Epsilon") who was an invited guest at a performance event attended by the aristocrats in the capital along with her apprentice after his stunning performance in playing the song "Moonlight Sonata" in front of all the nobles gathered by Duke Perv Asshat. When the apprentice asked to tour the palace, Margaret volunteered as a guide and took him away when Shiron gave a hostile look at her, because of her developed figure.

The pair walked the castle ground, as Margaret noticed that there was no one around, so Margaret tried to tempt the apprentice into hiring him to Earl Parton and Marquis Newwealth, even offering him a job with her family after being given the task of patronizing the apprentice from his magnificent performance because Margaret wanted to use his piano skills to improve her status and her family's position. However, the boy is deceptive by changing the question regarding her duties as Rose's servant by asking where the Princess was when Margaret gave a despise answer about Rose who had brought the kingdom into chaos from which there are no one acknowledges her as the rightful queen anymore.

Even though she kept the princess' location a secret, Margaret gave the boy a special treatment by openly revealing Rose who is currently in her personal room by giving him the condition to visit his parents until [Kevin](Kevin.md "Kevin") appeared who suddenly called the apprentice to his presence, much to Margaret's irked and hope the boy will be careful. Hearing reports of the disappearance of a pastry dish that was supposed to be prepared for Princess Rose, Margaret had the opportunity to accuse Kevin of stealing food by making her co-workers putting a kind of story and reporting to the official, which resulted in Kevin being suspended from his duties as retribution for disrupting her solicit plan on the apprentice's service.[[1]](#cite_note-V4C1-1)

The next day, Margaret met the apprentice again in the music room to ask about his condition yesterday until Margaret told the boy that he had nothing to worry about anymore because she had already reported Kevin to the point of being reassigned for alleged wrongdoing that he did not commit. When Margaret heard that Shiron had not come with the apprentice today, she deliberately locked the door and tried to persuade the boy who was trying to avoid Margaret to make an appointment with Earl Parton and Marquis Newwealth so that his talents could be patronized until the opportunity to lure the apprentice into her parents' house ended in failure after Shiron suddenly entered the door that was supposed to be locked is somehow opened.

Despite being in shock for a moment, Margaret quickly recovered and greeted Shiron who she thought was not planning on coming until noon with Shiron responding that she had concerns that someone might disturb her apprentice and hinder his work to which Margaret tried to tell her that her worries were unfounded with Shiron saying that her feeling of worry were quite founded as she found out about Margaret's true intentions which were visible from her actions just now, to the point that the two of them crossed their arms in sync and looked at each other.

When Shiron said that she and her apprentice had to get ready for work, Margaret used the excuse of making tea for them which resulted in them teasing each other until finally Shiron firmly told Margaret to leave because she was annoyed by her annoying behavior. Realizing that the tables have turned against her, Margaret tactically decides to withdrew herself as she tells the boy about Shiron's true nature until she then leaving the music room.

In the evening, Margaret dispassionately served Rose when she finished making tea and decided to leave Rose's room as part of her work, unnotice that Rose came out with Shadow who intended to show the "real truth" to the princess which made her determination to save her kingdom rise again.[[2]](#cite_note-V4C2-2)

On the day of the wedding precession held at the church altar with Margaret attending along with the invited guests, she witnessed Rose suddenly declares her rejection of her vow to marry when she declared that she was indeed takes full responsibility for killing her father with Rose providing clarification in accusing Perv of being guilty of his crimes against the kingdom for manipulating the king, defiling the queen, and plans to overthrow the government which is considered the highest treason. As Rose presents the "Ring of Succession" to the audience, the ring is then activated and a recording of the late king Raphael Oriana's projection appears that is played to everyone in attendance. In the recording of his will and testament, the king explained the truth about what happened in front of all the citizens while anticipating the loss of his sanity, starting from revealing Perv as the main culprit of his manipulation and also implying the Queen Reina's involvement in his crime who attempted to brainwash him with his wife collaborating with Perv to mix up his food with mind manipulation drugs until the contents of his mind have been undermined and ultimately controlled as Perv's puppet, which is supported by a powerful organization that is trying to conspire to seize control over the kingdom while exposing all of Perv's criminal activities, as well as his helplessness in his struggle to continue fighting to protect his country until the king lastly entrusting Oriana Kingdom's future to his daughter and implored the citizens to believe in her as Rose will lead their nation to greatness before the recording finished.

Learning the truth from the King's confession, Margaret, who was initially disappointed in the Princess, realized that the reason why Rose killed her own father was to free him from Perv's control, which she then saw the Princess confronting Perv until Rose defeated him as she avoided fatal wounds to get him for confessing his sins.

But when suddenly Margaret along with the invited guests saw Duke Perv and Queen Reina killed by a mysterious man who appeared out of nowhere named [Mordred](Mordred.md "Mordred"), then the clouds that were previously bright now looked black clouds which Mordred showed everyone as he stated to witness the true appearance of the Black Rose whose legends almost destroyed the Oriana Kingdom and start declared a banquet of slaughter when the Magical Beast came out of the Black Rose which immediately preyed on the citizens and wreaked havoc in the capital.

When everyone wanted to escape from the beast attack, Margaret, who was cornered and almost became prey to the Magical Beast, was saved by Rose who hugged Margaret to check on her condition and told her to leave as soon as possible which she replied obediently. In the middle of her steps, Margaret turned around and wanted to apologize to Rose for her misjudgment with Rose responding that it's okay and then asked her to move away while Margaret followed Rose's orders who were dealing with the Magical Beasts together with the Shadow Garden organization.[[3]](#cite_note-V4C3-3)

## References

1. Volume 4 Chapter 1: Putting the Kibosh on Rose Oriana's Wedding!
2. Volume 4 Chapter 2: Begin Operation: Obstruction!
3. Volume 4 Chapter 3: Crashing the Ceremony!
