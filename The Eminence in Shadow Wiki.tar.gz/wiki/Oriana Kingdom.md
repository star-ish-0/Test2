# Oriana Kingdom

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Oriana%20Kingdom](https://the-eminence-in-shadow.fandom.com/wiki/Oriana%20Kingdom)

## Oriana Kingdom

### Japanese

オリアナ王国（おうこく）

### Romaji

Oriana Ōkoku

### Alias

Country of Arts

## Location Information

### Leader

Raphael Geerk Oriana (previously/Deceased)
Rose Oriana (Volume 5)

### Status

Active

### Affiliates

Cult of Diablos (Puppet Nation) (Formerly)
Midgar Kingdom (Allied until Volume 5)
Shadow Garden (Secret Allies)

### Type

Country

### Government

Unknown

### Location

To the northwest of Midgar Kingdom

### Inhabitants

Humans (predominantly)

## Debut

### Web Novel

Chapter 31 (Mentioned)
Chapter 143

### Light Novel

Volume 1 (Mentioned)
Volume 4

### Manga

Chapter 9 (Mentioned)
Chapter 40

### Anime

Episode 7 (Mentioned)
Episode 20

Oriana Kingdom (オリアナ王国（おうこく）, Oriana Ōkoku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a nation known as the "Country of Arts" (芸術（げいじゅつ）の国（くに）, Geijutsu no Kuni[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) which has now become Shadow Garden's forward base of operations, after they eliminated the [Mordred](Mordred.md "Mordred") Sect faction of the Cult of Diablos.

## Geography

The Oriana Kingdom's territory borders the Midgar Kingdom to the northwest, it essentially looks like a large island, whose only land access is a bridge that connects it to the Midgar Kingdom, going directly to its capital.[GAME ONLY]

## History

Oriana is a small country that is known for its people's reverence for the arts. The nobility devote most of their time assessing every work of art and craft that can be considered as such, the nobility see every piece of art in their possession as a status symbol, as well as any artists they have under their employ. In Oriana it doesn't matter what race you are or what status you have. A person's value is determined by their artistic talent.

## Culture

As the name of the kingdom's title referred to as the "Country of Arts", the Oriana Kingdom devoted their time pursuing arts and crafts because of people's loyalty to the arts such as painting, literature, music, acting, fashion design, embroidery, sculpting, etc. Which resulted in the country becoming a popular tourist destination. Anything else like swordsmanship is seen as barbaric and met with ridicule.

In Oriana, people respect the artistically talented, no matter what race they are or what their social status might otherwise be.

However, it is revealed that the reason the kingdom is so attached to artistic culture is due to the kingdom's agreement with the Cult of Diablos to give a majority of the kingdom's tax revenue to the cult, resulting in the kingdom to heavily invest in the arts.

## Military Strength

The Oriana Kingdom had become the Cult's puppet nation, ever since the cult helped stop the Black Rose. As a result of the kingdom's pact with the Cult, this kingdom lacks proper military strength as the Cult had wanted to deprived its strength to resist them. The cult planted the idea that swordsmanship is barbaric in order to persecuted Dark Knights. The Cult wanted to prevent Oriana's potential resistance.

The Oriana Kingdom used to have an alliance with the Midgar Kingdom. But now, the alliance with Midgar has been abolished and they have no more allies.

## Known Locations

- Saisho Fortress

## Foreign Relations

The Oriana Kingdom's relations with other countries generally ranged from good to neutral, but heavily relied on their ally the Midgar Kingdom to send their troops for defense and protection from other nations as it was unable to build up a proper military of its own. By the time Oriana was declared a heretic state by the Church due of the Cult's instigation, the kingdom's trade had been restricted and all diplomatic ties with neighboring countries had been severed as they prepared to annihilate the heretical kingdom.

### Midgar Kingdom

Both nations had friendly relations with each other as the Oriana Kingdom made an alliance with Midgar Kingdom with the objective to build an army to rebel against the Cult in order to gain independence from their influence. However, Midgar Kingdom had decide to officially nullify their alliance after the Church branded Oriana as heretics after the "Black Rose" incident.

### Velgalta Empire

In the past, Oriana Kingdom was on the brink of defeat in their war with the Velgalta Empire until the Black Rose opened and obliterate the Velgaltan army.

### Altena Empire

They have semi-hostile relationship with each other, due to Altena being a vassal state of Velgalta.

## Known Citizens

- Rose Oriana (Queen)
- Raphael Geerk Oriana (King; Deceased)
- Reina Oriana (Queen; Deceased)
- Perv Asshat (Royal Chancellor; Deceased)
- [Grant](Grant.md "Grant") (Marquess)
- Newwealth (Marquis)
- Parton (Earl)
- [Margaret](Margaret.md "Margaret") (Maid)
- [Kevin](Kevin.md "Kevin") (Palace Guard; Formerly)
- [Marie](Marie.md "Marie")

## Trivia

- In the Oriana Kingdom, it's said that the world of fine arts has two rising stars that shine brighter than all the rest, namely [Natsume Kafka](Beta.md "Beta") for literature and [Shiron](Epsilon.md "Epsilon") for music.
- Oriana Kingdom's capital in the anime is inspired by the city of Paris, France.[[1]](#cite_note-:0-1)
  - Within the kingdom of Oriana, one of its constructions is equal to the "[Arch of Triumph](https://en.wikipedia.org/wiki/Arc_de_Triomphe "wp:Arc de Triomphe")" of Paris.[[1]](#cite_note-:0-1)

## References

1. Episode 20

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • **Oriana Kingdom** • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
