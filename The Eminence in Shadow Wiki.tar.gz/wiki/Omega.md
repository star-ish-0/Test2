# Omega

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Omega](https://the-eminence-in-shadow.fandom.com/wiki/Omega)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Chronology](Omega-Chronology.md "Omega/Chronology")

[Relationships](Omega-Relationships.md "Omega/Relationships")

Image Gallery

## Omega

### Japanese

オメガ

### Romaji

Omega

### Aliases

No. 24
Olga
No. 122 (Formerly)

## Characteristics

### Race

Half-Elf

### Gender

Female

### Age

24

### Height

Unknown

### Hair Color

Black

### Eye Color

Heterochromia
Silver (right)
Gold (left)

### Birthday

December 4

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Numbers

### Affiliation

Shadow Garden
Mitsugoshi Company

## Debut

### Web Novel

Chapter 186

### Light Novel

Volume 6

### Manga

Chapter 66.2

### Anime

Episode 11

### Game

Seven Shadows Chronicles: Chapter 22

## Portrayal

### Japanese

[Ryōko Maekawa](https://en.wikipedia.org/wiki/Ry%C5%8Dko_Maekawa "wp:Ryōko Maekawa")

### English

Skyler Sinclair

### French

Camille Béchon

### Italian

Gaia Chiaro

### German

Johanna Giraud

Omega (オメガ, Omega[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Ωμέγα) formerly known as Olga (オリガ, Origa[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a member of Shadow Garden, being one of the Numbers. Initially codenamed No. 122, she quickly rose through the ranks and is currently codenamed No. 24. She is often assigned to guard [Gamma](Gamma.md "Gamma") by [Alpha](Alpha.md "Alpha").

## Appearance

Omega is a half-elf with short black hair, a light tattoo on the right profile of her face and the right half of her body with a well-developed physique with good chest and musculature. She also has striking heterochromia eyes, her right eye being silver while her left eye is gold.

As a member of Shadow Garden, she wears a dark slime bodysuit with gold adornments in the form of jacket shoulder pads and suit trims, with attributed violet gem decorations along her figure. Her chest has a V-shaped veiled opening at the sternum and a chevroned collar.

Her bodysuit also has a stylized jacket with wrist-length sleeves having gold lined trims before the cuffs of the sleeves, and an unbuttoned rib-length torso. Her jacket's gold decorations include golden shoulder pads to display her position among the Numbers which cover her upper back.

Her uniform details seem to be different in the anime compared to her debut in Volume Six. Omega has a ribbon strapped to her left arm in the anime where the shoulder meets the triceps, but the ribbon is on her right arm in the light novel. Her uniform also has a ribbon above her collar bone, not included in the anime.

Her waistline has a guard lining around the femoral section of both legs. In the anime, she has decorative straps around her upper thighs, while she has unique cross decorations in the light novel. Also in the light novel, her boots have two thick golden chevron cuffs, thin gold chevron ankle cuff armor, golden lined midsoles between short-lifted outsoles at the heels of the boots. In the anime, her boots kept the holden cuff but are boots with a raised heel and a gold chevron at the cap-toe.

The design of her suit is near identical to [Chi](Chi.md "Chi")'s.

## Personality

Omega is usually calm and collected but is troubled by her tendency to laugh at silly jokes and teasing her fellow Shadow Garden members. She was abandoned like the others in Shadow Garden when stricken with [Possession](Possession.md "Possession") and became loyal to their cause of destroying the Cult of Diablos.

While active on Shadow Garden missions, Omega is steadfast in her duties, executing her objectives to their fullest. When Omega is in her civilian dressing, she is seen to be friendly toward citizens and her coworkers, [Chi](Chi.md "Chi") especially as the two are partners.

### Web Novel

Omega is the type of person who is always silent, she only responds to orders from her superiors with short sentences or nodding silently. She acts like that not because she is disobedient to her superiors, but because she has social phobia like Chi.

She has great anxiety and fear when interacting with other people. This was proven when she was ordered directly by Shadow, Omega responded by running with her body trembling in fear. However, Shadow immediately overcomes this by having a relaxed conversation containing advice for her.

## Powers & Abilities

Omega has been trained to use and control her magic, as well as fighting practices, based on lessons passed down from Shadow. Omega quickly rose through rank and making her one of the double-digit Numbers as a testament to her prowess and ability, which she is given a Greek name.

### Swordsmanship

Omega is proficient with a blade, as are all of Shadow Garden, but Chi is likely a master to some degree having earned a Number rank.[CITATION NEEDED]

### Magic

Omega is proficient in magic, having maintained her Slime Bodysuit during the magic distortion effects of the Holy Sanctuary Infiltration. Such is a requirement given Epsilon's renown within Shadow Garden for her refined magical control.

### Physical Capabilities

Omega, like many before and after her joining, trained daily to improve upon her physical prowess. Such is necessary to be ready for a fight or to retreat to safety. This includes self-defense, martial arts, and strength training.

### Weapons and Equipment

- Slime Bodysuit: A standard issue in Shadow Garden, with Chi's having notable decoration to express higher rank and authority within the command structure compared to the rank-and-file.
- The Rolapoid: An instant camera for missions of espionage, a reverse-engineered technology from Shadow Wisdom by [Eta](Eta.md "Eta").

## Trivia

- Omega is the first character in Eminence in Shadow series to have [Heterochromia iridum](https://en.wikipedia.org/wiki/Heterochromia_iridum "wp:Heterochromia iridum").
- Despite being women, [Chi](Chi.md "Chi") and Omega like to occasionally cross-dress as men. According to them, this facilitates other means of information gathering. Although sometimes, they cross-dress for fun.[CITATION NEEDED]
- Various fan translations mistranslated Omega's sex and erroneously introduced her as a male. Omega's appearance in the anime helped clarify the confusion, and subsequent revisions occurred on some websites.[[1]](#cite_note-WNC187-1)[[2]](#cite_note-2)
- Omega and Chi are the only Web Novel original members who have debuted in Volume 6 of the Light Novel.

## References

1. Web Novel: Chapter 187
2. Independently Verified by Staff

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • **Omega** | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
