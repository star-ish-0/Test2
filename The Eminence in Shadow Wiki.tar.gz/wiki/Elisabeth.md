# Elisabeth

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Elisabeth](https://the-eminence-in-shadow.fandom.com/wiki/Elisabeth)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Chronology](Elisabeth-Chronology.md "Elisabeth/Chronology")

[Relationships](Elisabeth-Relationships.md "Elisabeth/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | Let us build a Haven here. A land where humans and vampires can live in peace. | ” |
| — Elisabeth, Light Novel Volume 03 | | |

## Elisabeth

### Japanese

エリザベート

### Romaji

Erizabēto

### Aliases

Blood Queen

## Characteristics

### Race

[Vampire](Vampire.md "Vampire")

### Gender

Female

### Age

1000+

### Height

Unknown

### Hair Color

Red

### Eye Color

Red

### Birthday

August 21

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Monarch (Lawless City) (Formerly)

## Debut

### Web Novel

Chapter 94

### Light Novel

Volume 3

### Manga

Chapter 30

### Anime

Episode 23

### Game

Episode 22

## Portrayal

### Japanese

[Saori Hayami](https://en.wikipedia.org/wiki/Saori_Hayami "wp:Saori Hayami")

### English

Brianna Roberts

### French

Chantal Baroin

### Italian

Jessica Tedesco

Elisabeth (エリザベート, Erizabēto[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), also known as the Blood Queen (血（ち）の女王（じょおう）, Chi no Joō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), is a [Vampire](Vampire.md "Vampire") Progenitor and formerly one of the Lawless City's triumvirate, being the ruler of the Crimson Tower.[[1]](#cite_note-V3C1-1) In reality, she was a figurehead used by her subordinate, [Crimson](Crimson.md "Crimson").[[2]](#cite_note-V3C3-2)

## Appearance

Elisabeth is a beautiful vampire woman with a small but well-formed body, with very light crimson hair that reaches to her knees and is intense, and eyes of the same color, and pointed ears like those of an elf, but her hair covers them. She wears a knee-length dark red dress made of blood that slides hypnotically over her skin with red accents, dark red hands, dark red stockings, and a pair of shoes. She also wears a crimson hair clip and a red necklace around her neck and ribbon and walks with an umbrella to protect herself from the sun.

Because of her lineage as a vampire progenitor, Elisabeth could withstand sunlight to some extent, albeit with discomfort. She managed to live by abstaining from human blood and exclusively consuming human food. To shield herself from the sun's direct rays and to avoid further discomfort, Elisabeth carries a crimson umbrella.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Please, cast my ashes into the sea so I can never rise again and repeat this mistake… | ” |
| — Elisabeth, Light Novel Volume 03 | | |

Unlike other [Vampire](Vampire.md "Vampire") Progenitors who had used their abilities for survival or for evil, Elisabeth is not only the most benevolent of the progenitors but her entire species. She is a kind woman, who believed that Vampires could coexist with the other races which lead to her building her utopia where there is equality for all.[CITATION NEEDED]

Elisabeth would even sacrifice herself if to ensure no one would be hurt by her power, to which she even tries to fight off her urge to feed, but her nature as the vampire progenitor makes it hard for her to do so. Elisabeth refuses to take humans lives excessively and hunted only the bare minimum she needed to survive.[CITATION NEEDED]

Elisabeth has a slow nature to wake up completely, whether she is well fed or in need of drinking blood. According to [Mary](Mary.md "Mary"), Elisabeth always had that naturalness, due to low blood pressure in her body.[[3]](#cite_note-:4-3)

## Powers & Abilities

Elisabeth is the most powerful Vampire Progenitor, once destroying four countries in just three days, and [Beta](Beta.md "Beta") estimated her strength to surpass even [Alpha](Alpha.md "Alpha")'s. She is also, by far, the strongest of the [Three](Yukime.md "Yukime") [Monarchs](Juggernaut.md "Juggernaut") of the Lawless City, easily overwhelming the other two and even managing to land a hit on Shadow, albeit while he was weighed down by the loot he was carrying, forcing him to get a "little serious".

### Vampiric Physiology

Like any vampire, Elisabeth boasts strength, speed, agility, and senses far above the average human. This allows her to easily smash, kill, and fight multiple high-ranking magic knights at once without any problem. Her physical strength as such is powerful enough to be able to stop a Slime Sword attack, from one of the "Seven Shadows" of Shadow Garden, like [Beta](Beta.md "Beta"), with only her bare hands, without even receiving damage.[[4]](#cite_note-MNV8C31-4)

When said power is at 100%, (after feeding on human blood adequately, or having enough), Elisabeth demonstrates that if she sets her mind to it, she can wipe out a small country, but completely, in less than a day, or in just one night. This was seen when, during the second appearance of the "Premature Red Moon", upon ingesting human blood, Elisabeth lost control, recovering 100% (without being completely increased by the appearance of the Premature Red Moon), of her vampire abilities, and managed to destroy a small country with her, while her deer (manipulative vampires) delighted in the civilian victims, who tried to escape.[[5]](#cite_note-V3C2-5)

Vampiric Senses: Like every Vampire, which is Elisabeth, she has very supernaturally heightened senses, in all her 5 senses and others, especially her smell, vision, hearing and taste. As she is a progenitor, these senses are greatly increased, a thousand times more than those of vampires, and others are in command, and as she is "The Vampire Queen", these abilities make her someone to fear and respect almost for all, those of her class.

Blood Thirst: Like every [Vampire](Vampire.md "Vampire"), Elisabeth has a strong taste for human blood, but she only drank when it was necessary and when she needed to survive. And unlike the other vampires and progenitors, Elisabeth does not like the idea of hunting for pleasure, but being a progenitor, if she is not fed properly, her appetite for human blood was a thousand times stronger than that of normal vampires and counts, but as time went by, and by sheer force of will and adaptability, she managed to free herself in a practical way.

By having a strong resistance to the thirst for human blood, Elisabeth can avoid the desire to want to drink blood, even if she is in front of it, even though she has spent a long time without drinking blood, or even if she ingests a little, she will maintain the control.

Inhuman Resistance: Elisabeth has resistance to physical attacks, at extreme levels, related to attacks that involve hands, legs or even the head itself, this ability allows her to tolerate or escape unscathed from attacks that can cause damage of various tons including decapitation, while being under the effects of the Red Moon, she becomes almost Practically Invulnerable, to direct physical attacks, and to conventional weapons, such as Normal pistols and semi-rifles. During their fight in the Red Tower of the Lawless City, after her resurrection, Elisabeth received Juggernaut's innate strong blow to the face, filling and without flinching, and even so, it did not hurt her in any way, taking into account that said attack had a force of more than 20 to 50 tons (as analyzed).[[3]](#cite_note-:4-3)

Vampiric Flight: Like any vampire, Elisabeth has the ability to fly and stay in the skies, allowing herself to reach very fast speeds. When she is under the effects and influence of the Red Moon, her flight abilities become supersonic, rivaling those of the [magical dragons](Dragon.md "Dragon") of the other world, while it is in its stages from start to finish.

### Vampire Progenitor Biology

Elisabeth has a vampire biology, very strong, special and powerful, being a progenitor vampire, since like her kind, even if their bodies are destroyed, as long as their hearts remain intact, or they do not suffer serious damage, in certain circumstances, can resurrect themselves, with the help of others, offering a blood sacrifice of a living young person, mainly in this. Elisabeth's vampire heart, like her blood, is very special and powerful, within the race of Vampires and their parents, especially her Heart, since Elisabeth is the most powerful parent of vampires, the older she is. The level of biological power of these, the more difficult it will be to kill them, even if you know the weak points of a vampire.

- Even after having her entire body is destroyed...
- ...Elisabeth is able to regenerate in seconds

1/2

Vampiric Regeneration: Elisabeth is noted to have the strongest regenerative ability of any vampire in existence. As long as her heart remains intact, she can regenerate all the other organs in her body. When under the effects of the Red Moon, Elisabeth becomes practically immortal, capable of regenerating her entire body from just her blood after it was destroyed by the [Aurora](Aurora.md "Aurora")-possessed Claire.[[6]](#cite_note-MNV8C32-6)[[2]](#cite_note-V3C3-2)

Blood Curse: Elisabeth can impose a curse on her victims, similar to "[Possession](Possession.md "Possession")", injecting her vampire blood into her enemies, causing their bodies to rot rapidly. Sometimes she can use this ability to turn people into [vampires](Vampire.md "Vampire"), or their [familiars](Ghouls.md "Ghouls"), more easily than a normal vampire.[[4]](#cite_note-MNV8C31-4) This curse as such can be applied in many ways, in different possible ways, whether by bite, direct injection of vampire blood or their deadly techniques, but only if they want to, turn someone into their [Ghoul](Ghouls.md "Ghouls") familiar, kill them, or maybe turn him into a [Vampire](Vampire.md "Vampire").

Vampiric Heart: Elisabeth's vampire heart (in the [Anime](Anime.md "Anime") and Game) has an appearance somewhat similar to the core artifact; "Eye of Avarice", said heart, has the shape of an obelized shoot in the shape of an unopened flower, whose sides cover 60% of it, made of a metallic aspect of it, whose upper center is made of a crystallization It is hard red, (apparently made of blood), which is the only fragile part of the Cuaron, and the lower center has roots close to arteries, as if they were the roots of a plant. This heart has the ability to remain eternally intact, as long as it does not suffer any serious damage to its upper center, and if it received and adsorbed a certain amount of blood, even a small one, from the sacrificed body of the person, it could beat again and allow the resurrection of Elisabeth. The heart was very hard and difficult to destroy, if its only weak point was not taken into account, since apart from being eternal, it was hard enough to withstand damage from metal swords, whether they had magic or not, even to emerge intact from a magical explosion, with enough force to destroy anything from a house to possibly a multi-story building. Within the Anime and Game, when Crimson barely put the heart in the body of the sacrificed boy, right where his heart went, a few moments later, Shadow came and unleashed a huge explosion of fire, which destroyed the body of the sacrificed boy, (except his head), keeping [Crimson](Crimson.md "Crimson") in it, but Elisabeth's Heart remained intact after it, and falling to the floor.[[3]](#cite_note-:4-3)[[7]](#cite_note-7) (it is not entirely clear, if necessary, the strength of the Red Moon, as a source of support, for the resurrection as such).

- In the Manga and Light Novel, Elisabeth's heart, looks like a normal heart and a little more fragile, and like that of the other parents, with the same requirements to be able to revive, with the difference that, the body of the sacrificed boy or girl, must remain intact, without suffering any damage, as such, at a full level and with a little more time, so that Elisabeth can revive, and with the support of the Red Moon (it seems).[[5]](#cite_note-V3C2-5)[[4]](#cite_note-MNV8C31-4)

- Elisabeth uses her Cloning against Shadow.
- Shadow confronts and repels Elisabeth's Clones.

1/2

Vampiric Cloning: Elisabeth can create powerful clones of herself using her blood, which allows her to considerably multiply the damage dealt to her opponents or more than one, (as far as is known, she can make 2 to 3 clones of herself). This Ability works in the same way as Nelson's Skill (the Miser), with its flaws and so on, although Elisabeth cannot generate as many clones, these, for their part, demonstrate to have more power than normal, and can execute several normal skills. by Elisabeth. When Elisabeth is under the increased power of the Red Moon, said Technique and ability greatly increase the damage power, making the clones close to that of the original body, and possibly gaining a bit of direction. [Mary](Mary.md "Mary") affirmed to everyone that Elisabeth was classified as the most powerful vampire queen that has existed up to the present date because of this ability. During the night of the "Red Moon" in the red tower at the Lawless City, Elisabeth uses this ability against Shadow. [[4]](#cite_note-MNV8C31-4)[[2]](#cite_note-V3C3-2)

### Swordsmanship

Although it may not seem like it, Elisabeth is an expert fighter at the level of weapons handling, being able to fight and be on par in fencing combat, with any weapon, whether short or medium distance that she wields. This ability, added to her vampire abilities, and the power of her opponents' movements and attacks, make her a very dangerous Vampire to be feared more, when she is half or fully conscious to fight, although it depends in part on the reinforcement and increase of magic, partly for this.

When under the effects of the Red Moon, her swordsmanship abilities become monstrous, both in level of damage, as well as in attack speed and adaptability, surpassing strong beings in swordsmanship. Until now, her level of skill in fighting with weapons or swordsmanship is only equaled and greatly surpassed by Shadow, whether in ground or aerial combat, even with the support and increase of magic from the Red Moon.

During their final fight, in the Red Tower in the Lawless City, under the glow of the Red Moon, Elisabeth and Shadow, fought a deadly combat of weapons, at the aerial level, with an overwhelmingly deadly speed of attacks, being able to generate strong luminous explosions in the air, with only the clash of their weapons, in a few moments, while they moved and moved, luminously in the sky.[[3]](#cite_note-:4-3)

### Power of the Red Moon

During the nights when there is a "Red Moon", the powers and abilities of the vampires become even more powerful and are influenced by it, both for normal vampires and nobles, even Elisabeth is overwhelmed by such power that she must be more careful when the "Red Moon" arrives. When she lost control due to the betrayal of one of her subordinates, who made her drink human blood during one of those nights, she alone destroyed 4 countries, reducing them to rubble in less than 3 days.[[4]](#cite_note-MNV8C31-4)[[5]](#cite_note-V3C2-5)

### Magic

Elisabeth has great magical power, which makes her a very fearsome person. When under the effects of the Red Moon, her magic grows enormously, and she does not show even a trace of fatigue. According to [Beta](Beta.md "Beta"), her level of magical power in that state was greater than [Alpha](Alpha.md "Alpha") and can continue to grow.[ANIME ONLY][[3]](#cite_note-:4-3)

Elisabeth has shown to use her magic, either by wild instinct or in full consciousness, for various things, whether to protect herself, attack or multiple things, when combined with her blood manipulation, she can further increase the damage and defense she exerts, and she can recover magic by absorbing magic around her, (although she has only been seen when there is a Red Moon) [ANIME ONLY][[3]](#cite_note-:4-3)

#### Blood Manipulation

Her main offensive ability, as well as partly defensive, is the power to freely control her own blood and imbue it with magic, using it to heal herself when she is injured, as well as to protect herself. Mainly, Elisabeth uses this ability in an offensive way, since it allows her to aggressively and deadly be able to sword and kill her enemies very effectively, either with her short- or long-range attacks, or by injecting them with Curse of the Vampire.[[2]](#cite_note-V3C3-2)

Aurora also has this capacity and ability, with the difference that Aurora has said ability, at higher offensive levels than Elisabeth, since Aurora comes from the "Original Blood", plus the experience she has as witch (among other things), [Aurora](Aurora.md "Aurora") can wield this ability, in a more complex way, countering, cursing or using the blood of others, including that of Elisabeth herself.[[3]](#cite_note-:4-3) [[6]](#cite_note-MNV8C32-6)This ability as such, although both Aurora and Elisabeth possess it, unlike Aurora, Elisabeth doesn't need to use magic, for the most part, to manipulate her blood unless necessary, the Blood responds to her will, and by interacting with that of other living beings, Elisabeth can use their blood for herself and against them. [[3]](#cite_note-:4-3)

This ability of Elisabeth only allows her to manipulate the blood of her, and of other living beings, whether they are beasts, humans or other races, but as such, she cannot at all (apparently) manipulate the liquids themselves, as normal water, or salt water, from any source. Among her abilities to Manipulate Blood, there are these like.

When Elisabeth was cured of her lack of control by the power of the Red Moon, by the magical power of the "Sir-Knight" who saved her, a few days after that, before leaving the Lawless City, she was still able to see a boy from a distance, instantly knowing that said teenage boy was the person who saved her, then in a subtle way, she bowed her head to him in the form of "thank you".[[2]](#cite_note-V3C3-2)[[8]](#cite_note-MNV8C33-8)

#### Mist Form

This is an ability vampires have which allows them to turn their bodies into mist. Elisabeth' being a progenitor vampire, can not only turn her body into mist and vice versa, but also only parts of herself, which allows her to dodge her enemies' attacks and at the same time deal damage to them. She also uses this ability to move easily. But this does not make her fully invulnerable, she can take burst-level damage while in that state, which can hurt her on a cellular level. [[9]](#cite_note-:7-9)[[2]](#cite_note-V3C3-2)

### Weapons & Equipment

Elisabeth's primary weapon is her crimson claws, which she can extend and manipulate at will using her immense blood-based magic.[[2]](#cite_note-V3C3-2)

## Trivia

- Elisabeth shares a name with the infamous Countess Elisabeth Báthory. Báthory was accused and jailed for the murder of hundreds of girls. Fact or conspiracy, witnesses claimed she bathed in blood to retain her youthful skin, among other horrendous practices.[[10]](#cite_note-10)

## References

1. Volume 3 Chapter 1: Lawless City Bandit Hunting!
2. Volume 3 Chapter 3: Pursuing the Blood Queen!
3. Episode 23
4. Manga: Chapter 31
5. Volume 3 Chapter 2: Storming the Crimson Tower!
6. Cite error: Invalid `<ref>` tag; no text was provided for refs named `MNV8C32`
7. Game: Episode 21
8. Manga: Chapter 33
9. Manga: Chapter 31
10. Pallardy, Richard. [Elizabeth Báthory](https://www.britannica.com/biography/Elizabeth-Bathory)

## Site Navigation
