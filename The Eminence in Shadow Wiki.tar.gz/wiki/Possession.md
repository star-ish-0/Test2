# Possession

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Possession](https://the-eminence-in-shadow.fandom.com/wiki/Possession)

Possession (悪魔憑（あくまつ）き, Akumatsuki[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a hereditary condition inherited by the female descendants of the Three Heroes. The blood disease causes the sudden onset of magical overload. Extended case symptoms include cancerous growths and rapid decay of the body, culminating in death. The Cult of Diablos continues to seek individuals displaying symptoms of possession for further experimentation and information control.[[1]](#cite_note-V1CP-1)[[2]](#cite_note-V2C2-2)

## Background

The origins of demon possession traces back to the Cult of Diablos hero implantation program. They injected Diablos Cells into orphaned children in the hopes of recreating their initial success of a magically engineered humanoid weapon—[Aurora](Aurora.md "Aurora"). The experiments conducted by the Cult of Diablos proved immensely lethal. The few children who survived the experiments passed their altered biology down to their descendants. Those individuals propagated further, leading to the widespread phenomenon of "the possessed." [[2]](#cite_note-V2C2-2)

### Propaganda

The Other World has been indoctrinated with the Cult of Diablos' propaganda, remaining unaware of the condition's true origins. To conceal the truth, the Cult and the Church of Holy Teachings, embarked on a misinformation campaign. They propagate the notion that a real demon infect the possessed with a standing bounty offered for their bodies. Consequently, bringing possessed individuals to the church has become a lucrative business enterprise. Those who do not seek a bounty, merely exile or kill the possessed.[[1]](#cite_note-V1CP-1)[[3]](#cite_note-MGC22-3)

## Racial Propagation

The frequency of possession varies among different races based on blood dilution. Each subsequent generation lowers the percentage of the ancestor's blood and decreases the chance of recurrence. Humans, possessing a shorter life expectancy than other humanoid races, exhibit a lower occurrence rate of possession. Conversely, elves and therianthropes demonstrate a higher onset rate. This disparity is primarily attributed to elves' longer lifespans that result in longer generations.[WEB NOVEL ONLY][[4]](#cite_note-WN08-4)

### Male Cases

Possession only affects females. This fact is evident by the experiments conducted by the Cult of Diablos, where men merely died without becoming possessed. Magical overload—one of the side effects of possession—is not a sex specific condition;[[1]](#cite_note-V1CP-1) however, it occurring due to possession is unique to females. Even for men born into lineages of the Three Heroines, the cells do not appear or remain dormant. The specific reason of this oddity yet to be elucidated, although, the Cult has circumvented this restriction through the creation of the Beads of Diablos.[[2]](#cite_note-V2C2-2)

## Cure

Efforts by the Cult of Diablos to actively cure possession continue to prove futile. Instead, they seek those who naturally overcome the ailment, or use the Beads of Diablos for temporary power.[[2]](#cite_note-V2C2-2) Historic examples of natural recovery include the three heroes; with a contemporary example being [Beatrix](Beatrix.md "Beatrix"), the War Goddess.[[5]](#cite_note-V2C8-5)

Cid Kagenou later developed a more consistent cure. Through magical experimentation, he harnessed the magic emanating from a possessed individual, significantly enhancing his own magical abilities and control. This process inadvertently healed the mound of flesh, restoring [Alpha](Alpha.md "Alpha") to her original form while seemingly granting her increased magical abilities. All of the Seven Shadows were later cured through this method.[[6]](#cite_note-V1C1-6) Likewise, Cid's ability extended to curing his sister, Claire Kagenou, from possession. Initially mistaking it for an error in her mana flow, successfully healed her before the later stages of possession took root.[[1]](#cite_note-V1CP-1)[[7]](#cite_note-V3CP-7)

Alpha and [Epsilon](Epsilon.md "Epsilon") adopted the ability to cure individuals afflicted by possession. They successfully treated hundred of those displaying possessed symptoms, subsequently recruiting them into the Shadow Garden organization during its membership expansion phase.[[8]](#cite_note-8)

## Vampirism Connection

Shadow Garden's extensive research lead [Eta](Eta.md "Eta") to a hypothesis of a possible consanguineous connection between the possessed and [vampires](Vampire.md "Vampire"). Through their research and physical samples, they validate Eta's theory.[[9]](#cite_note-V3C3-9) Recognizing the potential usefulness of vampiric power, combined with proper training, the Seven Shadows have begun to master the various vampire techniques.[[10]](#cite_note-10)[[11]](#cite_note-V5CP-11)

## References

1. Volume 1 Prologue: Preparing the Perfect Stage!
2. Volume 2 Chapter 2: Investigating the Sanctuary!
3. Master of Garden | Seven Shadows Chronicles. Strum of Velgalta: Chapter 22
4. Web Novel: Chapter 8
5. Volume 2 Chapter 8: Lay Your Eyes on My True Powers!
6. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
7. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
8. Seven Shadows Chronicles Chapter 1: Shadow Garden, Mobilize! Episode 5
9. Volume 3 Chapter 3: Pursuing the Blood Queen!
10. Volume 3 Chapter 6: Circulating Counterfeit Cash!
11. Volume 5 Prologue: The Case of the Missing Students and the Not-So-Peaceful Academy!

## Side Navigation
