# Marco Granger/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Marco%20Granger/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Marco%20Granger/Chronology)

Main

Relationships

Image Gallery

## Background

Before joining the Crimson Order, Marco was one of the strongest dark knights of the Knight Order. It was also rumored that he would be the future commander of the Order.

He was once betrothed to Nicoletta Marquez, with whom they exchanged letters and attended social functions. However, their engagement ended when her family stated she contracted a [fatal illness](Possession.md "Possession") and died.

## Princess Alexia's Kidnapping

After Princess Alexia's case was closed, Marco and [Glen](Glen.md "Glen") held a private meeting with Princess Iris Midgar, who asked them to join the newly formed Crimson Order upon learning the existence of secret organizations such as the Cult of Diablos and the Shadow Garden. She chose to form this new order with them because she couldn't trust the Knight Order after learning Zenon Griffey was a Cult member, as well as the warehouse arson incident which destroyed all confiscated evidence, classified documents, and objects from the Cult of Diablos. Marco and Glen agreed to help Princess Iris investigate the organizations, becoming the first members of the Crimson Order.[[1]](#cite_note-1)

## Midgar Academy Terrorist Attack

Marco and Glen accompanied Princesses Iris and Alexia to meet Sherry Barnett at the Midgar Academy in order to decipher the artifact known as the "Eye of Avarice", the only evidence connected to the Cult of Diablos. Assistant Principal Lutheran Barnett said he could only allow up to two guards to offer protection to Sherry while she was researching the artifact, so Princess Iris chose her most trusted men: Marco and Glen.[[2]](#cite_note-V1C4-2)

While Marco served as Sherry's bodyguard, there was a sudden attack on the academy by the Cult's forces posing as Shadow Garden, likely targeting the artifact Sherry was still deciphering the functionality of. Once Sherry was attacked by [Rex](Rex.md "Rex"), pretending to be Shadow Garden seeking to retrieve the artifact that Sherry had, she escaped with the artifact while Rex battled Glen and Marco, despite their magic being sealed.[[3]](#cite_note-V1C6-3)

Afterward, Glen was killed while Marco was unconscious and barely alive, and [Nu](Nu.md "Nu") was passing by during his incapacity.[[3]](#cite_note-V1C6-3) After the incident, Marco attended Glen's funeral and paid his respects to his senior.[[4]](#cite_note-4)

## Bushin Festival Tournament

## Great Trading Company Conflict

## The Academy Disappearances

Marco and the Crimson Order investigated the academy disappearances concurrent to the death of the head librarian. When Alexia tried to provide evidence and witness testimony, Iris shut her down under manipulations by Hubb into believing that the cult was only a fabrication by Shadow Garden, and Marco apologized to Alexia for the instance. Unable to answer her question regarding his stance on the matter, he could only leave in silence and resume his duties.[[5]](#cite_note-:0-5)

## References

1. Episode 5
2. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
3. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
4. Episode 14
5. Light Novel Volume 5 Chapter 2: Shocking Morning, School Skewer Murder Case!!
