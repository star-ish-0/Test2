# Mary

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mary](https://the-eminence-in-shadow.fandom.com/wiki/Mary)

[Chronology](Mary-Chronology.md "Mary/Chronology")

[Relationships](Mary-Relationships.md "Mary/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | The rampage is beginning... | ” |
| — Mary, Light Novel Volume 03 | | |

## Mary

### Japanese

メアリー

### Romaji

Mearī

### Aliases

Ancient Vampire Hunter

## Characteristics

### Race

[Vampire](Vampire.md "Vampire")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Red

### Eye Color

Gold
Red (thirst for blood)

### Birthday

May 10

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Vampire Hunter

### Affiliation

[Elisabeth](Elisabeth.md "Elisabeth")

## Debut

### Web Novel

Chapter 94

### Light Novel

Volume 3

### Manga

Chapter 28

### Anime

Episode 21

## Portrayal

### Japanese

[Ai Kakuma](https://en.wikipedia.org/wiki/Ai_Kakuma "wp:Ai Kakuma")

### English

Katelyn Barr

### French

Anne-Sophie Nallino

### Italian

[Debora Magnaghi](https://en.wikipedia.org/wiki/it:Debora_Magnaghi "wp:it:Debora Magnaghi")

Mary (メアリー, Mearī[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a legendary Ancient Vampire Hunter (最古（さいこ）の吸血鬼（きゅうけつき）狩（が）り, Saiko no Kyūketsuki-gari[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) whose notoriety creates far-reaching rumors.[[1]](#cite_note-V3C2-1) Once the Blood Queen [Elisabeth](Elisabeth.md "Elisabeth")'s closest aid, she continues to lament past failures and dedicates her life to stopping Progenitor's rampage in order to prevent another Red Moon tragedy.[[2]](#cite_note-V3C3-2)

## Appearance

Mary possesses long attractive red hair, golden eye and a tall slender stature. She is dressed all in black as she wears an outfit consisting of a black shirt, a red ruffle tie, black pants with red and gold accents, black gloves, calf-high boots, and a black cape with red and gold accents that covers the shoulders and back, also wearing a wide-brimmed hat like a pirate's hat with red and white feathers.

## Personality

In stark contrast to the typical portrayal of vampires, Mary stands out as a benevolent soul. She holds no regard for [humans](Human.md "Human") as mere cattle, always ready to extend a helping hand to those in need. Her unwavering loyalty to her master, [Elisabeth](Elisabeth.md "Elisabeth"), knows no bounds, rendering her incapable of disobeying orders or causing harm to her. Mary's determination to shield her mistress from malevolent forces, like [Crimson](Crimson.md "Crimson"), is unwavering.

Following Elisabeth's destructive rampage, Mary redirected her life's purpose, committing herself to the relentless pursuit of her former mistress and vowing to eliminate any vampires that posed a threat to humanity.

## Powers & Abilities

## Weapons and Equipment

In the novel, Mary wielded a menacing black cross sword in her pursuit of vampires, whereas in the anime adaptation, she favored a blood sword.

## Trivia

- Her name was renamed to Mary in the light novel, which was previously named Milia. The edit was done to differentiate her from Viscount [Grease](Grease.md "Grease")'s daughter, [Millia](Millia.md "Millia").
- In the Novels, Mary remained silent during Claire Kagenou's confession and admission of her [Demonic Possession](Possession.md "Possession"). But in the Anime, Mary shows a surprised reaction and articulates concern.[[3]](#cite_note-AS2E2-3)
  - The manga skips this scene.
- In the Anime, Claire initially mistook Mary for an [elf](Elf.md "Elf") since they are known for longevity. Claire does not make such a surmise in the light novel, web novel, and manga.[[3]](#cite_note-AS2E2-3)

## References

1. Volume 3 Chapter 2: Storming the Crimson Tower!
2. Volume 3 Chapter 3: Pursuing the Blood Queen!
3. Episode 22

## Site Navigation
