# Stan Bach

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Stan%20Bach](https://the-eminence-in-shadow.fandom.com/wiki/Stan%20Bach)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Stan_Bach?action=edit).

## Stan Bach

### Japanese

ヒカエ・オロー

### Romaji

Hikae Orō

## Characteristics

### Race

Unknown

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- 10th seat of the Knights of Rounds
- First Children
- Member of the Seven Blades

### Affiliation

Cult of Diablos
Velgalta Empire

Stan Bach (ヒカエ・オロー, Hikae Orō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the 10th Seat of the Knights of Rounds belonging to the Cult of Diablos and one of the Velgalta's Seven Blades. Years ago, he was fatally killed in a duel against Sergey Gorman for the title of Seven Blades while testing [Malak](Malak.md "Malak")'s enhanced powers, causing his position in the Rounds being soon taken by his opponent.

## Personality

Like many members of the Cult, Stan had quite a confident delusion that led him to completely convinced of his invincibility and have a severe overestimation of his own abilities.

## Early Life & Final Fate

Stan was a 10th Seat Knight of Rounds from the Cult of Diablos, though he keeps his true position a secret from those outside his faction by falsifying his official rank as First Children. Every year, he takes a drop of "Beads of Diablos" to maintain his strength and immortality. Stan and his faction operate in the Velgalta Empire. Due to his immense power gained from consuming the Beads, Stan instantly became a highly skilled swordsman and rose to become a senior knight, that which earned him the title of Velgalta's Seven Blades in the empire.

At one point at the annual imperial tournament event, Stan was publicly challenged by Sergey Gorman to a duel with wagering his title as the Seven Blades on the line. Stan, with high self-esteem, accepted his opponent's duel unaware of his [hidden power](Malak.md "Malak") until eventually Stan was killed in his fight against Sergey and claimed his Seven Blades position, yet his passing was classified as an accident within the duel according to the tournament regulations.

Subsequently after Stan's death, his duel contender Sergey is recruited by the Cult of Diablos who was very surprised because they did not expect their members to be defeated by outsider knight who had no affiliation with the Cult and making him the First Children, likely signifies that they deemed Sergey Gorman worthy of the title due to his willingness to align with the Cult's cause.[[1]](#cite_note-1)[[2]](#cite_note-2)[[3]](#cite_note-3)

## Powers & Abilities

## Trivia

## References

1. Master of Garden Seven Shadows Chronicles, Chapter 28: Hero....Lured by Illusions
2. Master of Garden Seven Shadows Chronicles, Chapter 20: Cult Secrets Revealed!
3. Master of Garden Seven Shadows Chronicles, Chapter 21: The Garden Heads North!

## Site Navigation
