# Sarasa

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sarasa](https://the-eminence-in-shadow.fandom.com/wiki/Sarasa)

## Sarasa

### Japanese

サラサ

### Romaji

Sarasa

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Dark Blue

### Eye Color

Dark Blue

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

[Gamma](Gamma.md "Gamma") (Descendant)

## Professional Information

### Occupation

Hero

### Affiliation

The Heroes
Cult of Diablos

## Debut

### Game

Apocrypha: Chapter 2 Part 3

Sarasa (サラサ, Sarasa[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the Heroes that took part in the battle against the [Demon Diablos](Aurora.md "Aurora"). She is the ancestor of [Gamma](Gamma.md "Gamma").

## Appearance

## Personality

## Chronology

### Requiem for Scattered Shadows

## Powers & Abilities

## Relationships

### [Olivier](Olivier.md "Olivier")

### [Lily](Lily.md "Lily")

### [Freya](Freya.md "Freya")

### [Duet](Duet.md "Duet")

### [Pente](Pente.md "Pente")

### [Nonna](Nonna.md "Nonna")

### [Rouge](Rouge.md "Rouge")

## Image Gallery

## Trivia

## References

## Site Navigation
