# King Anorion

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/King%20Anorion](https://the-eminence-in-shadow.fandom.com/wiki/King%20Anorion)

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/King_Anorion?action=edit).

## Anorion

### Japanese

アノリオン

### Romaji

Anorion

## Characteristics

### Race

Elf

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

King

## Debut

### Light Novel

Volume 7

King Anorion (アノリオン[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the King of the Elven Country.

## Appearance

## Personality

## Chronology

## Relationships

## Powers & Abilities

## Trivia

## References

## Site Navigation
