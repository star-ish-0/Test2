# Clara Oriana

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Clara%20Oriana](https://the-eminence-in-shadow.fandom.com/wiki/Clara%20Oriana)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Clara_Oriana?action=edit).

## Clara Oriana

### Japanese

クララ・オリアナ

### Romaji

Kurara Oriana

## Characteristics

### Race

Human

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

### Relatives

Raphael Geerk Oriana † (Father)
Reina Oriana † (Mother)
Rose Oriana (Elder Sister)

## Professional Information

### Occupation

Princess (Oriana Kingdom)

### Affiliation

Oriana Kingdom
Royalist Faction

## Debut

### Web Novel

Chapter 148

Clara Oriana (クララ・オリアナ, Kurara Oriana[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the second princess of the Oriana Kingdom and the younger sister of Rose Oriana.

## Appearance

According to Cid, Clara has pinkish blond hair and looks similar to her sister, Rose Oriana.

## Personality

Clara is a kind-hearted young girl who is willing to stand up for those who couldn't. Despite many told her about Rose's actions, Clara still believes in her older sister.

## Chronology

## Trivia

- The name Clara (Clarus) means "Bright, Clear, Famous" in Latin.
- Clara's surname Oriana means "Gold, Sunrise, Dawn" in Latin

## References

## Site Navigation
