# Zeta/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Zeta/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Zeta/Chronology)

[Main](Zeta.md "Zeta")

[Relationships](Zeta-Relationships.md "Zeta/Relationships")

Image Gallery

## Background

### Dark and Troubled Past

Zeta was originally known by the name of Lilim and had a loving family with her father, mother, and little brother. She was the daughter of the leader of the Golden Panther tribe, which is most prestigious tribes even among [Therianthrope](Therianthrope.md "Therianthrope"). The tribe was located far away from the Midgar Kingdom. She is also the direct descendant of the "Therianthrope Hero" Lili, who defeated the demon Diablos, which makes her bloodline and family exceptionally well esteemed, even among the Golden Leopard Tribes. Many settlements followed the Golden Leopard Tribe, and she was the eldest daughter of the chieftain who had ruled the tribe for time immemorial.

Apparently, her father had been covertly investigating the [Possession](Possession.md "Possession") since he feared that Lilim contracted it, having speculated and becoming suspicious of the beliefs of the Church. Since she was little, Lilim had great intelligence and a taste for reading freely, having spent all her time investing in her focused subject. At the same time, being the chief's daughter, she was allowed freedom from marital commitments with other Therianthrope tribes.

When Lilim turned twelve years old, she began showing symptoms of the Curse until they became visible and unbearable. When she told her parents, her father chose to hide the disease instead of killing her, and both would undertake a trip to the Midgar kingdom in search of a cure, according to an elf that she read about in a book. If he confirmed a cure, he would return to take Lilim as her father believed that there was someone in Midgar capable of curing the curse she had. Lilim did not believe it at all in the beginning and she was ready to be killed before her curse worsened, but she tearfully chose to trust her father and wait a month for him to return.

A month later, Lilim is still locked up in her house while she waited for her father, but those of her tribe found out through a priest of the church, really a member of the cult, that their boss had a possessed daughter of hers locked up in her house. They tied him up and killed him, but before her father tried to tell the "truth" of the Three Heroes and demon Diablos story, no one believed him, so her father ordered his wife bring Lilim and her brother to take care of themselves and to reach the kingdom of Midgar since there was "someone" there he believed could cure her of her Curse. Lilim fled in tears from her native tribe together with her mother, before being apprehended with her brother when she saw her father engaged against the priest and the branch family leader.

During her journey to the kingdom of Midgar, Lilim separated from her mother, who entrusted her with the care of her little brother. Regarding her curse, she was found by the village priest before her who showed her the severed head of her parents. When the priest introduces himself as [Petos](Petos.md "Petos"), after Lilim finally decided to confess that she is possessed in an attempt to save her little brother, but in the end, Petos ends up killing him in front of her and tells her that his job will turn him into Rounds before showing her all the severed heads of the Golden Panther tribe, including the head of the branch family. Lilim is enraged and strikes Petos, but he makes her unconscious also ordering his men to arrest the girl and take her to the laboratory of Valliora, while he made the preparations to be part of the faction.

When Lilim woke up, she was furious that her entire family and tribe were killed, and she loudly pleads for someone to save her and give her power. Fittingly, she was rescued by Shadow under the company of [Alpha](Alpha.md "Alpha") who was a little behind him, Shadow gave Lilim his power and cured her curse, while he finished off her captors. Lilim realized that everything her parents said was true, to which Shadow is surprised (since he didn't expect the invention to spread without knowing it was true) and tells him that the priest and the people who capture her were not from the Holy Church. Those men were actually from the Cult of Diablos and they hid the truth about the Three Heroes and the story of the demon curse in the darkness of history because they wanted to bury the truth about the hero lineage that was an obstacle to them by naming the demonic curse as a Possession, also tells Lilim that they tried to revive the demon Diablos and that they need the blood of the possessed, that is, of the girls descended from the Three Heroes. Lilim then joined Shadow Garden and under Alpha's explanations, she was given the new name that is Zeta, becoming the sixth member of the "Seven Shadows" under her master, Shadow.[[1]](#cite_note-1)

## Volume 1

### First Assault on the Cult

During the case of when her lord Cid's sister, Claire Kagenou was abducted by the Cult of Diablos, Zeta participated in the assault on the hidden secret base where Claire was kidnapped. Alongside her lord and the others of the Seven Shadows, they managed to rescue Claire after they eliminated Cult members, including the leader of the branch base Viscount [Grease](Grease.md "Grease") and hiding their involvement. In the aftermath, Zeta with the Seven Shadows decide to leave Shadow to hunt down the Cult of Diablos, as they to scatter across the world to build Shadow Garden's power.[[2]](#cite_note-V1C1-2)

### Zeta's Extremist Determination

At some point, Zeta formed a faction behind Alpha's back because she feared that after the complete collapse of the Cult, Shadow Garden would no longer have a purpose and disband. This faction served with the goal of resurrecting [Diablos](Aurora.md "Aurora") to make Shadow immortal and the god of the new world. The only known members this faction are [Victoria](Victoria.md "Victoria") and [Nina](Nina.md "Nina"), who's in keeping eye on Claire by entering the Midgar Academy.

### Laugus's Origins Research Investigation Discoveries

## Volume 5

### The Academy Disappearances

With students of Midgar's Academy mysteriously disappearing, Shadow Garden investigated and deduced that the [Fenrir](Fenrir.md "Fenrir") sect was responsible and used them for dark machinations of releasing Diablos' right arm which was kept underneath the Academy. Zeta was dispatched to the academy before Alpha learnt of her whereabouts and it was there, she reunited with her master. Despite keeping a calm demeanor, Cid noticed that her tail was waging and had marked his belongings.

## References

1. Volume 5 Chapter 3 Case Closed, Yes, Let’s Talk About the Old Days
2. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
