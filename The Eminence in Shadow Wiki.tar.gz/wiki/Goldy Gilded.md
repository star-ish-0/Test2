# Goldy Gilded

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Goldy%20Gilded](https://the-eminence-in-shadow.fandom.com/wiki/Goldy%20Gilded)

Chronology

Relationships

Image Gallery

## Goldy Gilded

### Japanese

ゴルドー・キンメッキ

### Romaji

Gorudō Kinmekki

### Aliases

Unbeaten Legend
Victorious Golden Dragon

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Blond

### Eye Color

Purple

### Birthday

January 24

## Personal Information

### Status

Alive

## Professional Information

### Occupation

- Swordsman
- Slave (Former)
- Vow of Black Rose Commander (WN)

### Affiliation

Vow of Black Rose (WN)

## Debut

### Web Novel

Chapter 67

### Light Novel

Volume 2

### Manga

Chapter 21

### Anime

Episode 15

## Portrayal

### Japanese

[Kazuyuki Okitsu](https://en.wikipedia.org/wiki/Kazuyuki_Okitsu "wp:Kazuyuki Okitsu")

### English

[Justin Doran](https://en.wikipedia.org/wiki/Justin_Doran "wp:Justin Doran")

### French

Jimmy Redler

### Italian

Renato Novara

Goldy Gilded (ゴルドー・キンメッキ, Gorudō Kinmekki[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a swordsman who once called the Unbeaten Legend (不敗（ふはい） 神話（しんわ）, Fuhai Shinwa[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) by the public for being "undefeated", though only technically true as he tends to forfeit fights that he is unsure of winning, and instead is known as the Victorious Golden Dragon (常勝（じょうしょう） 金（きん） 龍（りゅう）, Jōshō Kin Ryū[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Appearance

Goldy is a gorgeous handsome man with sparkling blond hair. As the name suggests, he's dressed in golden armor.

## Personality

Goldy is a highly pretentious individual who wants to look cool.

Despite acting like a flamboyant braggart, in truth, Goldy was a coward who ran away the minute he knew he was facing an opponent stronger than him. He was deeply ashamed of this cowardice, hence why he hated his title "Unbeaten Legend" as it was a constant reminder that no one could beat him because he ran from the fight.

## Powers & Abilities

Goldy is a powerful swordsman, but he only fights those he knows he can beat, then withdraws once he has to contend with anyone stronger than him. Even Goldy has only ever fought those he knows he can best, he places highly in his tournaments as when he’s won a few of the smaller match and never shown off the true extent of his strength. Annerose state that if Goldy been aiming for the top and actually took on stronger opponents, he could’ve made an outstanding dark knight.

### Physical Dexterity

### Analytic Eye

Goldy can accurately perceive other people's strength, skill, and magic, just by looking at them when he measures combat power based on the opponent's appearance and martial arts also their weapons. He analyzes his behavior, attitude, aura and equipment, and calculates those factors that result in what he calls "battle power", this ability in a certain way, works similar to the magic detectors of the academies, which evaluate the magic power. than one, but in Goldy's case, he can measure more than just that.

He used this eye for his preferred tactic is to make sure to gather battle data and chooses his opponents and battles wisely, because whenever he meets stronger opponents, he either flees or forfeits.

However, this ability has a weak point, and that is that it cannot be used to perceive the level of battle power, along with their magic and abilities, of people who have the ability to hide them very strongly, so as a consequence, can give an erroneous reading, without the latter realizing it, as was the case with as Mundane.[[1]](#cite_note-V2C5-1)

### Swordsmanship

Goldy Swordsmanship is based on speed and fast sword movement also coordinated strikes.

### Magic

Goldy can be capable of manifesting his magic and materializing it into a golden color and shape the magic into whatever he wants.

#### Demonic Golden Dragon! Fatality Strike

Goldy can make his magic into the form of a dragon and use it to attack his enemy. [Quinton](Quinton.md "Quinton") state that this attack techniques had enough power if he’d advanced to the final tournaments.[[1]](#cite_note-V2C5-1)

## Trivia

- Although Goldy is a strong warrior, he does not have the ability to perceive how strong and powerful a person is on an instinctive level due to his lack of experience, unlike Shadow, [Beatrix](Beatrix.md "Beatrix"), [Alpha](Alpha.md "Alpha"), [Delta](Delta.md "Delta"), [Zeta](Zeta.md "Zeta"), [Aurora](Aurora.md "Aurora"), [Elisabeth](Elisabeth.md "Elisabeth") and partly Alexia Midgar. Therefore, it depends a lot on his "Analytical Eye".

## References

1. Volume 2 Chapter 5: A Battle to Attract Only MVPs!

## Site Navigation
