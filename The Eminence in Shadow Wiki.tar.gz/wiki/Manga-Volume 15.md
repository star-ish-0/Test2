# Manga/Volume 15

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2015](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2015)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_15?action=edit).

## Manga Volume 15

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041158579

### ISBN EN

ISBN 979-8855427813

### Release Date

February 26, 2025 JP
September 22, 2026 EN

## Volume Information

### Pages

144

Publication Order

| Previous | Next |
| --- | --- |
| Volume 14 | Volume 16 |

This is the fifteenth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

Claire may have randomly disappeared (again), but at least she managed to find her own way back this time! What’s more, her otherworldly experience has gotten the attention of Princess Alexia, who’s increasingly worried that their school may hide a dark secret. The two team up to investigate, but they’re not the only ones on the case, as both the Knights of Rounds and the Seven Shadows are pursuing the same leads…![[1]](#cite_note-1)

そして永遠の命を得たシャドウ様がこの世界の神となる――…！！

異世界に転生し、あらゆる物事に陰から介入し
実力を示す「陰の実力者」設定をエンジョイしているシド。
連続失踪事件が巻き起こり生還したクレアだったが、
学園に魔人ディアボロスに関する秘密が眠っていることを知る。
アレクシアと共に謎を追う中、ラウンズ第５席のフェンリル陣営も動き出し、
そして七陰のゼータは独自の道を行き――。

重度の勘違いと理不尽な強さで圧倒する、暗躍の第１５巻！ [[2]](#cite_note-2)

## Summary

## Chapters

- Episode 58
- Episode 59
- Episode 60
- Episode 61

## Characters

:   In order of appearance:

## References

1. [The Eminence in Shadow, Vol. 15 (manga) Yen Press](https://yenpress.com/titles/9798855427813-the-eminence-in-shadow-vol-15-manga/)
2. [The Eminence in Shadow (15). Kadokawa](https://www.kadokawa.co.jp/product/322410000340/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • **Volume 15** • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
