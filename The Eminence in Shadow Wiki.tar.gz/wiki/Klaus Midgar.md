# Klaus Midgar

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Klaus%20Midgar](https://the-eminence-in-shadow.fandom.com/wiki/Klaus%20Midgar)

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | Our nation needs time to make preparation as well. The darkness that has been lurking behind the curtains of history since ancient times was growing ever more dense. We dared not tread into their realm to confront them unprepared. | ” |
| — Klaus, Episode 20 | | |

## Klaus Midgar

- Manga
- Anime

### Japanese

クラウス ・ミドガル

### Romaji

Kurausu Midogaru

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Red

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

### Relatives

Iris Midgar (Oldest Daughter)
Alexia Midgar (Youngest Daughter)

## Professional Information

### Occupation

King of Midgar Kingdom

### Affiliation

Midgar Kingdom

## Debut

### Web Novel

Chapter 82

### Light Novel

Volume 2

### Manga

Chapter 71.1

### Anime

Episode 19

### Game

Episode 17

## Portrayal

### Japanese

[Satoshi Mikami](https://en.wikipedia.org/wiki/Satoshi_Mikami "wp:Satoshi Mikami")

### English

Dickie Sanders

### French

Philippe Rouillier

### Italian

Andrea Failla

Klaus Midgar (クラウス ・ミドガル, Kurausu Midogaru[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the king of the Midgar Kingdom as well as the father of both Iris and Alexia. Though often criticized for his seeming inaction, he is actually fully aware of the existence of the Cult of Diablos and quietly fights their influence.[CITATION NEEDED]

## Appearance

Klaus has rarely been seen within the series, but glimpses of him showed that he is a middle-aged man with red hair and a mustache. He is also usually seen dressing up in attire befitting a king presently ruling his nation. His appearance makes him look more like Iris than Alexia, with matching red hair.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Acting impetuously will create too many enemies. Even if your deeds are just, we cannot assume those who are unaware of the circumstance will understand them as being so. | ” |
| — Klaus to Iris, Episode 19 | | |

Klaus is a cautious ruler who wants to neutralize any troubles as he adopted "the principle of avoiding things" in which he doesn't make any moves if the problems don't affect too much of his kingdom.[CITATION NEEDED] Because of his policy, Klaus is not highly regarded as a king by both of his daughters, who see him as too inactive for their sense of initiative.[CITATION NEEDED] However, he is also a man of honor, taking great care to respectfully deliver the body of King Raphael Geerk Oriana to his homeland, but through the Marquess [Grant](Grant.md "Grant") of the anti-Duke faction opposing Perv Asshat.

## Powers & Abilities

Being the ruler of the Midgar Kingdom, Klaus has great political power over the nation's internal affairs. Granted that he is aware of the Cult but takes strides to legitimately and inconspicuously challenge their stranglehold on the world, Klaus can also be seen as a capable tactician.[CITATION NEEDED]

## Trivia

- The name "Klaus" in German means "victory of the people".
- Klaus and Iris share matching crimson hair. It is unclear if his wife, the queen, shares matching silver hair with Alexia.

## References

## Site Navigation
