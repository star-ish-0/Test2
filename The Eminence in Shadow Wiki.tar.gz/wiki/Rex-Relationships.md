# Rex/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Rex/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Rex/Relationships)

[Main](Rex.md "Rex")

[Chronology](Rex-Chronology.md "Rex/Chronology")

Image Gallery

## Cult of Diablos

He was one of the Cult's Named First Children, a strong group used as an assaulting force when needed. Being a First Child, he has command over other members of the Cult.

### Sir Gaunt

His superior. Their relationship was tense due to how little respect Rex showed to him. The former Rounds Knight was patient with Rex's attitude until he reported what happen with the Eye of Avarice to which he was enraged and had threaten him to retrieve it from Sherry. When Rex didn't come back, the former Rounds Knight called him useless, unaware that Rex was killed by Shadow.

## Enemies

### Midgar Academy for Dark Knights

#### Sherry Barnett

His primary target during the raid on the Academy. Rex's cocky attitude became his undoing when he allowed the Researcher to escape where she later met up with Cid.

#### [Glen](Glen.md "Glen")

His opponent. Upon arriving to retrieve the Eye of Avarice from Sherry, Glen protected her from Rex's onslaught stating that his skills alone are enough to match against his magic abilities. Feeling insulted, Rex was confident in killing the Knight and so he did with ease.[[1]](#cite_note-V1C6-1)

#### Marco Granger

One of his opponents. The Knight's incapacitated body was seen in the same room where Glen was killed.[[2]](#cite_note-:0-2)

### Shadow Garden

#### Shadow

Although Rex was unable to identify the student as the Shadow Garden's leader, he was able to notice that he's too injured to keep fighting when he saw his blood-stained uniform and thinks he used an artifact that boosts his abilities where he wrongly concluded that the student has no chances of defeating him. That is until Rex witnessed multiple corpses of his subordinates before being killed by Shadow after being complimented by him.[[1]](#cite_note-V1C6-1)

## References

1. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
2. Episode 8
