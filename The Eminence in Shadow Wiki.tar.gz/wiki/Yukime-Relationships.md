# Yukime/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Yukime/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Yukime/Relationships)

[Main](Yukime.md "Yukime")

[Chronology](Yukime-Chronology.md "Yukime/Chronology")

Image Gallery

## Shadow Garden

### Shadow

Yukime acted teasingly and unashamedly flirted with Shadow after he protected her prostitutes from the vampires. Upon witnessing his incredible strength, Yukime desired to gain his aid in order to bring down [Gettan](Gettan.md "Gettan") and the Major Corporate Alliance. She tried seducing him, but Shadow could tell what her motives were and dismissed the attempts. She finally got Shadow's aid with the promise of riches by collapsing both the Major Corporate Alliance and Mitsugoshi Company.

When the two worked together, Yukime was quite fearful of her partner as she learnt that not only did Shadow (now under the guise, John Smith) possessed power but also seemingly supernatural intelligence which kept her on her toes. Still, Yukime developed respect for John that by the time their plans were complete, she apologized to him for using him for her revenge.

Unbeknownst to her and John, the two had actually met years ago. When [Gettan](Gettan.md "Gettan") attacked Yukime for refusing to join the Cult of Diabolos, John came to her rescue and used his magic to heal her. Upon being rescued once more and healed of her scars completely by John in the present day, Yukime realized that John and her past savior were one and the same. Combined with the belief he rescued her out of care, Yukime fell in love with John.

When informed by [Alpha](Alpha.md "Alpha") that John had in fact used her to bring down the Major Corporate Alliance and protected Mitsugoshi Company (a Shadow Garden front), Yukime does not hold ill will towards him.

### [Alpha](Alpha.md "Alpha")

Yukime had a respectful working relationship with [Alpha](Alpha.md "Alpha") after the former become an ally to Shadow Garden. Although, Yukime admitted she was envious that [Alpha](Alpha.md "Alpha") was one of the people Shadow held dear.[CITATION NEEDED]

## Lawless City

### [Kana](Kana.md "Kana") & [Natsu](Natsu.md "Natsu")

### [Juggernaut](Juggernaut.md "Juggernaut")

## Cult of Diablos

### [Gettan](Gettan.md "Gettan")

Gettan was Yukime's hated enemy and her former fiancée. The two were romantically in love until [Gettan](Gettan.md "Gettan") betrayed her by not only attacking her for refusing to join the Cult of Diablos with him but also murdering her beloved mother. Since then, Yukime solely wanted vengeance against her former fiancée, and she did it by destroying the Major Corporate Alliance which [Gettan](Gettan.md "Gettan") had led. When the two former lovers confronted each other years later, even though Yukime had [Gettan](Gettan.md "Gettan") beaten and was about to deliver the killing below, Yukime stopped herself as she believed there was still some good within her former lover; Gettan, however, only saw Yukime's act of mercy as an insult and made a repeat of his betrayal by slashing Yukime in the back while mockingly told Yukime that he should have killed her in his first betrayal. After Gettan was defeated and suffered heavy torture, by John Smith, Gettan came to regret his choices and died while asking John Smith to protect Yukime. After Yukime came to learn about the Cult of Diablos, being responsible for changing Gettan for the worse which led to her personal past tragedy, Yukime chooses to join Shadow Garden in their efforts to destroy the Cult of Diablos.
