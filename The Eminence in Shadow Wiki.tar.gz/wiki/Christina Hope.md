# Christina Hope

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Christina%20Hope](https://the-eminence-in-shadow.fandom.com/wiki/Christina%20Hope)

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

Chronology

Relationships

Image Gallery

## Christina Hope

- Christina
- "Jack the Ripper"

### Japanese

クリスティーナ・ホープ

### Romaji

Kurisutīna Hōpu

### Aliases

"Jack The Ripper" (successor)

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

16

### Height

Unknown

### Hair Color

Red

### Eye Color

Blue

### Birthday

Unknown

## Personal Information

### Status

Alive

### Relatives

Unnamed Father
Suzuki Hope † (Distant Relative)

## Professional Information

### Occupation

Student

### Affiliation

Midgar Academy for Dark Knights
Oriana Kingdom (Web Novel)

## Debut

### Web Novel

Chapter 197

### Light Novel

Volume 5

### Manga

Chapter 57

Christina Hope (クリスティーナ・ホープ, Kurisutīna Hōpu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a student at Midgar Academy for Dark Knights and distant relative of Suzuki Hope.[[1]](#cite_note-V5C5-1)  Being saved by Shadow and witnessing the actions of Jack the Ripper inspired her to pursue vigilantism and continue the crusade to fight corruption in Midgar Kingdom.[[2]](#cite_note-V6CA-2)

## Appearance

Christina has red hair and blue eyes. Christina is usually seen in her Academy uniform with her hair bundled into twin buns and golden ring decorations.

## Personality

As the daughter of the illustrious Duke Hope, Christina originally disciplined herself to become a proper lady, determined to display a noble's dignity and uphold the family name. Consequently, she would stop anything that would besmirch her family, such as the actions of branch members or outside comments. Despite her prestigious presentation, Christina used to be sociable and pragmatic. She recognized her shortcomings and deferred to others when necessary, status or birthright notwithstanding.[[1]](#cite_note-V5C5-1)

Christina's optimistic virtues drastically altered after the exoneration of Eliza Despoht. Witnessing a criminal be acquitted broke her perceived ideals of the aristocracy and their role in society. Past sensibility and rectitude became internal acrimony and hopelessness.[[3]](#cite_note-3)[[4]](#cite_note-4) She continues to advocate and pursue justice; however, her belief on how one should execute it has broadened past local authorities and pacifism.[[2]](#cite_note-V6CA-2)

## Powers & Abilities

As daughter of the main Hope family, Christina's swordsmanship, magical abilities, and academic performance is highly praised enough to be considered one of the five best students in Cid's class.[[5]](#cite_note-V5C1-5) During the ghost incident, she was one of students who helped in the investigation and was able to hold off hordes of them.[[1]](#cite_note-V5C5-1)

### Weapons and Equipment

- Broad Sword: As a student of Midgar Academy, Christina uses a regular broad sword.
- Knife: When Christina killed Eliza, she used a knife to pierce Eliza's chest.

## Trivia

## References

1. Volume 5 Chapter 5: Terrorists Attack the School… Again!!
2. Volume 6 Auxiliary Chapter: The Inherited Monster
3. Volume 6 Prologue: The Clandestine Rulers of the Midgar Kingdom... I'm so Jealous!
4. Volume 6 Chapter 1: Jack the Ripper Makes an Entrance
5. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • Alexia Midgar • **Christina Hope** • [Isaac](Isaac.md "Isaac") • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |
