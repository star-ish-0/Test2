# Mary/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mary/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Mary/Relationships)

[Main](Mary.md "Mary")

[Chronology](Mary-Chronology.md "Mary/Chronology")

Image Gallery

## [Elisabeth](Elisabeth.md "Elisabeth")

Her highness to which she served devotedly. When Elisabeth ordered her to stop and kill her, Mary chose to imprison her instead of allowing her to suffer because of her vampiric nature. Due to her reluctance to follow the order, it was to the point she hid her body in a coffin and vowed to protect her for eternity from Crimson after the previous Red Moon incident. Even though she could not go against her master's will, her decision backfired when Crimson managed to overpower her and steal Elizabeth's body.

## [Crimson](Crimson.md "Crimson")

Advisor for the Queen, Mary despised Crimson for causing the Queen to go berserk and kill many when he mixed human blood into her food with the intention of subjugating mankind under Vampire rule. Stealing her became his undoing when Shadow annihilated him.[[1]](#cite_note-:1-1)

## Claire Kagenou

Bushin Festival Champion and prodigy, Mary employed her to come to the Lawless City in handling the upcoming Red Moon. She would almost regret employing her when her brother Cid got involved and knowing his life was endangered, they rush over to the Crimson Tower.[[2]](#cite_note-:0-2) Initially they believed to be too late to save him, Mary was shocked by her demeanor and recognition towards him.

When they fought alongside each other, they were able to be held on their own against the berserk Elisabeth until Shadow saved her.[[1]](#cite_note-:1-1)

## References

1. Volume 3 Chapter 3: Pursuing the Blood Queen!
2. Volume 3 Chapter 2: Storming the Crimson Tower!
