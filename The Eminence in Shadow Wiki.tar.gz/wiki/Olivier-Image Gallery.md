# Olivier/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Olivier/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Olivier/Image%20Gallery)

[Main](Olivier.md "Olivier")

[Chronology](Olivier-Chronology.md "Olivier/Chronology")

[Relationship](Olivier-Relationship.md "Olivier/Relationship")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

character introduction

Genesis Paladin

Game Event: Apocrypha "Requiem for the Falling Shadows": Heroine Olivier along with Alpha, Yukime, Delta and Tessera

Heroine Olivier in hi solitude

Game Event: Apocrypha "Requiem for the Falling Shadows": Demonic Olivier - Kills Yukime and Tessera

Game Event: Apocrypha "Requiem for the Falling Shadows": Olivier affected by the trauma of her past

Game Event: Apocrypha "Requiem for the Falling Shadows": Traumatized Olivier prepares to fight against her companions (Olivier and Epsilon)

Demonic Paladin: Olivier

Apocrypha: Requiem for the Falling Shadows - Heroine Olivier vs Demon Zeta
