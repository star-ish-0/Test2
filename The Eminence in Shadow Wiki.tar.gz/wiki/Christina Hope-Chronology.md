# Christina Hope/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Christina%20Hope/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Christina%20Hope/Chronology)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Christina_Hope/Chronology?action=edit).

Main

Relationships

Image Gallery

## Volume 5

### The Midgar Academy Mist Terrorist Attack

## Volume 6

## Bloody Midgar Serial Murder Terror
