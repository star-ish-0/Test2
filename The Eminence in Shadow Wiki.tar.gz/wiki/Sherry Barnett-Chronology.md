# Sherry Barnett/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sherry%20Barnett/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Sherry%20Barnett/Chronology)

Main

Relationships

Image Gallery

## Chronology

### Background

For the first nine years of her life, Sherry was solely raised by her mother Lukreia Crowley who took care of her alone until she become nine years old, while working as a researcher since her father died soon after she was born.[[1]](#cite_note-V1C6-1) Her father died shortly after Sherry’s birth and was never a part of her life. Although employed as a researcher, Lukeria harbored financial difficulties but worked hard to raise Sherry in a loving environment. A mysterious man named Lutheran Barnett appeared in Sherry’s life one day. Introducing himself as a friend, he expressed an interest in her mother’s work and offered to become Lukeria’s patron. After agreeing to the terms, her mother began to study artifacts Lutheran supplied, including the "Eye of Avarice." The relationship between the two progressed to intimacy and financial concerns were soon alleviated.

Those times did not last long. Sherry, attempting to observe her mother’s work, a common occurrence, witnessed the murder of her mother at the hands of a mysterious man. The man was Barnett, but Sherry’s trauma-ridden mind is incapable of recollecting those details. The only memories that remain are the blood and tears.

After her mother's funeral, Lutheran accepts guardianship and treats her like his blood. Ever since, she spent the rest of her childhood with her adoptive father, unaware of his alternative motives. Sherry, deprived of the ability to spend any more time with her mother, sought the next best alternative. Delving into her mother’s passion, research. [[2]](#cite_note-:2-2)

### Midgar Academy Terrorist Attack

Sherry and Lutheran Barnett are paid a visit by Princess Iris Midgar and Alexia Midgar. Iris gives them an artifact salvaged from a Cult of Diablos warehouse fire. She formally requests Sherry’s assistance in deciphering it. Sherry is regarded as one of the brightest minds in the kingdom, inspiring confidence in Iris’s decision. Due to Iris’s diminished faith in the Knight Order after Zenon Griffey’s involvement in Alexia’s kidnapping, the request was on behalf of the newly created Crimson Order. Sherry’s demure response causes her father to encourage the endeavor, stating it is a rare opportunity. After acceptance, Iris articulated her desire to assign the Crimson Order to guard her from potential danger. Lutheran agrees to the circumspect proposition, under the condition that only two guards be assigned to Sherry's laboratory, so as not to overwhelm or impede her work. Princess Iris accepts the terms and chooses two trusted men for protection: [Glen](Glen.md "Glen") and Marco Granger.[[3]](#cite_note-V1C4-3)

The next day, while researching the artifacts given to her by Princess Iris, Sherry unexpectedly is approached by a boy. He nonchalantly gives her a box of chocolates. Unbeknownst to her, it was part of a mutual humiliation arrangement set up by his friends. Back in her research room, she is perplexed by the strange gift and even more befuddled by the boy's actions. Her father, Lutheran, enters the room and questions Sherry’s possession of chocolate. Sensing her confusion, Lutheran explains chocolate is comestible and highly sought after. Sherry explains how she came by the chocolate. As chocolate is regarded as a luxury item, Lutheran surmises the boy may be infatuated with Sherry, suggesting it may have been “love at first sight.” He advises Sherry to consider her reply carefully while also exercising reasonable haste. Lutheran explains while study and research can take precedence, social interactions are a necessity for a healthy life. A sudden coughing fit from Lutheran brings the current conversation topic to an end. Sherry hurriedly offers assistance, expressing distress about his deteriorating condition. Lutheran dismisses her concerns by claiming he has felt better lately and how fortunate he is to have a good daughter. Sherry redirects the compliment, stating she is lucky to be his adoptive daughter.

Sherry learns that the boy, Cid Kagenou, is a participant in the Bushin Festival preliminary tournament. To satisfy her curiosity, she spectates his match and witnesses his humiliating defeat at the hands of the Student Council President Rose Oriana. Summoning the courage to approach him, she offers him homemade cookies as a token of her appreciation and a friendship offering. After Cid’s acceptance, she tells her father, who is quietly observing the interaction for moral support, that she made a friend. After some small talk, Lutheran advises Cid to take care of his injuries, parting ways with the pair.

The cookie exchange brought no equilibrium to Sherry’s turbulent mind. Ideas of subsequent interactions distract her from work. Knowing his name, she realizes he is rumored to be in a relationship with Alexia Midgar. Sherry decides to cease restless speculation and talk with the source. Alexia, having a few minutes of free time, respectfully invites Sherry into her room. Her initial guess on Sherry’s company relates to the artifact, but Sherry refutes the claim. Nervously, she broaches the topic of Alexia and Cid’s relationship, asking for confirmation. Alexia states they separated and the relationship in question was fictitious for an unspecified purpose. After hearing her answer, Sherry visibly relaxes and expresses joy. She explains a friendship with Cid started the other day. The open question about his relationship made concentration on research impossible. She feels happy that her actions are not interfering with an established relationship. She ecstatically states her work to decipher the artifact will continue at a new accelerated pace. Taking her leave and lost in ecstasy, Sherry failed to hear or see the fate of Alexia’s teacup. A porcelain mound of smoldering anger and jealousy[[4]](#cite_note-V1C5-4)

Five days later, while engrossed in artifactual analysis, a group of black hooded people attack the Academy. A hoodlum, proclaiming to be from ‘Shadow Garden’ barges into her research room through a window. He reveals his name as [Rex](Rex.md "Rex"), the Game of Betrayal, explaining his job is to retrieve the artifact. Once his mission is concluded, he is permitted to wreak havoc indiscriminately. Rex, seeing the artifact in Sherry's hands, goes for the kill. His lethal blow is interrupted by an opportune parry from Glen. Glen and Marco engage in combat against the terrorists to allow Sherry to retreat. Her retreat is hindered by inexperience in combat.  Noisy clothing and improper positioning make her a prime target for kidnapping. Cid lethally intervenes from a distance to save her from being captured or detected. Encountering Cid, she hurriedly attempts to expound on several topics at once. Cid tells her he will listen but first asks her to remove her noisy slippers.

The two of them then head to the Vice Principal's room. Sherry locates the book she was after and explains to Cid that the Eye of Avarice is inhibiting their magic. The artifact absorbs and stores the magic from any user, but it can be programmed to ignore some magical frequencies. Sherry hypothesizes it can absorb magical outliers that are too small to detect or powerful spells that exceed its capacity. The latter is conjecture, for no human is capable of maintaining stability on that level. Once the artifact has reached maximum capacity, it undergoes an exothermic reaction, violently dispersing the stored energy.

Sherry expounds that the artifact could be manipulated to disable or control other artifacts like the one creating a magic-nullifying barrier around the Academy. Cid partially understands the significance of these ideas. Since all the students are in the auditorium, Sherry speculates that the artifact is located nearby. The possibility of energy capacity being reached could endanger the lives of the students. Sherry states her father did not publish his findings and gave the artifact to the government for safekeeping due to the potential danger. She further explains that the artifact she was researching is used to control the Eye of Avarice. That control would allow for stability in applications where long-term energy storage is required. Sherry cautiously sketches her plan to use the basements and secret passageways to reach the auditorium. Once she is close to the Eye of Avarice, she will activate this artifact and counter the Eye of Avarice's magic seal. However, she left all the tools to fine-tune the artifact in her research room. Cid volunteers himself for the retrieval of the tools and leaves Sherry to her own devices.[[1]](#cite_note-V1C6-1)

Cid, having returned safely with all the tools required for the operation, silently observes as Sherry fine-tunes the artifact. Before leaving the lab, Sherry confides in Cid about the death of her mother. Lutheran offered comfort at the time of her death, declaring her mother was a great researcher and offered to raise Sherry. She is determined to repay him by completing the research. With a final goodbye, she heads to the auditorium through the Academy's secret tunnels alone.

Sherry reaches the auditorium unimpeded and makes visual conformation of the Eye of Avarice, located in a knight's hand. She activates her artifact and throws it to disable the magic-blocking field. With the magical obstruction disabled, Rose Oriana made quick work of a nearby terrorist. She announces the return of their magic and the time to initiate a counterattack is now. With a cry of rebellion, the students engage in combat. Descending from the roof amidst the chaos, Shadow and Shadow Garden members join the battle to retake lost ground.

Unable to locate her father in the auditorium, Sherry retraces her steps through the tunnels to find him. She does find Lutheran, along with Shadow standing over his corpse. Lutheran recently confessed to killing her mother and orchestrating the entire terrorist incident only moments before her arrival. She collapses onto Lutheran’s corpse, only able to gasp in between tears. Shadow’s form disappears into the night, leaving behind the mentally shattered Sherry.t.

In the aftermath of the incident, Sherry tells Cid she will head to [Laugus](Laugus.md "Laugus") to further her research and bids him a sullen farewell.[[5]](#cite_note-:4-5) Behind her dead eyes, future machinations against Shadow can be inferred. Revenge is the only thing animating her soulless body as she turns away from her one remaining friend.

#### Anime/Game

In the anime, Sherry reads about how Iris and [Beatrix](Beatrix.md "Beatrix") chased Shadow off during the Bushin Festival, and Rose Oriana is still missing after she killed her father, King Raphael Geerk Oriana. It is also revealed that she has become so obsessed with seeking vengeance that her entire room is plastered with Shadow's wanted poster.[[6]](#cite_note-:1-6)

## Volume 6

It's revealed by Eta that sometime after Sherry's arrival in Laugus she became a professor.

## References

1. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
2. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
3. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
4. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
5. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
6. Episode 20
