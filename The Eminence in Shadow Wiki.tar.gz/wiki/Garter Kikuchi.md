# Garter Kikuchi

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Garter%20Kikuchi](https://the-eminence-in-shadow.fandom.com/wiki/Garter%20Kikuchi)

Chronology

Relationships

Image Gallery

## Garter Kikuchi

### Japanese

ガーター・キクチ

### Romaji

Gātā Kikuchi

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Grey

### Eye Color

Brown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

President of the Garter Corporation

### Affiliation

Major Corporate Alliance
Cult of Diablos (secretly)

## Debut

### Web Novel

Chapter 120

### Light Novel

Volume 3

### Manga

Chapter 34

### Anime

Episode 24

## Portrayal

### Japanese

[Chafurin](https://en.wikipedia.org/wiki/Chafurin "wp:Chafurin")

### English

[Mark X. Laskowski](https://en.wikipedia.org/wiki/Mark_Laskowski "wp:Mark Laskowski")

### French

Patrice Melennec

### Italian

[Luca Semeraro](https://en.wikipedia.org/wiki/it:Luca_Semeraro "wp:it:Luca Semeraro")

Garter Kikuchi (ガーター・キクチ, Gātā Kikuchi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the former president of the Garter Corporation and [Gettan](Gettan.md "Gettan")'s primary confidant. He acted as the figurehead for the Major Corporate Alliance, overseeing movement and providing reports on circumstances, while Gettan dictated policy and actions.

## Appearance

Characterized by his obesity, Garter's appearance is described as "frog-like."

## Personality

Garter is a pusillanimous individual who obediently follows Gettan's orders, after his hostile takeover. Incompetence may outmatch his weight, as all Major Corporate Alliance directive failed.

## Powers & Abilities

Garter had authority over his corporation, which grew exponentially after he became the "leader" of the Major Corporate Alliance. It was lost after the Alliance's collapse.

## Trivia

## References

## Site Navigation
