# Manga/Volume 9

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%209](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%209)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_9?action=edit).

## Manga Volume 9

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041129371

### ISBN EN

ISBN 978-1975372217

### Release Date

October 25, 2022 JP

March 19, 2024 EN

## Volume Information

### Pages

144

### Chapters

4

Publication Order

| Previous | Next |
| --- | --- |
| Volume 8 | Volume 10 |

This is the ninth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

A troubled wind is blowing—Mitsugoshi’s new innovations have put them in the sights of entrenched business interests, and the filthy quagmire of shady underworld schemes is escalating to all-out economic warfare! Naturally, there’s no way Cid would ignore something that cool-sounding! If it looks like the girls are getting in over their heads, he’ll just have to step in and betray them to save the day—not as mild-mannered Cid or the grim and mysterious Shadow, but as Super Elite Agent John Smith, he who destroys all and rebuilds it anew…![[1]](#cite_note-1)

「私の名はジョン・スミス。全てを破壊し、再生する者」設定、始めます。

異世界に転生し、あらゆる物事に陰から介入し実力を示す「陰の実力者」設定をエンジョイしているシド。
王都の市場を二分する勢力であるミツゴシ商会と大商会連合の対立が深まる中、
シドは「スーパーエリートエージェント」ジョン・スミスに扮し、泥沼化した市場をまっさらにするべく経済の混乱を巻き起こす。
シャドウガーデンに対する裏切りともとられかねない行動に踏み切ったのは、
「自分の裏切りは全てミツゴシ商会を救うためだった……！」というカッコいいムーブをしたいから――！

いつも通りの勘違いも、いつも通りに炸裂する異世界異聞奇譚、知略の第9巻!!！[[2]](#cite_note-2)

## Summary

### Great Trade Alliance Conflict

After the Red Moon Incident, [Yukime](Yukime.md "Yukime") invited Shadow to sit with her for discussion. In her office, she asked for Shadow's help in a secret war between Mitsugoshi Company and their economic rival, the Great Trade Alliance, and seeks to destabilize and usurp their influences to monopolize the market. Internally, Cid was stunned to learn of the trade war, but with this new development he plotted to help Yukime and establish a new corporation under his direct control. He also sought to fulfill his fantasy of being a "traitor" for the trope of "doing it to save Mitsugoshi." Shadow agreed and continued helping Yukime as "John Smith," donning a suit and mask, and using a different combat method to disguise himself. To achieve Yukime's objective, he instructed her on the trust system of Banknotes and collapsing that system will end both companies in one motion.

As counterfeits circulate, [Gettan](Gettan.md "Gettan") of Garter in the Great Trade Alliance had also planned a similar scheme. Seeking to spread counterfeits to collapse the trust system, Gettan planned to move the Cult of Diablos's financial assets to another location and destroy both companies, as Garter has failed to surpass Mitsugoshi and Mitsugoshi has been gaining too much power too quickly for the Cult's liking. However, as he learned counterfeits not his own were flooding the market, and with the assets still in relocation, Gettan concluded Mitsugoshi instigated the same scheme to bring them down, likely with enough capital to survive the collapse.

As the conflict with the Great Trade Alliance escalated, Alpha and Shadow Garden noticed the increasing circulation of counterfeit banknotes into the economy. As the circulation could consequently ruin both companies if left unrestricted, Alpha dispatched Numbers to locate the source. However, their attempts to locate the source of the forgeries had failed due to the interference of a mysterious guard named John Smith, who defeated the Numbers and sent them back to Alpha with a warning of avoidance.

Needing a more forceful approach, Alpha dispatched [Delta](Delta.md "Delta"), who instantly discovered John Smith was really her master. But in order to continue his "secret mission," he overruled Alpha and sic Delta upon [Juggernaut](Juggernaut.md "Juggernaut") in his Black Tower, and Cid later gave Beta an encrypted note in Japanese explaining himself, hoping they'd figure it out by the time he was done. After dispatching Delta resulted in her presumed death, Alpha herself confronted the new adversary, only to discover that Shadow was the true culprit. Demanding an explanation, she attempted to subjugate him by force for an answer, only for the leader of the Seven Shadows to ultimately be defeated, spared and left by her master as he knocked her out.

Following the confrontation, Alpha became heavily depressed while the counterfeit situation continued to worsen, as citizens began demanding their gold coins returned in lost faith of bank notes. With Alpha believing that her master had abandoned Shadow Garden, she had consigned herself to his "decision" and was willing to disappear, despite Gamma's protests. Fortunately, upon receiving a decrypted message by [Eta](Eta.md "Eta") previously given by Shadow earlier detailing his motives, and also led them to the location of their storage. Alpha, Beta, Gamma, and Nu were exuberant that Shadow had not betrayed them and even supplied them the funds to resolve Mitsugoshi's financial crisis. With her faith reaffirmed, Alpha then led Shadow Garden to retrieve their master's capital after Delta returned, further proving their master's genius and grace.

Subsequently, Shadow Garden located and collected the coin stash before infiltrating Gettan's residence as the Great Trade Alliance's leader, discovering a letter addressed to his former fiancé, Yukime, the White Monarch of Outlaw City. When "John Smith" found the storeroom empty, he concluded Gettan took the money as he abducted Yukime. Confronting Gettan, "John Smith" overpowered and mortally wounded him despite his use of power ups from the Cult, and Gettan repented for his choices as he directed "John Smith" to have Yukime. With the conflict officially over with, Yukime's back scars were gone after being healed by Shadow's magic, remembering him as the vigilante who saved her from Gettan years earlier.

Later, Alpha approached Yukime and gave her Gettan's letter before revealing Shadow's connection with the Mitsugoshi Company and his plan to reestablish their strength. Alpha revealed Gettan was coerced by the Cult of Diabolos into service, and how Shadow has been systematically deposing them. Following the revelations, the two agreed to an alliance against the Cult of Diabolos and depart together to discuss their plans. Meanwhile, Cid was content with his "failed" plan, as Mitsugoshi survived war with the Great Trade Alliance, who went under as they didn't have the capital to repay the circulated notes. With matters seemingly resolved, Cid planned to head to Oriana Kingdom to check up on Rose Oriana.

## Chapters

- Episode 34
- Episode 35
- Episode 36
- Episode 37

## Characters

:   In order of appearance:

- [Beta](Beta.md "Beta")
- [Nu](Nu.md "Nu")
- [Alpha](Alpha.md "Alpha")
- [Yukime](Yukime.md "Yukime")
- Cid Kagenou
- [Gamma](Gamma.md "Gamma")
- Mr. Kagenou
- [Gettan](Gettan.md "Gettan") (Debut)
- Garter (Debut)
- Leaf One (Debut)
- Leaf Three (Debut)
- Leaf Two (Debut)'
- [Delta](Delta.md "Delta")
- [John](John.md "John") (Mentioned)
- Leaf Four (Debut)
- Po Tato
- Skel Etal
- Alexia Midgar
- [664](664.md "664")
- Rose Oriana
- [665](665.md "665")
- [Juggernaut](Juggernaut.md "Juggernaut")

## References

1. [The Eminence in Shadow, Vol. 9 (manga). YenPress](https://yenpress.com/titles/9781975372217-the-eminence-in-shadow-vol-9-manga)
2. [The Eminence in Shadow (9). Kadokawa](https://www.kadokawa.co.jp/product/322205000504/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • **Volume 9** • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
