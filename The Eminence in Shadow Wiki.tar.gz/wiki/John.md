# John

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/John](https://the-eminence-in-shadow.fandom.com/wiki/John)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/John?action=edit).

## John

### Japanese

ジョン

### Romaji

Jon

## Characteristics

### Race

Golden Retriever (Dog)

### Age

Unknown

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Black

### Birthday

Unknown

## Personal Information

### Status

Unknown

### Relatives

Minoru Kageno (Owner)

## Professional Information

### Occupation

Pet

## Debut

### Web Novel

Chapter 118 (Alluded)

### Light Novel

Volume 3 (Alluded)
Volume 4

### Manga

Chapter 35

### Anime

Episode 24 (Mentioned)

John (ジョン, Jon[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a Golden Retriever owned by Minoru Kageno, Cid Kagenou's previous life on [Earth](Earth.md "Earth").

## Appearance

John was a normal Golden Retriever with a golden coat.

## Chronology

Before reincarnating, John was adopted by the Kageno family. And later John had moved with Minoru's parents and would reside in America during their job relocation.[[1]](#cite_note-1)

## Relationships

### Owner

### Minoru Kageno

John was Cid's pet dog in his previous life. But later at some point John later moved out of Japan and had moved to America due to Minoru's parents relocating due to their jobs. After reincarnating, Delta tends to remind her of his pet dog from his past life.

## Trivia

- The name John means "God is gracious" in Hebrew origins.
- John's name in the [manga](Manga.md "Manga"), Requiem (クイエム, Rekuiemu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) which means "rest or repose" in Latin.
  - John's manga name "Requiem" was used in religious or musical context, referring to a mass for the dead in the Roman Catholic Church.

## References

1. Volume 4 Lurking in the Darkness in Fantastical Japan!
