# Light Novel/Volume 3

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%203](https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%203)

## Light Novel Volume 3

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Touzai

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4047357112

### ISBN EN

ISBN 978-1975315771

### Release Date

July 26, 2019 JP
April 27, 2021 EN

## Volume Information

### Pages

384 JP
224 EN

### Chapters

9

## Adaptations

### Manga

Volume 7, Chapter 27 - Volume 10, Chapter 40

### Anime

Episode 21 - Episode 27

Publication Order

| Previous | Next |
| --- | --- |
| Volume 2 | Volume 4 |

This is the third volume of the light novel series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

THE RED MOON HANGS LOW IN THE NIGHT—AN OMEN OF WHAT’S TO COME

Deep within the Lawless City lies the Blood Queen, a Progenitor Vampire, slumbering in her coffin for many moons. An expert at landing himself in trouble, Cid should know better than to go after her…but he’s dying to get a piece of the action. It’s time he shed his daytime persona to take on the role of Shadow! It seems, however, that he’s not the only one with this idea. Soon enough, he finds the three rulers of the Lawless City—Juggernaut the Tyrant, Yukime the Spirit Fox, and Crimson the vampire—are all on his tail. To complicate things even further, the Shadow Garden descends on the scene as the hour of the Blood Queen’s awakening looms closer and closer…[[1]](#cite_note-1)

累計15万部突破!!　大人気・勘違いシリアスコメディ!!

クレアに誘われ『無法都市』へと訪れたシド。
そこに眠る始祖の吸血鬼『血の女王』の討伐依頼に参加することになった彼の眼前に現れたのは、『最古のヴァンパイアハンター』を名乗る謎めいた美少女・メアリーだった。

『無法都市』の三大勢力、『暴君』ジャガノート、『妖狐』ユキメ、『吸血鬼』クリムゾンに加え、
『始祖の血』と『悪魔憑き』の繋がりを探る『シャドウガーデン』までもが乱入し、
混迷を極める戦場に今、『伝説の始祖』の覚醒の刻が迫る……！

とまあ、とにかくガチでビッグな『陰の実力者』的イベントが大発生!!!!!!![[2]](#cite_note-2)

## Summary

### Red Moon Incident

The Red Moon of legend is rising. The followers of the Queen of Blood from the Lawless City are wreaking havoc in nearby towns, who ask for help from the Knight Order. Claire joins the group dispatched to subdue the Blood Queen, taking Cid with her. While in the Lawless City, Claire loses contact with Cid after ghouls cause a commotion. She joins with [Mary](Mary.md "Mary") to storm the Crimson Tower with suspicion that Cid has been abducted to be a sacrifice to revive the Blood Queen. They clash with Juggernaut on the way to the top of the tower, but Shadow comes to their rescue. Upon reaching the top they find the Blood Queen Elisabeth resuscitated. She attacks Claire but before she finishes her off Beta, with her subordinates, rushes to the rescue. Yukime and Juggernaut also join in the fight. They hold Elisabeth off briefly, until Aurora joins the battle by possessing Claire to buy time until Shadow arrives. As Shadow arrives, he unleashes his "Atomic Recovery" move, which heals everyone that was injured during the fight and also helps Elisabeth control the effects of the Red Moon.

### Major Corporate Alliance Conflict

Mitsugoshi Ltd, an arm and front of Shadow Garden, has expanded their business with such rapid pace that they've now caught the attention of the Major Corporate Alliance (MCA), an alliance made up of legacy merchants. Following the introduction of bills, the MCA copies the idea from Mitsugoshi. The concept of credit is new to the world's markets, and the grasp of its construct poorly understood. Furthermore, in contrast to Mitsugoshi, the bills of the MCA are easier to counterfeit. Therefore, Shadow (whose plan is to bring down Mitsugoshi in an attempt to lecture the Seven Shadows in not provoking legacy merchants) is in cahoots with the Spirit Fox Yukime of the Lawless City to introduce fake bills and set off a credit crisis, resulting in a bank run and cripple both parties. This had, as we learn later, been the plan of the Cult of Diablos as well; to bring down Mitsugoshi even at the cost of the MCA. Though, they'd plan to execute their plan when their capital in the MCA had been safely withdrawn.

The sequence of events plays out to Mitsugoshi coming out on top by managing to build up enough collateral (thanks to misinterpreting Shadows actions and taking the wealth, he acquired during the debacle which he'd planned on using to comfortably retire) when customers come rushing for withdrawals of coins when they see the MCA faltering. The customers stop withdrawing when they see that their money is safe with Mitsugoshi.

## Chapters

Note: The chapter count does not include the Appendix, which contains character profiles and 'The Chronicles of Master Shadow Complete Version: Volume 3.'

- Prologue: Heading to the Lawless City over Fall Break!
- Chapter 1: Lawless City Bandit Hunting!
- Chapter 2: Storming the Crimson Tower!
- Chapter 3: Pursuing the Blood Queen!
- Auxiliary Chapter: Field Notes on a Little Brother—by Young Claire!
- Chapter 4: I'll Destroy It All and Start from Scratch!
- Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
- Chapter 6: Circulating Counterfeit Cash!
- Epilogue: The One to Destroy It All and Start from Scratch—with Fakes Bills!
- Appendix

## Characters

:   In order of appearance:

- Cid Kagenou
- Claire Kagenou
- [Beta](Beta.md "Beta")
- Perv Asshat (Mentioned)
- [Quinton](Quinton.md "Quinton")
- Goldy Gilded
- White Demon (Debut)
- [Mary](Mary.md "Mary") (Debut)
- [Marie](Marie.md "Marie") (Debut)
- Graine (Debut)
- [Claudia](Claudia.md "Claudia") (Debut)
- [Crimson](Crimson.md "Crimson") (Debut)
- [Juggernaut](Juggernaut.md "Juggernaut") (Debut)
- [Yukime](Yukime.md "Yukime") (Debut)
- Rose Oriana (No. 666)
- [Lambda](Lambda.md "Lambda") (Mentioned)
- [No. 664](664.md "664")
- [No. 665](665.md "665")
- [Elisabeth](Elisabeth.md "Elisabeth") (Debut)
- [Epsilon](Epsilon.md "Epsilon") (Mentioned)
- [Aurora](Aurora.md "Aurora")
- [Eta](Eta.md "Eta") (Mentioned)
- Mr. Kagenou (Mentioned)
- Mrs. Kagenou (Mentioned)
- [Scarface](Scarface.md "Scarface") (Debut)
- [Natsu](Natsu.md "Natsu") (Debut)
- [Kana](Kana.md "Kana") (Debut)
- [Alpha](Alpha.md "Alpha")
- Skel Etal
- Po Tato
- [Delta](Delta.md "Delta")
- Leaf Four (Debut)
- Garter (Debut)
- [Gettan](Gettan.md "Gettan") (Debut)
- [Gamma](Gamma.md "Gamma")
- [Nu](Nu.md "Nu")
- Leaf One (Debut)
- Leaf Two (Debut)
- Leaf Three (Debut)
- Alexia Midgar
- [Shiva](Shiva.md "Shiva") (Mentioned)

## Illustrations

- [English](#)
- [Japanese](#)

Shadow battles against Elisabeth (EN)

Table of Contents (EN)

Title Page (EN)

Vampire hunter Mary

Shadow along with Juggernaut and Yukime

Mary swallows blood from Claire’s mouth

Beta faces Elisabeth

Delta approaches Cid

John Smith appears

Delta’s Profile (EN)

Epsilon’s Profile (EN)

Claire Kagenou’s Profile (EN)

Yukime’s Profile (EN)

Shadow battles against Elisabeth (JP)

Table of Contents (JP)

Title Page (JP)

Vampire hunter Mary

Shadow along with Juggernaut and Yukime

Mary swallows blood from Claire’s mouth

Beta faces Elisabeth

Delta approaches Cid

John Smith appears

Delta’s Profile (JP)

Epsilon’s Profile (JP)

Claire Kagenou’s Profile (JP)

Yukime’s Profile (JP)

## References

1. [YenPress. The Eminence in Shadow, Vol. 3 (light novel) (EN)](https://yenpress.com/9781975315771/the-eminence-in-shadow-vol-3-light-novel/)
2. [Kadokawa. The Eminence in Shadow 03 (JP)](https://www.kadokawa.co.jp/product/321904000577/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • **Volume 3** • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
