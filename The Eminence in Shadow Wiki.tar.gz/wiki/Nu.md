# Nu

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Nu](https://the-eminence-in-shadow.fandom.com/wiki/Nu)

[Chronology](Nu-Chronology.md "Nu/Chronology")

[Relationships](Nu-Relationships.md "Nu/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | Please leave the rest to me. I’ll extract information from him. | ” |
| — Nu to Shadow, Light Novel Volume 01 | | |

## Nu

- Light Novel
- Manga
- Anime
- Game

### Japanese

ニュー

### Romaji

Nyū

### Aliases

No. 13
Nicoletta Marquez
No. 93 (Formerly)
Renu (Forged Identity)

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

18

### Height

Unknown

### Hair Color

Dark Brown

### Eye Color

Dark Brown

### Birthday

August 28

## Personal Information

### Status

Alive

### Relatives

Marco Granger (former fiancée)
Unnamed parents

## Professional Information

### Occupation

- Numbers
- Employee of Mitsugoshi Company (Public Disguise)
- Student at the Midgar Academy for Dark Knights (Formerly)

### Affiliation

Shadow Garden
Mitsugoshi Company
Midgar Academy for Dark Knights (Formerly)

## Debut

### Web Novel

Chapter 23

### Light Novel

Volume 1

### Manga

Chapter 7

### Anime

Episode 6

### Game

Episode 6

## Portrayal

### Japanese

[Maaya Uchida](https://en.wikipedia.org/wiki/Maaya_Uchida "wp:Maaya Uchida")

### English

[Cat Thomas](https://en.wikipedia.org/wiki/Cat_Thomas "wp:Cat Thomas")

### French

Mathilde Riey (Season 1)
Jessie Lambotte (Season 2)

### Italian

[Jolanda Granato](https://en.wikipedia.org/wiki/it:Jolanda_Granato "wp:it:Jolanda Granato")

### German

Francis Dichmann

Nu (ニュー, Nyū[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Νυ), formerly known as Nicoletta Marquez (ニコレッタ・マルケス, Nikoretta Marukesu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a member of Shadow Garden, designated as thirteenth of the Numbers. Initially possessing the code name No. 93, she quickly rose through the ranks due to her strength and loyalty. Outside of specifically directed tasks, she acts as [Gamma](Gamma.md "Gamma")'s personal assistant and bodyguard.[[1]](#cite_note-V1C4-1)[[2]](#cite_note-V3C5-2)

## Appearance

Nu is young woman with dark brown hair and matching eyes.[[1]](#cite_note-V1C4-1) Although called a beauty by others, she has a bland face that can easily be altered through makeup.[[3]](#cite_note-V1C5-3) Her hair is parted to give her face full view, her long hair ending roughly around her waistline, with two locks of hair partitioned beside her cheeks ending at chest length and a decorative choker around her throat.

When working under the Mitsugoshi Company, her attire is professional, as to be expected of a woman in a commercial workforce. She wears a collared V-neck, deep blue mini-one piece atop a white dress, stockings with high heels.

When operating as a Shadow Garden Numbers, she wears the standard Slime Bodysuit with golden decorations and adornments to denote high rank. Her torso carries the standard unitard center connecting to the top with a jacket shouldering, with parallel gold trims descending the center of her torso from her breasts to her pelvis. Her sleeves have gold decoration circling under her deltoid, with violet gem coloring, with a thin gold trimming on the back that forms a T on the upper back. She wears matching cesti with gold accents, a small harness under her breasts with golden clasps that connect to the back of her attire, and her belt is a suit standard with gold hip guards and violet centers. She has symmetrical detailing of three belts across both her thighs, and boots with gold trims along the joints and gold decoration at the pull loop just before the collar, and golden leg guards forward of each of her boots.

While disguised as a Student of Midgar Academy for Dark Knights, Nu wears the Midgar Academy uniform. She also wears a pair of frameless rimmed circular glasses and has her hair tied up in a bun. She also wears black tights in addition with the uniform.[ANIME ONLY]

## Personality

|  |  |  |
| --- | --- | --- |
| “ | I’m not as kind as Master Shadow... Don’t think I’ll let you die in peace. | ” |
| — Nu, Light Novel Volume 01 | | |

Nu is a dutiful, hardworking young lady. Beneath the smile she offers to some, lies a brutal nature. She can be ruthless to non-Shadow Garden members, especially those who slighted her in the past or her master, Shadow.[[1]](#cite_note-V1C4-1)

In her old life, Nu innocently followed her noble family's orders and took advantage of their affluence. Despite the restrictive nature of her childhood, she was content with her situation and happy. Even in the present day, she holds some nostalgia for her past privilege and ignorance of the darker word.[[3]](#cite_note-V1C5-3)

## Powers & Abilities

Despite having just joined Shadow Garden, Nu quickly rose through the ranks to become one of the Numbers, with even [Alpha](Alpha.md "Alpha") validating her skills. She has shown to be athletic, intelligent, and professional, making her the perfect fit to serve as [Gamma](Gamma.md "Gamma")'s bodyguard.[CITATION NEEDED]

#### Adept Combatant

Despite not having the immense strength and mana reserves her superior has, Nu proved to be an excellent fighter as she disarms a man without moving from her stance at least in battle. While Nu doesn't match Gamma's intellect when acting as her assistant, she is the better fighter when it comes to being her bodyguard as she was assigned to handle all of Gamma's fights due to Gamma's extreme clumsiness in coordination and technique of harnessing such power.[CITATION NEEDED]

#### Master of Disguise

In addition to her combat skills, Nu is also skilled at disguise. But unlike most members of Shadow Garden, this is her greatest skill as she is an expert in disguising her figure to avoid detection and infiltrate enemy bases. When she meets Cid and accompanying him in the Academy, Nu dressed herself in an academy uniform with an inconspicuous presentation, blending as a background character and she is able to mask her presence during missions. Cid only recognizes her because he remembers her voice.[[3]](#cite_note-V1C5-3)

#### Swordsmanship

As a Shadow Garden agent, Nu is trained in their advanced and unique swordplay. When she joined her sisters in repelling the terrorists, she used to swordplay to slay numerous attackers.

However, unlike other members of shadow garden, her swordsmanship is meant to wound rather than kill. As she was born in a family that specializes in interrogation, she learned a sword style that specializes in breaking their opponent rather than killing them, as killing them would leave them unable to be interrogated. This has left her sword skills to be somewhat lacking compared to the likes of the rest of the numbers of Shadow Garden.[CITATION NEEDED]

### Standard Equipment:

- Slime Bodysuit:
- Slime Weapons:

### Magic

### Interrogation Specialist

Nu is also capable of being an interrogator who uses several methods of torture to crush her victims and force them to reveal their secrets, which shown when she will use any means to get information out of the Cult of Diablos members.[CITATION NEEDED]

#### Makeup Slime

By taking the [Slimes](Slime.md "Slime") normally used to create the bodysuits, they can instead be used in specialized masks to disguise someone as another person. Nu applied this to Cid by helping him to be disguised as "Mundane Mann" for entering the Bushin Festival tournament, without fear of being exposed to his true identity as Shadow.

## Trivia

- Nu's exact age presents as inconsistent across mediums. In the first volume of the light novel, Nu stated that she would have been in her second year at the academy if not for being [possessed](Possession.md "Possession"), but her Master of Garden character screen lists her age as 18.[[3]](#cite_note-V1C5-3)[[4]](#cite_note-4)
- Within the game, it is revealed that Nu was the first possessed human to join Shadow Garden.[CITATION NEEDED]

## References

1. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
2. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
3. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
4. Master of Garden Nu Character Screen

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • **Nu** • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
