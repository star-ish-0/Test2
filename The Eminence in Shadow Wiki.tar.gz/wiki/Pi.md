# Pi

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Pi](https://the-eminence-in-shadow.fandom.com/wiki/Pi)

Chronology

[Relationships](Pi-Relationships.md "Pi/Relationships")

Image Gallery

## Pi

### Japanese

パイ

### Romaji

Pai

### Aliases

No. 16
No. 81 (Formerly)

## Characteristics

### Race

[Therianthrope](Therianthrope.md "Therianthrope") (Dog Therianthrope)

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

White and black

### Eye Color

Blue

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Numbers

### Affiliation

Shadow Garden

## Debut

### Light Novel

Volume 6

### Manga

Chapter 71.2

### Game

Boughs of Shadow Chapter 4 part 4: "Let's create the strongest pack!"

## Portrayal

### Japanese

Takagaki Ayahi

Pi (パイ, Pai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Πι) is a member of Shadow Garden, and she is one of the Numbers. She is [Delta](Delta.md "Delta")'s subordinate.[[1]](#cite_note-:0-1) Initially possessing the code name No. 81, she was promoted by completing a special test devised by [Lambda](Lambda.md "Lambda"), which was to catch [3](Omega.md "Omega") [other](Chi.md "Chi") [members](Nu.md "Nu") of the Numbers.[[2]](#cite_note-:1-2)

## Appearance

Pi is a [Therianthrope](Therianthrope.md "Therianthrope") that Cid mentions to resemble a Siberian Husky. She is a beauty with blue eyes and white and black ears. As a member of Shadow Garden, she wears a dark slime bodysuit.

## Personality

As a typical [Therianthrope](Therianthrope.md "Therianthrope"), Pi is a muscle brain which believes that 'might makes right'. She is respectful to [Delta](Delta.md "Delta") as she is higher up in the hierarchy and is especially loyal to Shadow, where she lies down in a pose of submission in their first encounter to signify her loyalty to him. She also has a timid nature and inferiority complex as she occassionally goes on a tangent about how others look down and would trample her as if she were an insect. [[1]](#cite_note-:0-1)

She also seems to be quite a friendly person as she is seen playing around with Delta and Shadow, all while cheerfully making plans with her on how to create a massive Harem for Shadow. [[1]](#cite_note-:0-1)

## Powers & Abilities

When she first joined Shadow Garden, Pi consistently excelled in the covert training curriculum where she demonstrated an excellent ability to hide her presence, however her intelligence prevented her from being a useful asset. After being promoted to the Numbers, Delta shared some of her magic power to Pi and trained her to make Pi stronger as Pi's combat abilities were below average. [[2]](#cite_note-:1-2) According to Delta, she is strong and has a better sense of smell than her, which by itself is a mighty accomplishment, considering that Shadow himself admitted that Delta's senses exceed his own.[[1]](#cite_note-:0-1) In addition, Delta has stated that Pi is even dumber than her.[[1]](#cite_note-:0-1)

## Trivia

## References

1. The Eminence in Shadow Light Novel, Volume 6, Chapter 3: Let's Decipher the Crime Announcement!
2. Boughs of Shadow Ch. 9: Hide-And-Seek Battle! | Kagemasu: Seven Shadows Chronicles Story

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • **Pi** • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
