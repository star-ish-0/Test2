# Mithril

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mithril](https://the-eminence-in-shadow.fandom.com/wiki/Mithril)

## Mithril

### Type

Metal

### Effects

High Magic Conductivity

### Source

Mines

Mithril (ミスリル, Misuriru[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a natural ore in the Other World.[[1]](#cite_note-:0-1) The ore is commonly extracted from the terrain through dedicated mithril mines.[GAME ONLY][[2]](#cite_note-2) Once processed, the metal possesses one of the highest magic conductivity at 50%. By comparison, materials like wood and iron have a 10% conductivity. For this reason, mithril weapons are considered a premium product.[[1]](#cite_note-:0-1)[[3]](#cite_note-3) Mithril can likewise function as a base metal for artifacts if combined with appropriate runic scripts.[ANIME ONLY][[4]](#cite_note-4)

Although the metal acts as a foundation for many of the world's most potent weapons, its high magic conductivity is not conducive to durability. Mithril weapons can shatter if sufficient power impacts them.[[5]](#cite_note-5)

Outside of weapons, mythril can used for tools or conductors.[[6]](#cite_note-6)[[7]](#cite_note-7)

## References

1. Volume 1 Prologue: Preparing the Perfect Stage!
2. Seven Shadows Chronicles Part 3: Secret of Sacra, Chapter 4: Influencers Ahoy!, Episode 3: An Aristocratic List
3. Volume 6 Chapter 1: Enter Jack the Ripper!
4. Episode 20
5. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
6. Volume 1, Chapter 6: That Scene Where Terrorists Take Over the School
7. Volume 5 Eta's Research Journal
