# Korrupt White

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Korrupt%20White](https://the-eminence-in-shadow.fandom.com/wiki/Korrupt%20White)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Korrupt_White?action=edit).

## Korrupt White

### Japanese

オショク・ホワイト

### Romaji

Oshoku Howaito

### Aliases

Earl White

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- Earl
- Leader of the Thirteen Nightblades

### Affiliation

Thirteen Nightblades
Cult of Diablos

## Debut

### Light Novel

Volume 6

### Manga

Chapter 71.2

Korrupt White (オショク・ホワイト, Oshoku Howaito[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), also known as Earl White, was a nobleman of the Midgar Kingdom and a leader of the Thirteen Nightblades.

## Appearance

## Personality

## Chronology

### Bloody Midgar Serial Murder Terror

He held an event in the colosseum inside his mansion to which he gathered some assassins from across the world to kill Jack The Ripper. His attempts to kill Jack The Ripper failed and he ended up getting his throat pierced by Jack The Ripper using the queen of spades.[[1]](#cite_note-1)

## Relationships

## Powers & Abilities

## Trivia

## References

1. Light Novel/Volume 6 - Chapter 4

## Site Navigation
