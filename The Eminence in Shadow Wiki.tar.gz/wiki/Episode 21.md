# Episode 21

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2021](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2021)

## The Lawless City

### Kana

無法都市

### Romaji

Muhō Toshi

## Special Title

### English

The Eminence in Shadow wants to take advantage of the legend!

### Kana

陰の実力者は伝説に乗っかりたい！

### Romaji

Kage no Jitsuryoku-sha wa Densetsu ni Nokkaritai!

## Episode Information

### Season

2

### Episode

1 (21)

### Air Date

October 4, 2023 JP & EN

### Adapted From

Volume 3 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

Grayscale dominator

Episode Navigation

| Previous | Next |
| --- | --- |
| Advent of the Demon | The Haven |

The Lawless City (無法都市, Muhō Toshi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the the first episode of the second season, and twenty first episode of [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Cid and his sister Claire venture to the huge slum known as the “Lawless City.” There, Cid gets caught up in the commotion caused by the Red Moon.[[1]](#cite_note-1)

吸血鬼を退治するというクレアに連れ出され、巨大なスラム「無法都市」にやってきたシド。だが早々にクレアとはぐれ、「赤き月」が引き起こした大騒動に巻きこまれる。[[2]](#cite_note-2)G

## Summary

Shadow, six founding partners, and miscellaneous members are attending a Shadow Garden meeting. [Delta](Delta.md "Delta") is the absent Seven Shadow, engaged in feral proclivities. [Beta](Beta.md "Beta") reports to the assembly about ongoing affairs. Shadow’s Bushin Festival intervention has forced the Cult of Diablos’ ancillary sects to temporarily cease Midgardian activity. The [Fenrir](Fenrir.md "Fenrir") sect’s reconstruction was similarly placed on hold, allowing Shadow Garden ease of movement in future Oriana Kingdom operations. [Zeta](Zeta.md "Zeta") and [Eta](Eta.md "Eta") warn against becoming complacent. There is an increase in monetary resources bound for Lawless City, a notorious slum outside the jurisdiction of any kingdom. Shadow warns that the Red Moon shining down is an augury of bloodshed. He tells the gossiping congregation his decision to investigate this matter. Beta begins to furiously add to The Chronicles of Master Shadow about the "revival of the [Blood Queen](Elisabeth.md "Elisabeth").” Gazing at the genuflecting girls, Shadow meditates on their commitment to the act. Their improvisational skills are "worthy of an Academy Award."

Outside of this discussion, two have already ventured into Lawless City. Goldy Gilded and [Quinton](Quinton.md "Quinton"), past competitors from the Bushin Festival. They gaze at the menacing height of The Crimson Tower. It marks the Blood Queen’s domain, sovereign of the vampires. A sudden presence explains Goldy's comment regarding the wide berth residents give the entrance. The newcomer introduces himself as the White Devil, a ruthless criminal with a considerable bounty. He has now been reduced to one arm and acts as Elisabeth's loyal “watchdog”. The loser bracket pair recognizes the name and prepares for battle.

The next morning, Claire makes her way to the Dark Knight Association, dragging her brother Cid along. Despite winning on a technicality, her victory at the Bushin Festival has increased her fame and responsibilities. She has been assigned to hunt down vampires in Lawless City. Cid recapitulates past events up to the present moment, casually glancing around. Claire does not want her brother to become a fainéant and believes his participation will secure him a position in Midgar’s Knight Order.  A merchant stops the siblings, claiming to have new pets in stock. Cid is reunited with Goldy and Quinton but only expresses vague familiarity. They were defeated by the White Devil and sold to a slave trader. Claire complains that his prices are too steep for damaged merchandise. She stops haggling and maintains one pet is good enough, placing her hand on the black-haired boy. Cid manages to break free from his sister’s watchful gaze. He spends time meandering the streets and allowing himself to become a victim of petty larceny; returning the favor shortly afterward. Cid meditates on the “dog-eat-dog” city as a group of men drubs a [ghoul](Ghouls.md "Ghouls") in an alley. An indifferent red moon abruptly sends a magical wave that resonates across Lawless City.

The beaten ghoul is invigorated and attacks the past oppressors with new strength. Humans bitten by this ghoul transform into one, yielding a cascading effect. Cid contemplates possible shadow broker scenarios as the ghouls draw near. Before Cid can make any decisions, a mysterious red-haired girl wearing a cocked hat takes out the ghoul. She introduces herself as [Mary, the Ancient Vampire Hunter](Mary.md "Mary"). Mary tells him to flee and murmurs ominous statements about being “...out of time” and a "...frenzy". All that remains after her departure is a bloody pile of corpses and a single tear running down the face of Cid Kagenou. A concerned sister subsequently arrives at a hotel room to find it vacant. Claire told her impetuous brother to wait at the inn, but he failed to listen. Across the hall, a half-naked man runs out of his room screaming. A ghoul wearing a negligee jumps out of the room. Claire uses this opportunity to vent her anger, crushing its head. She asks the staggering man if he saw “...a boy with black hair and black eyes?” The man says no, he has not seen anyone matching that description.

Two students from the Midgar Academy, Skel and Po, likewise have ventured into Lawless City. The city is famous for its thriving redlight district, and the lascivious teenagers hope to lose their virginities. Marie, an employee of the red light district, encounters another ghoul. Shadow’s grand appearance narrowly saves Marie's life. He recites Mary’s lines verbatim to the shocked woman and disappears to repeat his performance to others. A co-worker, hearing the commotion, arrives in Marie’s room. Marie immediately takes advantage of the second chance given her and packs to leave Lawless City. She disregards a co-worker's warning about contract violations and Shadow’s reputation. Marie will repay Shadow’s kindness by traveling down the life path he has laid for her.

Claire’s sole attention is not on the ghouls' attack on visitors and residents but on the mangled body of a boy. Claire’s sniffles are interrupted by the appearance of Mary. The ancient vampire hunter points out that the corpse has neither black eyes nor black hair. Mary says she met two boys that match her description. One was smiling at the ghoul rampage, the other was kidnapped by vampires. A blood sacrifice is needed to awaken Elisabeth, the Blood Queen, from her long slumber. Disregarding the former boy, Claire allies with Mary to storm the tower.

Vigorous exercise does befall Po and Shel but in the form of sprinting from ghouls as the destruction increases. Ghouls are running rampant across the city, and The Dark Knight Association is soon overwhelmed by the mob. The majority of members have fled the scene. Only the [director](Claudia.md "Claudia") and a single subordinate remain at the outpost. Their deaths seem assured, but the ghouls fall under Shadow's sword. On top of the Crimson Tower, an attendant informs [Lord Crimson](Crimson.md "Crimson") that preparations are nearly complete. Dominating the city has proven successful, but some areas have withstood the onslaught. Crimson surmises two people are behind it: The first is [Juggernaut, the Tyrant](Juggernaut.md "Juggernaut"), ruler of The Black Tower. The second is [Yukime, the Spirit Fox](Yukime.md "Yukime"), ruler of The White Tower. He disregards their efforts, claiming the revival of their queen will kill them regardless of any struggle. The subordinate agrees but adds that one more person is killing ghouls.

The two rulers Crimson mentioned are subsequently engaged in fierce combat. When no ghouls remain, Yukime and Juggernaut fight each other. A mysterious figure wearing black appears between the two combatants. The sudden appearance makes the pair stop and ask for his name. He says:

"My name is Shadow; he who lurks in shadows to hunt shadows."

## Characters

- [Delta](Delta.md "Delta")
- Cid Kagenou/Shadow
- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Gamma](Gamma.md "Gamma")
- [Epsilon](Epsilon.md "Epsilon")
- [Zeta](Zeta.md "Zeta")
- [Eta](Eta.md "Eta")
- [Omega](Omega.md "Omega")
- [Chi](Chi.md "Chi")
- [Lambda](Lambda.md "Lambda")
- [Nu](Nu.md "Nu")
- [Quinton](Quinton.md "Quinton")
- Goldy Gilded
- White Demon (Debut)
- Claire Kagenou
- Mrs. Kagenou (Flashback)
- Alexia Midgar (Flashback)
- Zenon Griffey (Flashback)
- Sherry Barnett (Flashback)
- Skel Etal
- Po Tato
- Rose Oriana (No.666)
- Lutheran Barnett (Flashback)
- [Rex](Rex.md "Rex") (Flashback)
- [Aurora](Aurora.md "Aurora") (Flashback)
- Iris Midgar (Flashback)
- [Beatrix](Beatrix.md "Beatrix") (Flashback)
- Imatry Nottaloos (Flashback)
- Mr. Kagenou (Flashback)
- [Mary](Mary.md "Mary") (Debut)
- [Marie](Marie.md "Marie") (Debut)
- [Yukime](Yukime.md "Yukime") (Debut)
- [Elisabeth](Elisabeth.md "Elisabeth") (Mentioned)
- [Juggernaut](Juggernaut.md "Juggernaut") (Debut)
- [Claudia](Claudia.md "Claudia") (Debut)
- [Crimson](Crimson.md "Crimson") (Debut)
- [664](664.md "664")
- [665](665.md "665")

## Promotional Videos

「陰の実力者になりたくて！ 2nd season」 第1話予告≪ノーマルVer.≫「無法都市」

『陰の実力者になりたくて！ 2nd season』 第1話予告≪スペシャルVer.≫「陰の実力者は伝説に乗っかりたい！」

## Trivia

- Skel and Po's appearance is not mentioned in any currently released light novels.
- The Japanese name for The Crimson Tower is 紅 (Kurenai). It can be translated to red, crimson, or scarlet. The official English light novel translation (translated by Hiroshi Thrasher) and anime (translated by [Sentai Filmworks](https://www.sentaifilmworks.com/)) both chose crimson.

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e021>
2. <https://shadow-garden.jp/story/#story1>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| **Episode 1** • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
