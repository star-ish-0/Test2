# Ghouls

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Ghouls](https://the-eminence-in-shadow.fandom.com/wiki/Ghouls)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Ghouls (グール, Gūru[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are a race in the world of The Eminence in Shadow that are zombie-like vampires' familiars created by vampires.

Ghouls are beings that were originally [humans](Human.md "Human") who were then turned into [Vampire](Vampire.md "Vampire") servants.[[1]](#cite_note-V3CP-1)

## Appearance

Ghouls have black eyes with red pupils, these eyes turn bright blood red completely, when Being under the effects of the Red Moon, they have pale, lifeless skin, and sharp teeth visible through their slightly open mouths.

They have partially strong musculature, which becomes significantly visible and somewhat robust, for those who see them, and these physical capabilities become even tougher, when the ghouls are under the effects of the red moon, causing them to begin to parts of their facial and corporeal characteristics, causing it to sometimes not be possible to distinguish whether they were men or women.

## General Information

Ghouls' movements closely resemble those of a beast rather than a human, displaying a remarkable vitality. However, it appears that Ghouls have completely lost their sense of reason.

They're classified as more powerful creatures than zombies, yet far from vampires which serve as lesser pawns.

## Power & Abilities

They are under the control of the vampire who bites them. They eat human flesh and are intelligent enough to their instinct. Due to their undead state, ghouls possess low-level invulnerability to conventional injury; allowing them to survive multiple slash wounds and even being dismembered. It is not rare to see a vampire amass a small army of ghouls for offense and defense. Despite their relative skill, compared to the lumbering undead of other lore, they are still quite slow and lack the intellect to execute any manner of defensive maneuvers, making them vulnerable to specialized weaponry. Once they have been tainted, ghouls cannot be cured, and can only be saved by ending their suffering.

In any way, they're not smart; in fact, they can be considered brainless. They're just moving corpses, however, with far superior durability and strength than that of even the strongest humans. Despite this fact, they're slow and that's what makes them so easy yet sometimes, so hard to kill; because of the fact that creatures like this are kept secretive, so normal humans meeting them would easily freak out. That is one of the advantages ghouls get, despite being easily killed by experts and such. Ghouls are also considered "failures who've unsuccessfully attempted to become full-fledged vampires", but they're still monsters to be feared.

Plus, when the Red Moon appears, the number of Ghouls will increase with their strength increasing when illuminated by moonlight.

## Trivia

## References

1. Volume 3 Prologue: Heading to the Lawless City over Fall Break!

## Site Navigation
