# Christina Hope/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Christina%20Hope/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Christina%20Hope/Relationships)

Main

Chronology

Image Gallery

## Family

### Unnamed Father

### Suzuki Hope

Although Suzuki was her distant relative, the relationship between the two was one sided with her being condescending towards him for being the son of a branch family. When the Academy was targeted, she began to develop feelings towards him as she wanted him to come to the main branch.[[1]](#cite_note-:0-1) However she began to doubt her feelings when he revealed himself as Shadow and that the real Suzuki has passed.[[2]](#cite_note-:2-2)

## Midgar Academy for Dark Knights

### Alexia Midgar

Princess of Midgar and schoolmate, Alexia was a lead investigator and authority figure who Christina respected when she tried to stop Suzuki from suggesting the plan to investigate the premise. Due to her status as princess, Christina was confident in her testifying against Eliza when Alexia asked if she was prepared in facing the possible consequences of provoking the high noble.

### Claire Kagenou

Claire and Christina are schoolmates, yet never really interacted with each other. Christina knew of Claire and recognized her brother after Claire mysteriously dropped into her class exams one day.

### [Nina](Nina.md "Nina")

Nina is a senior student Christina respected, despite the former's poor academic performance and extra casual presentation. When the two in the auditorium alongside the others, Nina was one of the students who briefed the investigation team of what has happen.[[1]](#cite_note-:0-1) However, she and multiple others are unaware of her true affiliation when she knocked the remaining members of the investigation out.

### [Isaac](Isaac.md "Isaac")

Christina held a level of respect towards Isaac however during the Ghost incident, she grew annoyed with his inability to help in the situation and was disgusted at him for accusing her relative, Suzuki for being suspicious. This made her unsurprised once he reveals himself to be the mole of the Cult of Diablos.[[2]](#cite_note-:2-2)

### Eliza Despoht

Eliza was the opportunistic and prideful the student council vice president. Eliza caused friction with Christina during the Academy disappearances, and added to their animosity by having her family conspire with Thirteen Nightblades to incriminate Christina for deaths and disappearances.

When the conspiracy was made known, Eliza met her demise at the hands the mysterious and bloody assassin, Jack The Ripper.[[3]](#cite_note-:3-3)

### Cid Kagenou / Shadow ("Suzuki Hope" / Jack The Ripper)

She is unaware that Shadow is her classmate, Cid Kagenou. During the new semester exam her class took, the two had never talked nor did she recognize him.[[4]](#cite_note-:1-4) While Cid was impersonating her relative Suzuki and later his reveal as Shadow, Christina would wonder about the path he must take. A month after the incident, Christina would later remember him as Claire's younger brother, recalling Claire's mysterious sudden arrival and give him sanctuary at her home due to him giving her notes from Jack the Ripper.

She initially saw Shadow and Shadow Garden as a terrorist organization like every other students until he saved her life as "Suzuki Hope". This causes her to admire Shadow as a hero and start her own research as Shadow Garden, with her even fantasizing of Shadow killing the Thirteen Nightblades. After Shadow reveals himself to be Jack the Ripper after killing the Thirteen Nightblades and lets the clown costume be destroyed by Millia, who he saved, her idolization of Shadow grew further causing her to conclude that his way is truly the just one.

### [Kanade](Kanade.md "Kanade")

## References

1. Volume 5 Chapter 5: Terrorists Attack the School…Again!!
2. Volume 5 Epilogue: I’d Let the Whole World Burn, If That’s What It Took!
3. Volume 6
4. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
