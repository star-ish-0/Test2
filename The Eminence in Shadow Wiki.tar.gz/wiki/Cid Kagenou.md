# Cid Kagenou

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Cid%20Kagenou](https://the-eminence-in-shadow.fandom.com/wiki/Cid%20Kagenou)

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | The pinnacle doesn’t exist... Thinking they’ve reached the pinnacle is when people stop climbing. | ” |
| — Shadow, Light Novel Volume 05 | | |

## Cid Kagenou

- Cid
- Shadow
- Minoru
- Mundane Mann
- John Smith
- Jack the Ripper

### Japanese

シド・カゲノー

### Romaji

Shido Kagenō

### Aliases

Minoru Kageno
Shadow
Mundane Mann
Fancy Bandit Slayer
The Demon, Shadow
John Smith
Fancy Hoodlum Slayer
Ski Mask Berserker
The Black Knight
Jack The Ripper

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

17 (past life)
1 [[1]](#cite_note-V3CA-1)
6[[1]](#cite_note-V3CA-1)
 10-13[[2]](#cite_note-V1CP-2)
15[[3]](#cite_note-V1C1-3)
16[[4]](#cite_note-V5-4)

### Height

Unknown

### Hair Color

Black

### Eye Color

Black
Red (Shadow/Overdrive)[[1]](#cite_note-V3CA-1)

### Birthday

January 10[[5]](#cite_note-5)

## Personal Information

### Status

Alive (reincarnated)

### Relatives

Pre-Reincarnation

- Unnamed Previous Father
- Unnamed Previous Mother
- [John](John.md "John")  (dog)

Post-Reincarnation

- Mr. Kagenou (Father)
- Mrs. Kagenou (Mother)
- Claire Kagenou (Older Sister)

## Professional Information

### Occupation

- Leader of Shadow Garden
- Student of Midgar Academy for Dark Knights
- Student of Sakurazaka High School (Former)

### Affiliation

Shadow Garden
Midgar Academy for Dark Knights

## Debut

### Web Novel

Chapter 1

### Light Novel

Volume 1

### Manga

Chapter 1

### Anime

Episode 1

### Game

Chapter 1 - Episode 1

## Portrayal

### Japanese

[Seiichirō Yamashita](https://osawa-inc.co.jp/men/yamashitaseiichiro/) (Anime)
[Hikaru Midorikawa](https://hikaru23.hatenablog.com/) (Mundane Mann)
[Jun Fukuyama](https://ameblo.jp/junfukuyama/) (John Smith)
[kumagaihk Kentarō Kumagai](https://x.com/k) (Commercial)

### English

[Adam Gibbs](https://www.iamadamgibbs.com/)
[Joe Daniels](https://x.com/JoeSDaniels) (Mundane Mann)

### French

[Alan Aubert-Carlin](https://www.alanaubertcarlin.fr/)

### Italian

Ezio Vivolo

### German

[Benjamin Mereis](https://blk.actor/)

Cid Kagenou (シド・カゲノー, Shido Kagenō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), formerly Minoru Kageno (影野実, Kageno Minoru[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), is the titular antihero and protagonist of The Eminence in Shadow series. After a premature death, he reincarnates into a world of swords and sorcery. Choosing Shadow as his nom de guerre, he leads the secret organization Shadow Garden. He lives out unfulfilled Chunibyou (厨二病, Chūnibyō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) fantasies of being an enigmatic shadow broker, unaware that his creative scenarios are close to the truth.[[2]](#cite_note-V1CP-2)

## Appearance

Cid is a slim young man with an athletic frame, short black hair, and black eyes. His facial features are average, without impressionable qualities. A countenance that is forgettable as it is generic. His new body has similar characteristics to his previous appearance as Minoru Kageno.[[6]](#cite_note-6) As a student, Cid wears the compulsory male uniform of Midgar Academy. The standard navy-blue blazer with gold shoulder straps and a white dress shirt. A casual appearance is facilitated by keeping the black apron necktie loose. White loafers and navy-blue trousers round out the bottom.[[7]](#cite_note-7)

The costume Cid selected for Shadow is an ebony slime bodysuit, styled like a popped collar overcoat. Gold and purple trim adorn a dark jacket, shirt, pants, and high boots. A long hood casts a shadow to hide the upper half of Cid’s face. The only discernible facial features are his mouth and the glow of red eyes.[[3]](#cite_note-V1C1-3)[[8]](#cite_note-V1C3-8)

### Other Personas

Throughout the series, Cid has had many aliases and just as many outfits. Shadow Garden's technique to create indistinguishable facial masks, utilizing various cosmetics and a clay-like slime base, has proven monumental to his master of disguise routines.[[9]](#cite_note-V2C4-9)[[10]](#cite_note-:0-10)

- Mundane Mann (ジミナ・セーネン, Jimina Sēnen[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")): Previously a fallen aristocrat from the Altena Empire, Cid borrows his face to enter the Bushin Festival. The mask presents a pale face with baggy eyes, a drooping mouth, and unkempt facial hair. A hunched back and cheap equipment assist in Cid’s desire to look “weak”.[[9]](#cite_note-V2C4-9)

- John Smith (ジョン・スミス, Jon Sumisu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")): For Cid’s second dalliance in Lawless City, he adorns a double-breasted black suit over a pin-striped dress shirt. A black skinny tie is kept tight around his neck. The final items are straight-tipped shoes and fingerless gloves. Anonymity is maintained through the use of a dominion mask. The whole outfit has an “FBI agent” aesthetic.[[11]](#cite_note-V3C4-11)

- Jack the Ripper (ジャック・ザ・リッパー, Jakku Za Rippā[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")): To eliminate the corrupt nobles of the Thirteen Night Swords, Cid became an infamous serial killer. Donning a full-body clown suit and leaving playing cards behind, his enigmatic ruthlessness baffled the authorities.[[12]](#cite_note-V6C1-12) In a few days, Cid succeeded in destroying the Thirteen Night Swords.[[13]](#cite_note-13)

### Past Life

In his previous life, Minoru Kageno possessed a tall and toned physique due to his constant training. His face was plain, having short black hair and black eyes, resembling his post-reincarnated life as Cid Kagenou. As a student of Sakurazaka High, he wore a standard white school coat, a light blue shirt, blue pants, and a blue tie.[[14]](#cite_note-:1-14) On [Earth](Earth.md "Earth"), he operated as a vigilante, using the alias Fancy Hoodlum Slayer. The outfit was all black, and a balaclava (ski mask) covered his face.[[15]](#cite_note-V4CA-15)

## Personality

|  |  |  |
| --- | --- | --- |
| “ | We all go through life amassing things we cherish. We acquire friends and lovers and jobs… and it keeps going from there. But on the other hand, I cut things out of my life. | ” |
| — Cid Kagenō, Light Novel Volume 01 | | |

From early childhood onward, he—in both lives—had an abiding fascination with shadow broker characters. Leaders of cabals and puppet masters who secretly exert enormous power and worldly influence. Cid was and still is obsessed with becoming a genuine shadow broker. Cid’s megalomania has gone past simple juvenile or 'chūnibyō' fantasies, as he vows permanent loyalty to becoming an eminence and refuses to outgrow it.[[2]](#cite_note-V1CP-2) Cid spares no effort or expense in achieving his dream—endlessly training and developing elaborate scenarios or dialogue for his routine. Cid’s materialistic nature has guided many decisions as he continuously searches for more capital to fund his shadow broker operations.[[14]](#cite_note-:1-14) When not focused on Mob or Eminence performances, his general attitude comes off as aloof or apathetic.

To maintain efficiency, Cid separates things in his life into two categories: “Important Stuff” and “Unimportant Stuff.” The latter category imputes no malignity, merely apathy. He dedicates his complete attention to his likes or desires and disregards everything else. The pruning process is continuous, chipping away ever more at his life until the only thing that remains are things he cannot live without.[[16]](#cite_note-V1C2-16) [[17]](#cite_note-V1CF-17)[[18]](#cite_note-18)Cid's extreme modus operandi does not mean the absence of emotion or friends. His laconic behavior and dismissal of others reflect deepening isolation; however, he has shown the capability for compassion on several occasions, offering sympathy for people he perceives as having suffered similar or extreme hardships.[[17]](#cite_note-V1CF-17)[[19]](#cite_note-V3C3-19) If someone praises something precious to him, he will endeavor to express gratitude or give a targeted compliment.[[16]](#cite_note-V1C2-16)[[20]](#cite_note-V2C6-20) Reflecting on his unwavering pursuit, Cid expresses open contempt for those who have abandoned their ambitions.[[17]](#cite_note-V1CF-17)

Cid has described the Seven Shadows as friends and frequently thanks them for playing along with his role-playing.[[21]](#cite_note-V2C7-21)[[3]](#cite_note-V1C1-3) Periodically, Cid can get envious or annoyed at the constant success they have garnered utilizing his otherworldly knowledge but tolerates many of their decisions.[[20]](#cite_note-V2C6-20)[[22]](#cite_note-V2CP-22) His relationships are not without difficulty. A personal philosophy of Cid’s is that relational contretemps resolve themselves over time. Ignoring others becomes an appropriate and valid social strategy with this view. He has received several sharp lessons that maintaining an insouciance approach does not always work, but he considers that not enough time has elapsed in these instances; death will solve it.[[21]](#cite_note-V2C7-21) Cid differs from his lascivious school friends, articulating a lack of interest in relationships or marriage. His one relationship happened by mere happenstance; after concluding the farcical relationship, he rejects an offer to make it serious.[[16]](#cite_note-V1C2-16)[[8]](#cite_note-V1C3-8) Other women have misinterpreted Cid’s actions as romantic gestures when he had no such intention. Associating with the Seven Shadows has inundated him with beautiful individuals, making him apathetic towards attractive women.[[16]](#cite_note-V1C2-16)

Cid has retained the pride of a Warrior, continuing his martial arts and swordsmanship training from his past life. He recognizes power and technique but respects those who understand the intricacies of battles. Brute strength and borrowed power are abhorrent to him.[[21]](#cite_note-V2C7-21) An ambiguous element of Cid’s personality is his feelings towards others. Cid’s behavior and statements towards characters are contradictory. It is open to interpretation if he views people as props, individuals, or some combination of the two. Rhetorical actions strengthen Cid’s mob character persona but disregard feelings for those involved.[[10]](#cite_note-:0-10)[[16]](#cite_note-V1C2-16) Activities like these reinforce the prop view of people, but his rare instances of solicitude support the notion of people as individuals.[[17]](#cite_note-V1CF-17)[[19]](#cite_note-V3C3-19)

### Role-Playing

The theory Cid maintains is that a shadow leader's identity is always the person whom one would least expect. He accomplishes this by masquerading as two independent personas: Background Character Cid and the Mysterious Mastermind Shadow.

Background Cid is a character that blends into the background, hence the name. In this civilian or mob persona, he preserves a below-average grade at the Midgar Academy for Dark Knights and industriously seeks methods to advance his "normie" status. The behaviors can vary from befriending moderate students to further an average presentation or confessing love to a popular girl to receive a rejection. Cid will exuberantly allow himself to be beaten or stabbed if he believes it will display an ordinary existence.[[16]](#cite_note-V1C2-16) Extreme actions, like self-induced cardiac arrest for the sake of dying a pathetic death, are constantly explored and perfected.[[23]](#cite_note-V1C6-23)

Role-playing as Shadow, he is obsessed with appearing cool and mysterious, muttering ominous lines and putting on grandiloquent performances. Shadow is an underworld puppet master—one who controls everything from the darkness and whose power is unfathomable. Cid deepens his voice to offer a sonorous vocal performance. Others have depicted Shadow's voice as an "echo from an abyss", with every utterance possessing layers of meaning.[[20]](#cite_note-V2C6-20) His aesthetic and dialogue choices are determined by whatever fantasies or story clichés he considers cool. Everyone assumes his impromptu acting is genuine, while Cid thinks his friends are obeying the [Yes… and](https://en.wikipedia.org/wiki/Yes_and... "wp:Yes and...") improvisational rule and hire supporting performers or extras.[[8]](#cite_note-V1C3-8) Communication problems complicate these circumstances. The Seven Shadows are vague about their activities, believing their prescient leader is conscious of all Shadow Garden and world circumstances. Cid's ambiguous statements feed into this misunderstanding, allowing the projection of personal interpretations. As a result, he frequently does not understand what is occurring or comes to some erroneous conclusion. Not all performances end with Cid’s presumed denouement, but the finales are satisfactory for him. Success is solely due to Cid's ingenuity, competent subordinates, and luck.

## Powers & Abilities

### Pre-Reincarnation

Minoru Kageno was a practitioner of various swordsmanship and martial arts disciplines (e.g., karate, mixed martial arts, wrestling, grappling, fencing, kendo).[KENDO WEB NOVEL ONLY] [[2]](#cite_note-V1CP-2)[[25]](#cite_note-25) Miscellaneous physical fitness activities kept his body in peak condition, and exercise equipment while idle discouraged muscle atrophy.[ANIME ONLY][[26]](#cite_note-26) Practice started in his childhood and spanned into his teenage years.

In the pursuit of becoming a shadow broker, Kageno sought various Agama and Zen techniques to elevate his mind and body. Abrahamic religions were likewise dabbled in to transcend.[[2]](#cite_note-V1CP-2) Kageno did not exclusively adhere to kata and theory. He was nicknamed Ski Mask Berserker by his local motorcycle gangs for gaining practical combat experience at their expense.[[15]](#cite_note-V4CA-15)

### Post-Reincarnation

Resolved to be a proper shadow broker in his new life, Cid Kagenou began training privately. Practical experience was, once again, gained from local hooligans. Bandits were substituted for the absent motorcyclists. Years of experimentation and practice have yielded superior development compared to his contemporaries. All of Cid's battles have hitherto concluded with overwhelming victories, some against highly decorated combatants.[[27]](#cite_note-V2CF-27) [[28]](#cite_note-V5CE-28)Protractive matches result from an observational strategy, a desire to harangue the target, or an ideal shadow broker aesthetic. These achievements have not made Cid complacent, as he continues to hone his power and skills, determined to become the perfect eminence in the shadow.

Fighting for Cid is like a nuanced "conversation". Words and emotions are conveyed through actions like body language or weapon movements. Combat superiority is achieved through predictive proficiency. Those interposing through force devolve combat into a strength or guessing contest. Cid has articulated his dislike and rejects the reliance on simple, overpowering tactics. If given an ultimatum, he would choose power, but it should not be an excuse to disregard the intricacies of battles.[[29]](#cite_note-V2C1-29)

#### Swordsmanship

When he could move, juvenile Cid began another rigorous training regimen. His past life activities and combat knowledge provided an adequate starting point. The family Cid was born into has a long tradition of training Dark Knights. At age six, his father began teaching him the Bushin Style; regular sparring sessions with his sister Claire became the norm. Traditional adherence and lack of globalization has caused styles to remain unrefined. Superfluous movements are still present in many techniques. In the new Middle Ages World, magic is essential to battle (anime: [Mid-Second Industrial Revolution](https://en.wikipedia.org/wiki/Second_Industrial_Revolution "wp:Second Industrial Revolution")).[CONJECTURE][[31]](#cite_note-31) Magic can supplement strength or speed, but as a consequence, magical combat disregards refinement and many aspects of Maai: the fundamental idea of rhythm, angle, timing, and space.[[2]](#cite_note-V1CP-2)[[32]](#cite_note-:16-32) Incorporating Earth's contemporary methodologies with new tools gives Cid an overwhelming advantage over others in the new world.

The katana is Cid's preferred style of sword, but he has shown familiarity with handling other weapons, conventional and unconventional—manga and anime depict it as a long or broadsword.[[8]](#cite_note-V1C3-8) He has revealed two distinct sword styles. The first style is based on the adherence to fundamentals. Through steadfast practice, techniques are refined until only essential movements remain. Cid uses this style for Shadow and Mob Cid—reducing refinements and dexterous movements to maintain Cid's background character facade.[[8]](#cite_note-V1C3-8) The second style is flamboyant, drawing attention through artistic and beautiful motions.[[21]](#cite_note-V2C7-21) He has further demonstrated the ability to refine personal or mimicked enemy techniques in the heat of battle.[[29]](#cite_note-V2C1-29)[[28]](#cite_note-V5CE-28) Both sword styles take a methodical approach towards adversaries, relying on ripostes or counter-attacks to overwhelm or whittle down an opponent. The precision of parries can be delicate enough to intercept a sword thrust tip to tip.[ANIME ONLY][[33]](#cite_note-33) If a range or area of effect attack is required, intense, empowered sword swings can create swirling waves.[[34]](#cite_note-V3C6-34) Cid has exhibited a mastery of [mushin](https://en.wikipedia.org/wiki/Mushin_(mental_state) "wp:Mushin (mental state)")—removing emotion from one's mind or attacks—combat practices. It offers a fluid defense and a difficult-to-perceive offense.[[2]](#cite_note-V1CP-2)[[32]](#cite_note-:16-32) Feints serve to mislead opponents and assist in dominating the rhythm of battles. Cid has exploited perceptive opponents by utilizing subtle feints to dissuade the approach. This perception can manifest as vivid hallucinations of mutilation and makes discerning reality difficult for those affected.[[35]](#cite_note-35)

#### Martial Arts

Hand-to-hand martial arts are another victim of the new world's unrefined teachings. It is regarded as advantageous to practice magic, as throws and guards can be made irrelevant via superior magical force. Other's negligence notwithstanding, Cid continues the development and practice of hand-to-hand techniques. Unarmed combat has been noted as his specialty, but there are few instances where he gets to exhibit this confidence.[[27]](#cite_note-V2CF-27) Melee skirmishes are the predominant form of warfare, but Cid incorporates multifarious striking techniques into personal swordplay.

#### Magic

Magic is essential for fights in this new world. Cid describes magical energy as "minuscule grains of light floating" in his body.[[2]](#cite_note-V1CP-2) His magic differentiates from typical dark knights as the color manifests as shades of blue and purple. A serendipitous discovery of an afflicted mound of flesh allowed young Cid to experiment to his heart's content. The pile of flesh served as an excellent tool for research and helped Cid develop a cure for [the possessed](Possession.md "Possession").[[3]](#cite_note-V1C1-3)

After turning ten, Cid reported having the strength to lift giant boulders with one finger and magically enhanced agility to run twice as fast as a horse or leap as high.[[2]](#cite_note-V1CP-2) Through exacting labor, Cid has rapidly augmented all his abilities and exceeded his ten-year-old feats, demonstrating imperceptible speeds, heightened strength, and his tour de force, nuclear magic. Likewise, personal magic control has proven intricate enough to modify bodily magical density, relocate organs, and manipulate mana emissions.[[10]](#cite_note-:0-10)[[37]](#cite_note-37) His power is further augmented by an immense magical reservoir and natural regeneration. A device that gives numerical values to magic produced a 9999, a reported quantization error.[[10]](#cite_note-:0-10) Despite this reservoir, Cid has stated that the quality of mana is more important than quantity—intricate control and compression surpass limitations and can multiply magical power by one thousand times its original strength.[[38]](#cite_note-V5CP-38)[[39]](#cite_note-:19-39)

Agility and endurance are not the sole benefactors of magic amplification; the young shadow broker's magic can suppress his presence. Although he is not the strongest user of this ability—an honor Cid gives to Delta—it remains invaluable for assassinations or grand entrances.[[11]](#cite_note-V3C4-11)[[19]](#cite_note-V3C3-19)

##### Nuclear Magic

Cid's signature nuclear or atomic magic is the culmination of his magical research and training; it is the most potent technique in his repertoire. The functional principle behind it is the accumulation and compression of magic into a single point, his sword, followed by release.[[8]](#cite_note-V1C3-8)[[41]](#cite_note-41) The energy unleashed is comparable to fission or fusion chain reactions. While channeling the esoteric technique, Cid says: "I...Am...Atomic" in English. It was birthed out of the desire to be strong enough to survive a nuclear strike. Cid's sole purpose of cultivating magic, besides general shadow broker practices, was to accomplish this unrealized desire. His logic became that to survive a nuclear explosion, he must transcend past the physical limitations and become a "nuclear power" incarnate.[[8]](#cite_note-V1C3-8)

> ###### I…Am…Atomic Variations:
>
> - Atomic (Standard): Magic is concentrated into a sword, leading to a devastating subsequent strike. The impact releases an explosion of magic that disintegrates everything caught inside it. [[8]](#cite_note-V1C3-8)
>
> - All-Range Atomic: An area of effect atomic magic modification. A magical-infused sword is struck into the ground, discharging power in a set radius around the insertion point.[[8]](#cite_note-V1C3-8)[[42]](#cite_note-V4C3-42)
>
> - Recovery Atomic: The attack functions similarly to the standard atomic technique. Magic still damages structures (destruction of the Crimson Tower), but individuals are healed rather than disintegrated.[[19]](#cite_note-V3C3-19) Those who were turned into ghouls, vampire thralls, likewise returned to normal.[[43]](#cite_note-:27-43)[ANIME ONLY]
>
> - Atomic Sword: Magic perceptively manifests to elongate a weapon. A single horizontal strike bisects everything in the sword's sweeping arc.[[44]](#cite_note-V4CE-44)
>
> - Atomic Locust Shell: A sword splits into nine visible images and transforms into dragon-like slashes. Each dragon consumes a part of the enemy. Slash one and two bite the arms; three and four devour the legs; slash five and six bisect the torso; strike seven pierces the chest; slash eight severs the neck. The ninth and final attack swallows the head.[[28]](#cite_note-V5CE-28)
>
> - Almost Atomic: An early iteration of standard atomic magic. It is smaller than the traditional technique; later experimentation yielded a more potent result.[[45]](#cite_note-V5C3-45)
>
> - [Web Novel] Atomic Rain: Slime is shaped into four wings to gain altitude. Mana is rapidly stored in the wings, becoming feather-like in shape. The magic feathers are released as rapid-fire bursts of energy, raining destruction from above.[[39]](#cite_note-:19-39)
>
> - [Web Novel] Atomic Radar: Magic is focused into the tips of fingers, indistinguishable with the naked eye. The compressed magic turns into particles and is released around the user. They are used to perceive their surroundings. Atomic radar is a non-offensive nuclear technique.[[46]](#cite_note-46)
>
> - [Game] Rising Atomic: Instead of a sword strike or radius effect, Cid concentrates magic into a sword and releases it in an upward beam. Incineration of weaker targets or objects occurred immediately. If the receiver survives the initial burst, breathing becomes difficult due to a freezing feeling permeating the body. The magical damage quickly accumulates, leading to death.[[47]](#cite_note-47)
>
> - [Game] Archetype Atomic: Another early iteration of atomic attacks. It disintegrates physical and magical matter within a set radius.[[48]](#cite_note-48)

Median Differences: The light and web novels portray nuclear magic as an empowered sword strike that triggers an explosion from impact. The anime and manga depictions suggest internal magical explosions.

#### Physical Capabilities

Magical reinforcement and augmentation actively assists Cid in surpassing the limits of the average human body. While not noted as the maximum speed, one documented numerical value is 1,200 km/h (648 kn 746 mi/h).[MANGA ONLY][[49]](#cite_note-49) Rapid acceleration, to this degree, continues to benefit Cid in combat—facilitating high velocity exchanges, quick maneuvers, and intricate movements. Outside of general speed, his offensive strategy of swift ripostes and counterattacks takes full advantage of magical amplification.[[29]](#cite_note-V2C1-29) He has even sustained this agility while airborne, demonstrating combat prowess while executing sharp turns, slow descents, and bursts of motion for flight.[ANIME ONLY][[43]](#cite_note-:27-43)[[50]](#cite_note-50) When further combined with the suppression of presence, his swiftness enables assassinations or grand entrances.[[23]](#cite_note-V1C6-23)[[19]](#cite_note-V3C3-19) Cid's movements likewise possess enough speed that they periodically leave an afterimage behind. He plays into this visual effect to accentuate his shadow broker persona. Announcing that an opponent attacked a mere afterimage after they released a strong attack can psychologically shake enemies.[[21]](#cite_note-V2C7-21)[[28]](#cite_note-V5CE-28)

Cid's standard defensive strategy is to dodge or parry with the quick minute movements. Unavoidable attacks are tanked by magically reinforcing armor or body parts to ameliorate potential damage. Unavoidable attacks are occasionally endured to crush opponents' spirits. As early as six, he used fortification techniques to overcome past-life difficulties, a mass and strength disadvantage. There is a limitation on how much force can be exerted on a child's body, but Cid pushed past it, allowing for such feats as shattering metal.[[1]](#cite_note-V3CA-1) In later years, he withstands powerful attacks, passively resists lethal poisons, and can become impervious to modern firearms.[[42]](#cite_note-V4C3-42)[[51]](#cite_note-V4C6-51)[[52]](#cite_note-52)[[53]](#cite_note-53) If damage occurs, purposeful or accidental, Cid developed the ability to heal severe injuries for himself or others. This skill has evolved from increasing the body's natural healing capabilities to regenerating damage at the cellular level—scars or lasting damage versus complete recovery.[[54]](#cite_note-54) Intricate magic control further allows for internal manipulation that can move or repair vital organs. Through magic, Cid calculates that his life will last six hundred years.[[45]](#cite_note-V5C3-45)[[55]](#cite_note-55) This length is still inadequate for him. An eminence in the shadow must be eternal.[[28]](#cite_note-V5CE-28)

Although he is inferior compared to some strong [therianthropes](Therianthrope.md "Therianthrope"), reinforcement and body conditioning have assisted in developing Cid's senses beyond many dark knights.[[11]](#cite_note-V3C4-11) The heightened awareness is invaluable in and out of combat.[[23]](#cite_note-V1C6-23) Cid's perception of magic is high enough to follow the mana behind attacks, even imperceptible techniques.[[28]](#cite_note-V5CE-28) His acute vision can likewise identify masked individuals and, if strengthened, can see through opaque objects.[[17]](#cite_note-V1CF-17)[[56]](#cite_note-56)[ANIME ONLY]

#### Intelligence

Cid shows a higher-than-average intelligence in several areas but falls below in others. He has noteworthy fluid intelligence in battle.[[29]](#cite_note-V2C1-29)[[27]](#cite_note-V2CF-27) As a combat savant, tactical decisions and calm analysis assist his methodical approach to fighting. His astuteness has dissected enemy techniques and replicated them with refinements.[[28]](#cite_note-V5CE-28) For science and technology, Cid presents as a generalist, only showing a surface comprehension of modern enlightenment, Shadow Wisdom.[[8]](#cite_note-V1C3-8) What he lacks in natural talent, Cid makes up for it by repeated trial and error for innovative technologies. The discovery of slime conductivity was a significant breakthrough.[[2]](#cite_note-V1CP-2) His analytical brain can extend into objective situational awareness for non-combat strategies or investigatory deductions.[[51]](#cite_note-V4C6-51)[[10]](#cite_note-:0-10)

Cid can communicate in a few different languages. He speaks the language of Midgar fluently and retains his past life's Japanese language skills—showing knowledge in hiragana, kanji, katakana, and romaji.[[34]](#cite_note-V3C6-34) English words are part of his vocabulary, but fluency has not been established. Cid's social acumen is the price for his combat prowess, as his interpersonal emotional intelligence has significant shortcomings.[[22]](#cite_note-V2CP-22)[[57]](#cite_note-57)

#### Normie Techniques

Mob Cid keeps a low profile to dissimulate his "true" shadow broker identity. Mob Cid is a mediocre individual who blends into the background. Some actions and words are carefully crafted to reinforce this perception. The rehearsed practices are named "normie techniques" (mob-fu manga). If atomic magic Shadow's culmination of eminence dedication, normie techniques would be the mob variant.[[59]](#cite_note-V1C5-59)

Cid has articulated that forty-eight techniques exist, not including special variations, but only several have made canonical appearances.[[59]](#cite_note-V1C5-59)

> ##### Named Normie Techniques:
>
> - Spinning Guard, Bloody Tornado: After receiving an attack, the individual reels back in a spiral aerial course, trailing blood behind them. For added effect, add additional blood while on the ground. The blood is kept in containers and secretly opened during flight.[[59]](#cite_note-V1C5-59)
>
> - Ten-Minute Death, Heartbreak Mob: Magic supplements standard blood and heart functions after a lethal attack. The body will appear dead to outside observers. As it induces cardiac arrest, it is dangerous and can spell disaster if done improperly.[[23]](#cite_note-V1C6-23)
>
> - Swiss-Cheese Dance, Bloody Marionette: The technique creates the illusion of bullets perforating the body. It is achieved by grotesquely thrashing and letting out cries of pain. The generous use of fake blood completes the effect.[[51]](#cite_note-V4C6-51)
>
> - Technique 49: Slows down the perception of time by magically enhancing the body. It is used to cheat on tests to get average grades.[[60]](#cite_note-60)

#### Other Named Techniques

- Ebony Swirl: Magic is used to elongate a slime sword, and magical energy is concentrated into the length. The technique differs from Atomic Sword as Multiple attacks slice enemies like a "whirlwind" rather than a single strike.[[61]](#cite_note-61)

- Overdrive: Brute forces magical energy into the body to surpass usual biological limitations. Recoil damage occurs if bodily stress exceeds acceptable strain.[[1]](#cite_note-V3CA-1)

- Birdcage of Darkness: Magical Threads are weaved together and encase a target. Space is slowly reduced until the threads tear into the recipient.[[42]](#cite_note-V4C3-42)

- Prison of Black Chains: Raw slime is subtly planted on the target. At an appropriate moment, the slime turns into solid chains to immobilize the target. Shadow has boasted that no one has broken out of the technique.[[44]](#cite_note-V4CE-44)

- [Web Novel] Shadow Marionette: Imperceptible magical threads are attached to one or more bodies of an ally. The thread acts like a tube that pumps additional magic into connected party, and allows the caster partially controls them. While Cid can maintain the magical load, the technique's mental strain is proportional to the number of attached individuals. The ability can become quite debilitating. To optimally control of hundreds of soldiers, Cid needed to balance his usual magical perception with micromanaging movements. According to Cid, the strain feels like one's brain is on the verge of exploding. [[62]](#cite_note-62)

#### Miscellaneous Talents

> Musician: As a virtuoso pianist, Cid can play and has memorized various Classical and Romantic compositions. His favorite musical piece is Sonata No.14, "Moonlight" in C-Sharp Minor, Op.21 No. 2: I. by Ludwig van Beethoven. Although it began as a parentally forced activity on Earth, Cid grew partial to it and realized that there is much shadow broker potential. A secondary benefit is that it supplied an excuse for his absence from after-school activities. Reincarnated in the new world, Cid makes full theatrical use of this skill. He never misses an opportunity to play the piano if one is available to further his shadow broker persona, either as Cid or Shadow.[[20]](#cite_note-V2C6-20)
>
> Card Player: Cid has proven to be an adept card player. The legitimacy of his present conduct has yet to be confirmed. Cid has hustled others in the past. He specified that he would respond to cheating by cheating.[[38]](#cite_note-V5CP-38)[[64]](#cite_note-64)
>
> Acting: Cid dedicates himself to rehearsals just as much as combat exercises. He has demonstrated exemplary improvisational skills for conversations or plot contrivances. In almost every line of dialogue, Cid stays in character, even if the words are preposterous. He is shown to be a satisfactory Mimic, with each persona having different voices and mannerisms.[[9]](#cite_note-V2C4-9) The characters he dedicates the most time to are Shadow and Mob Cid.
>
> Luck: While debatable as an ability, Cid displays an implausible amount of luck. His contrived lore for the world has remarkable accuracy, and whim-based locational decisions coincide with significant events.

#### Weapons and Equipment

Slime byproducts are the core of Shadow's arsenal. Infusing matter with magic always yields energy loss. However, by utilizing the slime's high magic conductive, ninety-nine percent compared to iron's fifteen or Mithril's fifty, Cid can create an assortment of powerful items that rival artifacts. The fluidity of slime offers endless applications.

- Slime Sword: Shadow's primary weapon is a katana. The anime sword hilt is depicted with two horizontal quillons; it would make it some variation of a longsword. A more decorative or ornamental broad-sword design was selected for the manga.

- Slime Bodysuit: A black bodysuit made from slime. It can change states and shapes through the application of magic. Cid can fortify or reinforce parts of the body for an increase of protection and dissipate large attacks.[[2]](#cite_note-V1CP-2)[[42]](#cite_note-V4C3-42)

- Slime-Ball Projectiles: Slime globules are compressed into round shot and flicked at high speeds. Though the number of joules is unspecified, one ball has sufficient kinetic energy to penetrate the skull and heart of two different people.[[23]](#cite_note-V1C6-23)

- [Anime Only] Slime Tendrils/Tentacles: The fluidity of slime allows the creation of flexible appendages. Reminiscent of vampire blood magic, slime tendrils can offer a seamless offense and defense.[[43]](#cite_note-:27-43) Lethality can be modified by altering the sharpness of the tip or edge. When attempted on less conductive material, like water, it diminishes potential power.[[36]](#cite_note-:31-36)

- Wires/Threads: The wires are magically reinforced steel or magic-based threads. These threads can be used as lethal weapons or offer esoteric utility. The potency varies depending on the strength of the opponent.[[34]](#cite_note-V3C6-34)

- Crowbar: Easy to transport, sturdy, and inconspicuous, the crowbar was the weapon of choice for Stylish Ruffian Slayer. The gooseneck pry enables Cid to wield crowbars like a tonfa (t-baton) or blunt weapon.[[15]](#cite_note-V4CA-15) Crowbar combat returned in the Shadow's battle against Beatrix and Iris.[ANIME ONLY][[36]](#cite_note-:31-36)

- Miscellaneous Items: Creative utilization of magical infusion has allowed for the weaponization of unconventional objects or elements. Cid has used pens and playing cards as a lethal projectile and water to mimic [vampire](Vampire.md "Vampire") blood tendrils.[[28]](#cite_note-V5CE-28)[[36]](#cite_note-:31-36)[[12]](#cite_note-V6C1-12)

## Trivia

- His past name 影野実 has 野 used as an [ateji](https://en.wikipedia.org/wiki/Ateji "wp:Ateji") for の; alternatively, 影野 read together translates as "shadow field", as in Shadow Garden.
  - Minoru's surname, Kageno (影野), has the kanji 影 meaning "shadow".
  - 影野 corresponds to 陰の at the beginning of the series title "陰の実力者になりたくて!" (Kage no Jitsuryokusha ni Naritakute!) with 実 being read as "Jitsu" in the title while in the name 影野実, 実 is read as "Minoru".
- His new life's family name is Kagenou (カゲノー, Kagenō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). The word カゲ in his surname means "shadow".
  - Cid Kagenou also has another meaning. Cid means "Lord" in Spanish and Arabic, while Kagenou means "Of the Shadows" in Japanese. Combining the two language meanings would make Cid's name "Lord of The Shadows".
- Cid has collected rare and expensive items, such as art and antiques, from various bandit camps. His purpose for raids is to live comfortably as an eminence in the shadows. The rare painting, The Shriek, is a real-world reference to [[wp:The Scream|Skrik (The Scream)] by Edvard Munch.
- Cid is oblivious to the fact that he is the owner of the Mitsugoshi Company and believes any money given would be a loan.
- In the Web Novel, Cid says, "I am Taepodong!" rather than Atomic. The name comes from the North Korean line of [triple-stage rockets](https://en.wikipedia.org/wiki/Taepodong-1 "wp:Taepodong-1"). The author changed it to "Atomic" for the light novel release for undisclosed reasons.
- His student detective Suzuki Hope disguise shares the same initials as Sir Conan Doyle's fictional detective [Sherlock Holmes](https://en.wikipedia.org/wiki/Sherlock_Holmes "wp:Sherlock Holmes").

## References

1. Volume 3 Auxiliary Chapter: Field Notes on a Little Brother—by Young Claire!
2. Volume 1 Prologue: Preparing the Perfect Stage!
3. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
4. Volume 5
5. [Official Tweet](https://x.com/Shadowgarden_PR/status/1854833745477746765)
6. Volume 4 Chapter 5: Sneaking Around Japan, Just Like the Old Days!!
7. Volume 1 Color Insert
8. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
9. Volume 2 Chapter 4: This Situation Calls for a “Who is This Guy?!
10. Volume 5 Chapter 5: Terrorists Attack the School... Again!!
11. Volume 3 Chapter 4: I’ll Destroy It All and Start From Scratch!
12. Volume 6 Chapter 1: Enter Jack the Ripper!
13. Volume 6 Chapter 4: The Monster Becomes a Legend!
14. Volume 4 Chapter 4: Lurking in the Darkness in Fantastical Japan!
15. Volume 4 Auxiliary Chapter: Rise of the Fancy Hoodlum Slayer!
16. Volume 1 Chapter 2: Assuming the Role of a Side Character at School!
17. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
18. Volume 4 Chapter 2: Begin Operation Obstruction!
19. Volume 3 Chapter 3: Pursuing the Blood Queen!
20. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
21. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
22. Volume 2 Prologue: To Lindwurm, the Sacred Land!
23. Volume 1 Chapter 6: That Scene Where Terrorists Take Over the School
24. Volume 4 Auxiliary Chapter: Rise of the Fancy Hoodlum Slayer!
25. Web Novel Chapter 1: Within the Limits of Being Human Means You Would Be Vaporized by a Nuke
26. Episode 1
27. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
28. Volume 5 Epilogue: I’d Let the Whole World Burn, If That’s What It Took!
29. Volume 2 Chapter 1: Fun Times at the Goddess’s Trial!
30. Episode 2
31. In the anime, mass train transportation means industrial steel production (Bessemer process), and Eta’s use of a straight key in episode 20 are two out of many examples that place Midgar in the [Mid-Second Industrial Revolution](https://en.wikipedia.org/wiki/Second_Industrial_Revolution "wp:Second Industrial Revolution") (rapid scientific advancement and industrialization). In the light novel, Mitsugoshi textile output would require mechanized gins and spinners, and the steam engine (Volume 3 Prologue: Heading to the Lawless City over Fall Break!) would place it at the start of the [First Industrial Revolution](https://en.wikipedia.org/wiki/Industrial_Revolution "wp:Industrial Revolution") (mechanization and constant output rate). The leap to the [Third Industrial Revolution](https://en.wikipedia.org/wiki/Third_Industrial_Revolution "wp:Third Industrial Revolution") (transistors and digitization) has been teased by Beta’s laptop borrowed from Earth.
32. Web Novel Chapter 2: Bandits Are Basically Just Walking Bonus Stages
33. Episode 2
34. Volume 3 Chapter 6: Circulating Counterfeit Cash!
35. Volume 2 Chapter 8: Lay Your Eyes on My True Powers!
36. Episode 20
37. Volume 2 Chapter 3: When Things Get Boring, It’s Time for Explosives!
38. Volume 5 Prologue: The Case of the Missing Students and the Not-So-Peaceful Academy!
39. Web Novel Chapter 166: Mordred
40. Episode 5
41. Web Novel Chapter 20: “I Am……”
42. Volume 4 Chapter 3: Crashing the Ceremony!
43. Episode 23
44. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
45. Volume 5 Chapter 3: The Case Is Closed, So, It’s Time for a Flashback!
46. Web Novel Chapter 181: The Other Side Connecting the Past, Present and Future
47. Seven Shadow Chronicles Chapter 27
48. Seven Shadows Chronicles, Part 3: Secret of Sacra, Chapter 13, Episode 5
49. Manga Volume 5
50. Episode 29
51. Volume 4 Chapter 6: Something Smells Fishy…But an Eminence in Shadow Always Cracks the Case!
52. Volume 5 Eta Research Journal
53. Seven Chronicles, Rise of Garden Episode 2: The Ancient Dragon of Alexandria
54. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
55. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
56. Episode 30
57. Volume 4 Chapter 2: Begin Operation: Obstruction!
58. Master of Garden Official Art
59. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
60. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
61. Volume 3 Chapter 1: Lawless City Bandit Hunting!
62. Web Novel Chapter 174: Do Not Kick the Platform
63. Episode 17
64. Volume 6 Prologue: There Are People Ruling the Midgar Kingdom from the Shadows? I'm So Jealous!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | **Shadow** | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
