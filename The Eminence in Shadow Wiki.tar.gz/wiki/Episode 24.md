# Episode 24

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2024](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2024)

## Mask of Falsehood

### Kana

偽りの仮面

### Romaji

Itsuwari no Kamen

## Special Title

### English

The Eminence in Shadow Wants to Become a Super Agent!

### Kana

陰の実力者はスーパーエージェントになりたい！

### Romaji

Kage no Jitsuryoku-sha wa Supā Ējento ni Naritai!

## Episode Information

### Season

2

### Episode

4 (24)

### Air Date

October 25, 2023 JP & EN

### Adapted From

Volume 3 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

Grayscale dominator

### Ending

Polaris in the Night (Chi ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| The Hour of Awakening | He Who Pulls The Strings |

Mask of Falsehood (偽りの仮面, Itsuwari no Kamen[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the fourth episode of the second season, and the twenty-fourth episode of [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

The Mitsugoshi Company is doing great, all thanks to Gamma! However, the biggest crisis imaginable rears its ugly head.[[1]](#cite_note-1)

急拡大するミツゴシ商会がライバルの大商会連合に目をつけられる。その独占的なやり方に懸念を抱く謎の男ジョン・スミスはユキメとともに商業戦争を仕掛けていく。[[2]](#cite_note-2)

## Summary

A high-value Mitsugoshi Company cargo trade laden with precious goods is ambushed by a hired gang of bandits, who surround the extracted female Mitsugoshi employees and are in the process of pillaging the cargo; products estimated to be worth a staggering one hundred million zeni. As the bandits go about their criminal endeavors, one of them confides in the terrified women about their sinister motives and asserts that Mitsugoshi's exceptional profitability and rapid expansion pose a grave concern for his boss. Ripping part of the the young woman's clothes, she cautiously inquires about the identity of this employer. The bandit reveals that Garter sent them, with the young woman recalling how he is the president of the Major Corporate Alliance (MCA) and a high standing figure in society. She voices skepticism, noting that Garter is well-known for his piety to the Divine Teachings and significant contributions to the Church, and it seems inconceivable that such a man would employ bandits to disrupt honest business activities.

In response, the bandit cautions her about the hidden facets of every individual's character. Surprisingly, the woman calmly asserts that there is no point in reiterating what they already know, confusing the man. [Alpha](Alpha.md "Alpha") then replies that there is some value from the concerned party's testimony, frightening the men as they suddenly find themselves encircled by an assembly of women dressed entirely in black-- Shadow Garden. With the women they were threatening removing their disguises to reveal their true identities-- [Nu](Nu.md "Nu"), [Chi](Chi.md "Chi"), and [Omega](Omega.md "Omega")-- with no trace of feigned dread. The bandits are taken aback and overmatched, having no chance as they succumb to a merciless one-sided onslaught. Following this swift and decisive encounter, Nu reports to Alpha that their assault has considerably diminished the strength of the MCA, as Alpha acknowledges how this will now force the MCA to use their legitimate resources in the coming war.

In the royal capital, Skel and Po proudly parade their recently acquired designer outfits from Comme Ça du Mitsugoshi to Cid during their lunch, their latest ploy to charm the ladies. Cid ponders that anything design-related from Mitsugoshi is probably from Eta, adding to the number of girls who profited off Shadow's knowledge. As Skel continues to flaunt his new attire, the Comme Ça du Mitsugoshi logo peels off his shirt revealing the emblem of the store where they had made their purchase. Skel is disheartened realization he's sporting a knock-off, but he attempts to console himself by suggesting that they can simply reattach the logo, as if it were a minor issue.

Meanwhile, Cid has a revelation regarding the clothing prepared by Alpha and her team for him to wear. He realizes that the business attire he's seen people wearing around the capital are actually Mitsugoshi produced textiles, which he had initially assumed was commonplace in this world. He understands that this revelation is the result of the knowledge he shared with the girls to expand their market share, remarking with a disapproval on the unfairness of taking business from others, causing discontent among those who've been affected-- namely himself. He departs, declaring his intention to reclaim everything that rightfully belongs to him, leaving Po and Skel confused by his cryptic statement. In his dorm room, Cid outfits himself in a sleek black suit from the Snow Fox Corporation, securing his hair in a tidy short ponytail, and completing his transformation with a magician's mask to unveili his latest persona: the super elite secret agent, John Smith. Fully prepared, he proceeds to rendezvous with [Yukime](Yukime.md "Yukime") in an unoccupied train compartment.

At the meeting, Yukime expresses her satisfaction at having Shadow on their side, but he promptly disowns the name in declaring his usage of "John Smith" henceforth, and asserts that their collaboration is primarily motivated by the prospect of a profitable partnership. During their meeting, Yukime provides John with an update on recent developments in the market, revealing that Garter has convened a meeting of the MCA heads to discuss fortifying their strategies against Mitsugoshi. Emphasizing the ongoing conflict between Mitsugoshi and the MCA, she underscores their intent to seize everything after collapsing both entities, and implores John to take action on their behalf. Yukime also cautions him about the formidable secret leader of the MCA, [Gettan](Gettan.md "Gettan") the Sword Devil, who quietly assumed control of the MCA from Garter. She underscores his ruthlessness, noting that he stops at nothing to achieve his objectives. Yukime discreetly reveals a deep scar on her back while fixated on her plans to handle Gettan herself. As the train comes to a halt, John takes his leave as he vows to obliterate the existing order and rebuild it from the ground up.

The following day, MCA-affiliated merchants in the capital held a massive sale on all their products. As Cid joins Skel and Po, eagerly attend to take advantage of the bargains, he couldn't help but notice that Mitsugoshi had pushed the envelope too far, making enemies of local traders and jeopardizing their own future. He remarked that their competitors would likely bring Mitsugoshi down, and when that happened, he would use the capital he had acquired to establish a new corporation, offering managerial positions to Alpha and girls. As the boys proceed to pay for their purchases, Cid noticed that the banknote Po handed over was different from the usual currency.

Po explained that it was the new 1000 Zeni MCA-issued banknote, and the sales event was designed to celebrate its release. Intrigued, Cid requested a closer look, and discerned upon closer inspection some significant disparities between the MCA and Mitsugoshi banknotes. The Mitsugoshi banknote uses multicolor printing and has a carefully placed watermark, while the MCA's version had simpler, cruder printing and a less detailed design. Cid recollected sharing details with the girls ([Beta](Beta.md "Beta"), [Gamma](Gamma.md "Gamma"), and [Eta](Eta.md "Eta")) about an MHK documentary on banks and credit creation, which seemed to have inspired them to establish their own bank.

In a sudden recollection, Cid shared a childhood memory with the two friends of how, as a child, he had aspired to make copies of a one thousand yen bill using a copy machine at a local store. However, he abandoned this dream after a cashier scolded him. Skel and Po were puzzled by the story, and Po asked Cid to return his money, but Cid refused and swiftly takes off with it. Skel and Po pursue Cid as he frantically tries to recall the MHK documentary. In his John Smith persona, Cid met up with Yukime once again to share his findings. He explained that the banknotes were essentially worth nothing more than paper, acting as promissory repayment notes as long as the banks held the gold reserves equal to the notes in circulation. Their sole advantage was the convenience they offered over carrying gold coins, handing Yukime two banknotes and asked her to spot the differences between them. As she examined the notes, she swiftly realized that it would be easier to create counterfeits of the MCA banknotes, to which John proposed that they capitalize on this opportunity and profit from it.

However, Yukime promptly explains that since these banknotes were only in circulation within the capital, it would be relatively simple to trace the source of any fakes. She continues how the authorities would track them to the source and the gold they could flee with would barely be a child's allowance, to which a disheartened John approached Yukime with a more menacing tone, pressing her to confirm if this was what she thinks. A startled Yukime pondered the situation for a brief moment, reflected on his elaboration of "credit creation," and put forward a plan suggesting that they intentionally let the fake notes be discovered. Once rumors of counterfeit bills circulating in the public domain spread, it would create a [credit crisis](https://www.investopedia.com/terms/c/credit-crisis.asp), leading to the devaluation of the banknotes and citizens rioting for their money be returned. However, if they cashed out their holdings before the crisis took hold, they would be safe and escape with a fortune before the discovery. Yukime nervously smiled as she presented this strategy to John, who once again posed the question menacingly, inquiring if this was indeed what she thinks. A nervous Yukime confirmed her stance, with John disembarking from the train with a gloomy expression following Yukime's affirmation. Yukime believes the plan to be flawless and John Smith to have tested her sincerity, in awe at his genius.

Afterward, Cid headed out for his evening meal and encountered [Delta](Delta.md "Delta"), who picked up on the distinct scent of a fox [Therianthrope](Therianthrope.md "Therianthrope") that clung to Cid. As she inquired about it, Cid explained that he had been engaged in hunting foxes, prompting Delta to swiftly propose that Cid join her in hunting bandits in the capital. However, Cid politely declined her offer, advising her to attend to the tasks Alpha had assigned her first. But as Delta gazed at Cid with big, pleading eyes, he noted reminded him of his pet dog [John](John.md "John") from his previous life, and ultimately conceded, promising to join her in the hunt once she had fulfilled her duties to Alpha. Elsewhere, Garter provides Gettan with a comprehensive briefing on the MCA's most recent activities within the lavish confines of Gettan's adorned office. He conveys the surprising discovery that Mitsugoshi's private soldiers possess more formidable strength than they had initially estimated. In response to this development, Gettan deploys the Clovers, an elite assassination squad handpicked by him, to address the situation.

When Shadow and Delta rendezvous later for their bandit hunting mission, Delta takes a merciless approach to swiftly dispatching the bandits, while the bored Shadow searches through their treasure. He can't help but grumble over Delta leaving no bandits for him to deal with. However, the situation takes an unexpected turn when a muscular man pleads with Delta to stop. To Shadow's astonishment, she complies when the man identifies himself as [Zabra](Zabra.md "Zabra"), claiming to be Delta's brother, a fact she confirms by detecting their father's scent on him. Zabra recalls Delta (formerly Sara) was hunted when she underwent [Possession](Possession.md "Possession"), but goes on to explain that he now serves under the great wolf, Gettan. But before he can say more, Delta abruptly stabs him in the chest, killing him. Shadow questions whether it's acceptable to have killed her own brother, but Delta callously responds that weaklings only bring disgrace to the family. Delta shares that their father is the clan's chief, having over a thousand offspring, making the loss of one inconsequential. Shadow, in an attempt to change the topic, suggests that he should visit the Therianthrope lands sometime. Delta becomes enthusiastic and tells Shadow that if he can defeat her father, he could become the clan's chief, promising to give him a hundred women and having a hundred offspring herself, but Cid declines her offer.

Garter provides a report to Gettan, informing him that the fourth leaf, Zabra, has been defeated. He further notes that in recent months, their firepower has been significantly diminished, leaving them with almost nothing, to which Garter suggests a pragmatic approach and advises a temporary retreat to reevaluate their situation. However, Gettan dismisses this suggestion and asserts that Garter should simply adhere to his orders. Gettan proposes an alternative strategy, emphasizing that they should intensify their offensive against Mitsugoshi and aim to acquire all of their closely guarded trade secrets. Gettan dismisses Garter to carry out his orders, then proceeds to stare out the window with his scarred eyes hidden behind his visor.

## Characters

- [Nu](Nu.md "Nu")
- [Chi](Chi.md "Chi")
- [Omega](Omega.md "Omega")
- Garter Kikuchi
- [Alpha](Alpha.md "Alpha")
- Skel Etal
- Po Tato
- Cid Kagenou/John Smith/Shadow
- [Yukime](Yukime.md "Yukime")
- [Gettan](Gettan.md "Gettan")
- [Gamma](Gamma.md "Gamma")
- [Beta](Beta.md "Beta") (Flashback)
- [Eta](Eta.md "Eta") (Flashback)
- [Delta](Delta.md "Delta")
- [John](John.md "John") (Mentioned)
- Zabra

## Promotional Videos

「陰の実力者になりたくて！ 2nd season」 第4話予告≪ノーマルVer.≫「偽りの仮面」

『陰の実力者になりたくて！ 2nd season』 第4話予告≪スペシャルVer.≫「陰の実力者はスーパーエージェントになりたい！」

## Trivia

- The Mitsugoshi Company's banknote resembles the [Japanese Yen](https://en.wikipedia.org/wiki/Banknotes_of_the_Japanese_yen), while the Major Corporate Alliance design is more comparable to the [US Dollar](https://en.wikipedia.org/wiki/Banknotes_of_the_United_States_dollar).
- The mask Cid wears as John Smith is flipped upside-down, with the nose of the mask acting as a horn.
- John Smith's attire is supplied by the Snow Fox Corporation, which profits off of bootleg Mitsugoshi merchandise.
- In other adaptations, [Yukime](Yukime.md "Yukime") was more provocative with John Smith—offering carnal services and uttering lewd remarks. During one of their meetings, she disrobes, displaying a scarred back to emphasize her hatred towards [Gettan](Gettan.md "Gettan").
- Cid used information he learned from an [NHK Documentary](https://www3.nhk.or.jp/nhkworld/en/tv/documentary/) to educate [Beta](Beta.md "Beta"), [Gamma](Gamma.md "Gamma"), and [Eta](Eta.md "Eta") on the banking system and credit creation.
- Cid begins his persona as John Smith at the beginning of the autumn semester, as the operation to counterfeit bills will become a months long endeavor leading into the winter.

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e024>
2. <https://shadow-garden.jp/story/#story4>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • **Episode 4** • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
