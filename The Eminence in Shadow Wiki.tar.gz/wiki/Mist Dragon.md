# Mist Dragon

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mist%20Dragon](https://the-eminence-in-shadow.fandom.com/wiki/Mist%20Dragon)

|  |  |  |
| --- | --- | --- |
| “ | The true victory over a Dragon... is obtained if one possesses the power... to kill it! | ” |
| — Mist Dragon, Seven Shadows Chronicles, Chapter 2 | | |

## Mist Dragon

### Japanese

霧（きり）の龍（りゅう）

### Romaji

Kiri no Ryū

## Characteristics

### Race

[Dragon](Dragon.md "Dragon")

### Gender

Male

### Age

Millennia+

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Blue

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Protector of [Alexandria](Alexandria.md "Alexandria")

### Affiliation

Shadow Garden

## Debut

### Web Novel

Chapter 88 (Mentioned)

### Light Novel

Volume 2 (Mentioned)

### Manga

Chapter 4.2 - Seven Shadows Chronicles

### Anime

Episode 20 (Mentioned)

### Game

Seven Shadows Chronicles: Chapter 2

## Portrayal

### Japanese

[Hidenboru Kuichi](https://en.wikipedia.org/wiki/Hidenobu_Kiuchi "wp:Hidenobu Kiuchi")

The Mist Dragon (霧（きり）の龍（りゅう） , Kiri no Ryū[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a [Dragon](Dragon.md "Dragon") that resides in the Abyss Woods, having claimed it as his territory. Even though his territory is so wide, he is only thought to be folkslore.

## Appearance

The Mist Dragon is a large serpentine-like silver dragon with blue stripes and elongated whiskers. He is equipped with 2 big arms ready for combat and 2 pairs of wings.

The area surrounding him is always covered by heavy mist, this is due to it being the reason that the mist exists.

## Personality

The Mist Dragon is an arrogant, intimidating, and serious dragon with a strong behavior.

He seems to find interest in telling old tales to those who rather seek knowledge than power, allowing them to listen to those tales.

While being an intimidating and cold being, he seems to have some kind of sense of humor, having fun while fighting the seven shades and having a deep interest towards Cid’s growth as well as Delta’s training.

The Mist Dragon, due to his long lifespan, could be considered the being with the most wisdom in the realm, and a high level of intelligence to the point of having his own philosophy and beliefs.

His philosophy focuses on the manifestation of the spirit and the ascension to higher living beings by one’s will and strength.

## History

### Alexandria's Mistake

Approximately one millennium ago, the Mist Dragon formed a pact with the king of [Alexandria](Alexandria.md "Alexandria"), having promised prosperity and protection for the city. In return of his obedience, his condition was that one day he would be given death by the king's heirs.

However, as time passed, the pact was forgotten, and the descendants of the king became greedy with their prosperity instead of striving to grow in strength. The Mist Dragon, enraged, destroyed the kingdom by surrounding the kingdom alongside its surrounding woods. This is how the Abyss Woods came to be.

### Shadow Garden's New Base

The Mist Dragon was awakened by the girls of Shadow Garden. After a small talk with them, the dragon became enraged after being questioned, resulting in a fight where the dragon ended up defeating the girls.

Shortly after, Shadow appeared to save the girls. While Shadow was able to overwhelm the dragon due to his own arrogance, he was left surprised when he realized he wasn’t able to kill the dragon. The Mist Dragon then proceeded to explain the curse of the dragon race’s immortality marking Shadow with his magic mist.

After this, the Mist Dragon allowed Shadow Garden to reside in Alexandria by removing the mist around it, with the hopes that someday, he will finally be able to meet his end.

### Delta's Training Partner

The Mist Dragon has appeared a few times training with [Delta](Delta.md "Delta"), who wants to become stronger. He acknowledges her strength as tells her some of his wisdom which may help her in the future.

## Powers & Abilities

### Overwhelming Strength

Due to the Mist Dragon’s size and magic, he is capable of destroying anything that is in his way. His body is tough enough to take attacks head-on from [Alpha](Alpha.md "Alpha") or Delta without any problem.

### Regeneration

Having adapted to magic in this realm, he is a part of the True Dragons, meaning he does have immortality. He also is equipped with very strong regeneration.

### Flight

The Mist Dragon’s build hints at him being able to fly at an incredible quality due to his serpentine-like form and his 4 wings. However, we have not seen him be serious enough to use such ability in a fight.

### Magic Manipulation

The Mist Dragon is one of the only beings known to be able to manipulate magic outside of his body. He is seen shooting magic projectiles that redirect to Shadow during their fight, and even doing magical explosions, hinting at a large amount of mana capacity and control.

### Poison Mist

As the name says, this is the Mist Dragon’s specialty. The Mist Dragon is able to launch Mist Breath attacks, which he can control at will to a scale big enough to surround a whole kingdom.

The mist is said to be very poisonous, being able to kill a member of Shadow Garden if they go into an area with a bigger concentration of mist. Even stronger members, like Delta, would fall unconscious if hit directly by the poisonous mist.

The mist also seems to work as a magical barrier, which messes up with one’s sense of orientation, making it impossible to know where you are going inside the mist. However, other senses like smell still work, making theriantropes the only ones able to find a way inside the mist when its not too poisonous.

## Trivia

- Within the manga, light novels, and anime[[1]](#cite_note-1), there is only a mention of the dragon. But as such, its only appearance was in the Game; "The Eminence in Shadow: Master of Garden."
  - Both the interactions and past of the Mist dragon, along with the fight against Shadow and his Shadow Garden, are revealed in the game, with their encounter only being mentioned in the light novel, the web novel, and the anime.

## References

1. Episode 20

## Site Navigation
