# Episode 12

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2012](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2012)

## The Truth Within the Memories

### Kana

記憶の中の真実

### Romaji

Kioku no Naka no Shinjitsu

## Special Title

### English

The Eminence in Shadow Wants To Avoid Death Traps at Any Cost!

### Kana

陰の実力者は即死トラップだけは避けたい！

### Romaji

Kage no Jitsuryokusha wa Sokushi Torappu Dake wa Saketai!

## Episode Information

### Season

1

### Episode

12

### Air Date

December 21, 2022 JP
March 13, 2023 EN

### Adapted From

Volume 2 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Beta ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| The Goddess' Trial | A Bloody Showdown as an Offering to Annihilation |

The Truth Within the Memories (記憶の中の真実, Kioku no Naka no Shinjitsu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the twelfth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

The door to the Sanctuary opens and Alpha strides through it, intending to expose the Cult’s grave secrets. Meanwhile, Cid also enters the Sanctuary and reunites with… Aurora?[[1]](#cite_note-1)

女神の試練の会場に、聖域に続く扉が出現。アルファは、ネルソンをその中に引っ立て、教団と魔人に関する重大な秘密を暴露する。いっぽうシドは、聖域でアウロラと再会し…!?[[2]](#cite_note-2)

## Summary

As the red glow of the [Sanctuary](Sanctuary.md "Sanctuary") door illuminates [Lindwurm](Lindwurm.md "Lindwurm"), Cid stands atop the dam and feels he did well, hoping people will talk about Shadow and forget about Cid Kagenou. Thinking about going to a hot springs next, a magical door then appears next to Cid atop the water. Despite his efforts and realizing he won't be able to escape it, Cid decides to enter.

As another door appeared in the middle of the arena, Jack Nelson wonders why the Sanctuary responded to Shadow, explaining to the princesses that the door appears to those who are worthy to pass through it. When Alexia recounts hearing of the door to the Sanctuary being in the Cathedral, Nelson clarifies that the "door" doesn't refer to a physical entry, but rather changes shape and location at will. He adds that there are three doors based on those who seek it and those who are worthy: a Forbidding door, a Beckoning door, and a Welcoming door. As Nelson moves to dismiss Alexia and the rest, Shadow Garden appears. Seeing the door start to open, Nelson orders the citizens be removed and declares the trial cancelled.

Led by [Alpha](Alpha.md "Alpha"), she asks Alexia and Rose to behave until the door is closed, taking [Delta](Delta.md "Delta") and a small contingent into the door. As [Epsilon](Epsilon.md "Epsilon") had defeated Nelson's guards, she orders the princesses to stay as she takes Nelson to into the Sanctuary. [Chi](Chi.md "Chi") and [Omega](Omega.md "Omega") take him and Ms. Natsume hostage, but Alexia considers leaving her to her fate, as Epsilon quietly agrees with her seeing Beta's assets. Once Alpha's squad enter, Nelson calls his guard [Venom](Venom.md "Venom") to kill Epsilon. But when Venom attempts to cut Epsilon, she bends to dodges the slash only for him to cut her fake slime breasts. Not wanting to be exposed, an enraged Epsilon reattaches them and quickly defeats Venom faster than anyone present can witness. Upon questioning if Nelson saw anything, the frightened archbishop states he saw nothing, with Rose and Alexia are confused since she moved too fast to be seen. Epsilon then grabs him by the face and jumps in as Shadow Garden members take Beta as hostage. Seeing the door start to close, Alexia and Rose jump in as well.

Inside the sanctuary, Alexia and Rose are transported to where Alpha is, landing atop Beta as Alexia states she tripped and fell into the door. As Alpha doesn't care, she tells her that it's fine if she also learns. As Shadow Garden study the Sanctuary, Alpha explains that this is where the left arm of Diablos was sealed after Olivier defeated it, and they came to learn more about the Cult of Diablos. Knowing Nelson won't talk, Alpha brings their attention to a statue of the hero Olivier, surprising the girls that its an elf woman despite the public understanding being Olivier was a man. As Shadow Garden has a general grasp of facts, knows the true history, and the Cult's real objective, Alpha reveals she has the same face as Olivier. A panicked Nelson realizes she was a possessed elf, exclaiming she wasn't compatible and should be dead, but Epsilon notes how he does know about them. Alpha states they know the truth behind Olivier and the possessed, suspecting that the Cult's true goal isn't just reviving the demon and states that they'll proceed to see for themselves. Alpha activates the big door, opening it as lights flood the room and the memory of Olivier stands beside her.

Elsewhere, Cid enters a white void room where [Aurora](Aurora.md "Aurora") is held and wonders if she summoned him. While Aurora states she doesn't think she summoned him, she does notes that they had a fun fight, thinking him the strongest of anyone in her incomplete memories. She wonders how Cid came to be here and he explains a door showed up, followed him, so he relented and entered. Cid asks how they can leave, but Aurora states she has no memories of ever leaving, explaining their was simply her just woken up and she was simply there, and that had never happened before. While Cid decides to retrace his steps, Aurora stops him to ask what she is wearing and if he can help her. After Cid notes its straitjacket, he guesses she didn't put it on for training, like he used to do long ago. Once he frees her and since they have the same goal of leaving, Aurora requests they should work together. She explains she knows how to free herself, but the Sanctuary is a memory prison created from ancient battles, so they need to go to its center and destroy its magical core to be set free. Aurora also notes that they can't use magic, as it will be absorbed by the Sanctuary's core, with Cid seeing such with his own magic. However, Cid is unbothered as he is reliable at breaking stuff, with Aurora gleeful to have a galant knight to protect her. As he wonders what she will do once she is free, Aurora states she will vanish into nothing.

As Alpha and her group explore the memories, they come upon a technologically advanced research laboratory within the damn, explaining that these are the memories of the hero Olivier locked away. Long ago, the Cult gathered orphaned children and used them for experiments, with most of them dying while a small group of girls survived. Meanwhile, Cid and Aurora come upon a memory of young Aurora crying, but as they need to end the memory so as to move forward. To do so, Aurora slaps her younger self to end the memory, telling her that crying won't change anything, and soon the memory shatters.

Alpha continues how Olivier was one of the few compatible children implanted with Diablos cells, the Cult's experiment to implant demon cells into children. Nelson argues they didn't have a choice as they needed power to fight the demon. While Olivier did indeed sever the demon's left arm, Alpha elaborates that everything they are seeing are just bygone memories, which fade to be replaced by new ones proceeds; as seen when the present ruins are intermittently seen within the memory. Once Olivier matured, the fairy tale claimed she was given a mission to vanquish the demon, when she was really sent to extract new cells from Diablos. Olivier remained obedient in the belief that her mission would lead to people living in peace, while the Cult held another objective. After the memory transitions to a battlefield, Alpha narrates that no matter how many parts she cut, the demon still lived, with the dismembered pieces still killing the Cult's researchers who came near it. The cult used powerful artifacts to immobilize the left arm and gained more Diablos cells, creating the red pills Alpha presents to the group, which Alexia recalls Zenon Griffey using. But the powerful side effects not what the Cult wanted, as the memory shatters to take them to the left Arm, so grand in size it had to be stored in a silo.

While Nelson is offended she would expose the truth in front of the princesses, Alpha draws their attention to the secret Nelson wanted to hid. The Cult was able to make pills that would grant tremendous power with an ageless body, to which Alpha points to the man in the memory IS Nelson, who is forced to reveal the drug is called Tears of Diablos. However, Alpha states it had two flaws, one of which Alexia interjects to claim the flaw is hair loss since the past Nelson had hair. Yet present Nelson denies that, as he lost his hair due to stress from being surrounded by idiots, who made him do all the work since he has immortal body. Alexia apologizes, and Alpha continues that the first flaw is that the Beads need to be taken at regular intervals of once a year or the effects wear off. The second flaw is that they can only produce small amounts, which Nelson reveals they can make twelve annually. Alpha rhetorically asks if it's coincidence that the Cult's leadership, the contain only twelve members; Alexia again recalls Zenon, who aimed to be the new twelfth seat in Rounds.

But as they have not perfected the Beads, the Cult continued production of the Beads by using the demon's arm and experimenting on the hero's descendants with Olivier's blood. Alpha asks Nelson to answer if she is correct, exposing him as the Eleventh of the Rounds. While Nelson confirms as such, as every member wants that power, he confirms he is one of the chosen Knights: Nelson the Avaricious. Although he buffs himself with his magic, Delta nonchalantly stabs him from behind and throws him down into the water. While Delta smiles at a good hunt, Epsilon reminds her she was suppose to wait until after they got all their intel, to which Delta fervently apologizes to Alpha. While her pack leader tells her to stop, she also repeats what she often reminds Delta: always make sure your prey is actually dead. A maniacal Nelson then rises from the water in a mutated physiology, breaking the memory to use the Sanctuary's security system to bring Alpha, Delta, Beta, and the princesses to a white void. Elsewhere, Epsilon and her squad are in another part of the Sanctuary's memories, while Nelson uses the space to multiply himself to punish the interlopers. However, Delta charges in happy to hunt again.

## Characters

- Cid Kagenou
- [Beta](Beta.md "Beta")
- Alexia Midgar
- Rose Oriana
- Jack Nelson
- [Alpha](Alpha.md "Alpha")
- [Delta](Delta.md "Delta")
- [Epsilon](Epsilon.md "Epsilon")
- [Chi](Chi.md "Chi")
- [Omega](Omega.md "Omega")
- [Venom](Venom.md "Venom")
- [Olivier](Olivier.md "Olivier")
- [Aurora](Aurora.md "Aurora")

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第12話予告≪ノーマルVer.≫「記憶の中の真実」

TVアニメ『陰の実力者になりたくて！』第12話予告≪スペシャルVer.≫「陰の実力者は即死トラップだけは避けたい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e012>
2. <https://shadow-garden.jp/1st/story/#story12>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • **Episode 12** • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
