# Brad Despoht

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Brad%20Despoht](https://the-eminence-in-shadow.fandom.com/wiki/Brad%20Despoht)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Brad_Despoht?action=edit).

## Brad Despoht

### Japanese

ブラッド・ダクアイカン

### Romaji

Buraddo Dakuaikan

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Eliza Despoht † (Daughter)

## Professional Information

### Occupation

- Marquis
- Leader of the Nightblades

### Affiliation

Thirteen Nightblades

## Debut

### Light Novel

Volume 6

### Manga

Chapter 72.2

Brad Despoht (ブラッド・ダクアイカン, Buraddo Dakuaikan[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), was the leader of the Thirteen Nightblades.

## Appearance

## Personality

## Chronology

### Bloody Midgar Serial Murder Terror

After the fall of the [Fenrir](Fenrir.md "Fenrir") faction he attempted to gain support from the [Loki](Loki.md "Loki") faction. During the fight in the colloseum he attempted to kill Jack The Ripper by using the possessed victim [Millia](Millia.md "Millia") (who had been recovered and upgraded by the [Loki](Loki.md "Loki") faction[[1]](#cite_note-:0-1)). However, Jack The Ripper was still able to kill Brad by throwing the king of spades card into his head.[[1]](#cite_note-:0-1)

## Powers & Abilities

## Trivia

## References

1. 1 - Volume 6 Chapter 4

## Site Navigation
