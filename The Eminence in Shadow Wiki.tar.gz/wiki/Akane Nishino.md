# Akane Nishino

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Akane%20Nishino](https://the-eminence-in-shadow.fandom.com/wiki/Akane%20Nishino)

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | Wait for me Minoru. | ” |
| — Akane, Light Novel Volume 04 | | |

## Akane Nishino

### Japanese

西野（にしの）アカネ

### Romaji

Nishino Akane

### Aliases

Senpai (by students of Sakurazaka High School)
Nishimura/Nishitani (by Minoru who got her name wrong)
The Savior (by Knights of [Messiah](Messiah.md "Messiah"))
First Knight
Original Knight
Otherworlder (by Shadow Garden)
No. 712
Akane Nishimura (By Shadow Garden)

## Characteristics

### Race

[Human](Human.md "Human") (Earthling)

### Gender

Female

### Age

17 (Debut)
20 (Current;Volume 4)

### Height

Unknown

### Hair Color

Black
Golden/Blonde (Awakened)

### Eye Color

Black (Formerly)
Red

### Birthday

October 4

## Personal Information

### Status

Alive

### Relatives

- Unnamed Father †
- Unnamed Mother †
- Akira Nishino † (Older Brother)

## Professional Information

### Occupation

- Student of Sakurazaka High School (Formerly)
- Actress (Formerly)
- Knight of Messiah (Formerly)
- Numbers Member

### Affiliation

[Arcadia](Arcadia.md "Arcadia") (formerly)
[Messiah](Messiah.md "Messiah") (formerly)
Shadow Garden

## Debut

### Web Novel

Chapter 145

### Light Novel

Volume 4

### Manga

Chapter 47

### Anime

Episode 1

### Game

Chapter 31, Episode 7

### Movie

The Eminence in Shadow Movie: Lost Echoes

## Portrayal

### Japanese

[Yui Horie](https://en.wikipedia.org/wiki/Yui_Horie "wp:Yui Horie")

### English

[Natalie Rial](https://en.wikipedia.org/wiki/Natalie_Rial "wp:Natalie Rial")

### Italian

Chiara Leoncini

### German

Zina Laus

Akane Nishino (西野（にしの）アカネ, Nishino Akane[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a former classmate of Minoru Kageno in his previous life. Following the fall of Japan to Magical Beasts, she became a "Knight", earning the name of Savior (救世主, Kyūseishu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) in the human settlement of [Messiah](Messiah.md "Messiah"), where she secretly was known as the Original Knight (はじまりの騎士, Hajimari no Kishi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).[[1]](#cite_note-V4E-1) After being 'kidnapped' by [Beta](Beta.md "Beta"), she is inducted into Shadow Garden as No. 712.[[2]](#cite_note-V6C5-2)

## Appearance

Akane appears as a teenage girl with long dark blue hair (black in the anime), olive green eyes (black in the anime), and slender legs. She donned her family's school uniform, which consisted of a standard white school blazer coat, light blue shirt, a blue skirt and tie, and black tights. Akane has three hair accessories that she wears on her hair, a flower hairclip on her right bang and two silver hair clips on her left. Her hair is in a half-up, half-down style with three braids hanging down her back, with the second braid tied in a ponytail.

Following her "Awakening", her eyes changed from black to red. In addition, when she became the "Original Knight", her hair changed from black to blonde. She retained her high school uniform, despite now being in her twenties, as it had been adopted as the standard uniform for Messiah's Knights.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | When I'm with you, I start thinking about the past... It's weird, right? | ” |
| — Akane to Minoru, Light Novel Volume 04 | | |

Akane presented herself as a proper, well-mannered girl but that was just a front. In truth, she was a scared, troubled girl, traumatized by her kidnapping and subsequent scandal. She masked her true self in an attempt to avoid others' scorn, reintegrate with them, and to escape the fallout of her kidnapping.[[3]](#cite_note-:0-3) This is most notable with her classmate Minoru, whom she hated for being immune to these efforts. Minoru would consistently misname her and vacantly stare past her. After her second kidnapping, Minoru changed, correctly remembering her name and looking at her properly. Upon discovering it was he who saved her, she began to believe they were alike, and their relationship began to reconcile. She held an immense fondness for him, persisting even after his death and after finding out he was still alive after his reincarnation.

After destroying Arcadia, Akane masked her true personality once more. She was unable to bear the immense guilt and developed suicidal tendencies, yearning to end her own life as penance. The incident also made her value human life as sacrosanct, willing to do everything in her power to protect others from harm, even from her own allies.[[4]](#cite_note-V4C4-4)

## Powers & Abilities

### Pre-Awakening

Originally, Akane was an ordinary human with no magic whatsoever.

### Post-Awakening

During the invasion of Magical Beasts in Japan, Akane gained magical abilities through human experimentation, becoming a superhuman referred to as a Knight. She is noted to be powerful even among other knights, potentially the strongest magic user on [Earth](Earth.md "Earth"). However, her abilities are still far inferior compared to those of the members of Shadow Garden, struggling against Magical Beasts that Shadow and [Beta](Beta.md "Beta") claimed were "small fry".[[4]](#cite_note-V4C4-4)

#### Swordsmanship

Akane wields a katana she infused with her magic and is proficient with it. Her magic-infused blade is capable of cutting down dozens of Magical Beasts in a single strike. Akane is also proficient enough that she can quickly cut a bullet from a gun.[MANGA ONLY]

#### Magic

Akane's magic is strong enough to easily blow away other Knights. Akane, however, primarily uses her mana by infusing it into her weapon to increase its cutting power drastically. However, her magic skills are still far inferior to members of Shadow Garden and even Crimson Order. Akane's magic manifests as a golden color.

#### Original Knight

Akane is actually the infamous Original Knight, having been injected with Magical Beasts' blood by her brother. When she enters her Original Knight state, Akane's hair turns changes to golden blonde and her magic becomes much stronger, able to shoot beams of light that can pierce through a person. She initially had no control over this state, attacking everyone in sight until her magic ran out and recalling nothing of what she did during that time.[[1]](#cite_note-V4E-1) However, after being taken to the other world, Akane began training to learn how to control her powers, eventually allowing her to access them without any problems.

### Intelligence

Prior to the death and reincarntion of Minoru Kageno. Akane could discern that he was never looking at her properly during the morning greetings. As if he's looking at something distance, looking through her. Following her second kidnapping, she was able to notice Minoru's change, as he properly remembered her name and was properly looking at her. Akane also discern that Minoru was like her, that he was living behind a mask.[[3]](#cite_note-:0-3)[[5]](#cite_note-:1-5)

Coming from the 21st century from [earth](Earth.md "Earth"), she understands her world's technology, which even Shadow Garden's most intelligent members struggle with. As a citizen of Japan, Akane can speak Japanese fluently. Akane can also read the Japanese language ranging from hiragana, kanji, katakana, and romaji. She can also recognize Japanese cuisines that were transplanted to another world such as miso soup and soy sauce. Akane can assess how proficient someone is in speaking Japanese. Conversely, Akane cannot read or speak the language of Midgar, but is currently learning the language.[[1]](#cite_note-V4E-1)[[2]](#cite_note-V6C5-2)

### Other Capabilities

Acting: Before the fall of Japan, Akane was noted to have been an up-and-coming child actress. During her time in high school, she resumed her work as an actress, starring in a drama film.[[5]](#cite_note-:1-5)

Handwriting recognition: Akane has shown that she can recognize Cid's handwriting from back when he was Minoru Kageno.[[2]](#cite_note-V6C5-2)

### Weapons and Equipment

- Katana: Akane's main weapon. She can infuse magic with her katana to enhance the cutting power of the blade.
- Hatchet: In the manga, Akane used a Hatchet in an instance as the Original Knight. This was during the destruction of Arcadia where her magical prowess went out of control and had caused her to go berserk.[MANGA ONLY][[6]](#cite_note-6)
- Baton: In the anime, Akane uses an extendable Baton.[ANIME ONLY][[7]](#cite_note-7)
- School Uniform: Standard equipment distributed to the Messiah's Knights as a means to distinguish them from their inhabitants. Once used to indicate a student's occupation and overall offers no noticeable protection whatsoever.

## Trivia

- The name Akane (アカネ) means "deep red" (茜) in Japanese.
  - It is named after the red dye obtained from the roots of the [Rubia plant](https://en.wikipedia.org/wiki/Rubia_cordifolia "wp:Rubia cordifolia").
- Akane's surname Nishino (西野) means "west," (西) (Nishi) and "field, wilderness" (野) (no).
  - The name Nishimura (西村), Minoru's initial mispronunciation of Akane's name, means "west" (西) (Nishi) and "town, village" (村) (mura).
  - The name Nishitani (西谷), Minoru's second mispronunciation of Akane's name, means "west" (西) (Nishi) and "valley, ravine" (谷) (tani).
- In the anime, Akane's eyes are red instead of black. Whether this is an oversight by [Nexus](Anime.md "Anime") is unclear.
- Akane is the second person to be healed by Cid before joining Shadow Garden after its debut.[[8]](#cite_note-8)

## References

1. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
2. Volume 6 Chapter 5: Welcome to the Shadow Garden!
3. Volume 4 Auxiliary Chapter: Rise of the Fancy Hoodlum Slayer! I
4. Volume 4 Chapter 4: Lurking in the Darkness in Fantastical Japan!
5. Anime Season 1 Episode 1: The Hated Classmate
6. [Manga](Manga.md "Manga") Chapter 50
7. Anime Season 2 Episode 12: HIGHEST
8. Volume 4 Chapter 6: Something Smells Fishy... But an Eminence in Shadow Always Cracks the Case!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • **No. 712** | |
