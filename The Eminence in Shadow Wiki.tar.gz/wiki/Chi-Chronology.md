# Chi/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Chi/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Chi/Chronology)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Chi/Chronology?action=edit).

[Main](Chi.md "Chi")

[Relationships](Chi-Relationships.md "Chi/Relationships")

Image Gallery

## Volume 6

### The Bloody Terror of Midgar

## Other Adaptations

### Master of Garden

#### Seven Shadow Chronicles

### [Anime](Anime.md "Anime")

### Web Novel

Chapter 187

### [Manga](Manga.md "Manga")

## References
