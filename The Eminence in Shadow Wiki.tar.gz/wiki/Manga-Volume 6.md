# Manga/Volume 6

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%206](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%206)

## Manga Volume 6

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041115640

### ISBN EN

ISBN 978-1975342722

### Release Date

June 25, 2021 JP
April 18, 2023 EN

## Volume Information

### Pages

144 JP
162 EN

### Chapters

4

Publication Order

| Previous | Next |
| --- | --- |
| Volume 5 | Volume 7 |

This is the sixth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

All eyes are on the Bushin Festival as the totally enigmatic Mundane Mann advances toward the finals, winning all his matches in an instant. Just who could this mysterious knight (who is certainly not mild-mannered Cid Kagenou in disguise) possibly be? However, beneath the festivities, a dark drama unfolds as Princess Rose goes on the run following her assault on her fiancé! Was the sordid affair simply a prenuptial argument gone too far, or is something more wicked afoot?[[1]](#cite_note-1)

「死ぬわアイツ」からの「アイツは一体何者なんだ!?」をやりたい！
陰の実力者設定を楽しむシド。最強剣士決定戦の「ブシン祭」に変装して出場し、「一見弱そうだが一瞬で勝利する謎の青年」として番狂わせを巻き起こす――！強大な力と重度の勘違いで突き進む最強奇譚、第６弾！[[2]](#cite_note-2)

## Summary

### God of War Tournament

After Rose escapes from the God of War Festival, [Alpha](Alpha.md "Alpha") would approach the fugitive princess to offer her the opportunity to join them to rescue the Oriana Kingdom against the Cult of Diablos. Upon Rose's acceptance, Alpha then guides the former student council president to their hidden base, Alexandria, where she entrusts their latest recruit to the instructor [Lambda](Lambda.md "Lambda") for training before departing.

## Chapters

- Episode 22
- Episode 23
- Episode 24
- Episode 25

## Characters

:   In order of appearance:

- Cid Kagenou
- Goldy Gilded
- [Quinton](Quinton.md "Quinton")
- Annerose
- Skel Etal
- Claire Kagenou
- [Epsilon](Epsilon.md "Epsilon")
- Rose Oriana
- Alexia Midgar
- [Beta](Beta.md "Beta")
- Iris Midgar
- [Beatrix](Beatrix.md "Beatrix") (Debut)
- Perv Asshat (Debut)
- Raphael Geerk Oriana (Debut)

## References

1. [The Eminence in Shadow, Vol. 6 (manga). YenPress](https://yenpress.com/9781975342722/the-eminence-in-shadow-vol-6-manga/)
2. [The Eminence in Shadow (6). Kadokawa](https://www.kadokawa.co.jp/product/322103001426/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • **Volume 6** • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
