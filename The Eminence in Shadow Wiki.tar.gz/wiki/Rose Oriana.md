# Rose Oriana

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Rose%20Oriana](https://the-eminence-in-shadow.fandom.com/wiki/Rose%20Oriana)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | Let's try to make a happy future a reality. | ” |
| — Rose, Light Novel Volume 02 | | |

## Rose Oriana

- Light Novel
- Manga
- Anime
- Game

### Japanese

ローズ・オリアナ

### Romaji

Rōzu Oriana

### Aliases

No. 666

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

17

### Height

Unknown

### Hair Color

Honey-Blonde

### Eye Color

Honey

### Birthday

August 7

## Personal Information

### Status

Alive

### Relatives

Raphael Geerk Oriana † (Father)
Reina Oriana † (Mother)
Clara Oriana (younger sister; WN)

## Professional Information

### Occupation

- Queen of Oriana Kingdom
- Princess of Oriana (formerly)
- Midgar Adacemy Student Council President (formerly)
- Numbers Member (formerly)

### Affiliation

- Shadow Garden
- Oriana Kingdom
- Midgar Academy for Dark Knights (formerly; expelled)

## Debut

### Web Novel

Chapter 31

### Light Novel

Volume 1

### Manga

Chapter 9

### Anime

Episode 4

### Game

Episode 4

## Portrayal

### Japanese

[Haruka Shiraishi](https://en.wikipedia.org/wiki/Haruka_Shiraishi "wp:Haruka Shiraishi")

### English

Donna Bella Litton

### French

Ludivine Maffren

### Italian

Giorgia Carnevale

### German

Alina Freund

Rose Oriana (ローズ・オリアナ, Rōzu Oriana[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the former student council president of Midgar Academy for Dark Knights, where she was Cid's upperclassman, as well as the princess of Oriana Kingdom. After being a victim of a plot by the Cult of Diablos, she joins Shadow Garden under the codename No. 666 and is later made her country's new queen following the "Black Rose Incident".[[1]](#cite_note-1)

## Appearance

Rose is a beautiful young woman with an athletic figure and a noticeable bosom, with bright honey-yellow eyes that match her long honey-blonde hair, with short bangs over her forehead and curls going down into spirals. After becoming the new queen of the Oriana Kingdom, Rose cut her hair to shoulder length. (In the anime, she cut her hair after joining Shadow Garden while in the manga she never cut her hair at all.)

In terms of attire, Rose often wore her school uniform with her black thigh-high socks with golden stripes and black loafers during her time at the Spellsword Academy. She also wore the school's sports uniform during practice and tournament events. As a civilian, Rose would wear something fashionable typical for a teenage young lady of her status.

After becoming a member of Shadow Garden, Rose started wearing the organization's standard Slime Bodysuit. She was quite skilled at manipulating it with her magic, capable of altering its shape and color to give it the appearance of a wedding dress. However, following her ascension to queen, Rose returned to dressing in ornate robes befitting her new station.

## Personality

Rose is depicted as an exceedingly kind, cool, strong, selfless, charismatic, and pure-hearted girl. Possessing a highly trusting personality, she readily places her trust in others, with the concept of deceit or lies absent from her understanding. These qualities align well with her royal lineage and dedication to serving with the purest of motivations, holding the distinguished title of Dark Knight. Demonstrating a robust sense of honor, Rose is willing to defend those who cannot protect themselves and holds admiration for individuals with unwavering determination. Despite being born into the highest echelons of society as a princess, she harbors no disregard or discrimination towards commoners. In her youth, she even clandestinely engaged with commoner children, concealing her true identity. Rose consistently exhibits respectful and considerate behavior towards everyone, exemplified when she grew to respect Cid for his resilience in their duel, despite repeated setbacks and significant injuries. Her admiration for Cid deepened when he risked his life to rescue her from terrorists attacking the school, leading to the development of romantic feelings for him.

After her rescue by the Stylish Bandit Slayer and seeing his beautiful swordplay, Rose views swordsmanship as more of an art form with wondrous potential than a hobby, with her most noteworthy trait being that she is very passionate about it. It's because of such passion that she pushed herself to excel in her tasks, but the same passion can lead her to make drastic decisions, such as after killing her father - although, it was an act of mercy, since he was suffering and being controlled, and it was thus the only option available to her to spare him further pain. Yet she does have the ability to grow, as after she learned the truth about her mother's relationship with Perv Asshat and motivated by Cid leaving her a wedding ring, she resolved herself to fight the Cult of Diablos and stop the Black Rose in order to save Oriana Kingdom. That resolve allowed her to take up the throne and lead as the next Queen of Oriana.

Rose shows emotional attachment to gifts she receives from her loved ones. When she joined Shadow Garden, Rose was really hurt when told to discard and forget everything, especially when [Lambda](Lambda.md "Lambda") destroyed the patty wrapper that Cid had given her, which left her heartbroken.

Upon becoming the new ruler of the Oriana Kingdom, she cuts off her hair to shoulder-length to show her resolve to become a ruler strong enough to defend her homeland from the Cult of Diablos. While the tole of rulership was great, Rose's steadfast love for Cid keeps her resolve absolute as she rebuilds Oriana Kingdom and coordinates with Shadow Garden in the proxy-war against the Cult.

## Powers & Abilities

Before her effective expulsion, Rose was considered to be the strongest student at Midgar Academy for Dark Knights, second only to Iris Midgar prior to the latter's graduation.[[2]](#cite_note-V1C5-2)[[3]](#cite_note-MV3C9-3) Following her training with Shadow Garden, she can now easily defeat Perv Asshat and subdue Magical Beasts that would otherwise take ten people to overpower. After becoming the new queen of the Oriana Kingdom, she also would have gained great political power but said power was limited due to Church condemnation and international sanctions.

### Swordsmanship

During her time as the Student Council President, Rose's skill with the sword was at the top of the academy, second only to Iris Midgar, when the latter was still a student.[CITATION NEEDED] Rose uses a white rapier molded from slime, different from the sword normally used by Dark Knights or Shadow Garden.

### Magic

Oriana possesses immense magical power, far superior to that of an average Dark Knight. She has masterfully used her magical power to focus her attacks.[Partial Language] Her magical power increased by being part of Shadow Garden, where she received a training to strengthen her abilities.[CITATION NEEDED]

### Physical Capabilities

In the anime, Rose's physical strength is great enough to easily subdue Claire Kagenou, despite having a dislocated shoulder.[[4]](#cite_note-AS1E4-4)[ANIME ONLY]

When she was a fugitive, Rose ran with little to no rest while suffering the pain of [Possession](Possession.md "Possession"), before being cured by Shadow. After joining Shadow Garden, Rose showed a remarkable growth. During the Red Moon incident, Rose was able to weather through damages from Blood Queen [Elisabeth](Elisabeth.md "Elisabeth")'s attacks and still stand back up and fight. When encountering John Smith, Rose was the only one on her team who was able to sense and avoid the magic threads and engage the masked adversary, before she was ultimately defeated along with her squad. When engaging [Mordred](Mordred.md "Mordred") during the advent of the Black Rose, she was able to parry and counter the ancient villain alongside her Shadow Garden companions until Shadow arrived to end the conflict.

### Weapons & Equipment

- Rapier Sword: Rose utilizes a Rapier sword in her combat art, being swift and nimble, and also developed from her practice emulating Shadow's sword style from his "Fancy Bandit Slayer" days.

- Slime Bodysuit: As an initiate within Shadow Garden, Rose used the bodysuit upon becoming 666 and has worn it during her tenure. Upon learning the suit's versatility, Rose could morph the suit into sleepwear or into her 666 uniform.

## Trivia

- The name Rose is derived from the Latin word Rosa.
  - Rose's surname Oriana means Gold, Sunrise, Dawn in Latin.
    - Likely a reference to her blonde hair, righteous character, and potential to bring light back to her kingdom.
- Excluding the Seven Shadows, Rose is one of the few healed of possession by Shadow. The others being [Victoria](Victoria.md "Victoria") and Claire.[[5]](#cite_note-5)[[6]](#cite_note-6)[[7]](#cite_note-7)
- After being healed by Shadow, her mana color changed from honey yellow to light green.[ANIME ONLY][[8]](#cite_note-8)
- Rose's real name and identity are an open secret among the members of the Shadow Garden. The only person who does not know about Rose's membership in Shadow Garden is Shadow himself.[CITATION NEEDED]
- Her assigned number in Shadow Garden, 666, is affiliated with John's biblical account of "the beast."
  - He compelled everyone—small and great, rich and poor, slave and citizen—to be branded on the right hand or on the forehead and made it illegal for anyone to buy or sell anything unless he had been branded with the name of the beast or with the number of its name. There is no need for shrewdness here: if anyone is clever enough, he may interpret the number of the beast; it is the number of a man, the number 666 (The Jerusalem Bible, Revelation 13:16-18).[[9]](#cite_note-9)

## References

1. Volume 4 Chapter 3: Crashing the Ceremony!
2. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
3. Manga Volume 3 Chapter 9
4. Episode 4
5. Volume 1 Chapter 1: Starting The Shadowbroker Tutorial
6. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
7. Volume 4 Prologue: It's Time for a War in the Oriana Kingdom!
8. Episode 17
9. The Jerusalem Bible. Doubleday, 1966. Print

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | **Rose Oriana** | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • Alexia Midgar • Christina Hope • [Isaac](Isaac.md "Isaac") • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • **No. 666** • [No.711](Millia.md "Millia") • No. 712 | |
