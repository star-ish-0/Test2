# Mitsugoshi Company

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mitsugoshi%20Company](https://the-eminence-in-shadow.fandom.com/wiki/Mitsugoshi%20Company)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Mitsugoshi Company

### Japanese

ミツゴシ商会（しょうかい）

### Romaji

Mitsugoshi Shōkai

### Aliases

Shadow Garden

## General Information

### Leader(s)

[Luna (Gamma)](Gamma.md "Gamma") (Public CEO)
[Alpha](Alpha.md "Alpha") (Covert Overseer)
Shadow (Oblivious Actual Owner)

### Status

Active

### Affiliates

Shadow Garden (Covert)
Snow Fox Corporation (Public Trading Partner)
[Yukime](Yukime.md "Yukime") (Underworld Ally)

### Base of Operation

Midgar Kingdom

## Debut

### Web Novel

Chapter 23

### Light Novel

Volume 1

### Manga

Chapter 7

### Anime

Episode 6

Mitsugoshi Company (ミツゴシ商会（しょうかい）, Mitsugoshi Shōkai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a relatively new, but highly successful multi-trade company. They are known for their innovative products and quickly becoming the largest commercial trading enterprise with a significant global reputation. Their public acclaim is due to their business empire having progressed in the industrial, extractive, real estate, banking, hospitality, infrastructure, and technology development sectors. The company progressed for three years until it became a worldwide, international mega-corporation, with influence over several nations due to their involvement in supplying the people.

Unbeknownst to the public, Mitsugoshi Company is operated by Shadow Garden as their primary front, managed by [Luna](Gamma.md "Gamma") as the company's director, who secretly founded it with help from [Alpha](Alpha.md "Alpha"). The establishment of this company was inspired by the knowledge given to them by Shadow, which actually comes from [Earth](Earth.md "Earth") as they were able to recreate modern products and then traded recreations of goods until they gained enormous wealth. Thanks to their unique goods having sold well with buyers, considered to be "revolutionary" qualities, their brand is considered a trend and beloved by all people. The company has also created banknotes to be used as a popular currency by the populace in order to speed up their financial processes, until they could build their own bank for monetary transactions and loans. In addition, Mitsugoshi even promotes all types of business commodities and ventures that they own, which are favorites with visitors, as well as introducing all kinds of entertainment for customers who come to visit until Mitsugoshi gained popularity in the public society.

This company is used as an important asset for funding Shadow Garden's missions as well as their employees, the Numbers. Mitsugoshi became a fundraising base in storing their wealth to increase their source of financial income, which became a vital place for building Mitsugoshi's foundation until the company has advanced considerably in order to consolidate their power against the Cult of Diablos by eliminating their influence. Mitsugoshi has reaped success with astounding product sales rates in conducting trade, both in urban and rural areas, accompanied by a high demand to trade their merchandise to the general public and conglomerates, even nobility, until Mitsugoshi's "new" commerce system had made progress on the economy in the Midgar Kingdom.

While the company has grown rapidly with the spread of their influence to foreign countries, requiring them to further expand their business by constructing branch offices in every country they reach. Mitsugoshi had competed with the Major Corporate Alliance, which was formed with the intent on preventing Mitsugoshi from selling their merchandise. This resulted in covert continuous conflicts in the struggle for trading district, all through sabotage in their distribution chain until a trade war over the marketplace in the region began. Amidst the conflict, Mitsugoshi was the first to realize counterfeit bills of the MCA's currency was already circulating and conducted their own investigation into the source. Concurrently, Shadow had collected a large amount of gold coins in secret by working together with [Yukime](Yukime.md "Yukime"), triggering the credit collapse.

Shadow Garden then learned the true purpose of Shadow's plan in hiding his identity by posing himself as "John Smith" and moving independently was to remove any clues linking their secret connection with Mitsugoshi. This prevented Shadow Garden's affiliation from being revealed to the public, and after translating the encoded letter, his message contained the location of where he hoarded the large stash of zeni coins. Shadow Garden kept the gold in order to replenish their reserves, able to weather the crisis, and successfully ensured Mitsugoshi Company's credibility would not falter.

As the credit collapse concluded, Mitsugoshi Company had survived the verge of bankruptcy and successfully regained the people's trust in banknotes after adequately conducting the money transactions on their gold coins. Knowing the MCA's inevitable swift fall, Mitsugoshi bought all of their assets and won the regional trade war. With a predetermined outcome, Mitsugoshi took advantage of the MCA's downfall to eliminate their chief competitors, gaining monopoly rights to fully control the market and elevate their position until it became unassailable within the Midgar Kingdom. From their heights, Mitsugoshi brought unprecedented prosperity, and later formed a partnership with the Snow Fox Corporation.

## Overview

The foundation of this company was established when [Gamma](Gamma.md "Gamma") intended to start a business after acquiring shares from the Luna, Ltd. and continue to develop in promoting the commodity products that are so well known to the citizens. After eventually changing the company name to Mitsugoshi, Gamma has implemented a marketing business strategy that can increase their financial resources.

In the early years, Mitsugoshi Company has made progress after their efforts have been fruitful in peddling their wares to reap such huge profits by causing various revolutions from citizens spending their money to purchase products from Mitsugoshi. Furthermore, with the creation of paper money as a substitute for gold coins, Mitsugoshi has built a bank to be used as an investment in running a money creation system to control the banking financial process.

Also, the company has run several types of businesses that they have developed for being able to attract visitors as a business opportunity and make large investments. As a result, Mitsugoshi Company quickly rises to prominence in the capital and has attracted the public attention to the point of being recognized as the world's most thriving company for their fascinating merchandises with prime quality.

## History

While managed by Gamma/Luna, who founded the company and has been operating it since its inception, the company's directorship rests with her. She has received assistance from Alpha and has utilized resources from the ancient city of Alexandria. Notably, the current ruler of Alexandria is none other than Cid Kagenou/Shadow himself, as appointed and acknowledged by the Mist Dragon. This makes Cid Kagenou/Shadow the true owner and leader of both the company and all its subsidiaries.

Gamma/Luna undertook these endeavors with the specific intention of fulfilling Cid Kagenou/Shadow's happiness and realizing his dream of expanding the Shadow Garden to its utmost potential. Paradoxically, Cid Kagenou/Shadow remains entirely absorbed in his own delusional fantasy, to the point where he fails to recognize the true magnitude of the Shadow Garden. Furthermore, he remains completely unaware of the existence of the city of Alexandria, let alone his own status as its ruler and the leader of the Shadow Garden and the Mitsugoshi Company.

Cid/Shadow continues to believe that the Shadow Garden consists solely of the seven actual shadows, who, now pursuing their own dreams independently, occasionally engage in role-playing dramas as a sign of their gratitude and respect towards Cid/Shadow for freeing them from demonic possession. Unbeknownst to him, the Shadow Garden extends far beyond these limited confines. In fact, it has evolved into a vast organization created on a whim or by accident, operating on a global scale. Similarly, Cid/Shadow remains ignorant of Alexandria's existence and the extent of his influence as one of the most powerful figures orchestrating events behind the scenes.

Cid/Shadow, as the leader of Shadow Garden and Mitsugoshi, unknowingly holds immense power and influence over the world. He unknowingly controls politics, warfare, decision-making, and economics. Additionally, he remains unaware of his vast ownership of numerous stores and his status among the world's wealthiest individuals.

## Products

The company has branches in every major city also the capital, within and outside of Midgar Kingdom, as Mitsugoshi produces to sell various kinds of products which are all based on the "Shadow Wisdom" from their leader, Cid Kagenou.

Using his wisdom as the basis, they were able to recreate various products with novel and fascinating qualities, which include chocolate, one of their most popular products. Another popular product is the business suit, a trend for nobility which was more stylish than the traditional noble garb.

From a full carriage filled with Mitsugoshi products, millions of Zeni can be generated from the sum of their budget amount in terms of market prices.

### Their lines of products include:

- Candy
- Chocolate
- Clothing/Accessories
- Coffee
- Cosmetics
- Daily goods
- Gourmet/Preserved foods
- Lingerie
- Liquor
- Soap
- Shoes
- Suits
- Tea
- Whiskey
- Uniform
- Underwear (especially for women)

In addition, many of Mitsugoshi Company's popular products have qualities that could not be imitated by similar products through unknown manufacturing methods that no one knows. Not even the Major Corporate Alliance could copy Mitsugoshi's way of making products. Although the Snow Fox Corporation has the right to plagiarizing their designs, it could only be able to replicate a small fraction of their products.

## Banking

Aside from commercial products, Mitsugoshi also established the "Mitsugoshi Bank" (ミツゴシ銀行（ぎんこう）, Mitsugoshi Ginkō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), issuing banknotes for the first time, causing a revolution on the monetary value as Mitsugoshi began printing promissory vouchers in exchange for the world's coin-based system.

Mitsugoshi Bank banknote bills are simple-yet-elaborate with serial numbers and watermarks, compared to Major Corporate Alliance's which attempts to mimic the process of making banknotes with a flashy-yet-sloppy bill with a less detailed design despite having a serial number, but no watermark that are so simple as to make counterfeits.

This was based on the bank and credit economic creation system that Cid once talked about to Gamma. The main reasons they produced the banknotes was to stimulate the economy and sell more products, while also incentivizing patrons due to the ease bills exchange compared to hefting large coin purses or troves.

Also, banknotes are made with the same value as real money and are used as deposit slips which can be used in transactions to take money loaned from a bank and liquidate it. Furthermore, Mitsugoshi is incentivized to cash in on the capital’s prosperity. By using the power of credit creation, the thousands of Zeni in their vault multiplies countless times over and thanks to the capital’s economic boom, Mitsugoshi Bank gets to rake in the interest.

Mitsugoshi then created a revolving loan service with an interest rate on loans of around 2% per month, equaling 24% per annum, the lowest rate among money lenders in the capital.

## Profit Income Result & Company's Power of Influence

Although the company was relatively new at first, Mitsugoshi had continued to progress steadily towards success until it grew into a large commercial company thanks to Gamma by remaking all kinds of products from the knowledge of her Master, Shadow.

From the net profit income generated, the Mitsugoshi Company is able to get large and abundant profits on product sales and the profit turnover that Mitsugoshi has so far can reach millions to billions, even trillions of Zeni from the income in the sale of their product until the company's market price has soared and increase exponentially. As a result of the revenue generated from market profits which has made the company's distribution continues to grow at a faster rate, there is already a high demand for trading Mitsugoshi merchandise due to its popularity.

The Mitsugoshi Company currently had developments in expanding their business to operate in many countries and even had branches in these countries until their company gained fame and became one of the most famous companies in the Midgar Kingdom. With Mitsugoshi's global expansion, the company had accumulated a vast amount of wealth and wielded a large sphere of influence over the world, that even the Cult of Diablos regarded the company as their threat.

## Enterprises Development

The Mitsugoshi Company has made several types of business ventures that they have developed into popular tourism traps. Based in part on "Shadow Wisdom", these are business ventures that appeal to commoners as well as nobility, with eateries for delicious cuisine to public lodgings for travelers, as well as relaxation locales for decompressing stress and improving beauty hygiene.

- Beauty salons
- Cafes
- Hotels
- Massage parlors
- Restaurants
- Saunas
- Spa resorts

## Infrastructure and Industrial Business Opportunity

The Mitsugoshi Company has planned to invest in each venture and putting its myriad techniques to be use in the industry. Mitsugoshi has shown their sheer degree of engineering prowess in the construction industry where they have succeeded in creating artificial walls called “reinforced concrete".

Mitsugoshi has even developed a manufacturing process by creating high-end chandeliers whose lamps are made from specially cut, highly transparent crystal glass to which their glow casts radiant shadows across the hallway. The cheapest models cost 10 million Zeni but sells off quickly from the shelves like there’s no tomorrow.

Also, Mitsugoshi has been running the mining industry by processing its natural resources in kinds of ores and minerals.

## Franchise Restaurants

The McRonald (まぐろなるど, Maguronarudo[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Tuna King in the Light Novel and Anime) is a burger shop that has chain stores all over the world, and like Mitsugoshi Company, this is also a front company of Shadow Garden. When Mitsugoshi Company was Luna, Ltd., it was developed as a street shop to obtain funds for its activities.

Prior to the founding of the Mitsugoshi Company, Gamma was worried that her business was not growing and confused about finding a solution because Shadow Garden lacked reserve funds due to [Eta](Eta.md "Eta")'s continued excessive use of funds which caused the financial process of Luna, Ltd. which was managed by Gamma to experience a drastic decline. However, Gamma was able to overcome her company's financial problems thanks to [Zeta](Zeta.md "Zeta")'s help, who invited her and Eta to a beach near the capital city of Midgar to take a break and at that time, they created a food made from the sea, called "Tuna Sandwich" which describe like a fried tuna sandwich with tartar sauce made based on "Shadow Wisdom", and later improved the tuna burger, which became a big hit.

After getting the idea of a business opportunity to increase Shadow Garden's financial funding and the company it manages using food that Gamma knows, she set up a tuna sandwich stall in the capital as a side business that functions as a food stall and eventually opened a permanent store which provides different food menu items other than tuna like sea bream, squid rings, beef, and onion rings with the sauce additions like mayonnaise, tartar sauce, and malt vinegar. By the conclusion of her venture setup, the sandwich shops were named McRonald/Tuna King by Cid.

When Gamma acquired shares of an existing business in Midgar Kingdom, in addition with the opening a new venture of McRonald/Tuna King stalls across the capital as a new side business branch, Shadow Garden's income rate had continued to increase with the net profit of 25 million Zeni per month, compared to the 4 million Zeni on the fashion side. Until eventually, Gamma expanded the venture side business into a developed food chain stores and gained a huge amount of wealth.

Currently, it is being developed separately from Mitsugoshi Company, but Gamma's personal ultimate goal is to make burgers using beef.

## Layout

The Mitsugoshi branches, despite being in different cities, follow a similar layout for easier navigation and inventory. At the top of the Midgar Branch building, and every other store, a mansion is set up on the roof as a Shadow Garden operation room, and in addition to setting up a throne for Shadow. The rooftop mansions also serve as residential quarters for the Seven Shadows and their immediate attendants.

In the anime version, the statues of Shadow and "Seven Shadows" are displayed in the atrium-style hall of the royal capital head office, and the mansion on the roof is hidden by a raised wall that extends the outer wall upwards, and when viewed from the ground, it is a mansion. The structure is such that the is not visible.

## Known Personnel

### Main Executive Committee Board

- [Luna](Gamma.md "Gamma"): Public Founder and Company President
- [Alpha](Alpha.md "Alpha"): Chairwoman, not publicly known as such.
- Cid Kagenou: Owner of all shares, even though he himself is unaware of it.

### Heads of Departments and Offices

- [Eta Lloyd Wright](Eta.md "Eta"): Research and Development department
- [Novem Silva](Iota.md "Iota"): PR (Public Relations) Department
- [Alpha](Alpha.md "Alpha") (under unknown alias): Mercenary Services Department[[1]](#cite_note-1)[[2]](#cite_note-2)

### Employees

- [Renu](Nu.md "Nu"): Gamma's Personal Aid & Bodyguard.
- [Chi](Chi.md "Chi")
- [Omega](Omega.md "Omega")
- Staff: Shadow Garden Numbers operating as store employees.

### Colleagues

- [Natsume Kafka](Beta.md "Beta"):
- [Shiron](Epsilon.md "Epsilon"):
- [Yukime](Yukime.md "Yukime"):

## Trivia

- Mitsugoshi Company is based on real life [Mitsukoshi](https://en.wikipedia.org/wiki/Mitsukoshi "wp:Mitsukoshi"), just renamed as parody offshoots.[CITATION NEEDED]
  - The store interiors of Mitsugoshi branches closely mirror the real-world supermarkets and shopping malls of Shadow's past life. This is due to Cid having taught the Seven Shadows about architecture and construction of his old life as well, especially to [Eta](Eta.md "Eta").

- Mitsugoshi work uniform is a short and simple navy-blue dress marked with the company logo, which is similar to what flight attendants wore back in Cid's past life that reminds him of it.[[3]](#cite_note-V1C4-3)

- The restaurant brands that Gamma's Mitsugoshi Company owns are based on real-life fast-food chains such as [McDonald's](https://en.wikipedia.org/wiki/McDonald%27s "wp:McDonald's") and [Burger King](https://en.wikipedia.org/wiki/Burger_King "wp:Burger King"), just renamed as parody offshoots.[CITATION NEEDED]
  - During the conflict between the Mitsugoshi Company and the Major Corporate Alliance, the McRonald/Tuna King doesn't get involved, probably because the field is different from the Mitsugoshi Company.

- In Other World, Tuna is a fish that can be easily eaten by common people because of its large quantities and easy to catch and "Sea Bream" is more valuable as a high-class fish. Also, Beef is treated as a luxury ingredient and livestock technology is not yet available which is still immature, even it seems that there is still no stable supply and not possible to provide it stably.[CITATION NEEDED]

- In the Web Novel, Mitsugoshi's product technology and creativity are all innovative with very broad fields, to the point of arousing suspicion from [Gettan](Gettan.md "Gettan") who thinks where ideas, technology, and the ability to combine them flexibly come from, and it's hard to believe that a new company that has only been established for a few years can do something like this, who frankly stated that their methods weren't something a mere company could manufacture to the point of thinking that something big was mysteriously lurking behind the Mitsugoshi Company.[[4]](#cite_note-WN122-4)

## References

1. Edge of Realm Ch. 1: The World Will Find Out | Kagemasu: Seven Shadows Chronicles Story
2. Edge of Realm Ch. 4: Activate! Slime Nightmare !| Kagemasu: Seven Shadows Chronicles Story
3. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
4. Chapter 122: The Malaise of Mitsugoshi

## Site Navigation
