# Victoria/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Victoria/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Victoria/Image%20Gallery)

[Main](Victoria.md "Victoria")

[Chronology](Victoria-Chronology.md "Victoria/Chronology")

[Relationships](Victoria-Relationships.md "Victoria/Relationships")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Victoria's profile in English

Victoria's profile in Japanese

Victoria Anime Episode 20/ First season

Victoria Anime Episode 20/ First season, part 2; training at the Shadow Garden base, in Alexandria.

Profile-Victoria Game.

Victoria and Zeta.

Victoria in-game render

Victoria in-game render

Victoria - The Saint - (game)

Merciless Blade: Victoria (with blood)

Merciless Blade: Victoria (without blood)

Bashful Summer Madness: Victoria

Victoria, Rose Oriana and Epsilon - game - Event: "Special mission! In search of the best osechi"

Victoria/No. 559 in Kimono attire: In-game event

The Chronicles ch.40

Victoria/559 - school uniform: uniform event promotion

Shadow Walker: Victoria

Demonic Fanatic: Victoria

Chronicles of the 7 Shades: Victoria, in casual wear and on deck, wants to sadistically kill Cid's mob friends.
