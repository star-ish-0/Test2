# Glen

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Glen](https://the-eminence-in-shadow.fandom.com/wiki/Glen)

[Chronology](Glen-Chronology.md "Glen/Chronology")

[Relationships](Glen-Relationships.md "Glen/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | I am Glen, the Lion’s Mane, vice commander of the Crimson Order. | ” |
| — Glen state his name to [Rex](Rex.md "Rex"), Light Novel Volume 01 | | |

## Glen

### Japanese

グレン

### Romaji

Guren

### Aliases

Lion's Mane

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Brown

### Eye Color

Brown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Vice-Commander of the Crimson Order

### Affiliation

Knight Order (Formerly)
Crimson Order

## Debut

### Web Novel

Chapter 22

### Light Novel

Volume 1

### Manga

Chapter 7

### Anime

Episode 5

## Portrayal

### Japanese

Shōta Yamamoto

### English

Andrew Love

### French

Frédéric Souterelle

### Italian

Davide Fazio

### German

Christopher Kussin

Glen (グレン, Guren[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), known as the Lion's Mane (獅子（しし）髭（ひげ）, Shishihige[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a dark knight who serves as the Vice Commander of the Crimson Order. On carrying out a mission to guard Sherry Barnett, he was killed by [Rex](Rex.md "Rex")—a named First Child from the Cult of Diablos. The empty position was later filled by [Adder](Adder.md "Adder").[[1]](#cite_note-V1C6-1)[[2]](#cite_note-V5C2-2)

## Appearance

Glen was a muscular man with a "beard as bushy as a lion’s mane" and a large scar across his cheek. He wore the standard green Knight Order uniform, but the outfit changed to red after his enrollment into Crimson Order under Princess Iris Midgar.[[3]](#cite_note-V1C4-3)

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Magic isn’t everything. If I’m fighting a weakling, I can easily dodge any attack. | ” |
| — Glen, Light Novel Volume 01 | | |

Glen was a noble and honorable man. He showed an unhesitatingly willingness to sacrifice himself to uphold the Crimson Order.[[4]](#cite_note-V1C*-4)

## Powers & Abilities

As a trained Dark Knight, Glen demonstrated a basic understanding of swordsmanship. This expertise exceeded the average warrior, displaying praise-worth strength capable of parrying a magic-infused attack without magical enhancements. However, the absence of magic severely handicapped Glen, and he could only offer a "feeble" resistance.[[4]](#cite_note-V1C*-4)

## Trivia

## References

1. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
2. Volume 5 Chapter 2: Shocking Morning, School Skewer Murder Case!!
3. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
4. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School

## Site Navigation
