# Zack

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Zack](https://the-eminence-in-shadow.fandom.com/wiki/Zack)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Zack?action=edit).

## Zack

### Japanese

ザック

### Romaji

Zakku

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Oriana Kingdom (Prisoner)

## Debut

### Web Novel

Chapter 147

### Anime

Episode 29 (Flashback)

Zack (ザック, Zakku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a prisoner in the Oriana Kingdom.

## Appearance

## Personality

## Chronology

## Relationship

### Cid Kagenou

## Trivia

## References

## Site Navigation
