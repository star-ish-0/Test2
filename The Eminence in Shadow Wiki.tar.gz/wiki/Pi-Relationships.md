# Pi/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Pi/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Pi/Relationships)

[Main](Pi.md "Pi")

Chronology

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

Just as with the other members of Shadow Garden, Pi holds their leader in the highest of regards. In their first encounter, she lay down in a pose of submission to signify her respect for him. Knowing he is the boss of her [boss](Delta.md "Delta"), she strives to earn his recognition. She wants Shadow to raise the strongest clan in the world for domination.

### [Delta](Delta.md "Delta")

Pi works as a direct subordinate of Delta. They seem to be quite friendly with one another as canine [Therianthrope](Therianthrope.md "Therianthrope") and share the ideal to make Cid Kagenou the chief of the strongest clan for world domination.
