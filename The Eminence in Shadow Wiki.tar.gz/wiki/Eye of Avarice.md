# Eye of Avarice

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Eye%20of%20Avarice](https://the-eminence-in-shadow.fandom.com/wiki/Eye%20of%20Avarice)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

The Eye of Avarice (強欲（ごうよく）の瞳（ひとみ）, Gōyoku no Hitomi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is an ancient artifact item that has been created by an ancient magical civilization to absorb and gather magic from its surroundings inside the artifact.

## Overview

This artifact is inscribed with ancient symbols that are exceedingly intricate and challenging to decipher, requiring the expertise of a seasoned researcher in ancient texts.

Furthermore, while this artifact can be utilized as a weapon, it possesses a limitation in terms of its ability to store magic for extended periods. Nevertheless, it proves highly effective in the short term, even if its capacity to retain power is limited.

To overcome the artifact's deficiency in autonomous movement, a control unit is incorporated. When the artifact is properly connected to the control device, it becomes fully functional, eliminating its limitations and enabling it to store magic for short-term usage.

The true potential of the Eye of Avarice is realized when all the constituent parts are combined with the control unit. This amalgamation grants the wielder an immense surge of magical power, transcending all restrictions, and even possesses the ability to alleviate ailments.[CITATION NEEDED]

## History

This artifact was discovered by the former 12th seat Knight of Rounds, Lutheran Barnett who wanted to perfect the artifact so that his illness could be cured by taking advantage of both Lukreia and Sherry Barnett's help that he could research the artifact to its completion.

## Functions

- Magic Absorption Storage: The Eye can absorb and collects the magic around it. When it’s activated, it’s harder to hone magic in the area.
- Magic Blocking Field: The Eye can make a field that can blocking any magic on the user, except it has been programmed the Eye to recognize the magical wavelength and be able to use magic inside the field. The control device has the power to temporarily disable the Eye magic blocking field by altering it only preparing the mithril tweezers, the bone powder of earth dragons, and the enchanted stone of ash, etc. Then, bring the activated control unit closer to the Eye.

## Similarities

The Eye of Avarice fulfills similar functions as the core of the [Sanctuary](Sanctuary.md "Sanctuary"), with the difference that the core of the Sanctuary is superior in terms of absorption capacity and potential than the artifact.[CITATION NEEDED]

## Weakness

This artifact cannot absorb microscopic magic particles, and neither can magic energies that are too solid and toughened to the point of being impossible to absorb, including very powerful explosive energies, which exceed the absorption level of the artifact. This was seen when Cid was able to exercise his magic on a minuscule level without problem after faking his death inside the absorption dome of the "Eye of Greed", when the cult decided to attack the Midgar Academy.[[1]](#cite_note-1)

## References

1. Episode 8
