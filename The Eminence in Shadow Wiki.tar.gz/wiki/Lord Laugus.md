# Lord Laugus

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lord%20Laugus](https://the-eminence-in-shadow.fandom.com/wiki/Lord%20Laugus)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Lord_Laugus?action=edit).

## Lord Laugus

### Japanese

ロード・ラワガス

### Romaji

Rōdo Rawagasu

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- City Chancellor
- 11th seat of the Knights of Rounds (Former)

### Affiliation

[Laugus](Laugus.md "Laugus")
Cult of Diablos (Deserted)

## Debut

### Game

Truth Seekers

Lord Laugus (ロード・ラワガス, Rōdo Rawagasu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets"))

## Personality

## Biography

## Powers & Abilities

## Trivia

## References

## Site Navigation
