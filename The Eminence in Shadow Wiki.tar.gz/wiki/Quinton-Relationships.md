# Quinton/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Quinton/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Quinton/Relationships)

[Main](Quinton.md "Quinton")

[Chronology](Quinton-Chronology.md "Quinton/Chronology")

Image Gallery

### Mundane Mann / Shadow

When the two met, Quinton viewed Mundane as a weakling. However, he was shocked that Mundane proceeded to easily progress through the tournament.[[1]](#cite_note-V2C4-1) Refusing to admit that Mundane was strong, Quinton was eager to face him to prove that he was a fraud only to be knocked down instantly.[[2]](#cite_note-V2C5-2) Quinton later learned that Mundane was the infamous Shadow.[[3]](#cite_note-3)

### Annerose Nichtsehen

Their interactions are limited though expansive enough to elaborate. The Bushin Festival veteran seemed to have recognized her abilities when she stepped in stop his onslaught on Mundane.[[1]](#cite_note-V2C4-1) During Mundane's bout with Goldy, the two tried analyzing his movements with the swordswoman being barely able to see them. Alas unlike the Veteran, she would overanalyze them and embarrassed herself when she tried replicating them.[[2]](#cite_note-V2C5-2)

### Goldy Gilded

Despite having to know each other for a short time, the two bonded and quickly became friends. When the former veteran was defeated by the hands of the White Demon, the formerly known "Undefeated Legend" tried escaping the Lawless City effectively abandoning him.[[4]](#cite_note-:0-4) Alas, he too would ultimately be taken down the anarchic nature of the town and became a slave alongside his friend.[[5]](#cite_note-:1-5)

### White Demon

Unaware of his infamy, the veteran underestimated the psychotic gatekeeper and was ultimately defeated.[[4]](#cite_note-:0-4) This defeat resulted in both he and Goldy's enslavement during the Red Moon incident.[[5]](#cite_note-:1-5)

## References

1. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
2. Volume 2 Chapter 5: A Battle to Attract Only MVPs!
3. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
4. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
5. Volume 3 Chapter 1: Lawless City Bandit Hunting!
