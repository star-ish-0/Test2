# Kagejitsu - Episode 4

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%204](https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%204)

## Operation 4

## Special Title

### English

The Seven Shades want to procure the legendary coffee!

### Kana

七陰は伝説のコーヒーを手に入れたい！

### Romaji

Shichi kage wa densetsu no kōhī o te ni iretai!

## Episode Information

### Season

1

### Episode

4

### Air Date

November 16, 2022

### Adapted From

Light Novel

## Staff

### Director

Minoru Ashina

### Writer

Daisuke Aizawa

Episode Navigation

| Previous | Next |
| --- | --- |
| Operation 3 | Operation 5 |

Operation 4 is the fourth episode of the spin-off series [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu").

## Summary

The relaxing atmosphere changes to hecticness as [Delta](Delta.md "Delta") bounds into the room. She hurriedly asks the stoic [Gamma](Gamma.md "Gamma") for a piece of chocolate, claiming binge eating offers an adequate coping mechanism for irritation. Gamma, placing her coffee cup down, asks the reason for her mood. The dog growls out the guilty party's name, Po Tato and Skel Etal. They have been spreading rumors that Cid is a "poop leaker," and Delta declares her refusal ever to forgive the pair. Gamma reasons that there must be a good reason behind Shadow's decision, but Delta avers there are no redeeming qualities to be perceived as a poop leaker. Even Gamma has a hard time understanding the purpose of fecal incontinence rumors, and Delta reiterates that he is not a poop leaker. A biting voice complaining about the choice of discussion interrupts Delta's ravings. Zeta, ignoring the shouting Delta, reports she has procured the requested item but is unsure of the purpose of it. Impressed by her swift acquisition speed, Gamma explains that the purpose is to make coffee. As explained by Shadow, some cats have difficulty digesting coffee, and the effect makes a delightful drink. Zeta admires their master's ideas, as poop does not usually equate to items one would usually drink. With the discussion of poop back, Delta hounds Zeta for talking about a subject she just forbade. She explains that it is different as it concerns a mission. The odor causes Delta to recoil, even though it was dried or cleaned. Gamma believes it smells pleasant—much to Delta's incredulity. She dismisses cats' weak noses, but Zeta retorts that dogs have inferior brains. Gamma asks them to stop playing for a while, causing a unison response of denial. A chocolate parley temporarily halts hostility.

## Characters

- [Gamma](Gamma.md "Gamma")
- [Delta](Delta.md "Delta")
- [Zeta](Zeta.md "Zeta")
- [Eta](Eta.md "Eta")

## Gallery

## Trivia

- Zeta's acquisition of the coffee mirrors a similar product on earth. Civet coffee—kopi luwak in Indonesian—is the coffee bean fermented by the Asian palm civet digestion and defection. Many gourmands and researchers regard it as the rarest and most expensive coffee in the world, costing between 200 and 400 USD per kg. Whether it tastes good is less of a consensus.[[1]](#cite_note-1)
- The official subtitles refer to Po and Skel by their Japanese names, Jaga and Hyoro.

## References

1. [N. D’Cruze, J. Toole, K. Mansell, and J. Schmidt-Burbach, “What is the true cost of the world’s most expensive coffee?,” (2014, Ory), vol. 48, no. 2, pp. 170–171.](https://www.cambridge.org/core/journals/oryx/article/what-is-the-true-cost-of-the-worlds-most-expensive-coffee/7C883DA427A9B6B5F8D795C511648B20)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • **Episode 4** • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
