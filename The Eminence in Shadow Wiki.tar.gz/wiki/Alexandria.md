# Alexandria

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Alexandria](https://the-eminence-in-shadow.fandom.com/wiki/Alexandria)

CLEANUP: ONLY YOU CAN IMPROVE THE WIKI!

You do not need to have peregrinated around Midgard or experienced dimensional travel help here. Shadow Garden encyclopedists have marked this page to be cleaned up by the community. You can assist the wiki by proofreading or checking if this article follows our standards and layout guide. Your contributions will make the wiki better for everyone in this community.

## Alexandria

### Japanese

アレクサンドリア

### Romaji

Arekusandoria

## Location Information

### Leader

Shadow

### Status

Active (hidden)

### Affiliates

Shadow Garden (Residents)
Mist Dragon (City Protector)

### Type

Ancient Capital City

### Government

Unknown

### Location

In the far East of the Midgar Kingdom, beyond the Abyss Woods outside the Kagenou lands.

### Inhabitants

Shadow Garden

## Debut

### Web Novel

Chapter 88

### Light Novel

Volume 2

### Manga

Chapter 6.2 - Seven Shadows Chronicles

### Anime

Episode 20

### Game

Seven Shadows Chronicles: Chapter 2

Alexandria (アレクサンドリア, Arekusandoria[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) served as an ancient capital until Alexandria's residents met demise, resulting from an encounter with the vengeful Mist Dragon. The city's downfall was triggered by an ancient king who had failed to honor a solemn vow to slay the Mist Dragon, thereby incurring the creature's wrath.[[1]](#cite_note-1)

However, through the passage of centuries, the city's ruins gained new significance as they became the central base of operations for the Shadow Garden. This transformation occurred after Shadow triumphed over the vengeful Mist Dragon in an epic battle, earning its respect and allegiance.

## History

Long ago, the king of Alexandria formed a sacred pact with the Mist Dragon, who bestowed prosperity upon the city and safeguarded it with his mystical mist. In return, the dragon asked that one day the king or his rightful descendant would fulfill their end of the bargain by granting him a death.[CITATION NEEDED]

However, as centuries passed, the once-honored pact faded from memory, and the king's descendants succumbed to greed and corruption, forsaking their duties and responsibilities. Instead of striving to grow stronger, they squandered the city's prosperity for their personal gains.[CITATION NEEDED]

In response to this broken vow and the kingdom's descent into darkness, the Mist Dragon decided to put the people's worthiness to the test. In a fateful night, the dragon's overwhelming force descended upon the capital, bringing ruin and devastation upon the city and its inhabitants. The capital, along with the king's descendant, fell before the might of the Mist Dragon's wrath.[CITATION NEEDED]

Following the destruction, the Mist Dragon took refuge within the fallen city, turning it into his resting place. Alexandria's existence became shrouded in mystery and obscured by the poisonous mist emanating from the Abyss Woods, making it a legendary folklore among the people, unsure if the city still stood or if it had been lost forever.[CITATION NEEDED]

## Location

It was a legendary capital, said to be far east of the Sacred Land [Lindwurm](Lindwurm.md "Lindwurm") at Midgar, beyond the Abyss Woods. It's a natural stronghold, surrounded by steep cliffs on three sides and to the west of the Abyss Woods, which is protected by the Mist Dragon's deadly poison mist.

It was located in the middle of the Abyss Woods, a place where there was a bluish-purple mist that was extremely thick, poisonous, and impenetrable to sunlight. This forest is not known exactly where it is located, but the rumor has it that anyone who enters it can never return, which is a perfect location to become the hidden headquarters for Shadow Garden organization.

## Layout

Alexandria is described as a very beautiful city, with a magnificent white castle standing there and wide fields stretching around the capital. The inner city is truly a veritable utopia itself, housing various departments organized with Shadow Garden members, such as defense system, training centers, research and development labs, housing, etc.

Additionally, Alexandria's land is so fertile that it can grow cacao and coffee trees, which are the only ones in the world on vast plantations that are cultivated into chocolate and coffee. The lands also grow other earthen products used for the materials sold in stores.

Upon claiming the city, [Gamma](Gamma.md "Gamma") was delighted to be able to make her long-awaited "chocolate." Afterwards, the members managed to install the farm and refined the cocoa en mass. As a result, Mitsugoshi Company became the only company in the different world that could exclusively sell chocolate. Later, Gamma succeeded in reproducing the coffee that Cid talked about in "Shadow Wisdom," cultivating it as exclusively as the chocolate.

## Trivia

## References

1. Master of Garden, Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 1-2: Ancient Dragon of Alexandria, Episode 3: Tale of Ruin

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| **Alexandria** • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
