# Gettan/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Gettan/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Gettan/Chronology)

[Main](Gettan.md "Gettan")

[Relationships](Gettan-Relationships.md "Gettan/Relationships")

Image Gallery

## Chronology

### Tragic Past

Gettan, the son of the Dire Wolves' Elder, rescued [Yukime](Yukime.md "Yukime") and her tribes also slaughtered their "rival Therianthrope tribe attackers" (presumably one of the invaders sent by the Cult of Diablos) who invaded her village when he was 17 years old. Gettan and [Yukime](Yukime.md "Yukime") fell in love ever since then. The Spirit Fox and Dire Wolf tribes chose to form an alliance to better defend themselves against the upcoming war by having [Yukime](Yukime.md "Yukime") and Gettan get married which is something both of them were happy to comply. However, [Yukime](Yukime.md "Yukime") had to reach the age of 15 before they could officially get married.

At some point during the war had occurred, Gettan was approach by the Cult of Diablos organization and they made a deal with Gettan that if his Dire Wolf and Yukime's Spirit Fox tribe swore allegiance to the Cult, they will protect them from the clan war. When Gettan was in despair that made his personality suddenly craves for power, he accepts the invitation and obtain the "red pills" with the intention of protecting his tribe and lover tribe and trying to make Yukime's mother to join the Cult. But Yukime's mother refused and tries to stop him leading Gettan to murdering her.

It was then village was wiped out by an attack by a band of thieves led by the Cult of Diablos because they want to obtain their beastmen's experimental body and both tribes fell victim, with only [Yukime](Yukime.md "Yukime") and Gettan the only survivors. While Yukime tried to comfort her fiancée, Gettan pushed Yukime away and revealed that he tried to save their tribes by gaining aid from a Cult and revealing the fact that he was the one who kill her mother. [Yukime](Yukime.md "Yukime") tried to flee but unfortunately, Gettan chased after her and brutally attacked her which left a slashed marks on her backs as he furious that Yukime refuses the Cult's offer to join forces who took the same attitude as her mother.

However, before Gettan could continue the assault by finishing [Yukime](Yukime.md "Yukime"), a mysterious figure suddenly appear and intervened him and annihilating all the invaders. He tried to fight back but ended up losing him because the figure slashes his eyesight also lost both eyes due to mysterious man's attack and robbing both of his eyes as the figure tear out of it, making him blind and decides to flee from him. After that, Gettan, who survived, took revenge on those who took something from him and cooperated with the Cult.

### Great Trading Company Conflict
