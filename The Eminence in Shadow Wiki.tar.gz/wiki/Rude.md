# Rude

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Rude](https://the-eminence-in-shadow.fandom.com/wiki/Rude)

CLEANUP: ONLY YOU CAN IMPROVE THE WIKI!

You do not need to have peregrinated around Midgard or experienced dimensional travel help here. Shadow Garden encyclopedists have marked this page to be cleaned up by the community. You can assist the wiki by proofreading or checking if this article follows our standards and layout guide. Your contributions will make the wiki better for everyone in this community.

## Rude

### Japanese

ルード

### Romaji

Rudo

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Beige

### Eye Color

Black

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Noble

### Affiliation

Velgalta Empire

## Debut

### Light Novel

Volume 2

### Anime

Episode 14

## Portrayal

### Japanese

Hayato Fujii

Rude (ルード, Rudo[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the eldest son of a feudal lord in the city of Madlid, the minor region on the outskirts of the Velgalta Empire.

## Appearance

In the anime, Rude is a man with fair skin dressed in a sky business suit with a dark blue necktie. He also has his light brown hair combed back and a slightly curly small mustache coming from just under his nose.

## Personality

## Chronology

### Bushin Festival Tournament

After the event of [Sanctuary](Sanctuary.md "Sanctuary"), Rude heard the rumors of Mitsugoshi Company in the Velgalta's imperial capital and experiencing a new wave of prosperity.

Hearing the news, he wants to repopulate his city and decide to meet with the director, [Luna](Gamma.md "Gamma"), and tried to convince her to buy a prime property in Madlid and opening her branch store in his city, which he gave a low price of up to 100 million Zeni. Luna isn't sure at first because Mitsugoshi Company was carrying out a reconstruction process in the Sacred Land, [Lindwurm](Lindwurm.md "Lindwurm") which resulted the city being flooded, after the Sanctuary under the dam water had destroyed.

But [one](Nu.md "Nu") of her employees tells her that they found petroleum, she decides to buy every property in that street and explains that she wants to redevelop the city if he's willing to meet their conditions and make it the greatest city in Velgalta Empire. Then, she ordered her employees to buy up all the necessary land downstream of the Nyle tributary and building a canal there.[[1]](#cite_note-V2C3-1)[[2]](#cite_note-2)

## Powers & Abilities

## Trivia

## References

1. Volume 2 Chapter 3: When Things Get Boring, It's Time for Explosives!
2. Episode 14

## Side Navigation
