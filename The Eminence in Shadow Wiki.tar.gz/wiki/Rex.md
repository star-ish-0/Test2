# Rex

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Rex](https://the-eminence-in-shadow.fandom.com/wiki/Rex)

[Chronology](Rex-Chronology.md "Rex/Chronology")

[Relationships](Rex-Relationships.md "Rex/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | We are the Shadow Garden. Or was it the Shadow Guardian? Oh, whatever. I’m Rex. Rex, the Game of Betrayal. | ” |
| — Rex, Light Novel Volume 01 | | |

## Rex

### Japanese

レックス

### Romaji

Rekkusu

### Aliases

Game of Betrayal

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Red

### Eye Color

Red

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

First Children (Named Child)

### Affiliation

Cult of Diablos

## Debut

### Web Novel

Chapter 34

### Light Novel

Volume 1

### Manga

Chapter 10

### Anime

Episode 6

## Portrayal

### Japanese

[Nobuhiko Okamoto](https://en.wikipedia.org/wiki/Nobuhiko_Okamoto "wp:Nobuhiko Okamoto")

### English

Jeremy Gee

### French

Juan Llorca

### Italian

Federico Viola

### German

Oliver Scheffel

Rex (レックス, Rekkusu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a Named First Child of the Cult of Diablos, titled Game of Betrayal (叛逆（はんぎゃく）遊戯（ゆうぎ）, Hangyaku Yūgi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). During the attack on Midgar Academy for Dark Knights, he was tasked by Sir Gaunt to retrieve the Eye of Avarice artifact control unit from Sherry but was thwarted and killed by Shadow.

## Appearance

Rex had the appearance of a 'flippant man' with dull red hair and have the eyes of a starving feral dog.[[1]](#cite_note-V1C6-1)

During the Cult's siege on Midgar Academy, he wore an imitation of the Shadow Garden uniform which included a jet-black coat and a mask.

In the anime, Rex is seen in a black uniform with a red vest, black boots, and carries two large swords on his waist without wearing a mask.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Difference in our strengths…… Do [you](Glen.md "Glen") really think you’re stronger than me? | ” |
| — Rex ferociously scowls at [Glen](Glen.md "Glen"), Light Novel Volume 01 | | |

Rex was a vicious, arrogant and capricious man who treated everything as a game regardless of how serious the situation is. He liked to humiliate those who he believed were below him, but he was good at provoking his opponents in order to take advantage of their exposed points and weaknesses to do so.

Like many members of the Cult, Rex was overconfident. He was convinced that he was invincible and severely overestimated his abilities.

Rex never felt fear until he sweat in terror for the first time in his life, when he saw all of his men being eliminated by a single student.

## Powers & Abilities

Rex was one of the strongest of the Named "First Children" who have provided extraordinary contributions to the Cult. Rex possessed stronger physical strength and magical powers compared to the average knight. Because of his strength he was promoted to a First Named Child

### Physical Prowess

Rex was an excellent magic swordsman being able to best both magicless [Glen](Glen.md "Glen") and Marco Granger in a fight. However, he (like everyone else in the Cult) was too weak against Shadow.

### Magic

Rex was capable of using magic as he intensifies his vision to its limit and focusing his gaze, which he can detect any rapid movements.

He is also able to channel all his magic into protecting his internal organs.

In the anime, he cast a net around himself that stretches using his magical power like a ball by linking both ends of his swords together to act as a barrier which detects anything as soon as it passes through. However, Cid broke through it easily, to Rex's surprise.[[2]](#cite_note-:0-2)

### Battle Estimation Deduction

The reason Rex called himself the Game of Betrayal is because he can completely expose his victims with minimal information and used it to his advantage. His combat experience and sharp mind enables him to identify his opponents' weakness and attack them psychologically with taunts.

## Trivia

## References

1. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
2. Episode 8

## Site Navigation
