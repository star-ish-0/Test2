# Olivier

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Olivier](https://the-eminence-in-shadow.fandom.com/wiki/Olivier)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Chronology](Olivier-Chronology.md "Olivier/Chronology")

[Relationship](Olivier-Relationship.md "Olivier/Relationship")

Image Gallery

## Olivier

### Japanese

オリヴィエ

### Romaji

Orivie

### Aliases

Elf Hero

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Blue

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

[Alpha](Alpha.md "Alpha") (Descendant)
[Beatrix](Beatrix.md "Beatrix") (Descendant)

## Professional Information

### Occupation

Swordswoman

### Affiliation

Cult of Diablos (Puppet)

## Debut

### Web Novel

Chapter 52

### Light Novel

Volume 2

### Manga

Chapter 17

### Anime

Episode 12

### Game

Seven Shadows Chronicles: Chapter 28
Apocrypha: Chapter 1

## Portrayal

### Japanese

[Asami Seto](https://en.wikipedia.org/wiki/Asami_Seto "wp:Asami Seto")

Olivier (オリヴィエ, Orivie[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was [Alpha](Alpha.md "Alpha") and [Beatrix](Beatrix.md "Beatrix")'s ancestor and one of the Three Heroes who defeated the demon [Diablos](Aurora.md "Aurora"), known as the "Elf Hero". In reality, however, she was a pawn of the Cult of Diablos, being a survivor of their experiments, tasked by them with defeating the demon for their own ends. Her signature weapon is the Holy Sword.[CITATION NEEDED]

## Appearance

Olivier is described as a beautiful, gallant, almost divine even, figure of a woman warrior. Her appearance looks like a mirror image of [Alpha](Alpha.md "Alpha") and [Beatrix](Beatrix.md "Beatrix").

She wears a kind of light blue magical talismans with gold accents on her forehead and on the sides of her cheeks that form the appearance of a kind of helmet, to which these are always attached to her head (it is not known at the moment what function they serve).

In the light novel and manga, Olivier is described wearing a beautiful aqua blue armor with gold details and a cape on her back, wearing a beautiful light skirt with gold and black details, black gloves with white details, metallic boots of the same color as her armor and is seen carrying a powerful magic sword made by the Cult for her.[[1]](#cite_note-V2C2-1)

While in the anime, she wears a white robe that covers almost her entire body down to below her knees without any footwear with a prototype magic sword.[[2]](#cite_note-2) It has also been shown that, unlike the rest of the heroes and their descendants, she is physically much smaller than her descendant.

## Personality

Olivier was noted to have a honest personality and a strong sense of justice, mainly because she had witnessed her entire family murdered by [vampires](Vampire.md "Vampire")[[3]](#cite_note-3). However, after she joined the Church, she slowly closed herself off from the others and created an air of mystery around her. [Nonna](Nonna.md "Nonna") had speculated that this because despite no matter how strong she got, her family couldn't return from the dead.

However, after being sealed inside the [Sanctuary](Sanctuary.md "Sanctuary") for centuries, she had been reduced to an emotionless state, possibly forced to serve the Cult of Diablos.[CITATION NEEDED]

## Powers & Abilities

Being one of the three survivors of the Cult of Diablos' experiments with the implanted cells of the demon [Diablos](Aurora.md "Aurora"), it can be assumed that Olivier was considerably the most powerful individual, making her the strongest weapon of the Cult, since she was able to defeat the demon king and seal it. Shadow himself noted that the projection of Olivier summoned by Nelson paled in comparison to the real deal.[CITATION NEEDED]

Physical Dexterity: Olivier has a massive physical dexterity, which allows her to face her opponents with mastery, having a superhuman physical ability, being able to overcome her enemies with ease.

### Swordsmanship

Olivier is a very skilled swordswoman, being able to cut off the arm of the demon diabolos, and subdue Cid Kagenou with relative ease, (although Cid had his magic denied, which left him vulnerable), as a swordswoman she is very skilled being recognized as a very powerful heroine.

### Magic

Olivier has a lot of magic power that surpasses that of a normal person and even very powerful warriors, who have an immense amount of magic power.

## Trivia

- Because the Cult misrepresented history worldwide, both Olivier and his companions are treated as men, instead of women.[CITATION NEEDED]
  - Interestingly, despite the fact that the statues of the Heroines were made in their male form, the cultists keep a few silhouettes of them as they really look, this is seen when Shadow Garden enter the [Sanctuary](Sanctuary.md "Sanctuary") and see the female statue of Olivier, and [Lily](Lily.md "Lily")'s memory appears to protect the right arm of Diabolos, under the royal academy of Midgar.
- Until now, Olivier's lineage is the most numerous compared to the other two heroes, which is ironic, since Olivier an elf, like her race, should not have so many offspring due to their low birth rate.[CITATION NEEDED]

## References

1. Volume 2 Chapter 2: Investigating the Sanctuary!
2. Episode 12
3. Apocrypha: Chapter 2, part 4A

## Site Navigation
