# Omega/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Omega/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Omega/Relationships)

[Main](Omega.md "Omega")

[Chronology](Omega-Chronology.md "Omega/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

Just as with the other members of Shadow Garden, Omega holds their leader in the highest of regards. Especially with his Shadow Wisdom and the unique technologies [Eta](Eta.md "Eta") constructs from said wisdom. Also like the other members, she follows Shadow's lead without question, such as venturing into the Sanctuary to gather intel on the Cult within the past memories.

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

Omega, as such, respects and obeys Alpha's orders as the one who directs everything as second in command in Shadow's absence. In addition, Omega acts as security for her, along with Epsilon and Chi.

#### [Beta](Beta.md "Beta")

Omega respects Beta and followed her orders during the Sanctuary infiltration.

#### [Gamma](Gamma.md "Gamma")

Omega respects and admires Gamma's position. Generally, serves as the one who more than most, wipes Gamma's bleeding nose with a slight smirk on her face.

#### [Delta](Delta.md "Delta")

Omega and Delta coordinated for the Sanctuary infiltration mission, but the extent of their relationship is unclear.

#### [Epsilon](Epsilon.md "Epsilon")

Omega works often below Epsilon. Like the others, Omega seems to be aware about Epsilon's fake slime body in the anime, but remains careful so as to not hurt her pride or upset her temper.

#### [Eta](Eta.md "Eta")

It is unknown how involved Omega has been with Eta.

### Numbers

#### [Lambda](Lambda.md "Lambda")

Before joining Shadow Garden, they were fellow military instructors in the Velgalta Empire.

However, after they both became possessed and were subsequently cured, their relationship ended up being skewed. Mainly because when Omega was cured, Lambda was already a member of the Numbers and as such demanded that Omega, a rank and file member at the time, show her the proper respect, which Omega refused. She would also continually address her as "Lambda-sama" in a comical tone as her way of teasing her for their now difference in rank.

#### [Nu](Nu.md "Nu")

Although her senior, Omega has been shown aiding Nu with preparing Cid for the [Lindwurm](Lindwurm.md "Lindwurm") and Bushin Festival missions.

#### [Chi](Chi.md "Chi")

They initially had difficulty understanding one another. Mainly because Omega was quite aloof in nature and simply followed along with everyone and only did things she was told to do. Meanwhile Chi was struggling with the guilt and realization of everything she had done for the Cult. However, as time went on, Omega began to understand Chi's need for penance and self-forgiveness and decided to aide her on her quest to set things right. Remarking that this was the first time she ever felt strong feelings for someone else.

They work as partners together.

### Members

#### Akane Nishino / "Akane Nishimura" (712)

## Others

### Claire Kagenou

## References
