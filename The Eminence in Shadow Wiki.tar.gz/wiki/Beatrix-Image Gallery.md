# Beatrix/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Beatrix/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Beatrix/Image%20Gallery)

[Main](Beatrix.md "Beatrix")

[Chronology](Beatrix-Chronology.md "Beatrix/Chronology")

[Relationships](Beatrix-Relationships.md "Beatrix/Relationships")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Beatrix confronts Shadow for the first time.

Iris teams up with Beatrix, to defeat Shadow.

Beatrix and Iris Midgar being easily defeated by Shadow, Perv Asshat witnesses whole scene.

Beatrix and Iris Midgar try to keep fighting, Shadow turns to reply.

Beatrix and Iris Midgar are shocked by Shadow's tremendous magical power, Iris reflects on what Shadow said.

Beatrix's first appearance.

Beatrix eating in the VIP room of the festival.

Beatrix reveals herself and confronts Shadow for the first time, at the Bushin Festival.

Beatrix VS Shadow

Beatrix and Iris midgar, fighting together to defeat Shadow.

Beatrix and Iris midgar, being subdued without problem, abruptly by Shadow's crushing force.

Beatrix and Iris midgar, witnessing Shadow's capital level magical power

Beatrix and Iris midgar, suffer a strong defeat, Iris begins to cry for her helplessness and useless help.

Elf Swordmaster: Beatrix

Holiday Frolic: Beatrix

Game Event: A Gift from Miss Santa

Glimmering Blade: Beatrix
