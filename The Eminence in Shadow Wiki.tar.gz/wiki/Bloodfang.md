# Bloodfang

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Bloodfang](https://the-eminence-in-shadow.fandom.com/wiki/Bloodfang)

Bloodfang (血牙（けつが）, Ketsuga[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a magic sword that once used by the man hailed as the "greatest knight ever."[[1]](#cite_note-V5E-1)

## History

Hundred years ago, this sword is used by the 5th seat Knight of Rounds, [Fenrir](Fenrir.md "Fenrir") in order to made a name for himself around the world by slaughtered people indiscriminately, making him a feared assassin in the Midgar Kingdom, known as the "Devil of Midgar" to which everyone who lives in the kingdom knows and even fears his name and nickname.[CITATION NEEDED]

## Known Users

- [Fenrir](Fenrir.md "Fenrir")

## Trivia

## References

1. Volume 5 Epilogue: I’d Let the Whole World Burn, If That’s What It Took!
