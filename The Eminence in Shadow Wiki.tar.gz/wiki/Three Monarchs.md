# Three Monarchs

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Three%20Monarchs](https://the-eminence-in-shadow.fandom.com/wiki/Three%20Monarchs)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Three_Monarchs?action=edit).

Three Monarchs (三人（さんにん）の支配者（しはいしゃ）, San'nin no Shihai-sha[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a name that referred to the exceptionally three strongest individuals who feud with each other on their rivalry to dominate the Lawless City. The Three Monarchs aren't a coherent group but rather rivals who fought amongst themselves for domination over the city.

## History

Their exact history is not known but each of the three monarchs allocated themselves in the Lawless City had their own respective goals and their presence are considered a symbolic sign of the "ruler" who ruled the city through domination with absolute power, while at the same time they had to create a major faction that controlled a third of the Lawless City's territory.

## Chronology

### Red Moon Incident

### Great Trading Company Conflict

## Known Members

- [Yukime](Yukime.md "Yukime"), the Enchantress (White Tower Monarch)
- [Juggernaut](Juggernaut.md "Juggernaut"), the Tyrant (Black Tower Monarch)
- [Elisabeth](Elisabeth.md "Elisabeth"), the Blood Queen (Crimson Tower Monarch)

## Trivia

## References

## Site Navigation
