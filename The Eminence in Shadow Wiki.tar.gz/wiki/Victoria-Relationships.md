# Victoria/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Victoria/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Victoria/Relationships)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Main](Victoria.md "Victoria")

[Chronology](Victoria-Chronology.md "Victoria/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou (Shadow)

Victoria is one of the several girls in the Shadow Garden who's deeply enamored with Shadow. She deeply idolizes him as a god. After losing her faith, Shadow gave her a new purpose in her life and another path of worship.

Despite becoming brash and cold hearted, Victoria retained part of her formerly kind and affectionate personality exclusively towards Cid. This is seen again after he saved her from a [Cult lieutenant](Kouadoi.md "Kouadoi"), adopting the childish and affectionate demeanor from when she was the Saint in his presence. She considers herself to be his loyal servant and stated that she'll mercilessly eliminate anyone she believes to be undeserving of his grace.[[1]](#cite_note-V4CP-1)

Influence by Zeta and her past as a clergywoman, Victoria radical belifes and fanaticism exceeds many Shadow Garden members. Because of this, she also had no qualms with joining Zeta's faction, whose goal is to immortalize Shadow.[[2]](#cite_note-V5C3-2)

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

Second in command of Shadow Garden. Like all members of the "Seven Shadows", Victoria respects Alpha and follows her orders without question. At the same time however, she could not help but envy her close relation with Shadow.

Despite following her orders, Victoria does not respect Alpha's leadership as she believed she is too soft, and it'll sully their master's authority. She alongside Nina joined Zeta's faction with the goal of immortalizing Cid, effectively working behind the organization's back.[[2]](#cite_note-V5C3-2)

#### [Beta](Beta.md "Beta")

Like all members of the Seven Shadows, Victoria respects Beta and follows her orders without questions. This was demonstrated when they worked together during the second Oriana Kingdom operation. At the same time however, she cannot help but envy her attachment towards Shadow especially when she clung onto him when he was transported to Japan.[[3]](#cite_note-3)

#### [Epsilon](Epsilon.md "Epsilon")

One of the Seven Shadows and her superior, the two share a deep attachment towards Shadow which helps them work greatly together. Epsilon saw the former priestess' potential and wants her to become her successor within the Seven Shadows. However, their affection towards their master does not stop the elven from reprimanding her instance with Rose and other failed missions.[[4]](#cite_note-V4C2-4) She is unaware of her subordinate's allegiance to Zeta and is working behind her and other members back with the intention of immortalizing their master.

#### [Zeta](Zeta.md "Zeta")

One of two Therianthrope members within the Seven Shadows. Victoria respects and admires Zeta as an original member and direct disciple of Shadow himself. A trait the two share is that they accomplish their missions without regards to collateral damage and casualty as well as the lack of respect towards Alpha. It is likely due to this that Zeta recruited Victoria into her secret sub-faction. After witnessing Zeta's new skill when she killed [Jean](Jean.md "Jean"), Victoria acknowledges Zeta's strength to be powerful as ever. Zeta revealed to Victoria that the Cult are after Claire due to [Aurora](Aurora.md "Aurora")'s spirit inside of her as well they need to protect Claire.

In the Master of Garden game, it is revealed that Victoria met Zeta long ago before joining Shadow Garden when she still referred as the "Saint" and made a prophetic remark that someday they would meet again.

### General Members

#### [664](664.md "664") and [665](665.md "665")

Victoria treats 664 and 665 condescendingly like any other members of Shadow Garden below her, almost to the point they wouldn't care about them unless they show signs of insubordination. In front of a superior member or not, she considers them as traitors if they go against her orders in the slightest even defending Rose is considered a sign of insubordination.

#### Rose Oriana (666)

Victoria makes no secret of her disapproval of Rose Oriana and openly expresses disdain. From Victoria's perspective, Rose's commitment to Shadow Garden is disproportionate to the advantages she received, such as Shadow's healing. The only members Shadow directly healed of demonic possession are the Seven Shadows, Victoria, and later Rose. Victoria considers the latter undeserving of the honor and too weak to meet expectations. The botched Oriana Kingdom retrieval operation further exacerbated Victoria's contempt, and she communicated a desire to see Rose executed for her supposed betrayal.[[1]](#cite_note-V4CP-1)[[4]](#cite_note-V4C2-4)

### Zeta's Faction

#### [Nina](Nina.md "Nina")

## Others

### Claire Kagenou

## References

1. Volume 4 Prologue: It's Time for a War in the Oriana Kingdom!
2. Volume 5 Chapter 3: The Case Is Closed, So, It’s Time for a Flashback!
3. Volume 4 Chapter 3: Crashing the Ceremony!
4. Volume 4 Chapter 2: Begin Operation: Obstruction!
