# Gamma/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Gamma/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Gamma/Relationships)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Main](Gamma.md "Gamma")

[Chronology](Gamma-Chronology.md "Gamma/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

Gamma deeply admires her lord ever since he discovered and rescued her after she was discarded by society, and being enveloped by Cid's power causes her to tear up immensely. Like Alpha, Gamma has devoted herself and her life to Cid only and his cause. Her reason of making Mitsugoshi and Shadow Garden as strong and as rich as can just to make the organization worthy of her master's standing. She is willing to do everything in power in hope of one day her master will acknowledge her and she literally put her life online to research on his shadow wisdom to make practical products out of it. Gamma views Cid as an intelligent man and was frustrated at herself for not being able to keep up with his warrior prowess, though she was pleased when he praised her business savvy. In response, she learned all he could teach her pertaining to economics and trade, even incomplete anecdotes from his past life which she filled in the blanks to and perfected. It really pains her to see that her master is so close to her yet someone so far from her reach.

Like the others in Shadow Garden, her master's movements are enigmatic to her, and she adapts herself in accordance. Such as commanding Shadow Garden forces during the academy terrorist attack, or disguising Cid into Mundane Mann for the Bushin Festival. When it seemed, Shadow betrayed them during the trade conflict with the Major Corporate Alliance, Gamma was just as heartbroken upon learning the news from Alpha but was relieved upon later discovering that he hadn't and had a secret plan to help them secure funding to survive a financial crisis.

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

Gamma serves as Alpha's right hand when it comes to managing Shadow Garden, in the sense of being responsible for the financial and administrative affairs of the organization, as well as the head of its operations in foreign countries. Gamma highly respects her superior and they are able to get along as friends on subjects outside of Shadow Garden. Acts as a second-in-command towards her, often instilling her with confidence or keeping Alpha aware of the bigger picture.

#### [Beta](Beta.md "Beta")

Beta and Gamma are colleagues and friends, both having the lesser aptitudes towards combat and both applying their efforts with administration and intelligence for Shadow Garden. Beta routinely reports to Gamma regarding her roles on missions and information she collected in the field. After Beta returned from Earth, both were weary of [Eta](Eta.md "Eta") and what she may be due to their alien guest. Gamma often endorses Beta's novels through her company causing Beta's alter-ego to amount great fame in a short amount of time.

#### [Delta](Delta.md "Delta")

Both Gamma and [Delta](Delta.md "Delta") did not get along when they were younger, due to [Delta](Delta.md "Delta") picking on Gamma for her lack of combat prowess. However, they eventually got over that and now treat each other like siblings. When Gamma thought [Delta](Delta.md "Delta") had been killed, she was genuinely devastated but overjoyed when Delta returned alive. Delta still tends to bite Gamma every so often, because Gamma is weaker than her but also as a sign of affection. In the spin-off they tend to bicker like sisters over what is better: brawn or brains, often fighting each other to a tie.

#### [Epsilon](Epsilon.md "Epsilon")

Gamma is Epsilon's senior in terms of time within Shadow Garden as well as hierarchy. As Gamma is the administrative head of the organization below Alpha, Epsilon must report back to Gamma with any findings and discoveries made during missions. It is unclear if Gamma is aware of Epsilon's envy for her well-endowed sisters. Despite being a prideful elf, Epsilon secretly admires Gamma's absolute confidence, not aware it's a clever facade to hide Gamma's embarrassment at her own clumsiness.

#### [Zeta](Zeta.md "Zeta")

#### [Eta](Eta.md "Eta")

Like most of Shadow Garden, Gamma disliked [Eta](Eta.md "Eta")'s use of them in her experiments, but still trusts her given their shared history. However, she was also annoyed with her fellow Elf for spending much of Shadow Garden's secret funds to carry out her experiments. Lately they have bonded over similar interests and realize that they have more in common than they thought, often asking for insight because of their similar intelligence. Alongside Eta, Gamma is considered the weakest of the Shadows, possibly of all of Shadow Garden.

### Numbers

#### [Iota](Iota.md "Iota")

Gamma is severely annoyed with all of Iota's antics. Especially with Iota talking to her in a casual manner and even referring to her as "Gammy" whenever they aren't in public, despite being direct superior and subordinate. And the part that annoys her the most is that Iota is always respectful towards Alpha and yet still treating her casually even if the two of them are present together.[CITATION NEEDED]

#### [Lambda](Lambda.md "Lambda")

#### [Nu](Nu.md "Nu")

Nu is a high-ranking officer within the Shadow Garden given one of the Greek names, carrying a double-digit number ranking just below the Seven Shadows. Nu serves as Gamma's assistant and personal bodyguard, due to her aforementioned discoordination. Nu is steadfastly loyal and shares Gamma's trust in their master, like when he acted as "John Smith" and they learned his true motives from his decoded message, happy at his foresight. Nu often sighs whenever Gamma has tripped and tends to be the one to wipe her nosebleed as a result.

#### [Chi](Chi.md "Chi")

#### [Omega](Omega.md "Omega")

### Members

#### [Victoria](Victoria.md "Victoria") (559)

#### [664](664.md "664") & [665](665.md "665")

#### Rose Oriana (666)

## Others

### Claire Kagenou

### Annerose Nichtsehen

### Alexia Midgar

### Iris Midgar

### Skel & Po

## References
