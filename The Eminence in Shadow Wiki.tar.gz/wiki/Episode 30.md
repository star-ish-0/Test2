# Episode 30

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2030](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2030)

## Caged Bird

### Kana

籠の鳥

### Romaji

Kago no Tori

## Special Title

### English

The Eminence in Shadow wants to be a little bit of an able-apprentice!

### Kana

陰の実力者はちょっとデキる系の弟子でいたい！

### Romaji

Kage no Jitsuryokusha wa Chotto Dekiru Kei no Deshi de Itai!

## Episode Information

### Season

2

### Episode

10 (30)

### Air Date

December 6, 2023 JP & EN

### Adapted From

Volume 4 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

Grayscale dominator

### Ending

Polaris in the Night (Lambda ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| The Key | Determination |

Caged Bird (籠の鳥, Kago no Tori[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the tenth episode of the second season, and the thirtieth episode of [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Did Princess Rose Oriana take it upon herself to join up with the enemy? Not even the Seven Shadows have authority over this matter anymore.[[1]](#cite_note-1)

ローズの結婚に激怒したシドは、真意を問いただすために王城を訪れる。
人気ピアニスト・シロンの弟子として潜入するが、素性を疑うドエムに演奏を求められてしまう。[[2]](#cite_note-2)

## Summary

Following the report of 666’s betrayal, [Lambda](Lambda.md "Lambda") heads to Oriana to confront her as her instructor, bringing Shadow Garden reinforcements in preparation for a confrontation with the Cult. While there, [Chi](Chi.md "Chi") and [Omega](Omega.md "Omega") inform her that the matter is now in Shadow's hands.

Cid plans to infiltrate the Oriana royal palace to tell Rose that he opposes her marriage to Duke Perv. Just as he's about to sneak in, he runs into [Epsilon](Epsilon.md "Epsilon"), who is disguised as Shiron the pianist. She brings him into the castle as her student, since in Oriana, those with artistic talent are highly respected.
While they are discussing Shadow Garden’s plans inside the palace, they encounter Duke Perv. He informs them that Rose is feeling unwell and won’t be attending Shiron’s performance. He then asks Shiron who the boy accompanying her is. She replies that he is her student, surprising them, as no one was aware she had taken on an apprentice.
Duke Perv asks whether the boy has a pass to be in the palace. Shiron says she believed it wouldn't be necessary for her student, but Perv informs her that the protocol has changed and now requires everyone to have one. He then suggests that Cid give a piano performance as compensation for his stay at the palace.

Following Perv's request, Cid performs the Moonlight Sonata for the palace guests. His performance captivates the audience, prompting many—including Perv—to volunteer as his patrons. However, Shiron informs them that Cid is still in the middle of his training and not yet ready for professional engagements.
While Shiron is addressing the guests, Cid quietly picks Perv’s pocket, retrieving a ring. Cid and Shiron then move on to a private room.
Cid tells Shiron that he would like to take a walk around the palace, which is overheard by [Margaret](Margaret.md "Margaret"), a palace maid who tends to Rose Oriana. She offers to be Cid's guide through the palace.

They take a stroll through the palace's flower field. Margaret praises Cid’s earlier piano performance, mentioning that he caught the attention of Parton and Newwealth, both of whom would offer him generous salaries. She adds that her own family would also be interested in becoming his patron. Cid turns her down, saying that Shiron wouldn't want him to accept.
He then asks where Rose is. Margaret blames Rose for the dire situation in the Oriana Kingdom and says her whereabouts are a secret, so she cannot disclose them. However, she eventually gives in and tells him Rose is at the top of the west tower.
Cid quietly sneaks away and runs into a castle guard named [Kevin](Kevin.md "Kevin"), who lectures him about how the Dark Knights do all the hard work to keep the kingdom safe while artists enjoy lavish lives under their protection. As Kevin begins to rant about his one-sided love for Margaret, Cid slips away unnoticed.

In her room, Rose worries about a looming confrontation between Shadow Garden and the Cult of Diabolos taking place in Oriana. As she struggles with her inner conflict, Cid scales the tower wall to reunite with her.
He brings up her upcoming wedding to Duke Perv, to which Rose responds that she has already accepted her fate. However, Cid urges her not to give up and encourages her to choose her own path—just as she once chose to become a Dark Knight, despite their negative reputation in Oriana.

After Cid leaves, Duke Perv confronts Rose, accusing her of having had a visitor. Rose reminds him that their marriage is to be in name only, but Perv warns her that her mother's life depends on the success of the union.
Having overheard the conversation, Cid quietly departs to initiate Plan B. Meanwhile, preparations for the wedding continue.

Later, at a resort, Epsilon and 559 discuss the mission's progress. Epsilon expresses surprise at 559’s first failed mission and advises her not to be too quick to label Rose a traitor. She cautions her to proceed carefully, as she’s considering promoting her to a rank directly below the Seven Shadows.
Epsilon adds that Shadow has already made contact with Rose, meaning the matter is now beyond their control—they must wait and follow Shadow’s lead. She then tells 559 about the ring recovered from the ruins and its connection to the legendary key to the Black Rose. The key, she explains, was once used to annihilate a hundred thousand Velgaltan troops when the Oriana Kingdom faced destruction.
Their discussion is interrupted by Cid, who enthusiastically praises the resort’s bath. He assures them that “that thing” will be taken care of.

Meanwhile, Duke Perv briefs [Mordred](Mordred.md "Mordred") on his ongoing plan to obtain the Black Rose, which he says is progressing smoothly. He reveals that he is still in possession of the Ring of Succession. Mordred assures him that, should the mission succeed, Duke Perv will be granted a seat in the Rounds.

## Characters

- [Lambda](Lambda.md "Lambda")
- [Omega](Omega.md "Omega")
- [Chi](Chi.md "Chi")
- Cid Kagenou
- [Epsilon](Epsilon.md "Epsilon")/Shiron
- Earl Parton
- Marquis Newwealth
- Perv Asshat
- Zenon Griffey (Flashback)
- [Margaret](Margaret.md "Margaret") (Debut)
- [Kevin](Kevin.md "Kevin") (Debut)
- Rose Oriana
- Raphael Geerk Oriana (Flashback)
- Reina Oriana
- [Victoria](Victoria.md "Victoria")
- [Eta](Eta.md "Eta") (Mentioned)
- [Beta](Beta.md "Beta") (Mentioned)
- [Mordred](Mordred.md "Mordred")

## Promotional Videos

「陰の実力者になりたくて！ 2nd season」 第10話予告≪ノーマルVer.≫「籠の鳥」

『陰の実力者になりたくて！ 2nd season』 第10話予告≪スペシャルVer.≫「陰の実力者はちょっとデキる系の弟子でいたい！」

## Trivia

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e030>
2. <https://shadow-garden.jp/story/#story10>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • **Episode 10** • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
