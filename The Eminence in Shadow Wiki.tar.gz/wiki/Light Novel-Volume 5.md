# Light Novel/Volume 5

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%205](https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%205)

## Light Novel Volume 5

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Touzai

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4047373112

### ISBN EN

ISBN 978-1975375256

### Release Date

December 28, 2022 JP
July 23, 2024 EN

## Volume Information

### Pages

384 JP
266 EN

### Chapters

7

## Adaptations

### Manga

Chapter 55 - Chapter 66.1

Publication Order

| Previous | Next |
| --- | --- |
| Volume 4 | Volume 6 |

This is the fifth volume of the light novel series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

BEFORE MUCH LONGER… THE WHITE FOG WILL ENGULF THE WORLD IN SILENCE

All is well at the Midgar Academy for Dark Knights, but then something wicked suddenly draws near: The students are vanishing one by one—even Cid’s older sister Claire! Zeta of the Seven Shadows sets off to investigate while Cid and Alexia embark for Claire’s room where they find...ancient scripts, a cool magic circle, and spells that seem like they have great meaning and yet absolutely no meaning whatsoever?![[1]](#cite_note-1)

「陰よ――喰らいつくせ」　シリーズ累計200万部突破！！

平穏なはずのミドガル魔剣士学園に突如、巨大な闇が迫る……。
生徒が次々と行方不明に!?
そして、シドの姉・クレアまでもが姿を消して……。

調査に乗り出す、七陰のひとり・ゼータ。
そしてシドは、アレクシアと共にクレアの自室に乗り込み……。

「こ、これは……ッ」

見た瞬間に、察してしまった。
古代文字、カッコいい魔法陣、意味ありそうで全く意味のない呪文。

「これは、中二病黒歴史ノートだ……！」[[2]](#cite_note-2)

## Summary

## Chapters

- Prologue: The Case of the Missing Students and the Not-So-Peaceful Academy!
- Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
- Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
- Chapter 3: The Case Is Closed, So, It’s Time for a Flashback!
- Chapter 4: Peace in Our Time!
- Chapter 5: Terrorists Attack the School…Again!!
- Epilogue: I’d Let the Whole World Burn, If That’s What It Took!
- Eta's Research Journal

## Characters

:   In order of appearance:

- Cid Kagenou
- Skel Etal
- Po Tato
- [Zeta](Zeta.md "Zeta") (Debut)
- Claire Kagenou
- [Aurora](Aurora.md "Aurora")
- Alexia Midgar
- [Delta](Delta.md "Delta")
- [Nina](Nina.md "Nina") (Debut)
- [Jean](Jean.md "Jean") (Debut)
- [Victoria (No. 559)](Victoria.md "Victoria")
- Christina Hope (Debut)
- [Elisabeth](Elisabeth.md "Elisabeth") (Mentioned)
- Dark Spider (Debut)
- [Willow](Willow.md "Willow") (Debut)
- [Fenrir](Fenrir.md "Fenrir") (Debut)
- Zenon Griffey (Mentioned)
- [Isaac](Isaac.md "Isaac") (Debut)
- Iris Midgar
- [Adder](Adder.md "Adder") (Debut)
- [Glen](Glen.md "Glen") (Mentioned)
- Marco Granger
- [Lily](Lily.md "Lily") (Debut)
- [Petos](Petos.md "Petos") (Debut)
- [Loki](Loki.md "Loki") (Mentioned)
- Nelson (Mentioned)
- [Mordred](Mordred.md "Mordred") (Mentioned)
- Sergey Gorman (Mentioned)
- [Alpha](Alpha.md "Alpha")
- Rose Oriana (No. 666)
- Raphael Geerk Oriana (Mentioned)
- [No. 664](664.md "664")
- [No. 665](665.md "665")
- [Gamma](Gamma.md "Gamma")
- [Beta](Beta.md "Beta") (Mentioned)
- [Eta](Eta.md "Eta") (Debut)
- Akane Nishino (Mentioned)
- [Epsilon](Epsilon.md "Epsilon") (Mentioned)
- Suzuki Hope (Debut)
- [Nu](Nu.md "Nu") (Mentioned)
- Eliza Despoht (Debut)
- [Kanade](Kanade.md "Kanade") (Unnamed)

## Illustrations

- [English](#)
- [Japanese](#)

Table of Contents (EN)

Title Page (EN)

Zeta confronting Delta

Nina greets Cid

Alexia and Claire talk while Aurora watches

Shadow appears in front of Head Librarian

Zeta meets Shadow and Alpha

Fenrir gets startled

Claire and Alexia's resistance

Shadow reveals himself

Young Aurora smiles creepily

Zeta's Profile (EN)

Eta's Profile (EN)

Aurora's Profile (EN)

Nina's Profile (EN)

Zeta confronting Delta

Nina greets Cid

Alexia and Claire talk while Aurora watches

Shadow appears in front of Head Librarian

Zeta meets Shadow and Alpha

Fenrir gets startled

Claire and Alexia's resistance

Shadow reveals himself

Young Aurora smiles creepily

Zeta's Profile (JP)

Eta's Profile (JP)

Aurora's Profile (JP)

Nina's Profile (JP)

## References

1. [YenPress. The Eminence in Shadow, Vol. 5 (light novel) (EN)](https://yenpress.com/titles/9781975375256-the-eminence-in-shadow-vol-5-light-novel/)
2. [Kadokawa. The Eminence in Shadow 05 (JP)](https://www.kadokawa.co.jp/product/322209000322/)

## Trivia

- Although this is [Zeta](Zeta.md "Zeta") and [Eta](Eta.md "Eta")'s debut within the Light Novel, both of them are debuted in the anime roughly two months prior in October 2022.

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • **Volume 5** • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
