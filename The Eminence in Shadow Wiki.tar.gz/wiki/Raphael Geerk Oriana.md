# Raphael Geerk Oriana

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Raphael%20Geerk%20Oriana](https://the-eminence-in-shadow.fandom.com/wiki/Raphael%20Geerk%20Oriana)

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | I plan on fighting to the bitter end to protect this nation, but even if I fall, there's nothing for you to fear. When that happens, I leave Oriana's future in the hands of my daughter, who I trust and adore more than any other. No matter what happens, I want you all to believe in her. She will be the one to lead our nation to greatness. Rose, I entrust the kingdom's future to you. | ” |
| — Raphael's Will and Testament, Light Novel Volume 04 | | |

## Raphael Geerk Oriana

### Japanese

ラファエロ・ゲールク・オリアナ

### Romaji

Rafaero Gēruku Oriana

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Beige

### Eye Color

Dark Brown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Reina Oriana † (Wife)
Rose Oriana (Daughter)
Clara Oriana (Youngest Daughter; WN)

## Professional Information

### Occupation

King of Oriana Kingdom (Formerly)

### Affiliation

Oriana Kingdom
Cult of Diablos (Puppet)

## Debut

### Web Novel

Chapter 31 (Mentioned)
Chapter 82

### Light Novel

Volume 1 (Mentioned)
Volume 2

### Manga

Chapter 25

### Anime

Episode 16

## Portrayal

### Japanese

[Yutaka Aoyama](https://en.wikipedia.org/wiki/Yutaka_Aoyama "wp:Yutaka Aoyama")

### English

[John Swasey](https://en.wikipedia.org/wiki/John_Swasey "wp:John Swasey")

### French

[Laurent Jacquet](https://en.wikipedia.org/wiki/Laurent_Jacquet "wp:Laurent Jacquet")

### Italian

Aldo Stella

Raphael Geerk Oriana (ラファエロ・ゲールク・オリアナ, Rafaero Gēruku Oriana[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets"))[[1]](#cite_note-1) was the king of the Oriana Kingdom. Through the use of a highly addicted drug, the Cult of Diablos brainwashed the King, turning him into a puppet. His daughter Rose later euthanized him to prevent further manipulation or damage to the country.[[2]](#cite_note-2) Rose's actions and the King's recorded testimony—implicating Duke Perv Asshat's involvement with the Cult of Diablos—erupted the Oriana Kingdom into a civil war.[[3]](#cite_note-3)[[4]](#cite_note-4)

## Appearance

## Personality

|  |  |  |
| --- | --- | --- |
| “ | I forgive you for your sins. | ” |
| — Raphael's last word to Rose, Light Novel Volume 02 | | |

Raphael had shown to be a wise and righteous king who would do what was right and stand up against evil, as he refused to give up his own daughter, Rose to the Cult of Diablos and even chooses to stand up against them by doing everything he could to ensure the protection of his daughter.

Although he ended up being a Cult's puppet, Raphael hoped deep inside him that everything he had planned to save his daughter and expose the Cult and their collaborator plans would not be in vain, even if it cost him his life.

Even after his death, Raphael got what he wished for when he still has one trump card left as a final trick to the Cult which finally happens when Rose put on the Ring of Succession and activates the recording inside the ring which exposes the Cult crimes and their collaborator Perv Asshat, the man that brainwashed him into becoming the Cult's puppet.

## Power & Abilities

While seemingly having no combat ability, being the ruler of the Oriana Kingdom, Raphael had great political power over the nation's internal affairs. Even the Cult of Diablos, who controlled the nation from the shadows, acknowledged the king's influence and brainwashed him before he could become a threat to them.

## Trivia

- The name Raphael (רָפָאֵל, rāp̄ā'ēl[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) means "God has healed" in Hebrew.
- In the Web and Light Novel, King Oriana's name is Raphael[[5]](#cite_note-V1C5-5), but his name was changed as Geerk in the Anime.[ANIME ONLY][[6]](#cite_note-6)
  - Realizing this mistake, Director Nakanishi and Original Writer Daisuke talked about possible fixes. They came to the agreement of giving him the middle name Geerk; thereby fixing the anime's accidental retroactive continuity.[[7]](#cite_note-7)

## References

1. King Oriana's full name was stated to be Raphael Geerk Oriana by Director Kazuya Nakanishi in [this](https://x.com/yaduka301/status/1740569072516178260) Season 2 afterword.
2. Volume 2 Chapter 8: Lay Your Eyes on My True Powers!
3. Volume 4 Chapter 3: Crashing the Ceremony
4. Volume 4 Prologue: It’s Time for a War in the Oriana Kingdom!
5. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
6. Episode 20
7. [Director Notes: Season Special, Episode Special](https://x.com/yaduka301/status/1740569072516178260)

## Site Navigation
