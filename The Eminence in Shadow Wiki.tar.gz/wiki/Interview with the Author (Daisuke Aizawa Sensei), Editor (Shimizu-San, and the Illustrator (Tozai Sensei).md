# Interview with the Author (Daisuke Aizawa Sensei), Editor (Shimizu-San, and the Illustrator (Tozai Sensei)

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Interview%20with%20the%20Author%20%28Daisuke%20Aizawa%20Sensei%29%2C%20Editor%20%28Shimizu-San%2C%20and%20the%20Illustrator%20%28Tozai%20Sensei%29](https://the-eminence-in-shadow.fandom.com/wiki/Interview%20with%20the%20Author%20%28Daisuke%20Aizawa%20Sensei%29%2C%20Editor%20%28Shimizu-San%2C%20and%20the%20Illustrator%20%28Tozai%20Sensei%29)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Anime "The Eminence in Shadow” Interview with original author Daisuke Aizawa Sensei | How did Cid create Shichikage/the seven shades, characters that reflects his own values? [Series 04]

[Link](https://www.animatetimes.com/news/details.php?id=1672213867&p=1\)

The popular light novel by Daisuke Aizawa, which began in October 2022, is the source material for the original TV anime "I Want to Become a Powerful Person in the Shadows!" and it is now entering its second half. In episode 11, Cid, who participated in the Trial of the Goddess, reunites with Aurora, his former opponent, and joins forces with Alpha during the battle. Keep an eye on it!

In the 4th installment of Animate Times' interview series, Daisuke Aizawa, the creator and author of the original story, makes an appearance. Alongside Mr. Shimizu, who is in charge of editing, Aizawa discusses how the concept of "Kagemi" came about, the backgrounds of characters like Cid and Shichikage, his favorite episode of the anime, and the original novel released on December 28th. Additionally, they provide insights into the highlights of the 5th volume.

Q: Cid is a character that reflects his own values. What inspired you to create Shichikage?

Aizawa Sensei: First of all, "I Want to Become a Powerful Person in the Shadows!" was conceived when I announced it on the novel posting site "Let's Become a Novelist." At that time, there was a vast number of works with the theme of "transmigration to another world," which had long been popular as a genre, posted on the site. Despite the competition in that genre, I decided to write about "Reincarnation in Another World." After writing about two episodes of Injitsu, I thought, "Let's add an element of misunderstanding," and I started to believe that "this might work." I had never attempted anything like this before, and I wasn't sure if I could pull it off, but I found the concept intriguing, so I decided to give it a shot. That was my initial feeling (laughs).

Q: In the reincarnated world, the Diabolos cult mentioned by Cid actually exists after his rebirth as a baby. Constructing the world view is a big task, how did you approach it?

Aizawa Sensei: I didn't have any particular strong opinions or specifics about the worldview. It was more of a feeling.

Q: Right from the start, I was amazed by the overwhelming strength of Cid and Shichikage.

Aizawa Sensei: Personally, I enjoy the exhilaration of being overpowered. I hope readers will enjoy it too.

Q: The main character, Cid, is a chuunibyou who pursues strength, but he also aspires to rule from the shadows and admires so-called mob characters. How was his character created?

Aizawa Sensei: The fundamental aspects of Cid were decided from the beginning. He's like an embodiment of my own values. One of the things I aim to convey through my works is the values I've gained in my life up to this point. The "shell" of the work could be anything at that time. Instead of "reincarnation in another world," it could be something like "shonen manga." Since my junior high school days, I've been choosing what to value and what to discard based on my own perspective in this world.

During my junior high school years, my thoughts were somewhat shallow, and I felt like a junior high school student. I thought it was about time to express "This is how I think." That's why all the main characters in my works share this characteristic (laughs). This time, Cid values "power behind the scenes," and I don't personally relate to that (laughs), but I developed his character based on the requirements of the story.

Editor-in-charge Shimizu-san: In Cid's conversation with Ruslan in episode 9 of the TV anime, he mentions, "I clearly distinguish what's important to me and what's not," and in episode 11, he goes to the hot springs with Alexia and says, "I separate things into 'I don't care if I like it' and 'I don't care if I don't like it.'''

Aizawa Sensei: Yes (laughs).

Q: It's a relief that the teacher isn't an ambitious person aiming to rule from the shadows (laughs). OxT's Masayoshi Oishi, responsible for the OP song "HIGHEST" in the second installment, mentioned that he felt the main character grasped the second emotions he had during elementary and junior high school. He appreciated that the character seemed to gently touch their wounds. Does the teacher have such an understanding of chuunibyou?

Aizawa Sensei: I believe there are many who do. I was quite a chuunibyou during my middle school and high school years (laughs).

Q: Chuunibyou characters are known for their strong delusions, but even in the real world, Cid's determination to push himself to the limit and become stronger is impressive.

Aizawa Sensei: I feel like there's a connection between my own insecurities and things I'm dissatisfied with, so at that time, I also desired power? (Laughs) During my junior high school years, I was still unsure of myself, and I couldn't fully accept reality as it was. So, maybe I kept distorting reality in various situations. I feel that Cid also has a bit of that tendency...

Q: The presence of the seven shades that support Cid is also a major highlight of the work.

Aizawa Sensei: The choice of "seven" doesn't hold a profound meaning. There's a theory that humans can instantly remember up to around "7" plus or minus a few numbers, and "7" is considered a lucky number, making it easy to remember. For each character, I had an image of creating the necessary character at that particular moment. That's why I didn't plan detailed character settings in advance; they emerged naturally, and their details were gradually refined afterward.

Shimizu-san: In the story's progression, which revolves around Cid, the characters are created with the mindset of "If there's such a character, the story will flow more smoothly." However, if we cram too many details into the setup, it can complicate the story's development. That's the impression I have.

Aizawa Sensei: Absolutely. Naturally, when Tozai-san illustrates the novel's artwork, many visual decisions must be made, so I consulted with him as I worked on it.

Q: Yamashita-san, who plays the role of Cid, is perfect! What is your favorite anime episode?

Q: How did you feel when you saw the TV anime?

Aizawa Sensei: It was an incredibly enjoyable experience! Witnessing the characters I had conceptualized in words come to life through animation was both satisfying and slightly surreal. There's a sense that they've taken on a life of their own and moved beyond my control, which makes me happy, albeit a bit wistful (laughs). Still, overall, I'm genuinely delighted.

Q: The development from the first episode was surprisingly unexpected. How did you feel about it, Sensei?

Aizawa Sensei: The deviation in storytelling structure from the original novel intrigued me and added to the story's appeal. Concurrently, there was a slight concern about how the audience would react, but I'm relieved that their response has been positive.

Q: How was Yamashita-san’s performance as Cid?

Aizawa Sensei: I believe it's impeccable! The protagonist's presence, which I initially conceived in words, acquired a more tangible reality in the anime, which I found remarkable.

Q: What about the line "I Am Atomic" that Yamashita-san put so much effort into?

Aizawa Sensei: It was fantastic! Merging with the distinctive animations, the voice acting synced seamlessly, creating an excellent synergy. Handling distinct lines for Cid and Shadow presents its challenges, yet I'm genuinely delighted with Yamashita-san's portrayal of Cid.

Q: Do you have a favorite scene or episode out of the 13 episodes?

Aizawa Sensei: Undoubtedly, the "Atomic Episode (Episode 5)" left a profound impact and is one of my favorites.

Shimizu-san: Additionally, in the opening scene of episode 8, there's a moment where a terrorist appears at the school, and Cid shields Rose-senpai, who was about to be attacked. Furthermore, during this scene, there's a monologue by Cid. "It's the Mob's role to be the first to die."

Aizawa Sensei: That was exceptional as well! The exchange between Sherry and Alexia in episode 7 carries an indescribable emotion through the animation, making it stand out. It's among my favorites!

Q: The scene where Alexia and Cid's photos are concealed behind the photo frame is distinctive to anime.

Aizawa Sensei: I was genuinely pleased that such meticulous attention was paid to those details!

Q: Do you have a favorite character?

Aizawa Sensei: Absolutely, the main character Cid and Seven Shadows mainly Delta. All these character embody motifs from my own life, and I've had a pet dog.

Shimizu-san: So that's why it's so oblique!? (laughs) Although Delta's true potential hasn't yet been unveiled in the anime, the original novel explores Delta's various episodes, portraying him as a lovable and endearing character.

Aizawa Sensei: A character that's enjoyable to observe (laughs).

Q: Seto-san's portrayal of Alpha received attention for her portrayal of a legal wife. Were you aware of that?

Aizawa Sensei: I was conscious of ensuring her portrayal didn't diminish due to her being the first Shichikage character. Consequently, she became a character called the "Perfect Choujin" (Superhuman).

Q: Character names like Cid's friends at Midgar Academy, Hyoro Gari and Jaga Imo, often convey their treatment or traits. How do you conceive such simple yet unique names?

Aizawa Sensei: I confess to not possessing much naming acumen (laughs), so I tend to assign names as they are. The same applies to Jimina Sehnen (laughs). In the upcoming episodes I'm working on, a character named Goethe Mohno will be introduced, so look forward to it! (laughs)

Q: A recurring question for this series is whether you ever envisioned mysterious scenarios or fantasized about becoming such a character as a child.

Aizawa Sensei: Indeed, during elementary school, I wished I could run faster during races.

Q: It's been mentioned that Oishi-san of OxT and Tom-H@ck-san both pretended to perform special moves or adopted certain roles in their childhood.

Aizawa Sensei: Although I didn't physically enact those scenarios, I can certainly imagine it. I'm an avid gamer, and my childhood was greatly influenced by the games I played, especially Final Fantasy VII through IX. I held a deep admiration for Sephiroth... Although Sephiroth isn't the mastermind behind the scenes, Cid exudes a similar aura. In retrospect, while I wasn't consciously aware of it, I believe it's had an impact.

Q: Please anticipate the increasing scope of the future anime and the customary discrepancy with Cid.

Q: If you were to highlight the future prospects of the anime, what would they be?

Aizawa Sensei: As the narrative unfolds, the scope will expand, yet the interplay between Cid and the usual dynamics will remain entertaining. I hope you enjoy this aspect. Also, anticipate the potential (?) triumphs of the protagonist Cid in the future! (laughs)

Q: The highly anticipated 5th volume will be released on December 28th. What can we look forward to?

Aizawa Sensei: Regarding straightforward topics, the yet-unseen Zeta and Eta will make their appearance. Naturally, the other Shichikage and Alexia will continue their involvement. Cid's side in the Shadow Garden, Alexia's Midgar Academy perspective, and each organization are setting events into motion. While the plot deepens, Cid himself continues his carefree exploits (laughs). Fans of the original work, as well as enthusiasts of the comics, anime, and games associated with Kagemi, will find enjoyment. I believe.

Volume 5 is slightly ahead of the anime storyline, but it rearranges the focus of each episode, introducing characters not featured in the anime. I think reading the original story and comics after watching the anime can offer valuable insights. If you're intrigued, consider delving into the original novel and comics as well to experience "The Eminence in Shadow."

Q: Please share a message for everyone.

Aizawa Sensei: To start, my heartfelt gratitude to all the readers for their continuous support of the novel. I attribute my journey this far to each one of you and can only express my immense thanks. A big thank you to everyone who has engaged with the comics, anime, and games. Going forward, the series as a whole will only become more captivating, so I hope you'll continue to relish it. And for those who haven't yet experienced the work... If you've followed this interview and find novels, comics, games, and anime intriguing, I encourage you to give it a try and explore. It would bring me great joy if you found interest.

Shimizu-san: "The Eminence in Shadow" has been developed across various media platforms – original novels, comic adaptations, animation, and games – each offering unique avenues for engagement. I believe you can enjoy each medium, so I hope you venture into the world of "The Eminence in Shadow" from whichever entry point resonates with you.

Aizawa Sensei: Exactly! Thank you very much!
