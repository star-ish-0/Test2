# Red Moon

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Red%20Moon](https://the-eminence-in-shadow.fandom.com/wiki/Red%20Moon)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Red_Moon?action=edit).

Red Moon (赤（あか）き月（つき）, Akaki Tsuki[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a legendary celestial event; a rare phenomenon believed to herald the awakening of a [Vampire](Vampire.md "Vampire"), occurring once in a thousand years.

## Overview

The Red Moon resembles a total lunar eclipse, with a reddish hue that gradually deepens into scarlet akin to blood, much like the Full Moon during a complete eclipse.

## History

The Red Moon is a enigmatic event that happens only once every 1000 years, lasting for a continuous three-day period during which the sun remains hidden, shrouding the world in perpetual darkness as if night never ends. During this extraordinary occurrence, the abilities of vampires and their followers experience a dramatic surge, intensifying their cravings and thirst for blood.

According to ancient legend, the Blood Queen [Elisabeth](Elisabeth.md "Elisabeth"), along with her devoted followers, accomplished the destruction of four entire nations over the course of the three Red Moon nights. As the moon deepens in crimson hue, the power of the vampires grows exponentially. At the peak of its crimson intensity, typically around midnight on the third day, vampires reach their maximum potential, making them formidable adversaries for those who dare to challenge them, with their strength varying depending on their lineage and class.

## Trivia

- In The Eminence in Shadow, the **Red Moon** unfolds once every 1000 years and lasts three days. In stark contrast, Earth's Blood Moon—a total lunar eclipse—transpires much more frequently. It occurs approximately every year and a half, enduring only for a brief span of hours.
  - In the light novel and manga, the protagonist Cid Kagenou openly admitted having never witnessed a lunar eclipse.
- In the Anime and Game, Shadow's I Am Recovery Atomic technique reverted the Red Moon.[[1]](#cite_note-1)

## References

1. Episode 23

## Site Navigation
