# Ainoa Hinoizumino

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Ainoa%20Hinoizumino](https://the-eminence-in-shadow.fandom.com/wiki/Ainoa%20Hinoizumino)

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Ainoa_Hinoizumino?action=edit).

## Ainoa Hinoizumino

### Japanese

陽の泉のアイノア

### Romaji

Ainoa Hinoizumino

## Characteristics

### Race

Elf

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Lalanoa Hinoizumino(Daughter)

## Debut

### Light Novel

Volume 7

### Manga

Chapter 82

Ainoa Hinoizumino (陽の泉のアイノア[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the mother of Lalanoa Hinoizumino. She was stabbed to death in the flower beds when she was tending the flowers. Her death was celebrated by many elves across the elven country.

## Appearance

## Personality

## Chronology

## Relationships

## Powers & Abilities

## Trivia

## References

## Site Navigation
