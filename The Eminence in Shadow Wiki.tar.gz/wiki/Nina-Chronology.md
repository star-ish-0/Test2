# Nina/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Nina/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Nina/Chronology)

[Main](Nina.md "Nina")

[Relationships](Nina-Relationships.md "Nina/Relationships")

Image Gallery

## Background

At some point in her life, Nina met Cid—a moment she would never forget.[[1]](#cite_note-V5C2-1) She later became a member of [Zeta](Zeta.md "Zeta")'s faction until eventually becoming her personal subordinate. She was then assigned an undercover role as one of the students by infiltrating the Midgar Academy for Dark Knights to watch and protect Claire Kagenou from the Cult of Diablos. Due to her cover, Nina always cared for Claire, even as a friend, helping her whenever she could.

## Volume 5

### The Academy Disappearance

## Volume 6

## References

1. Volume 5. Chapter 2: On a Shocking Morning, the School Murder Case!
