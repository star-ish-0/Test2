# Episode 13

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2013](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2013)

## A Bloody Showdown as an Offering to Annihilation

### Kana

消滅に捧げる血闘

### Romaji

Shōmetsu ni Sasageru Kettō

## Special Title

### English

The Eminence in Shadow Wants To Demonstrate a Cliched Template!

### Kana

陰の実力者はこてこてのテンプレを実演したい！

### Romaji

Kage no Jitsuryokusha wa Kotekote no Tenpure wo Jitsuen Shitai!

## Episode Information

### Season

1

### Episode

13

### Air Date

December 28, 2022 JP
March 20, 2023 EN

### Adapted From

Volume 2 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Kunihiko Okada

### Storyboard

Daisuke Takashima

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Delta ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| The Truth Within the Memories | Your Lie, Your Wish |

A Bloody Showdown as an Offering to Annihilation (消滅に捧げる血闘, Shōmetsu ni Sasageru Kettō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the thirteenth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Alpha faces off against an empowered Nelson in a vicious battle. Elsewhere, Cid and Aurora reach the Sanctuary's core, but a door only a hero can open blocks their path.[[1]](#cite_note-1)

聖域の中心に近づき力を増したネルソンが、アルファに攻撃する中、アウロラと行動を共にしていたシドは、聖域中心に到達。しかし、英雄にしか開けない扉に足止めされてしまう。[[2]](#cite_note-2)

## Summary

Trapped in a white room, [Delta](Delta.md "Delta") easily cuts down Jack Nelson's copies, but soon feels something is wrong. Nelson explains that the closer they are to the center of the Sanctuary, the more of their power is drained, to which [Alpha](Alpha.md "Alpha") deduces that Nelson gains power closer to the center. While Nelson was hoping to get closer to the core, he feels getting this close is enough to be able to defeat them. However, Delta is happy just to be able to hunt so many prey.

After walking through a black void to reach another memory, Cid and [Aurora](Aurora.md "Aurora") arrive to a battlefield with many casualties. Cid falls head first and cushions Aurora's fall, commenting how she's heavy as she retorts he's imagining that. They find young Aurora crying again and Aurora takes Cid's sword wanting to kill her to end the memory. However, as she gets close, the dead spring up to start attacking them, but Cid rescues Aurora, as Cid notes this must some "anti-virus" reaction, as Aurora explains that the Sanctuary is rejecting them. Cid wonders what will happen if Aurora dies, she guesses she will return in the first room where they met, both agreeing that sounds obnoxious.

Within the memory's of the Sanctuary, [Epsilon](Epsilon.md "Epsilon")'s group find a sick person, with [Chi](Chi.md "Chi") and [Omega](Omega.md "Omega") moving to defense. However, Epsilon moves towards her and they phase through Epsilon to reveal the person she once was before disappearing. Epsilon then explains that it similar to the Goddess's trial, as she probably was a memory that reacted to them and materialized. With her squad confused, Epsilon clarifies she means the [possessed](Possession.md "Possession"), each recalling their darker days. They later find an archive with information about the possessed, realizing this could have happened to them too if they didn't meet Shadow. Finding more than originally considered, Chi thinks they won't need to keep coming back for information as they have Eta's new Mitsugoshi Company product, the instant cameras, based on Shadow's Wisdom. As they take pictures of the information, they note the Sanctuary core's affect on their magic is partly destabilizing their uniforms like what happened at the Academy.[[3]](#cite_note-3) While Chi and Omega are fine controlling their magic, Epsilon's slime breasts fall off and she reattaches them, with nobody seeing anything.

While Cid and Aurora are easily defeating the zombies, but Cid is easily handling himself, explaining to Aurora that he's been bodybuilding since he was a boy. As more keep coming and will likely do so indefinitely, Cid apologizes as he has to kill the young Aurora to end the memory. The two then reach the center of the Sanctuary, finding a heavily chained door behind an ornate magical sword of great importance just before the door. Meanwhile, despite ongoing power loss, Delta is obliterating the Nelson clones, confounding the original as she should be on limited magical power by now. Seeing her barely struggle, Nelson asks if she is awakened, despite the technique necessary to accomplish that being lost, only for Alpha to rebuttal if it really was, frightening Nelson to see more clones slain. Unleashing his full power and amassing a hundred more clones, Nelson's confidence evaporates upon seeing Delta charge up her "Iron Slab" sword, used like a wide hammer to multi-kill the clones.

As Aurora tells Cid that they need to destroy the magic core on the other side of the sealed door. Cid's initial idea to cut the chains is rejected and Aurora notes there should be a key, clearly the ornate sword with inscription that it can cut the chains. Looking at it, Cid is sure he won't be able to remove the sword, as his attempted removal actually sinks into the stone, stating it must be drawn out by the chosen one. Aurora then sees a sign stating that the holy sword can only be drawn by direct descendants, surprised that Cid managed to decipher the magical inscription that fast. While Cid's efforts left some cracks in the sword's hilt, he states he is well versed in all the standard formulas, surprising Aurora that he memorized all of the countless magical scripts encryption patterns. With no other way to open the door nor an alternative path, the two then sit down in waiting.

Watching Delta fight Nelson, Alexia, Rose, and Beta come to pity the Cultist. Alexia even wonders if Delta really is working with Shadow, explaining that Delta's fighting style is totally different from Shadow's sophisticated techniques, with Delta only using unbridled violence. As Delta defeats more Nelson clones, the memory breaks to return them to their starting point, and Nelson is surprised she managed to defeat over one hundred copies without even breaking a sweat. Deducing he was a scientist once, Alpha states that even if he could create a hundred copies, they all still have one brain and he couldn't control them all that well. In a panic, Nelson then sees [Olivier](Olivier.md "Olivier")'s statue and summons her memory.

However, Epsilon's party reunites with Alpha's group having finished with the investigation and they can now leave. Nelson is surprised that they are just running away, but Alpha explains that their objective was to cut off the source of power and they now know how the Sanctuary defenses work. Thus, Shadow Garden will visit again but at a time of their choosing. As Shadow Garden begins their exit, Alpha had to bring a snarling Delta to heel to comply. Offered an exit as well, Beta goads Alexia to taking the exit. Once alone, Nelson got a good look at Alpha, scheming to take her blood so they can perfect the Beads. Wondering what to say to the rest of the Cult, he thinks he can claim he lured them into a trap to expose their identities, but gets a notification that someone is in the Sanctuary's center. While he initially thinks he can let off steam, he has a flashback to Delta's massacre and orders Olivier to follow.

Still waiting for something, Cid asks Aurora what she meant by she wants to disappear, so she explains that she'll be set free once the Sanctuary core is destroyed, as it is a prison of memories that repeats into eternity. Cid accepts her answer and requests she wait a bit more, to let things work out. Recalling story formulas, Cid expects the "protagonist" to show up and pull the sword. However, Nelson appears and Cid wonders if it's a scenario where the bad guy arrives first to stop the protagonist. Although Cid sees Olivier has the same face as Alpha, he dismisses the though before Nelson notes Cid freed Aurora. But she can't recall him as her memories are incomplete, Nelson sends Olivier to attack as Cid goes to face her, knowing that she is quite strong.

As Olivier attacks Cid, he blocks her attacks even though she sends him flying everywhere and ends up breaking his sword. Yet as Nelson wonders why Cid is smiling, Cid realizes he is indeed smiling. Olivier attacks again and injure Cid's shoulder, but Cid is unfazed and finds Olivier is just a mindless shell. Nelson questions how Cid is still alive, as Cid notes that a battle without a conversation is tedious, that Olivier doesn't have a heart so she isn't answering any of his questions. Nelson doesn't understand what he is talking about and orders Olivier to finish him off. But Aurora interjects begging Cid to stop, knowing that no human can defeat Olivier, despite her uncertainty knowing the fact. She tells Cid he's done enough and gave her more new memories that she could have asked, wanting him to stop and willing to solve the rest on her own. Nelson laughs at her, noting that she's helpless without magic, but he barters to spare Cid if she agrees to help him, needing her to return to schedule with the Cult's plans. But Cid interrupts them stating that he doesn't need help and they shouldn't assume he will lose. Enraged, Nelson foregoes any promises and orders Olivier to kill him, flanking and stabs Cid. While Aurora is in shock and Nelson grins, Cid opens the right eye he has had closed since he found Aurora, stating that he got Olivier, as magic circuit lines flare magic unaffected by the core.

## Characters

- Jack Nelson
- [Alpha](Alpha.md "Alpha")
- [Delta](Delta.md "Delta")
- [Beta](Beta.md "Beta")
- Alexia Midgar
- Rose Oriana
- [Epsilon](Epsilon.md "Epsilon")
- [Chi](Chi.md "Chi")
- [Omega](Omega.md "Omega")
- [Aurora](Aurora.md "Aurora")
- Cid Kagenou
- [Olivier](Olivier.md "Olivier")

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第13話予告≪ノーマルVer.≫「消滅に捧げる血闘」

TVアニメ『陰の実力者になりたくて！』第13話予告≪スペシャルVer.≫「陰の実力者はこてこてのテンプレを実演したい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e013>
2. <https://shadow-garden.jp/1st/story/#story13>
3. Episode 7

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • **Episode 13** • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
