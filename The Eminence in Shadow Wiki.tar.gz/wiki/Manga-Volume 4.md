# Manga/Volume 4

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%204](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%204)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_4?action=edit).

## Manga Volume 4

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041093320

### ISBN EN

ISBN 978-1975338763

### Release Date

August 25, 2020 JP
June 21, 2022 EN

## Volume Information

### Pages

144 JP
162 EN

### Chapters

4

Publication Order

| Previous | Next |
| --- | --- |
| Volume 3 | Volume 5 |

This is the fourth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

Cid is invited to Lindwurm, the Sacred Land, where a ritual known as the Goddess’s Trial is held. Ancient warriors are summoned according to the strength of the challenger, providing an opportunity for honor and glory—all the normie stuff Cid specifically wants to avoid! If his true strength is revealed, all his work to play the part of a nobody will be for naught...[[1]](#cite_note-1)

よっしゃ 「謎の実力者乱入で全部うやむやにしよう」作戦大成功だ!!!
異世界に転生し「陰の実力者」設定を楽しむシド。「女神の試練」が開催される聖地リンドブルムに赴いたが、そこには黒い噂のある大司教代理がいて――？強大な力と重度の勘違いで切り抜ける最強奇譚、第４弾！[[2]](#cite_note-2)

## Summary

### Midgar Academy Terrorism

Absent during the terrorist assault on Midgar Academy for Dark Knights, Alpha meets with Gamma after the incident who informs her of the situation. Despite Shadow Garden being framed as the perpetrators by the Order of Diabolos, she nevertheless resolves to continue following her master's will, ordering [Gamma](Gamma.md "Gamma") to gather the Shadow Seven before departing.

## Chapters

- Episode 13
- Episode 14
- Episode 15
- Episode 16

## Characters

:   In order of appearance:

- Cid Kagenou
- [Nu](Nu.md "Nu")
- Rose Oriana
- Lutheran Barnett
- Lukreia (Debut)
- Sherry Barnett
- Skel Etal
- Po Tato
- [Alpha](Alpha.md "Alpha")
- [Gamma](Gamma.md "Gamma")
- [Beta](Beta.md "Beta")
- Alexia Midgar
- [Epsilon](Epsilon.md "Epsilon") (Debut)
- Nelson (Debut)
- Annerose (Debut)
- [Aurora](Aurora.md "Aurora") (Debut)
- [Delta](Delta.md "Delta")
- [Gamma](Gamma.md "Gamma")
- [Venom](Venom.md "Venom") (Debut)

## References

1. [The Eminence in Shadow, Vol. 4 (manga). YenPress](https://yenpress.com/9781975338763/the-eminence-in-shadow-vol-4-manga/)
2. [The Eminence in Shadow (4). Kadokawa](https://www.kadokawa.co.jp/product/321912000567/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • **Volume 4** • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
