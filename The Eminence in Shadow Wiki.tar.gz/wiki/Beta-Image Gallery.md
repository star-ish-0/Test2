# Beta/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Beta/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Beta/Image%20Gallery)

[Main](Beta.md "Beta")

[Chronology](Beta-Chronology.md "Beta/Chronology")

[Relationships](Beta-Relationships.md "Beta/Relationships")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Beta's profile in English

Beta's profile in Japanese

Promotion

Volume 1

Volume 3

Volume 4

Beta vs Elizabeth

Beta and Tanaka's items

Homecoming

Season 1

Beta as Natsume Kafla

Beta meeting with Cid.

Epsilon teasing Beta

Teen Beta in her slime suit

White Slime Suit Beta

Illustration

Lovely Stories: Beta

Bright World: Beta

Romantic Artist: Beta

Best-selling Author: Beta

Ocean Temptation: Beta

Clever Bunny: Beta

Shadow Observer: Beta

Untouched Beauty: Beta

Second Member: Beta

Rivals in Sinc: Epsilon & Beta

Game Event: Clever & Lucky Bunny Girls!

Game Event: Apocrypha "Requiem for the Falling Shadows": Demonic Beta

Game Event: Apocrypha "Requiem for the Falling Shadows": Demonic Alexia VS Demonic Beta

Game Event: Apocrypha "Requiem for the Falling Shadows": Beta (demonic) summons clones of her master Shadow against Alexia (demonic).

Demonic Second: Beta

Second White Shadow: Beta.

Boughs of Shadow: Game chapter 5 - Epsilon and Beta stuck to the center

Game Event: Apocrypha "Requiem for the Falling Shadows": Demonic Epsilon & Demonic Beta

Service Is My Specialty: Beta
