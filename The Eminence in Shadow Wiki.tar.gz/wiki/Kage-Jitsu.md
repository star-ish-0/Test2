# Kage-Jitsu

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kage-Jitsu](https://the-eminence-in-shadow.fandom.com/wiki/Kage-Jitsu)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Kage-Jitsu?action=edit).

## Spin-off

- Season 1
- Season 2

### English

Kage-Jitsu!

### Kana

かげじつ!

### Rōmaji

Kagejitsu!

## Production

### Original Story

Daisuke Aizawa

### Original Design

Tōzai

### Studio

[Studio PuYUKAI](https://en.wikipedia.org/wiki/Studio_Puyukai "wp:Studio Puyukai")

### Direction

Minoru Ashina

### Air Date

October 26, 2022 - February 15, 2023  (season 1)
October 4, 2023 - December 20, 2023  (season 2)

### Episodes

17  (season 1)
12 (season 2)

Kage-Jitsu! (かげじつ!, Kagejitsu![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a spin-off series based on Daisuke Aizawa’s The Eminence in Shadow Light Novel. The first season aired from October 26, 2022 and concluded on February 15, 2023, dubbed by [Sentai Filmworks](https://en.wikipedia.org/wiki/Sentai_Filmworks "wp:Sentai Filmworks") into English on October 10, 2023 and called Em-Shade! Shorts. The second season aired from October 4, 2023 and concluded on December 20, 2023. All episodes are available on [Kadokawa's official YouTube channel](https://www.youtube.com/@KADOKAWAanime).

## Description

A spin-off chibi anime of Kage no Jitsuryokusha ni Naritakute!

## Characters

- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Gamma](Gamma.md "Gamma")
- [Delta](Delta.md "Delta")
- [Epsilon](Epsilon.md "Epsilon")
- [Zeta](Zeta.md "Zeta")
- [Eta](Eta.md "Eta")
- [Nu](Nu.md "Nu")
- Shadow (Background)

## Episodes

- [Season 1](#)
- [Season 2](#)

| Episode # | Image | Title | Air Date |
| --- | --- | --- | --- |
| 1 |  | Operation 1 オペレーション 1 Operēshon 1 | October 26, 2022 |
| 2 |  | Operation 2 オペレーション 2 Operēshon 2 | November 2, 2022 |
| 3 |  | Operation 3 オペレーション 3 Operēshon 3 | November 9, 2022 |
| 4 |  | Operation 4 オペレーション 4 Operēshon 4 | November 16, 2022 |
| 5 |  | Operation 5 オペレーション 5 Operēshon 5 | November 23, 2022 |
| 6 |  | Operation 6 オペレーション 6 Operēshon 6 | November 30, 2022 |
| 7 |  | Operation 7 オペレーション 7 Operēshon 7 | December 7, 2022 |
| 8 |  | Operation 8 オペレーション 8 Operēshon 8 | December 14, 2022 |
| 9 |  | Operation 9 オペレーション 9 Operēshon 9 | December 21, 2022 |
| 10 |  | Operation 10 オペレーション 10 Operēshon 10 | December 28, 2022 |
| 11 |  | Operation 11 オペレーション 11 Operēshon 11 | January 4, 2023 |
| 12 |  | Operation 12 オペレーション 12 Operēshon 12 | January 11, 2023 |
| 13 |  | Operation 13 オペレーション 13 Operēshon 13 | January 18, 2023 |
| 14 |  | Operation 14 オペレーション 14 Operēshon 14 | January 25, 2023 |
| 15 |  | Operation 15 オペレーション 15 Operēshon 15 | February 1, 2023 |
| 16 |  | Operation 16 オペレーション 16 Operēshon 16 | February 8, 2023 |
| 17 |  | Operation 17 オペレーション 17 Operēshon 17 | February 15, 2023 |

| Episode # | Image | Title | Air Date |
| --- | --- | --- | --- |
| 18 |  | Operation 1 オペレーション 1 Operēshon 1 | October 4, 2023 |
| 19 |  | Operation 2 オペレーション 2 Operēshon 2 | October 11, 2023 |
| 20 |  | Operation 3 オペレーション 3 Operēshon 3 | October 18, 2023 |
| 21 |  | Operation 4 オペレーション 4 Operēshon 4 | October 25, 2023 |
| 22 |  | Operation 5 オペレーション 5 Operēshon 5 | November 1, 2023 |
| 23 |  | Operation 6 オペレーション 6 Operēshon 6 | November 8, 2023 |
| 24 |  | Operation 7 オペレーション 7 Operēshon 7 | November 15, 2023 |
| 25 |  | Operation 8 オペレーション 8 Operēshon 8 | November 22, 2023 |
| 26 |  | Operation 9 オペレーション 9 Operēshon 9 | November 29, 2023 |
| 27 |  | Operation 10 オペレーション 10 Operēshon 10 | December 6, 2023 |
| 28 |  | Operation 11 オペレーション 11 Operēshon 11 | December 13, 2023 |
| 29 |  | Operation 12 オペレーション 12 Operēshon 12 | December 20, 2023 |

## Trivia

- In the spin-off, the provided English subtitles call the upper echelons of Shadow Garden the Seven Shades rather than the Seven Shadows—another conceivable translation.

## References
