# Claudia

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Claudia](https://the-eminence-in-shadow.fandom.com/wiki/Claudia)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Claudia?action=edit).

## Claudia

### Japanese

クローディア

### Romaji

Kurōdia

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Black

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

- Swordswoman
- Association Elite Staff Member

### Affiliation

Dark Knight Association

## Debut

### Web Novel

Chapter 98

### Light Novel

Volume 3

### Manga

Chapter 29

### Anime

Episode 21

## Portrayal

### Japanese

[Makoto Koichi](https://en.wikipedia.org/wiki/Makoto_Koichi "wp:Makoto Koichi")

### English

[Shannon Emerick](https://en.wikipedia.org/wiki/Shannon_Emerick "wp:Shannon Emerick")

Claudia (クローディア, Kurōdia[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is an elite staff member of the Dark Knight Association who becomes the leader of Association's task force.

## Appearance

Claudia wears a trench coat with a suit underneath. She also wears an armband of the crest of the Dark Knight Association.

## Personality

As a member of the Association, Claudia was responsible for the people working under her and did her best to follow orders, even if they were bad.

Claudia expressed her dislike towards the people in charge of the Association because they had repeatedly sexually harassed her throughout her time there.

As a swordswoman, she has shown to be brave individual to face off against the Ghouls and Vampires. However in the end, the odds were against her that she ordered a retreat to save herself regardless of the repercussions that will follow.

## Chronology

### Red Moon Incident

Claudia is the one in charge of leading the assault operation with her forces against the Crimson Tower and its owner, [Elisabeth](Elisabeth.md "Elisabeth") the Blood Queen. However, she and her men she and her men were up against too many [Ghouls](Ghouls.md "Ghouls") resulting the deaths of many members, including Graine.

Claudia is forced to order her entire team to retreat as she protected her rear. However, no one helping her. She is surrounded and about to be killed until Shadow stepped in to save her by slaughter all of ghouls instantly. After seeing his unbelievable power, she asks him for his assistance in taking down the Blood Queen but he declined and says to end it himself.[[1]](#cite_note-V3C1-1)

## Powers & Abilities

As an elite staff member, Claudia is one of the strongest members of the Dark Knight Association.

## Relationship

### Shadow

After seeing Shadow's action, she starts to believe that Shadow could not be the criminal the world saw him as. After silently thanking him for saving her life, Claudia intends to find out more about his alleged 'crimes'.[CITATION NEEDED]

## Trivia

## References

1. Volume 3 Chapter 1: Lawless City Bandit Hunting!

## Site Navigation
