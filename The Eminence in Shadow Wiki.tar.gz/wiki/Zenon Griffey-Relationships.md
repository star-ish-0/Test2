# Zenon Griffey/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Zenon%20Griffey/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Zenon%20Griffey/Relationships)

Main

Chronology

Image Gallery

## Cult of Diablos

### [Willow](Willow.md "Willow")

Willow was a fellow Cult member, infiltrator, and former mentor. Despite their student teacher relationship, he noted Zenon to be a terrible student.[[1]](#cite_note-V5C2-1)

### Lutheran Barnett

Fellow Cult member and infiltrator, Lutheran fell out of favor and lost his position of 12th seat when he was suffering from chronic illness.[[2]](#cite_note-2) The Round Knights saw Zenon's potential as his replacement when he demonstrated his strength and abilities but lacked the achievements to warrant the position. Due to this, he was set as a prime candidate for the position until he tried proving it by harvesting Alexia's blood and offing Shadow.[[3]](#cite_note-3)

### Perv Asshat

Candidate for the 12th seat position. After the instructor and assistant principal's death, the duke under [Mordred's](Mordred.md "Mordred") support had sought the position by infiltrating Oriana as the royal chancellor. Despite the disparity between him and the instructor in physical abilities, Perv had dubious means in elevating himself to the position. He almost succeeded when Cid pocketed his engagement ring and was killed after Rose exposed him and his plans.[[4]](#cite_note-4)

### Archbishop Nelson

An original member of the Cult and 11th seat of the Round Knights. Nelson was responsible for the creation of Diablos Tears and mass production of its normal variant. Zenon's death resulted in the discovery of the Cult and their connections to not only Midgar but to the Other World when Alexia investigated the priest for unrelated reasons.[[5]](#cite_note-5)

## Enemies

### Midgar Kingdom

#### Alexia Midgar

His former arranged betrothed and student. From the very beginning, he didn't mind with the arrangement but preferred Iris while Alexia despised him for his impeccable façade and forced future on him. As a result, she started her relationship with Cid as a means to spite Zenon, but the instructor easily saw through and allowed it to continue before telling her to get used to their engagement.[[6]](#cite_note-:0-6)

In due time, he had her kidnapped and revealed he was harvesting her royal blood for an experiment. While revealing his true nature, he proceeded to belittle her for her mediocrity in swordplay and abilities. Zenon even sarcastically apologized for comparing her to her sister but didn't hesitate to brutalize and recapturing her before Shadow intervened. After his death, Alexia did not feel anything and was glad of his death and newfound freedom when she confessed to Cid.[[7]](#cite_note-:1-7)

#### Iris Midgar

His would-be sister-in-law, Iris respected Zenon enough to entrust him of leading the investigation regarding the disappearance of her sister.[[6]](#cite_note-:0-6) Iris was unaware of his true nature and upon learning that he was the mastermind of Alexia's abduction, she was shocked of the revelation and apologize to Cid for suspecting him during the Bushin Festival.[[8]](#cite_note-8)

### Shadow Garden

#### Cid Kagenou / Shadow

Student and scapegoat. Cid was briefly his student when Alexia began to date him out of spite. Initially on avoiding the course, the Princess recommended him into his class under coercion. Like her, Zenon saw Cid as the perfect patsy when he framed him for her kidnapping.[[6]](#cite_note-:0-6)

As Shadow, Zenon was aware of his existence as the man who took down several of the cult's hideouts. His underestimation of the Shadow Garden leader would result to him being on the losing end of a belittling one-sided fight, as his attacks are easily parried with little to no effort.

Zenon lost all of his composure and finally gave in to his rage by swallowing the Beads of Diablos to become the "Third Awakened". Despite being in his Awakened form, it is still not enough to defeat Shadow and was horrified upon realizing the huge disparity in their powers, to the point that he even broke his own sword after he desperately tried to slash Shadow with it. He met his end as he remained frozen in shock, when Shadow used his "I Am Atomic" attack to annihilate him alongside his hideout.[[7]](#cite_note-:1-7)

#### Rose Oriana

Queen of Oriana and affiliate of Shadow Garden, it is unknown whether Zenon was aware of her engagement or possession symptoms. However, his death inadvertently forced Rose into hiding from his fellow candidate and eventually become a member of Shadow's organization.[[9]](#cite_note-9) It was after freeing Oriana from the Cult that the former princess became the sole heir and left Shadow Garden as affiliate.[[10]](#cite_note-10)

### Others

#### [Millia](Millia.md "Millia")

One of the Cult's test subjects under Zenon's custody, it is unknown whether he was aware of her identity or [father](Grease.md "Grease"). However, her intervention in freeing Alexia allowed her to discover the both the Cult's and Shadow Garden's existence firsthand as well as his true colors.[[7]](#cite_note-:1-7)

#### Claire Kagenou

Cid's elder sister, it is unlikely Zenon was aware of her past instance with the Cult or her [Possession](Possession.md "Possession") symptoms. During his report to Iris regarding Cid's interrogation, Claire barged in to confront Iris of his condition and had threatened her to release him. She would've stopped at nothing for her brother even if it meant going against the Knight Order and his instructor.

In the Light Novel, Zenon tried to stop her from confronting Iris by warning her of the incautions of pressing further in the matter. He threw her out of the room when she threatens Iris about Cid's condition [[6]](#cite_note-:0-6)

In the anime Rose stopped her from confronting Iris which Iris asked Zenon who she was. Upon his careful response, Iris decided to release the student's brother under his supervision.[[11]](#cite_note-11)

## Reference

1. Volume 5 Chapter 2: Shocking Morning, School Skewer Murder Case!!
2. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
3. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
4. Volume 4 Chapter 3: Crashing the Ceremony!
5. Volume 2 Chapter 2: Investigating the Sanctuary!
6. Volume 1 Chapter 2: Assuming the Role of a Side Character at School!
7. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
8. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
9. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
10. Volume 5 Chapter 4 The World is at Peace Today
11. Episode 4
