# Spartan

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Spartan](https://the-eminence-in-shadow.fandom.com/wiki/Spartan)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Spartan?action=edit).

## Spartan

### Japanese

スパルタン

### Romaji

Suparutan

## Location Information

### Leader

Unknown

### Status

Active

### Affiliates

Unknown

### Type

City-State

### Government

Unknown

### Location

Unknown

### Inhabitants

Unknown

## Debut

### Light Novel

Volume 6

### Manga

Chapter 72.1

Spartan (スパルタン, Suparutan[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a city-state with an unknown location. Spartan's coliseum is described as the harshest in the world by Korrupt White.[[1]](#cite_note-:0-1) Any details such as its location, history, or leadership are completely unknown.

The only mention of someone from Spartan was a warrior nicknamed ["The Butcher of Minced Meat"](Butcher.md "Butcher") who fought 200 battles in Spartan's colosseum without losing a single one. This warrior lost their life, however, when they fought Cid Kagenou who was acting as Jack the Ripper.[[1]](#cite_note-:0-1)

## References

1. Volume 6 Chapter 4: And the Monster Becomes a Legend!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • **Spartan** • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
