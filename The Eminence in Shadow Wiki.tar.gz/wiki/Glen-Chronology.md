# Glen/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Glen/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Glen/Chronology)

[Main](Glen.md "Glen")

[Relationships](Glen-Relationships.md "Glen/Relationships")

Image Gallery

## Early Life During Military Service

Not much is known about Glen's early life, other than that he had joined Midgar Knight Order during his adulthood. He served alongside Zenon Griffey when he saw Princess Iris Midgar' outstanding sword skills and talent from an early age. Glen also developed a friendship with Marco Granger.

## Princess Alexia's Kidnapping

After Princess Alexia's case was closed, Glen and Marco Granger held a private meeting with Princess Iris Midgar. Upon learning the existence of secret organizations such as the Cult of Diablos and Shadow Garden, she requested them to join her conceptualized Crimson Order. She started her own order due to her distrust towards the Knight Order upon learning that Zenon was a member of the Cult and discovered a burnt down warehouse arson which contained destroyed evidence, storing classified documents and objects from Cult of Diablos had confiscated. The two agreed in helping the princess investigate the organization, becoming the first members of the Crimson Order.[[1]](#cite_note-1)

## Midgar Academy Terrorist Attack

Glen and Marco accompanied Princess Iris and Alexia to meet Sherry Barnett at Midgar Academy in order to decipher the artifact functions known as the "Eye of Avarice", which was the only known item connected to the Cult of Diablos. Assistant Principal Lutheran Barnett allowed it, but only took two guards which Princess Iris pick Glen and Marco as her trusted subordinates.[[2]](#cite_note-V1C4-2)

While Glen served as Sherry's bodyguard, the Cult terrorized the academy posing as Shadow Garden under orders of retrieving the artifact Sherry was entrusted to decipher. Amidst the chaos, Sherry was attacked by [Rex](Rex.md "Rex") posing as a Shadow Garden member whose ordered to retrieve the artifact from her. Despite having his magic disabled, Glen was able to fend off the Named Child long enough for Sherry to escape before being killed by Rex.

Sometime afterwards, [Nu](Nu.md "Nu") passed by to find Glen's lifeless body and Marco unconscious. Shadow later avenged him by brutally killing Rex.[[3]](#cite_note-V1C6-3)

After the incident, a funeral was held for him with Iris and Marco paying their respect. The failure of the Crimson Order's first mission and his death after joining caused Iris to lose the majority support from the Knight Order. Iris noted to herself that her Crimson Order had lost their strongest member and will not likely to recuperate.[[4]](#cite_note-4)

## Legacy

After his death, it is revealed that Hubb became his successor to replace his position as the Vice-Commander of Crimson Order when Princess Iris lost to Shadow at the Bushin Festival. After Hubb became the Vice-Commander, more knights joined the Order but lacked competency. Unbeknownst to Iris, Hubb is a member of the Cult and infiltrated the Order to manipulate her by providing forged evidence regarding both the Cult and Shadow Garden.[[5]](#cite_note-V5C2-5)

## References

1. Episode 5
2. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
3. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
4. Episode 14
5. Volume 5 Chapter 2: Shocking Morning, School Skewer Murder Case!!
