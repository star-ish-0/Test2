# Episode 28

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2028](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2028)

## The Dragon's Tears

### Kana

龍の涙

### Romaji

Ryū no Namida

## Special Title

### English

A Day Without The Eminence in Shadow

### Kana

陰の実力者の居ない一日

### Romaji

Kage no Jitsuryokusha no Inai Ichinichi

## Episode Information

### Season

2

### Episode

8 (28)

### Air Date

November 22, 2023 JP & EN

## Staff

### Director

Daisuke Takashima

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

Grayscale dominator

### Ending

Darling in the Night
(Seven Shadows Ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Something Precious | The Key |

The Dragon's Tears (龍の涙, Ryū no Namida[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the eighth episode of the second season, and the twenty-eighth episode of [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

With Cid missing and things getting hot, the Shadow Garden springs into action. At the Mitsugoshi Hot Springs Land that is! [[1]](#cite_note-1)

ヒョロとジャガから「ミツゴシ温泉ランド」に誘われたニュー。シャドウの作戦だと察知した七陰は、任務という名のグループデートに意気込む。メンバーに選ばれたのは……。[[2]](#cite_note-2)

## Summary

Skel and Po go to Cid's dorm room to invite him to accompany them to Mitsugoshi HQ to hit on the employees. However, they find Cid missing but discover six premium tickets for Mitsugoshi Hot Springs Land, and from their usual logic, they decide in their own favor to use the tickets to boost their chances of meeting ladies. They head over to Mitsugoshi, where they show [Nu](Nu.md "Nu") the tickets and ask her to join them. Only for Nu to turn from exhausted by their antics to perplexed by this, so she takes them inside Mitsugoshi's offices to interrogate them with a pair of employees polishing weapons for intimidation.

She asks how they acquired the tickets, as the contents were delivered only to a chosen few, to which Skel and Po were not among those names. They tell her that they got them from their friend, Cid, and that he asked them to invite Mitsugoshi employees. She asks to confirm if the Cid they are talking about is Cid Kagenou, the two claim as such and that he gave them the tickets. Knowing Cid is her lord, Shadow, Nu surmises that he gave the tickets to his classmates for some purpose and has The Numbers call a meeting with the Seven Shadows. She asks if Cid will be present in the hot spring, they affirm, and she takes her leave while asking they take their leave in a wrathful tone.

In the conference room, they convened to deliberate on the motive behind Cid's cryptic message. Alpha discusses with the Seven Shadows and the rest of the Numbers what could be Shadow's plan sending his schoolmates to invite her on a date, before correcting herself and claiming it was for all of them. [Eta](Eta.md "Eta") proceeds to explain the origin of Mitsugoshi Hot Springs Land, inspired by a tale native to the area where the resort was built.

In their earlier years, after completing a mission to quell the Cult of Diablos, a dying adversary muttered to Shadow that he would never possess the dragon’s golden tears. Intrigued, Shadow inquired with the other members, and [Gamma](Gamma.md "Gamma") recalled a reference to the dragon's tears in a regional fable. This prompted Shadow to lead the group to start digging throughout the region for these elusive tears. After three days of digging, Shadow abruptly departed and left the girls to continue the excavation, during which Eta stumbled upon a hot spring.

The Mitsugoshi Hot Springs Land was subsequently established at that very location, but despite their efforts, they failed to detect any trace of dragon magic in the area. Hence, the impending trip to the hot springs was seen as an opportunity to uncover new information. As they debated on who would attend the hot springs excursion, as three tickets were for Cid and his friends, leaving another three tickets for a select trio among themselves. With disagreement, the subordinate members leave to allow the leadership to resolve the debate, and a resolution was reached through a game of rock-paper-scissors. Consequently, [Beta](Beta.md "Beta"), [Zeta](Zeta.md "Zeta"), and [Delta](Delta.md "Delta") emerged as the chosen trio to embark on this quest for answers.

At Mitsugoshi Hot Springs Land, the trio encounters Skel and Po, but their anticipation is dampened by the absence of Cid. Frightened by their angered smiles, Po offers reassurance that Cid is merely running late, alleviating their concerns as they begin to head inside. Despite the setback, Skel and Po forge ahead with their 'date,' attempting to apply insights gleaned from the book "World's Best Love Tips: Your Heart-Pounding First Hot Springs Date Edition" by Count Virgin Boy, albeit with the author's recorded little success.

In the meantime, given how there's no battle or mission, [Alpha](Alpha.md "Alpha") speculates that Shadow's mission might have been to encourage them to unwind and take a reprieve for once in their five years of activity. Just as this notion circulates, [Epsilon](Epsilon.md "Epsilon") asks [Chi](Chi.md "Chi") and [Omega](Omega.md "Omega") if there was any trouble, but aside from Nu taking paid leave for the grand opening, Chi found no troubles. However, Eta arrives with a report, disclosing the detection of an anomalous magical signature underground.

In the females-only bath, Zeta contemplates the mission's purpose and can only conclude with the significance of the dragon's tears. [Lambda](Lambda.md "Lambda") proceeds to narrate a [Shadow Play](https://en.wikipedia.org/wiki/Shadow_play) of the dragon's tears legend: Once upon a time there lived in the land a kind and gentle princess, who rescued a small dragon separated from it's clutch.

The princess and the dragon became friends and grew up together. But their peaceful and happy days were ended when war broke out. The dragon fought to protect the princess, fending off a hundred thousand soldiers despite being afflicted by deep wounds, but returned to find the capital in ruins. As the princess was about to breathe her last, the dragon implored her to open her eyes and begged they could soar through the skies together once more. As a tear fell from the princess’ lifeless body, the dragon then began to weep uncontrollably until hot tears flooded the land, covering the entire kingdom. The princess awoke to find a mysterious hot spring filled with the essence of life. But the dragon was nowhere, even as the princess called the dragon's name, and received no response.

In the midst of the contemplative atmosphere within the females-only bath, Zeta speculates that the key to Shadow's objective may be concealed within the legend; while Beta complemented Lambda's performance. Meanwhile, Skel and Po poorly attempt to discreetly observe the ladies' bath, but Eta sprays their eyes with an eye irritant mechanism. The unexpected result of their tears falling into the hot spring triggers a surge in magical energy.

Replicating the effect on the boys proved fruitless. Connecting the legend to the princess's tears, Zeta formulates a hypothesis. Eta, seizing on this revelation, decides to employ Beta, the self-proclaimed lovely elven princess, as the source of tears. Employing a less-than-dignified tactic, Eta goads Beta until she succumbs to tears. As Beta's tears mingle with the hot spring, a seismic tremor courses through the land.

With the event drawing public attention, Alpha and her group convene in the public area and find the water in the Mitsugoshi Hot Springs Land main pool taking on a form of a dragon, prompting chaos. As Alpha ponders if this was what Shadow had meant, Beta and her group return as Gamma swiftly commands the Mitsugoshi employees to safely evacuate the guests. Adapting to the circumstances, the Shadows don white attire instead of their customary black. While Epsilon is initially confused to see themselves in colored versions of their uniforms, Eta applied spray colors out of necessity in concealing their true identities as members of the Shadow Garden.

The dragon is confronted by the Shadows, but Eta and Gamma fall behind, and Beta is taken captive as she is still hurt by Eta's words. Once the dragon is defeated by Alpha, a golden magic cascades like snow from above upon their victory, infusing the hot spring water with enchanting properties that improve beauty and health, such as skin quality and high blood pressure and more. While Beta continues to shed tears, the dragon's spirit tenderly licks them from her eyes before ascending into the sky. As they witness this ethereal spectacle, Alpha concludes Shadow's true intent was to rescue the dragon's soul, which had led him to dispatch them on this unforeseen mission.

Afterward, Gamma and the Mitsugoshi staff entertain that the guests come back, claiming the event was staged for the opening and use it to sell limited edition merchandise to celebrate the resort's grand opening. As the guests buy the merchandise, Gamma is pleased by the profits while Alpha is pleased by the dragon's salvation. Inside the vendor stall, Nu recalls how she was on her day off but is working the venue, to which Lambda just tells her to take a compensation day for her troubles, and the day continues as usual for everyone.

Later in the evening, Skel and Po head home with no recollection of what happened from all the damage they took. However, Po thinks that is a good sign as it fits with Count Virgin Boy's book and they're on the right track to becoming "men", as they cheer into the night.

## Characters

- Cid Kagenou (Mentioned)
- Skel Etal
- Po Tato
- [Nu](Nu.md "Nu")
- [Alpha](Alpha.md "Alpha")
- [Delta](Delta.md "Delta")
- [Eta](Eta.md "Eta")
- [Beta](Beta.md "Beta")
- [Gamma](Gamma.md "Gamma")
- [Epsilon](Epsilon.md "Epsilon")
- [Zeta](Zeta.md "Zeta")
- [Omega](Omega.md "Omega")
- [Chi](Chi.md "Chi")
- [Elisabeth](Elisabeth.md "Elisabeth")
- [Mary](Mary.md "Mary")
- [Lambda](Lambda.md "Lambda")
- [Yukime](Yukime.md "Yukime")
- Alexia Midgar
- [Natsu](Natsu.md "Natsu")
- [Kana](Kana.md "Kana")

## Promotional Videos

「陰の実力者になりたくて！ 2nd season」 第8話予告≪ノーマルVer.≫「龍の涙」

『陰の実力者になりたくて！ 2nd season』 第8話予告≪スペシャルVer.≫「陰の実力者の居ない一日」

## Trivia

- This is the first anime original episode of [The Eminence in Shadow](Anime.md "Anime").
- The illustration in the Ending is made by Touzai (東西), the illustrator of the Light Novel

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e028>
2. <https://shadow-garden.jp/story/#story8>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • **Episode 8** • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
