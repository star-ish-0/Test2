# Yuudai Saejima

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Yuudai%20Saejima](https://the-eminence-in-shadow.fandom.com/wiki/Yuudai%20Saejima)

Chronology

Relationships

Image Gallery

## Yuudai Saejima

### Japanese

冴島（さえじま）ユウダイ

### Romaji

Saejima Yūdai

## Characteristics

### Race

[Human](Human.md "Human") (Earthling)

### Gender

Male

### Age

20 or 21

### Height

Unknown

### Hair Color

Black

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- Knight Vice Commander
- Student of Sakurazaka High School (formerly)
- Agent for The Alliance

### Affiliation

[Messiah](Messiah.md "Messiah") (Insider)

## Debut

### Light Novel

Volume 4

### Manga

Chapter 50

Yuudai Saejima (冴島（さえじま）ユウダイ, Saejima Yūdai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was Minoru and Akane's former high school classmate at Sakurazaka High School. Following the fall of Japan to Magical Beasts, he became the Vice-Commander of the Knights in the human settlement of [Messiah](Messiah.md "Messiah") and mole for The Alliance.[CITATION NEEDED]

## Appearance

Yuudai was a young adult with short black hair and facial hair whilst wearing a black shirt with a necklace under a Sakurazaka Senior High uniform as his Messiah uniform. It should be noted that he was often referred to as a gorilla due his bulky physique and expertise on Judo. He was also considered handsome by many students at his high school.[[1]](#cite_note-V4C5-1)

## Personality

As a Vice Commander for the Messiah, he was a blunt man who abused his position to force Akane into a relationship, even going so far as to blackmail her to get what he wanted.[[1]](#cite_note-V4C5-1)

## Skills and Abilities

### Martial Arts

Yuudai was highly skilled at judo and even went to the nationals.[[1]](#cite_note-V4C5-1)

## Trivia

## References

1. Volume 4 Chapter 5: Sneaking Around in Japan, Just like the Old Days!!
