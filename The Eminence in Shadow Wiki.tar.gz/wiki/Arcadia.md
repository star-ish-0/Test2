# Arcadia

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Arcadia](https://the-eminence-in-shadow.fandom.com/wiki/Arcadia)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Arcadia?action=edit).

## Arcadia

### Japanese

アルカディア

### Romaji

Arukadia

## Location Information

### Leader

Unknown

### Status

Destroyed

### Affiliates

Unknown

### Type

Settlement

### Government

Unknown

### Location

[Earth](Earth.md "Earth")

### Inhabitants

Humans

## Debut

### Light Novel

Volume 4

### Manga

Chapter 50

Arcadia (アルカディア, Arukadia[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a major human settlement following the Magical Beasts invasion of Japan. It was regarded by many as Japan's last safe haven before its destruction at the hands of the First Knight.

## History

Arcadia was just a normal settlement like any other that tried to survive following Japan's fall. One day, rumors spread around that other countries had created warriors called Knights that used magic to combat the magical beasts. Whether or not they believed it, the people of Japan was desperate for a solution.

Arcadia's top scientists, amongst them being Akira Nishino and Yuuka's husband studied magic and succeeded when Akane Nishino became a Knight. Akane cut down the beasts that roamed Arcadia's territory. Ever since then, Arcadia was lauded for their breakthrough and it became a symbol for the surviving Japanese. Soon, more humans joined Arcadia to become Knights and refugees found a safe haven from the monsters.

Ironically, Arcadia's fall was not at the hands of the magical beasts but the First Knight that defended them. While Akane was powerful, she had trouble controlling her abilities. This dissatisfied Akira who decided to harvest the blood of magical beasts and injected it into his sister out of complete arrogance that he had control over this forbidden power. This backfired horribly as the new power within Akane caused her to go on a rampage and destroyed Arcadia, killing many people, including Yuuka's husband.

With Arcadia gone, all hope was destroyed and the unity the people of Japan had was shattered. The aftermath of Arcadia's fall will still be felt years later as the Japanese were now driven to fight against each other for resources and manpower and [Yuuka](Yuuka.md "Yuuka") would later seek vengeance against the Nishino family for their role in her husband's death.

## Personnel

- Akane Nishino
- Akira Nishino
- [Yuuka](Yuuka.md "Yuuka")

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • **Arcadia** • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
