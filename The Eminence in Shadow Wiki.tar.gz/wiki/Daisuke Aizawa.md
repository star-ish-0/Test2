# Daisuke Aizawa

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Daisuke%20Aizawa](https://the-eminence-in-shadow.fandom.com/wiki/Daisuke%20Aizawa)

## Daisuke Aizawa

### Japanese

逢沢大介

### Romaji

Aizawa Daisuke

## Characteristics

### Race

Unknown

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Professional Information

### Occupation

Novelist

Daisuke Aizawa (逢沢大介, Aizawa Daisuke[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the author of the The Eminence in Shadow franchise. Daisuke Aizawa originally started writing The Eminence in Shadow Web Novel because he wanted to do something to relax during his free time.[[1]](#cite_note-:0-1) Daisuke Aizawa's Web Novel quickly gained traction after it began on the popular Japanese web novel publishing site [Syosetu](https://en.wikipedia.org/wiki/Sh%C5%8Dsetsuka_ni_Nar%C5%8D) in 2018, and was soon after taken under the wing of Kadokawa and published as a Light Novel the same year; His Light Novel then received a [Manga](Manga.md "Manga") adaptation, and the first volume was released in 2019. The franchise has since been adapted into an Anime (2022) as well as a Mobile and PC game (2022).

## Career

## Works

- The Eminence in Shadow Web Novel (2018JP) — Original Author & Writer
- The Eminence in Shadow Light Novel (2018JP) (2020EN) — Original Author & Writer
- The Eminence in Shadow [Manga](Manga.md "Manga") (2019JP) (2021EN): Manga adaptation the The Eminence in Shadow Light Novel by Anri Sakano — Original Author
- The Eminence in Shadow [Anime](Anime.md "Anime") Season 1 (2022-2023) — The first season of the Anime adaptation of the The Eminence in Shadow Light Novel by studio Nexus — Original Author
- The Eminence in Shadow: Master of Garden Game (2022) — Daisuke Aizawa oversaw certain parts of the game. Particularly the canonical parts like Seven Shadows Chronicles and the Auxiliary Chapters[[1]](#cite_note-:0-1) — Original Author
- The Eminence in Shadow [Anime](Anime.md "Anime") Season 2 (2023) — The second season of the Anime adaptation of the The Eminence in Shadow Light Novel by studio Nexus — Original Author
- The Eminence in Shadow ~Seven Shadows Chronicles~ (2024JP) — Manga adaptation of the The Eminence in Shadow: Master of Garden's Seven Shadows Chronicles by Kanco — Original Author

## External Link

<https://mypage.syosetu.com/298373/>

1. [Dengeki Online Interview](https://dengekionline.com/articles/202078/)
