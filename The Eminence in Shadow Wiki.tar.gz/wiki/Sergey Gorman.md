# Sergey Gorman

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sergey%20Gorman](https://the-eminence-in-shadow.fandom.com/wiki/Sergey%20Gorman)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

|  |  |  |
| --- | --- | --- |
| “ | My sword...is my means...to obtaining everything! Everything! The mere "10th rank" I was handed...will never satisfy me! Those old fools! I will use [this power](Malak.md "Malak"), this sword...to take EVERYTHING FROM THIS WORLD...!!! | ” |
| — Sergey, Seven Shadows Chronicles, Chapter 27 | | |

## Sergey Gorman

### Japanese

セルゲイ・ゴーマン

### Romaji

Serugei Gōman

### Aliases

Storm Sword

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- 10th seat of the Knights of Rounds
- First Children (Named Child)
- Member of the Seven Blades

### Affiliation

Velgalta Empire
Cult of Diablos

## Debut

### Light Novel

Volume 5 (Mentioned)

### Manga

Chapter 62 (Mentioned)

### Game

Seven Shadows Chronicles: Chapter 19

## Portrayal

### Japanese

[Akio Otsuka](https://en.wikipedia.org/wiki/Akio_Otsuka "wp:Akio Otsuka")

Sergey Gorman (セルゲイ・ゴーマン, Serugei Gōman[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the 10th Seat of the Knights of Rounds belonging to the Cult of Diablos, titled Storm Sword (闘剣（とうけん）嵐武（らんぶ）, Tōken Ranbu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) and one of the Velgalta's Seven Blades.[[1]](#cite_note-1)[[2]](#cite_note-2) He was a man with no allegiance to the Cult and eventually planned to betray them with his [army of artificial Dragons](Malak.md "Malak"). His ambitions lead to encounters with Shadow Garden[[3]](#cite_note-3), leading him to his demise at the hands of Shadow.[[4]](#cite_note-4)

## Appearance

Sergey is a tall, muscular man with red eyes who wears a mask that covers his nose and mouth, as well as thick green armor with a distinctive gauntlet wrapped around his left arm.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | You must never point your blade at the wrong opponent without knowing yourself. I'll teach you this golden rule of battle at the cost of your life! | ” |
| — Sergey, Seven Shadows Chronicles, Chapter 19 | | |

Sergey is an apathetic, cold and cruel person intent on world domination, convinced that his immense strength could surpass the Knights of Rounds.

Unlike many members of the Cult, Sergey is very vigilant and never underestimated any opponent he fought. Despite his ruthless and calculating nature Sergey has a calm and condescending demeanor and will bide his time to get whatever he needs in order to become stronger.

## Background

### Early life

When he was still an ordinary knight, Sergey traveled to Madlid to fight [Malak](Malak.md "Malak") but ended up being defeated. But while on his way back to the imperial capital, Sergey happened to stumble upon an abandoned hideout that appeared to be an ancient facility where Malak was being incubated using some form of technology.

Sergey was shocked at the time about Malak when he learned that the dragon, which was rarely seen in the eastern end of Velgalta, was actually an artificial lifeform. Furthermore, there was an artifact that could control Malak with rational actions, meaning that the artifact was the key to breaking the seal on this facility that was already equipped with a role suitable for a specific purpose.

Not yet satisfied with studying the facility, Sergey found records of experiments using Malak's flesh to enhance the human body. The results of the experiments written in the research records indicated that if the meat was consumed in small amounts continuously, it could have a constant effect. Although he was disgusted by the idea of ​​eating Malak's flesh which gave off a foul odor, Sergey felt that for now he should at least see if there was any truth to what was claimed in the records.

In his initial attempt to prove the veracity of the records, Sergey took a large amount of Malak's flesh to feed to a captured bandit as a guinea pig. The bandit initially refused to eat it, but eventually succumbed to the hunger caused by his captivity and devoured Malak's flesh with horrific results.

It was at this point that the bandit began to undergo a terrifying transformation after consuming Malak's flesh, as his body twisted into a rigid physique, horns grew from his forehead, and his skin hardened and dried like dragon scales. Looking closely at the bandit's initial appearance with his current transformed form that could barely be called human, Sergey considered that the bandit had now become a terrifying living weapon.

When the bandit attacked Sergey, he was almost overwhelmed to the point of not wanting to fight back because the creature's strength and speed were so astonishing. Although slightly surprised, he observed the transformed bandit closely and by the time Sergey regained his composure, he cleaved the creature in two with his blade.

The success of the experiment had made Sergey very confident after witnessing the greatness of the transformation in eating Malak's flesh, which gained strength and speed that exceeded human limits as written in the experiment's records. At that moment, Sergey thought that if he could make his body accustomed to this hidden power and combine it with the artifact's control over Malak, he might be able to rule the world.

Since then, Sergey tried to eat Malak's flesh in small amounts to feel the changes in his body's transformation, which the dose of meat he ate had made his insides feel like they were burning and then caused his bones and jaws to start cracking. Sergey felt that something terrible was happening to his body, assuming that there was very likely no way back from this change.

But the fact remains that the transformation in eating Malak's flesh, has made Sergey's magic level soar rapidly, his bones and skin harden, and even his senses are now sharper than before. If Sergey continues to train in his transformed state against a Malak who is forced to fight perfectly by the artifact, then his sword skills will soar to a new level.[[5]](#cite_note-5)

### Introduction to the Cult of Diablos

Wanting to test the power he had gained, Sergey took part in the annual imperial tournament and faced off against a senior knight named Stan Bach who was a member of the Velgalta's Seven Blades. Sergey emerged victorious by killing Stan. Sergey won the Seven Blades' position by claiming it from his defeated opponent. Stan's death was classified as an accident within the duel according to the tournament regulations.

Sergey is then recruited by the Cult of Diablos, the Cult was very surprised at a member of their organization being defeated by an outsider knight like Sergey who had no affiliation with them. The cult deemed Sergey worthy to be given the title of First Child, due to his willingness to align with the Cult's causes and his strength.

Feeling that this was his chance to improve his path in life, Sergey agreed to the Cult's invitation, and he became a formidable warrior for them. Earning himself the name, the Storm Sword. Following the tournament, there were rumors floating around saying that Sergey's skill with his great sword may even surpass the Seven Blades' leader.

## Chronology

### Herzog Family Purge

Due to the fact that Karen von Herzog, the only daughter of the Herzog family and one of the Seven Blades, was [possessed](Possession.md "Possession") which made Sergey has to committed a "treacherous act" that he acted solely on his own without even reporting Karen's condition to Knights of Rounds on the "Round Table". In an attempt to gather support from the people for his ambition, Sergey carried out an action that could be called a betrayal of the Cult by slaughtering the entire Herzog Family and intent to purging Karen. However, Karen was rescued by [Gamma](Gamma.md "Gamma") and [Eta](Eta.md "Eta"), who were present on the spot, and it ended in failure.

## Powers & Abilities

Sergey is the most powerful warriors as a Named Child, considering "First Children" who have provided remarkable contributions to the Cult. Sergey possessed stronger physical strength and magical powers compared to the average knight, from which the Cult granted him a name, also mentally stable.

## Trivia

## References

1. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 2: Sturm of Velgalta, Chapter 2-13: Hero...... Lured by Illusions, Episode 4: Ambition's End
2. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 2: Sturm of Velgalta, Chapter 2-12: Evil Ambition's End, Episode 1: The First Child
3. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 2: Sturm of Velgalta, Chapter 2-4: Possessed Cult Leader, Episode 2: Two "Seven Blades"
4. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 2: Sturm of Velgalta, Chapter 2-12: Evil Ambition's End, Episode 5: Summit of Strength
5. Master of Garden Seven Shadows Chronicles, Chapter 28: Hero....Lured by Illusions

## Site Navigation
