# Alpha

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Alpha](https://the-eminence-in-shadow.fandom.com/wiki/Alpha)

[Chronology](Alpha-Chronology.md "Alpha/Chronology")

[Relationships](Alpha-Relationships.md "Alpha/Relationships")

Image Gallery

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

|  |  |  |
| --- | --- | --- |
| “ | If that’s what you want, then I’ll devote my life to it. We’ll punish these sinners with death… | ” |
| — Alpha, Light Novel Volume 01 | | |

## Alpha

- Light Novel
- Manga
- Anime
- Game

### Japanese

アルファ

### Romaji

Arufa

### Aliases

Tokiseiryu no Kikyo (given/birth name)
Kikyo of Farstream(given/birth name)
Alfred

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

10-13 [[1]](#cite_note-V1CP-1)
15 [[2]](#cite_note-V1C1-2) (Currently)

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Blue

### Birthday

July 23

## Personal Information

### Status

Alive

### Relatives

- [Olivier](Olivier.md "Olivier") (Ancestor)
- Unnamed Mother †
- King Anorion (Uncle)
- [Beatrix](Beatrix.md "Beatrix") (Aunt)
- Tokiseiryuno Sakura (Clan)
- Lalanoa Hinoizumino (Cousin)

## Professional Information

### Occupation

- Second-in-Command of Shadow Garden
- 1st Seat and Leader of the Seven Shadows

### Affiliation

Shadow Garden

## Debut

### Web Novel

Chapter 3

### Light Novel

Volume 1

### Manga

Chapter 1

### Anime

Episode 1

### Game

Episode 1

## Portrayal

### Japanese

[Asami Seto](https://en.wikipedia.org/wiki/Asami_Seto "wp:Asami Seto")

### English

[Christina Kelly](https://en.wikipedia.org/wiki/Christina_Kelly "wp:Christina Kelly")

### French

Laura Blanc

### Italian

Federica Simonelli

### German

Angelina Markiefka

Alpha (アルファ, Arufa[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Aλφα) is the commander in chief of Shadow Garden and the first seat of the Seven Shadows, as well as a descendant of the "Elf Hero" [Olivier](Olivier.md "Olivier"). After Shadow cured her of [Possession](Possession.md "Possession"), she dedicated her life to him and destroying the Cult of Diablos.[[1]](#cite_note-V1CP-1) Second-in-command only in name, Alpha acts as the true leader of Shadow Garden, growing it from a grassroots organization into an economic and military superpower.[[2]](#cite_note-V1C1-2)[[3]](#cite_note-MoG-3)[[4]](#cite_note-V1C3-4)

## Appearance

Alpha is a young elf with long golden-blonde hair and blue eyes. Her general appearance is described as breathtakingly beautiful, garnering ample attention and praise.[[1]](#cite_note-V1CP-1)[[5]](#cite_note-V2C2-5) Unblemished skin adds to her striking characteristics.[[1]](#cite_note-V1CP-1) She bears a strong resemblance to her ancestor, [Olivier](Olivier.md "Olivier") the Elf Hero, and her aunt, [Beatrix](Beatrix.md "Beatrix"), the Goddess of War.[[5]](#cite_note-V2C2-5)

Dark dresses are Alpha's typical attire and several have been featured. One such dress is a side-slit evening gown with matching gloves, high heels, and a choker. The décolletage accentuates her curvaceous body and reveals a matinee pendant necklace.[[6]](#cite_note-6) Alpha's less ostentatious choice is a simple black dress without a conspicuous neckline. It offers refinement through simplicity.[[7]](#cite_note-V6P-7) Similarly, she sometimes chooses not to wear evening gloves and opts for bare hands with only blue nail polish.[[8]](#cite_note-8)

During her Shadow Garden activities, Alpha wears the customary ebony slime bodysuit ornamented with gold accents and a cutout-style chest design. A gold diamond is centered on the lower sternum, with two gold stripes descending below the chest cutout. The stripes continue down until they conjoin the hip decorations. Along Alpha's hips are ornate golden streaks adorned with three belts that wrap around her hamstrings. On her feet, she wears block high heels with gold-edged collars. Dark bracers covered in golden ornamentation protect her hands.[[9]](#cite_note-9) For anonymity, she dons a pitch-black mask.[[4]](#cite_note-V1C3-4) It is in the style of a domino mask, having ornamental frills and flowers.[MANGA ONLY]

### Other Personas

- Alfred ([?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")):

## Personality

|  |  |  |
| --- | --- | --- |
| “ | I’m dumb, so I don’t understand all the things you do. I’m weak, so I can’t do all the things you can. But still, even so… I want to understand, so I can support you. You saved me, saved all of us, so I want to do whatever it is I can to help. | ” |
| — Alpha, Light Novel Volume 03 | | |

Born from a devotion to her savior and malignity toward those who deprive many, herself included, of happiness, Alpha's sole purpose in life is to eliminate the Cult of Diablos. She jeeringly conveys contempt for the weak and the "ignoramuses" who are oblivious to the real world.[[4]](#cite_note-V1C3-4) Even for the shadow-enlightened, she can be cold if they lack ideals or ambition.[[2]](#cite_note-V1C1-2)Alpha's callous indifference regarding outsiders does not reflect her temperament in all circumstances. Acting as a Shadow Garden administrator, she presents as imperturbable, offering compendious replies and orders.[[10]](#cite_note-10)[[11]](#cite_note-V5C3-11) This composed demeanor has crumbled in the face of suspected harm or betrayal from those she cherishes.[[12]](#cite_note-V3C6-12)[[13]](#cite_note-V3E-13) Alpha conveys a larger emotional spectrum around the Seven Shadows and Cid. Ridiculing laughter is replaced with genuine giggling and sororal compassion supersedes impassivity.[[2]](#cite_note-V1C1-2)[[4]](#cite_note-V1C3-4)[[13]](#cite_note-V3E-13) She has called the Seven Shadows her family, periodically looking past faults and embracing them as her kin.[[14]](#cite_note-14) [The Possessed](Possession.md "Possession"), likewise, arouses profound empathy from Alpha and she endeavors to rescue as many as possible.[[2]](#cite_note-V1C1-2)[[4]](#cite_note-V1C3-4)

The blonde elf's achievements have not tempered a deep sense of inferiority and inadequacy. Like many of the Seven Shadows, Alpha feels like Shadow is in a realm beyond understanding, regarding her presence as a burden.[[12]](#cite_note-V3C6-12)[[13]](#cite_note-V3E-13) Unsatisfied with personal deficiencies, she strives to shoulder Shadow's responsibilities and earn even a little more of his trust.[[4]](#cite_note-V1C3-4)[[7]](#cite_note-V6P-7)

## Powers & Abilities

Since its inception, Alpha's abilities both on and off the battlefield have allowed her to remain unchallenged as Shadow Garden's second-in-command.[[15]](#cite_note-V2C3-15)[[16]](#cite_note-SSCC6-16)[[12]](#cite_note-V3C6-12) She is a versatile combatant, exhibiting proficiency in many areas, but is surpassed by her fellow Seven Shadows in their specializations.[[17]](#cite_note-17) So far, her only defeat has been to Shadow. As a testament to her strength, Cid has used her as a benchmark to determine the capability of an opponent and she remains one of the few combatants who has drawn blood from him in a genuine skirmish.[[2]](#cite_note-V1C1-2)[[12]](#cite_note-V3C6-12)

Rose Oriana believes that it would take the entire military force of an entire nation to have at least a real chance of subduing her and still believes that it would still result in massive casualties and loss of resources.

### Swordsmanship

Under the early guidance of Cid, Alpha learned various sword techniques and practices. Expanding upon the foundation laid for her, Alpha adopted a personal style, as did the other members of the Seven Shadows.[GAME ONLY][[18]](#cite_note-18) Alpha has displayed two-sword styles. One is similar to Shadow's methodical approach: observe the opponent and slowly create an advantage by refining movements amidst active combat. By calculating the trajectory of attacks, Alpha can evade with exactitude.[[2]](#cite_note-V1C1-2) The second style is about killing the enemy in a single strike—a preferred method of assassination or elimination of regenerative targets. Slime viscosity and fluidity can facilitate sword elongation for larger adversaries.[[4]](#cite_note-V1C3-4)[[12]](#cite_note-V3C6-12)

### Martial Arts

Alpha has shown that she can resort to brute force and fight with her bare hands if the situation requires it. These bruiser tactics take combatants by surprise and deliver an advantage during battles or fencing matches.[GAME ONLY][[19]](#cite_note-19)

### Magic

Alpha possesses an immense magical reserve, surpassing even Shadow when they were children.[[1]](#cite_note-V1CP-1) Rose Oriana later noted that Alpha's magical power is so exceptional that, if turned against the nation, it would be a Pyrrhic victory at best. Given Alpha's large mana pool, her level has been employed as a metric to determine large magical capacity.[ANIME ONLY][[20]](#cite_note-20) At a young age, she learned to heal the possessed—a rare feat even among the upper echelons of Shadow Garden. Other than the originator, Alpha and [Epsilon](Epsilon.md "Epsilon") are the only practitioners of purification.[[2]](#cite_note-V1C1-2)[EPSILON GAME ONLY][[21]](#cite_note-21) The control extends into combat, aiding quick and powerful engagements against enemies. She demonstrates the ability to compress magic, but unlike an atomic attack, Alpha focuses magic into a single point on a sword to make a piercing blow.[GAME ONLY][[16]](#cite_note-SSCC6-16) For magically enhanced stealth, Alpha's capabilities have caught some strong combatants unawares, but covert operations are not her defining characteristic.[[4]](#cite_note-V1C3-4)[[5]](#cite_note-V2C2-5)

#### Nuclear Magic

Alpha was able to replicate her master's atomic technique. While she about to execute the technique. However she is unable to handle the strain of exerted by the technique of the backlash of releasing compressed magic.[GAME ONLY][[22]](#cite_note-22)

> ##### Vampire Techniques
>
> A few months after confirming the consanguineous connection between Vampires and The Possessed, Alpha was the first Seven Shadow member to exhibit proficiency in vampire techniques. Those who have shown vampiric powers have slight variations in their utilization.[[12]](#cite_note-V3C6-12)[[23]](#cite_note-23)
>
> - Mistform: An ability that disperses the user into a fog-like state, rendering them immune from most attacks. The mist acts as an auxiliary sensory organ, detecting minute movements of those within the cloud. By utilizing pseudo-intangibility, Alpha's variation bombards combatants with crimson-colored blades. The power comes with two significant weaknesses. While in mistform, direct attacks can only be initiated after rematerializing. Fast transformation makes capitalizing on this difficult, but it is not impossible.[ANIME ONLY][[24]](#cite_note-24) The second weakness is that the ability is not incorporeal, but rather a gaseous state. A lack of mass and weak intermolecular bonds makes it susceptible to dispersion by an opponent.[[12]](#cite_note-V3C6-12)

### Intelligence

As second-in-command and one of the responsible members for transforming Shadow Garden into a powerful organization, Alpha presents herself as a charismatic leader and proficient in corporate compartmentalization.[[25]](#cite_note-25) As Shadow Garden's chief operating officer, she has been noted to have spearheaded many successful operations.[[3]](#cite_note-MoG-3)[[4]](#cite_note-V1C3-4)[[5]](#cite_note-V2C2-5)

Alpha similarly possesses an analytical intellect for rational problem-solving and deductive reasoning, both in and out of combat. Her discerning mind has unraveled many details regarding the Cult of Diablos and the Possessed before formal confirmation.[[5]](#cite_note-V2C2-5) Perceiving multiple variables and her master's supposed intentions, Alpha has made decisive actions to protect or cement Shadow Garden's position alongside their public front within the Mitsugoshi Company.[[26]](#cite_note-26) Alpha's strong personal bias has misinterpreted or neglected some pertinent verities, but it has not impeded success.[[13]](#cite_note-V3E-13)[[11]](#cite_note-V5C3-11) Her intelligence is expressed in battle by keen combat analysis, assisting in stratagems and opponent identification-- such as identifying an advisory by observing dodging techniques.[[12]](#cite_note-V3C6-12)

### Miscellaneous Talents

- Survival Skills: During Shadow Garden's infancy, when it consisted of just her and Cid, she was forced to take care of her own food. She regularly placed traps around the village for small game and foraged various fruits or vegetables to keep herself self-sufficient.[[27]](#cite_note-27)

### Weapons and Equipment

Alpha's gear is primarily slime-based equipment given the slime's ninety-nine percent magical energy conductivity and the form altering adaptability, makiing the slime flexible in combat.[[1]](#cite_note-V1CP-1) Her primary weapon, like the other Seven Shadows, is a katana based on teaching by Shadow. Other medians depict two horizontal quillons on the sword hilt, suggesting a longsword variant of slime sword, which is common among knights in the Midgar Kingdom.

## Trivia

- Despite being the strongest of the Seven Shadows, Alpha is always training and developing new combat techniques with the sole objective of always keeping up with Cid.[CITATION NEEDED]
- Alpha always assumes a role when interacting with the other members of the Shadow Garden, similar to how Cid takes on the role of Shadow. Among the Seven Shadows, she presents as a stoic leader, but she can be her true self with Cid and forego any need for pretense.[[4]](#cite_note-V1C3-4)[[7]](#cite_note-V6P-7)
- In the manga, Alpha is seen participating in the assault on Midgar Academy. In the other adaptations, [Gamma](Gamma.md "Gamma") is the leader as the blonde elf is unavailable.[[28]](#cite_note-28)
- Cid currently owes her a meal after eating both their shares during the abduction incident involving Princess Alexia. He has forgotten about the debt.[[4]](#cite_note-V1C3-4)[[7]](#cite_note-V6P-7)
  - Alpha subsequently annulled the obligation after Cid wore a suit that she gave him.[[7]](#cite_note-V6P-7)
- Six of the Seven Shadows acknowledge her as having the second highest authority in the organization after Shadow and loyally follow her orders.
  - [Zeta](Zeta.md "Zeta") and [Delta](Delta.md "Delta") have contested Alpha's leadership on different occasions.
    - Delta challenged the blonde elf for the second-in-command position shortly after joining Shadow Garden, but Alpha retained her title.[[15]](#cite_note-V2C3-15) The experience has led Delta to obey her orders without question.
    - Zeta has created a secret faction within Shadow Garden to undermine Alpha's authority. Believing their leader is not preparing for the future, she seeks to revive the demon Diablos to make Cid immortal.[[11]](#cite_note-V5C3-11) She routinely fails to report in and continues her clandestine behavior.
- It is revealed in spin-off series [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu") that Alpha lacks a sense and taste for female fashion. She tries to learn and take advice from her companions, such as Gamma's recommendation of wearing "cute" underwear.[[29]](#cite_note-29)
- Alpha is a skilled knitter, as shown in [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu"), and successfully made prototype animal shirts for the Mitsugoshi Company, which didn't work for adults, but was successfully marketed as a children's clothing line.[[30]](#cite_note-30)
- Although not confirmed by Daisuke Aizawa, Asami Seto, Alpha's Japanese voice actress, claimed in an interview that Alpha is in love with Shadow.

## References

1. Volume 1 Prologue: Preparing the Perfect Stage!
2. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
3. The Eminence in Shadow: Master of Garden
4. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
5. Volume 2 Chapter 2: Investigating the Sanctuary!
6. Volume 1 Appendix Illustrations
7. Volume 6 Prologue: There Are People Ruling the Midgar Kingdom from the Shadows? I'm So Jealous!
8. Volume 3 Appendix Illustrations
9. Volume 1 Color Inserts
10. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
11. Volume 5 Chapter 3: The Case Is Closed, So, It’s Time for a Flashback!
12. Volume 3 Chapter 6: Circulating Counterfeit Cash!
13. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
14. Volume 5 Chapter 4: Peace in Our Time!
15. Volume 2 Chapter 3: When Things Get Boring, It’s Time for Explosives!
16. Seven Shadows Chronicles Chapter 6: Intense! Unstoppable Alpha
17. Volume 2 Chapter 1: Fun Times at the Goddess’s Trial!
18. Seven Shadows Chronicles Chapter 1: Shadow Garden, Mobilize! Episode 2
19. Seven Shadows Chronicles Chapter 21: The Garden Heads North
20. Episode 23
21. Seven Shadows Chronicles Chapter 1: Shadow Garden, Mobilize! Episode 5
22. Seven Shadows Chronicles - Chapter 54, Episode 5
23. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
24. Episode 26
25. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
26. Volume 3 Chapter 4: I’ll Destroy It All and Start from Scratch!
27. Volume 6 SS
28. Manga Chapter 12
29. KAGE-JITSU! Operation 6: The Seven Shades Want to Recommend Cute Underwear!
30. KAGE-JITSU! Season 2 Operation 2: Seven Shadows Wants to Develop Cute Clothes!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | **Alpha** • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
