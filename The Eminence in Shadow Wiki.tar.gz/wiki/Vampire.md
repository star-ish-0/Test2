# Vampire

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Vampire](https://the-eminence-in-shadow.fandom.com/wiki/Vampire)

Vampires (吸血鬼, Kyūketsuki[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are one of the races in the world of The Eminence in Shadow with nearly eternal life. Although they can reproduce, they normally abstain. Hosting overwhelming magical energy and vitality, their flesh never decays.

The majority of vampires have become extinct, leaving only [Elisabeth](Elisabeth.md "Elisabeth") and her clan as the sole survivors residing in the Lawless City. Following the Red Moon Incident, Elisabeth and Mary are the last two remaining vampires.

## Appearance

Vampires closely resemble [humans](Human.md "Human"), with distinctive features including red hair, red eyes, sharp teeth with pointed fangs, claw-like nails, and occasionally, a tendency towards pale skin.

In general, they usually wear a tunic or cloak, black with red backgrounds and details, said coats, they have very open shirt lapels, long over the head and semi-pointed. Inside their tunics, they usually wear average normal clothes, sometimes white, but vampires have shown that if they want, they can wear elegant and beautiful clothes, among other types of clothes, like [humans](Human.md "Human").

## Chronology

### Background

According to [Mary](Mary.md "Mary"), vampires once reigned as the dominant species, feeding on [humans](Human.md "Human") as livestock. However, a significant shift occurred when humans unearthed their vulnerabilities: sunlight, heart-piercing, and their dependence on human blood.

It was then the vampires entered the dark ages as humans began hunting the vampires back, turning their era into a nightmare with the destruction of the vampires’ capital sparked the fire of rebellion and the number of their race dwindled in the blink of an eye. Consequently, humanity launched a relentless pursuit of vampires, nearly driving them to extinction, with just a small cadre of formidable individuals remaining.

### Red Moon Incident

During the fateful night of the Red Moon ascent, cornered vampires staged a formidable rebellion. The Red Moon persisted for three harrowing days, leaving a trail of destruction in its wake. On the initial night, an entire country lay in ruins. Over the following two nights, three more nations suffered damage so severe that recovery seemed impossible. As the Red Moon eventually descended, the [Blood Queen](Elisabeth.md "Elisabeth") and her kin abruptly vanished, retreating into hiding, patiently awaiting the next lunar cycle, effectively causing humanity to forget their existence entirely.

A millennium later, a second Red Moon emerged, ushering in the revival of [Elisabeth](Elisabeth.md "Elisabeth") by [Crimson](Crimson.md "Crimson"), who sought to harness her power in order to reassert dominance over humanity. However, before tragedy could unfold, Shadow intervened, thwarting Crimson’s nefarious plans.

## Category and Classification

Despite their near-eradication, vampires remain a potent and lurking menace to the public. Their terror and formidable power can resurface when they are subjected to the heightened influence of the Red Moon, transforming them into nearly indestructible beings capable of posing a threat, perhaps even to a Dragon, and especially to an entire nation.

## Powers & Abilities

### Vampiric Dexterity and Ability

Vampires' primary prowess lies in their superhuman strength, which amplifies further with age and the consumption of copious amounts of blood, rendering elder vampires even mightier. Additionally, they experience heightened enhancement in their five natural senses, with a notable emphasis on vision, hearing, and smell.

Certain vampires can outpace humans and even their fellow vampires in terms of speed, and this aptitude is intricately tied to the vampire's age and the volume of blood they've consumed.

### Night Vision

As vampires, they inherit the bat's remarkable night vision, granting them the capability to discern their prey both nearby and in the distance during the darkest of nights.

### Vampiric Regeneration

Vampires possess a natural regenerative capacity, allowing them to heal common wounds, ranging from minor cuts to deep lacerations, rendering them impervious to typical natural illnesses. The most powerful among them, the highest-ranking vampires, exhibit an even more profound regenerative ability, capable of mending grievous wounds like limb amputations or even decapitation, provided their heart remains intact and there's sufficient time for their body to mend the injuries.

### Vampire Curse

They have the ability to transform humans into [Ghouls](Ghouls.md "Ghouls"), or alternatively, into fellow vampires.

### Vampiric Immortality

As vampires, they are virtually immortal, sustaining eternal youth and physical vitality as long as they are adequately nourished.

### Red Mistform

Mystify is the extraordinary capability exclusive to high-class vampires, enabling them to transmute their corporeal form into mist.

### Red Moon Power

## Adaptability Biology

## Weakness

1. Their ultimate vulnerability lies in the piercing of their heart. Despite their formidable regenerative powers, vampires lose their ability to heal when their heart is destroyed. This crucial weakness became a formidable advantage for humanity, once fearful of these seemingly immortal beings.
2. The sustenance of their powers hinges on the regular consumption of blood. Vampires who abstain from blood for extended periods eventually find themselves with strength hardly distinguishable from that of ordinary humans. It's an intrinsic aspect of their existence, compelling them to coexist with, rather than annihilate, humans to survive as a species.
3. Sunlight proves fatal to vampires, reducing them to ash upon exposure. Regardless of the vampire's strength and the human's vulnerability, anyone can eliminate a vampire by harnessing sunlight. Numerous methods, including traps and the destruction of their sanctuaries, turned daytime into the execution ground for countless vampires.
4. Another weakness of vampires is that they are vulnerable to fire as such, since when exposed to strong temperatures close to the brightness of the sun, it hurts them even if it does not burn as badly, so it is a weakness of little concern for them as long as it doesn't damage them at a cellular level or that their heart continues to do so.

## Known Individuals

- [Elisabeth](Elisabeth.md "Elisabeth") (Revived)
- [Crimson](Crimson.md "Crimson") (Deceased)
- [Mary](Mary.md "Mary")

## Trivia

- The design and bat-like appearance of the vampires are inspired by the classic character of [Dracula](https://en.wikipedia.org/wiki/Dracula "wp:Dracula"), and some of its variants.
- Based on [Beta](Beta.md "Beta")'s insight from [Eta](Eta.md "Eta")'s hypothetical theory, there's a suspicion that the vampire curse on their race's blood shares some resemblance to the [Possession](Possession.md "Possession") curse. However, the exact nature of this relationship and the precise nature of this connection remains unknown.
  - [Mary](Mary.md "Mary") firmly opposes this notion, considering it blasphemy against the Vampire Progenitors, as both she and her associates are convinced of their disconnection.
  - [Aurora](Aurora.md "Aurora") herself later affirms that vampire blood and demon blood are distinct entities, but as a result of divergent adaptation due to different factors and environment. Both originate from the same source; Aurora's own blood as Diabolos, which is why the mixture of both blood types in Claire allowed Aurora to possess her.
- Even to this day, the question of whether [Elisabeth](Elisabeth.md "Elisabeth") was the original vampire remains shrouded in mystery. Although [Mary](Mary.md "Mary") and her clan have asserted that Elisabeth is the most formidable progenitor of their kind, they've never definitively stated that she was the very first vampire.
- To this day, the name and powers of the other vampire progenitors, who existed before Elizabeth became the only one of her kind alive, are unknown.
  - To this day, it is unknown if there were any heroes from the past who managed to kill the Vampire Progenitors that existed upon learning of their weaknesses. It is only intuited that there was one, who possibly fought against one, and this was a King of a small country whose said kingdom was destroyed in one night when Elizabeth's rampage began by the Red moon.[[1]](#cite_note-1)
- Like the [Dragons](Dragon.md "Dragon"), it is unknown what role the vampires played during the chaos and terror that the [Demon king Diabolos](Aurora.md "Aurora") exercised over the entire world, but according to Mary's intuition, they were aware of the existence of this Demon king, and the legacy he left.
- To date, vampires are the only race level that are not affiliated (apparently), with the Cult of Diablos.
- The design of the Crimson Tower, of the Lawless City that the vampires built, is inspired by the biblical story of the [Tower of Babel](https://en.wikipedia.org/wiki/Tower_of_Babel "wp:Tower of Babel").
  - The Crimson Tower was not the only design that the vampires built, they had their previous variants, in a better maintained, more dazzling and beautiful state, but each and every one of them, were destroyed by humans from the nations, who discovered, the weaknesses of vampires.

## References

1. Volume 3 Chapter 3

## Site Navigation
