# Juggernaut

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Juggernaut](https://the-eminence-in-shadow.fandom.com/wiki/Juggernaut)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Chronology](Juggernaut-Chronology.md "Juggernaut/Chronology")

[Relationships](Juggernaut-Relationships.md "Juggernaut/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | My instinct's always right. | ” |
| — Juggernaut, Light Novel Volume 03 | | |

## Juggernaut

### Japanese

ジャガノート

### Romaji

Jaganōto

### Aliases

Tyrant

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Brown

### Eye Color

Black

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Ruler of the Black Tower

### Affiliation

Black Tower

## Debut

### Web Novel

Chapter 99

### Light Novel

Volume 3

### Manga

Chapter 29

### Anime

Episode 21

### Game

Episode 20

## Portrayal

### Japanese

[Tsuyoshi Koyama](https://en.wikipedia.org/wiki/Tsuyoshi_Koyama "wp:Tsuyoshi Koyama")

### English

Luis Galindo

### French

Olivier Cordina

Juggernaut (ジャガノート, Jaganōto[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), also known as the Tyrant (暴君（ぼうくん）, Bōkun[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), was a part of the Lawless City's triumvirate, having been the ruler of the Black Tower until his death at the hands of [Delta](Delta.md "Delta").[[1]](#cite_note-V3C1-1)

## Appearance

Juggernaut is a man with tanned skin, brown hair, black eyes that have a falcon's glint in them, and black dreadlocks. He was as tall as a giant like a goliath and had a strong, muscular build.[[2]](#cite_note-V3C2-2)

He wears an outfit consisting of a black shirt that only covers the back, a black fluffy scarf, black gloves, black trousers, and a pair of black shoes. He did not forget to bring his giant sword.[CITATION NEEDED]

## Personality

Juggernaut is a man with his free-spirited and unrestrained personality, as he tries to push through everything with his strength. He is also very rude and insolent, as he often speaks to others in a hostile tone.[CITATION NEEDED]

Juggernaut was very bloodthirsty person as he brutally kills numerous amounts of vampires solely through brute strength by relying on his instinct and he is willing to attack anybody, even if they aren't his enemies, which he shown when he attacked Claire, despite her not being a vampire and having no connections to Elisabeth.[CITATION NEEDED]

According to Yukime, she has interpreted Juggernaut as a person with little brains, easy to provoke and in part, to deceive, nicknamed him insultingly, as Head of Muscles. Despite being rigid with innate and instinctive force, Juggernaut is not a fool at all, since he has shown to have a way of leadership in part, when it comes to simple issues, in which he can understand and handle, by now These are issues that do not add up or interest him, he leaves everything to his subordinates and lackeys, who manage it for him, and who inform him, in summary.[CITATION NEEDED]

## Powers & Abilities

Due to his inhumane strength, Juggernaut is extremely powerful with his vigorous physical body that he could become the ruler of the Black Tower of the Lawless City.[CITATION NEEDED] Among the "Three Monarchs", the only one who can match his strength is [Yukime](Yukime.md "Yukime").[CITATION NEEDED]

### Physical Capabilities

Juggernaut’s strength comes from his naturally high physical agility, due to his blessed physique and his large magic reserve.[CITATION NEEDED] Furthermore, Juggernaut possessed extraordinary endurance which makes him very durable, as he was still able to stand on his feet for a while despite being hit by the greatest number of arrows launched by the [Blood Queen](Elisabeth.md "Elisabeth").[CITATION NEEDED]

During the Red Tower in the Lawless City, during the Red Moon, Juggernaut, without any problem, managed to destroy, by brute force, the enormous door that gives the entrance to the Tower, which greatly surprised and scared White Demon, since that said door was strongly reinforced with not only wood, but also thick steel.[[3]](#cite_note-:0-3)[[4]](#cite_note-:1-4) And the strength of Juggernaut and his organization was so great that they were able to withstand Delta's onslaught for a few days, but ended up getting killed anyway.[CITATION NEEDED]

### Weapons and Equipment

Juggernaut wields a massive, billhook-shaped slab of iron as his weapon. Functioning as a cleaver and his principal weapon.

## Trivia

- The name of Juggernaut translated, from English to Spanish is "Gigante."
- Juggernaut and Yukime they have their respective insulting nicknames-- "Old Fox" for Yukime, and "Brain Head" for Juggernaut.[CITATION NEEDED]
- In the official YouTube series [Kage-Jitsu Season 2 - Episode 6](https://www.youtube.com/watch?v=RPL2uS8rgZk&ab_channel=KADOKAWAanime) it shows the events of Juggernaut's death at the hands of Delta.
  - In the Manga Chibi, Delta is seen asking Tipo that she was fatally beaten. In the Lawless City, during one of Cid Kagenou's "adventures" for that reason, shortly after the events reported, the story narrated, until volume 4 of the Novel. [[5]](#cite_note-5)

## References

1. Volume 3 Chapter 1: Lawless City Bandit Hunting!
2. Volume 3 Chapter 2: Storming the Crimson Tower!
3. Manga: Chapter 29
4. Episode 22
5. Manga Chibikage: Chapter 51

## Site Navigation
