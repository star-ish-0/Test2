# Episode 14

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2014](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2014)

## Your Lie, Your Wish

### Kana

君の嘘、 君の願い

### Romaji

Kimi no Uso, Kimi no Negai

## Special Title

### English

The Eminence in Shadow Needs a Hassle Free Solution!

### Kana

陰の実力者は手間を省いて解決したい！

### Romaji

Kage no Jitsuryokusha wa Tema wo Habuite Kaiketsu Shitai!

## Episode Information

### Season

1

### Episode

14

### Air Date

January 4, 2023 JP
March 27, 2023 EN

### Adapted From

Volume 2 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Mio Inoue

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Eta ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| A Bloody Showdown as an Offering to Annihilation | The Strongest Weakest Man |

Your Lie, Your Wish (君の嘘, 君の願い, Kimi no Uso, Kimi no Negai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the fourteenth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Cid's victory is short-lived when Nelson counters with his new magic. Meanwhile, Alexia convinces Rose and Natsume to form an alliance to uncover the truth of their world.[[1]](#cite_note-1)

ネルソンは、聖域の強大な魔力でシドを攻撃。しかし、シドはそのパワーを真っ向から受け止め、空前絶後の必殺技を放つ。その後、シドは改めて災厄の魔女アウロラと向き合うが…!?[[2]](#cite_note-2)

## Summary

As [Olivier](Olivier.md "Olivier") stabs Cid through his abdomen, he smiles that he got her and grabs Olivier to bite into her neck, ripping it open for a fatal victory and defeats her. A dumbfounded Nelson wonders how Cid is still alive after being stabbed, as Cid explains that if you protect your vital organs and arteries, its easy to survive a stabbing. As the method brings in your foe, it puts Cid in a position to use a nearly inescapable counterattack, even if he's bleeding profusely from the gut. Nelson is in shock thinking Cid is practically insane for trying such a method, and is approached by Cid thinking he'll be fighting Nelson next. As Cid continues channeling his magic through himself, Nelson feigns surrender before explaining that, thought he is surprised to see Olivier getting defeated by a kid with no magic. But as she was but a copy of Olivier, Nelson mocks Cid for thinking he won as Cid reciprocates the mockery. With the amount of magic in the Sanctuary center, Nelson summons countless copies of Olivier sending. While several attack Cid, he apologizes as he opens his right eye to defeat them using his magic and slime sword and cloak.

A startled Nelson asks how he is able to use magic, as Cid explains that he just tempered the magic until it was too solid to be absorbed by the core. It took him some time, but it was something rather simple to him, despite confusing [Aurora](Aurora.md "Aurora"). Knowing such is not possible for a normal human being, Nelson frantically orders the Olivier copies to kill him. While Cid fights them and comparing them to scarecrows, as his wound continues to bleed so he declares playtime is over. Recounting the steps to open the door, Cid decides to break the seal and defeat all copies at once, as it yields the same results. Enveloping the Sanctuary in his magical radius, Aurora is astonished anyone could have so much magical power, as he start casting his ultimate spell: I Am The All-Range Atomic. Stabbed by one of the Oliviers in the heart, Cid is unaffected and finishes his spell. The explosion obliterates all Oliviers, the sword, the chained door, Nelson, and everything else within the Sanctuary. Outside, The Seven Shadows gaze in bewonderment as their leader's magic reaches skyward to illuminate the early twilight sky, as the city of [Lindwurm](Lindwurm.md "Lindwurm") is flooded by the displaced water from the dam. In the nearby forest, Alexia Midgar and Rose Oriana stare in bafflement at the sight of a pillar of energy.

In a black void, Cid finds himself with the demon's left arm, approaching him before he wakes up in the morning with Aurora's spirit by his side. She is surprised that he survived even being stabbed in the heart, but Cid explains that he used magic to move his heart to the side to avoid a fatal blow. Cid acknowledges he is extremely tired now, with Aurora amazed he is full of surprises. Seeing that she is starting to disappear, she confesses that she was the one that called him into the Sanctuary and lied for other things as well, but Cid is fine with it. Aurora confides that she wanted to fade away into nothing for so long and forget everything, but she now has one memory she doesn't want to forget and thanks Cid. He also thanks her, stating he had a good time too. Before completely disappearing, Aurora tells Cid what to do if he ever met the real her. Once she fades, Cid takes his leave.

Elsewhere, Alexia, Rose and Natsume Kafka ([Beta](Beta.md "Beta")) contemplate the aftermath of Shadow's spell, but Alexia feels frustrated at being weak and unable to do anything, asking if Rose feels the same. Initially thinking she accepted being powerless, Alexia realizes there's more to what is happening and was unable to discern who was right or wrong, trapped as a spectator. Meanwhile, the citizens in Lindwurm concentrate on roofs or traverse in gondolas as the Church Knights mobilize disaster relief. Alexia realizes that if she does nothing, then she'll lose all she cares about before knowing the danger that takes them. Rose concurs with her own feelings, thinking how there have been huge organizations working in the shadows at war with each other since the Academy attack,[[3]](#cite_note-3) but nothing is known about either. [Beta](Beta.md "Beta") asks if Alexia has any ideas or plans, to which Alexia suggests they start a connection between the three of them, looking for any information. But as Beta ask what she'd do with the information, Alexia's half-hearted uncertain doesn't inspire confidence as they have no precise plan. However, both Rose and Beta agree to form a team regardless and pool their resources; or as Beta deems it, "The Hero, Wise Woman, and Dead Weight."

In flooded Lindwurm, [Chi](Chi.md "Chi") and [Omega](Omega.md "Omega") ferry a gondola with [Epsilon](Epsilon.md "Epsilon") reporting to [Alpha](Alpha.md "Alpha") that the Sanctuary had been obliterated. With the holy sword vaporized alongside the magical core and Nelson dead, Alpha notes that this particular situation was the simplest and the most effective solution, praising Shadow as Epsilon finds only he could have accomplished such an outcome, as Alpha states that his path is also their's. Epsilon also reports how Beta is working with the princesses, likely to infiltrate their inner circles if she plays her cards right. Finishing her report, Epsilon also confirms that their theory about Aurora was correct, as she had another name: the Demon Diablos. As Alpha reaches her own conclusion regarding Shadow, she tells Epsilon that their next performance is the Midgar royal capital. While Epsilon wonders if she should report to Shadow, Alpha tells her it's not needed, as he knows everything. The Shadow Garden executives then vanish without a notice.

Back in the Midgar royal capital, nobleman [Rude](Rude.md "Rude") of the Velgalta Empire is meeting with Mitsugoshi Company President Ms. Luna ([Gamma](Gamma.md "Gamma")) to open a second shopping centre within his domain. While Gamma understands, she reminds him that Mitsugoshi is contributing to reconstruction of the disaster in the Sacred Lands. As he argues the "prime property," she counters that it is still on the market despite the affordable price. But Rude argues that is precisely why they need a store out there, as even he has heard of Mitsugoshi within his outskirt domain, still petitioning she buy prime property in Madlid. As he continues his sales pitch with a discount and more, [Nu](Nu.md "Nu") steps in to update Gamma that they found and confirmed a petroleum reservoir in Rude's domain. Concluding his petition, Rude is surprised when a pleased Gamma decides to buy every property on that street. Gamma clarifies to the flummoxed Rude that she wants to redevelop the city, and should he accept their terms, Mitsugoshi will make Madlid the greatest city in Velgalta Empire. As Gamma asks about expanding the tributaries of the Nyle river, Nu orders her staff to begin buying property along the Nyle river, commanding they ready themselves for the "real estate bubble" to come.

Meanwhile, [Zeta](Zeta.md "Zeta") continues an expedition into an arctic region, met by curious penguins, as [Eta](Eta.md "Eta") sleeps after designing an [Airship](https://en.wikipedia.org/wiki/Airship). At their Mitsugoshi HQ office, Beta inquires [Delta](Delta.md "Delta")'s location, as they believe she's still in the Sacred Land, but decide to leave her alone as she will return home when she gets cold. As Epsilon plays the piano, Alpha sees her Shadow Garden compatriots enjoying their time in from the rain, recalling to an earlier time with Cid. Back when it was just the original seven, they had made their original base of operation from a small house based on Cid's teachings on [Woodframe Construction](https://en.wikipedia.org/wiki/Framing_(construction)). With a home to stay in, Alpha was ready to begin training the other girls to face the Cult and each needed to enhance their individual strengths. Cid agreed to share a portion of his wisdom to ensure they achieve their convictions, thinking young girls living on their own would need [self-defense](https://en.wikipedia.org/wiki/Self-defense) techniques. As Alpha returns from nostalgia, Gamma relays received news that Oriana's Royal Chancellor, Perv Asshat, will be visiting the Midgar Royal Capital.

At a Royal Capital Mitsugoshi Hot Spring, Alexia finishes explaining to Iris that archbishop [Drake](Drake.md "Drake") and Nelson were part of the Cult. To be able to keep the Sanctuary a secret, they would need an organization with considerable public influence. But while Alexia wants to investigate the Divine Teachings and hope to tie the recent revelation to the incident at the capital,[[4]](#cite_note-4) Iris had suggested the same thing to their father, King Klaus, but he denied them. Per his usual passive policies, and due to King Raphael Geerk Oriana visiting for the upcoming Bushin Festival, King Klaus doesn't want to instigate anything with the Church without clear evidence. However, Iris feels that if she wins the Bushin Festival again, then she will have more backing and support from the people, hopefully forcing their father to listen. Alexia voices concern, asking what if the Cult or Shadow Garden will get involved, but Iris is sure of her sword skills regardless of whatever artifacts they may have. While Alexia tries to warn her that both factions have more than simple artifacts, Iris rationalizes the massive explosion[[5]](#cite_note-5) was from an artifact, as no single human has that much power. Iris also knows she "saw" them send [an artifact](Millia.md "Millia") out of control, and will not run from her duties as First Princess, despite Alexia's warnings.

Remembering Alexia's trek to Lindwurm, Iris wonders why Alexia went into the Sanctuary as she didn't authorize her to do anything aside from auditing the archbishop, but Alexia plays dumb with feigning lightheadedness, excuses herself to the cold water bath. Alone, Iris fears that her Crimson Order Knights probably won't be able to rebuild after losing their strongest members so early. She feels the once supportive Knight Order likely hate her now, taking their strongest members and letting them die, leading Marco Granger to visit [Glen's](Glen.md "Glen") grave. A somber Iris feels that she just needs to win the tournament and show the knights a path to prove her trustworthiness. Just then, Iris hears a towel snap from the other bath before a second snap is heard a moment later. Elsewhere in the capital, Rose is training her fencing trying to emulate the motion she saw from Shadow's rescue at the academy and another time long before. But as she readies her stance, she feels strange pain and discovers [a red growth](Possession.md "Possession") appearing on her chest.

## Characters

- Jack Nelson
- Cid Kagenou
- [Aurora](Aurora.md "Aurora")
- [Olivier](Olivier.md "Olivier")
- [Alpha](Alpha.md "Alpha")
- Alexia Midgar
- Rose Oriana
- [Beta](Beta.md "Beta")
- [Epsilon](Epsilon.md "Epsilon")
- [Chi](Chi.md "Chi")
- [Omega](Omega.md "Omega")
- [Rude](Rude.md "Rude")
- [Gamma](Gamma.md "Gamma")
- [Nu](Nu.md "Nu")
- [Zeta](Zeta.md "Zeta")
- [Eta](Eta.md "Eta")
- [Delta](Delta.md "Delta")
- Perv Asshat (Mentioned)
- [Drake](Drake.md "Drake") (Mentioned)
- Iris Midgar
- Klaus Midgar (Cameo)
- Zenon Griffey (Flashback)
- [Millia](Millia.md "Millia") (Flashback)
- [Glen](Glen.md "Glen") (Mentioned)
- Marco Granger (Cameo)

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第14話予告≪ノーマルVer.≫「君の嘘、君の願い」

TVアニメ『陰の実力者になりたくて！』第14話予告≪スペシャルVer.≫「陰の実力者は手間を省いて解決したい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e014>
2. <https://shadow-garden.jp/1st/story/#story14>
3. Episode 9
4. Episode 5
5. Episode 5

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • **Episode 14** • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
