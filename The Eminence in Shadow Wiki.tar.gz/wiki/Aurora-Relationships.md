# Aurora/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Aurora/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Aurora/Relationships)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Main](Aurora.md "Aurora")

[Chronology](Aurora-Chronology.md "Aurora/Chronology")

Image Gallery

## Allies

### Cid Kagenou / Shadow

Having noticed Cid's accidental summons, Aurora invited Cid to her in hopes that he could free her from the [Sanctuary](Sanctuary.md "Sanctuary").

The two immediately developed an amicable relationship with each other, with Aurora making jokes about fair maidens and gallant knight, while Cid internally called her "violet." Aurora tried to stop Cid from fighting Olivier, but Cid decided to fight and got injured. Aurora was deeply moved as in all her life she had been scorned by people from all people alike while no one ever tried to risk their life for her. Aurora became worried for Cid when he was seemingly overwhelmed by the [Sanctuary](Sanctuary.md "Sanctuary") and impaled through the heart by a clone of [Olivier](Olivier.md "Olivier"). When she thinks Cid is about to be killed, she offers herself to the Cult of Diablos to save him. Cid however shows Aurora why she doesn't have to worry.

After finally being freed, Aurora reveals that she's the one who summoned Cid to the Sanctuary and admitted to Cid that the memory she had with him was the best she ever had, hinting she had developed romantic feelings for him. Aurora requests him to kill her if he finds the "real" her.

Cid had met Aurora once again but this time in her younger/kid version at the Midgar Royal Spells Sword Academy's Sanctuary twice.[[1]](#cite_note-:0-1)[[2]](#cite_note-:1-2)

Their first encounter had taken place when Cid was transported to a white room. Within the hidden white space of the Midgar Royal Spells Sword Academy, Cid had come across Aurora, who appeared as a young girl with striking violet eyes and dressed in a white outfit. She had questioned Cid's identity, and during their conversation, he had recognized her as Violet-san from a different age. Aurora had seemed distressed, struggling to remember certain things and experiencing intense pain. Cid had provided comfort and shared his own tendency to forget unimportant memories. Despite her agony, Aurora had unleashed a burst of magical power. Cid had managed to calm her by infusing his own magic into her, eventually soothing her and helping her regain control. While discussing how to cope with memories she wished to forget, Cid had advised Aurora to let them fade naturally. After regaining her composure, Cid had contemplated how they could exit the white space. Aurora had expressed fear about those who tried to leave disappearing, and Cid had offered to take her with him when he found a way out. However, Aurora had felt trapped and had pleaded with him not to leave. Cid had assured her that they would meet again, leading to a poignant exchange as the white space shattered, and they had returned to the rooftop. The encounter with Aurora had concluded, and Cid had retrieved a red jewel from his pocket, the same one Aurora had pointed to earlier. He had then pondered the whereabouts of Violet-san.[[1]](#cite_note-:0-1)

In the surreal second meeting, the air had been filled with a sense of familiarity as Aurora's voice had greeted Cid with a casual, "Yo, we meet again." In the heart of a pristine white chamber, she had been sitting there, curled up, her form bearing the scars of battle. Concern evident in Cid's voice, he had inquired about her well-being, offering his assistance by infusing mana to mend her wounds. Slowly, she had lifted her head, revealing tear-stained cheeks and blood-traced lines on her face. Gratitude had colored her words as she had whispered a heartfelt, "Thank you."

Driven by curiosity, Cid had pressed further, seeking to understand the events that had led to her injuries. Her response, delivered with an enigmatic smile, had portrayed the ordeal as merely ordinary—an answer Cid had met with a raised eyebrow and a hint of skepticism. Undeterred, she had referred to their connection, labeling Cid as "onii-chan," a moniker that had stirred memories of their past interactions. The conversation had pivoted to a significant object, a red gemstone that held importance for both of them.

As Cid had extended the gem to her, the weight of its importance had hung in the air, prompting her to accept it with a mixture of appreciation and anticipation. However, in the midst of their exchange, a subtle transformation had begun to take hold. Aurora's features had contorted, revealing something otherworldly, and an eerie energy had emanated from her, shrouding the once-pure surroundings in darkness. Her words had turned cryptic, slipping through the veil of this ominous shift.[[2]](#cite_note-:1-2)

Amidst the unfolding chaos, a chilling cycle had emerged phantoms had appeared, only to be ruthlessly dismantled by an enigmatic force. This disconcerting pattern had persisted until, abruptly, the scene had transformed, and Cid had found himself standing atop the Academy's roof, a setting reminiscent of their initial encounter with Kid Violet-san. The sun's warm embrace had given way to the cool hues of twilight, and the familiar surroundings had provided a stark contrast to the surreal events that had transpired.[[2]](#cite_note-:1-2)

In the aftermath of this uncanny experience, a lingering uncertainty had gnawed at Cid, questioning the implications of his actions. Had presenting Aurora with the gemstone been the right choice? The notion had settled within him, intertwining with the enigma that was Aurora and their intricate connection.[[2]](#cite_note-:1-2)

### Claire Kagenou

They first met during the battle against [Elisabeth](Elisabeth.md "Elisabeth"), due to her blood flowing through Claire's veins, which Aurora can appear in her mind and even temporarily borrow her body. Aware that she was Cid's sister, to whom she felt indebted, she then unilaterally signs a contract with Claire and lends her strength in times of emergency, even aiding her by taking over her body and fighting on her behalf. She also gave her a hint regarding her brother's true identity, though she did not pick up on it.[[3]](#cite_note-3)

Since then, Aurora protects Cid's sister Claire from harm thanks to him. She even admits to Claire about being a little envious of her for being always protected by a very powerful warrior like Cid. Aurora continued appearing in Claire's mind following their first meeting, regularly disrupting the latter's daily life. However, she refuses to elaborate to Claire what is happening to her, believing that Cid is trying to protect her. When Claire declares that she'll protect Cid with her newfound power only for Aurora tries to stop her because it's embarrassing since Aurora knew how powerful Cid is and not because it's an awkward moment for Claire. After escaping from [Jean](Jean.md "Jean") by [Zeta](Zeta.md "Zeta"), Claire blamed Aurora for "ruining" her reputation as a big sister for Cid when she crashed into her brother's class while in his exams.[[4]](#cite_note-:2-4)

### Alexia Midgar

When Aurora saw Alexia, she thought to herself as she and Claire had shown how similar the two of them were.[[4]](#cite_note-:2-4)

## Shadow Garden

### Seven Shadows

#### [Beta](Beta.md "Beta")

#### [Zeta](Zeta.md "Zeta")

Aurora is very nervous when she saw Zeta as she warned Claire to stay away from her when she didn’t know if she is a friend or enemy.[[4]](#cite_note-:2-4)

### Numbers

#### [Nu](Nu.md "Nu")

## Cult of Diablos

### Knights of Rounds

#### Jack Nelson

Nelson attempted to seize Aurora for his experiments. He only has her severed arm to create the Beads of Diablos. Like Alexia, Aurora called Nelson as a "Baldy".[[5]](#cite_note-:3-5)

#### [Fenrir](Fenrir.md "Fenrir")

Long ago, Aurora had met Fenrir when he was a greedy assassin who only wanted to increase his power to the point of being feared as the "Midgar Devil".

When Aurora saw Fenrir's true appearance, she was surprised because in her memory he should have been very old, even Aurora herself warned Claire about this while protecting her from Fenrir's attack.[[2]](#cite_note-:1-2)

### Children of Diablos

#### [Maximilian](Maximilian.md "Maximilian")

#### [Jean](Jean.md "Jean")

### Three Heroes

#### [Olivier](Olivier.md "Olivier")

Despite having no proper recollection of Olivier in her memories, Aurora has an unexplained fear of Olivier. Aurora is aware that Olivier is extremely dangerous to the point that she rules out any possibility of a human being able to best her in combat.

Due to this, Aurora warns Cid not to engage in combat with Oliver and even momentarily agrees to work with Nelson to save Cid.[[5]](#cite_note-:3-5)

## Others

### [Elisabeth](Elisabeth.md "Elisabeth")

## References

1. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
2. Volume 5 Epilogue: I’d Let the Whole World Burn, If That’s What It Took!
3. Volume 3 Chapter 3: Pursuing the Blood Queen!
4. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
5. Volume 2 Chapter 3: When Things Get Boring, It's Time for Explosives!
