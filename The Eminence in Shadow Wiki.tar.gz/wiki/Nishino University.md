# Nishino University

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Nishino%20University](https://the-eminence-in-shadow.fandom.com/wiki/Nishino%20University)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Nishino_University?action=edit).

## Nishino University

### Japanese

西野（にしの） 大学（だいがく）

### Romaji

Nishino Daigaku

## Location Information

### Leader

None

### Status

Unknown

### Affiliates

Unknown

### Type

University

### Government

Unknown

### Location

Japan

### Inhabitants

Humans

## Debut

### Light Novel

Volume 4

Nishino University (西野（にしの） 大学（だいがく）, Nishino Daigaku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a university that was owned by the Nishino family prior to the fall of Japan. But after the fall of Japan, Nishino University became a shelter strong hold for survivors of a post-apocalyptic Japan. With [Messiah](Messiah.md "Messiah") becoming one of the University owned by the Nishino family to become a strong hold.

## Overview

### Prior to the fall of Japan

### After the fall of Japan

## Layout

## Known Characters

## Trivia

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • **Nishino University** • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
