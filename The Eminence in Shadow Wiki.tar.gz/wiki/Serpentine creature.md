# Serpentine creature

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Serpentine%20creature](https://the-eminence-in-shadow.fandom.com/wiki/Serpentine%20creature)

## Serpentine creature

## Characteristics

### Race

Unknown

### Age

Unknown

### Height

Unknown

### Hair Color

Blue

### Eye Color

Yellow

### Birthday

Unknown

## Personal Information

### Status

Alive

## Debut

### Anime

Episode 10

### Game

Episode 11

This serpentine creature ([?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is an unknown creature that appeared once in the anime & game. Nothing else is known about it.[[1]](#cite_note-1)

## Appearance

## Personality

## History

## Powers and Abilities

## Gallery

## Trivia

## References

1. Episode 10 The Sacred Land, City of Deception
