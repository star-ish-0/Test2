# Claire Kagenou/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Claire%20Kagenou/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Claire%20Kagenou/Chronology)

Main

Relationships

Image Gallery

## Volume 1

### Assault on Viscount Grease's Base

When Claire was 15, her mother would arrange a farewell party. She was set to leave for the capital of Midgar Kingdom and attend their Academy. The night before her departure, the Cult of Diablos infiltrated her family home and kidnapped her. Claire was held inside a jail cell, where she learned that her kidnapper was [Viscount Grease](Grease.md "Grease"). She proceeded to mock Grease for his depressing defeat against First Princess Iris Midgar in the first round of the Bushin Festival. Feeling humiliated, he punches her in the face. His next punch did reach its target. Despite being restrained by Magic Sealing Chains, Claire managed to dodge his assault. Her ability Grease inquired if she had suffered from any symptoms of possession, to which she vaguely confirmed and accidentally brought up Cid during their conversation. Viscount Grease decided to bring him in for questioning. Enraged at this possible decision, Claire broke free of her chains and attacked the Viscount, only to have him knock her unconscious. Unbeknownst to her, Shadow Garden rescued her. When she woke up, she would return home safely by her power. Claire returned home and took a few days to recover from her injuries, and during that time she would pester her brother more than usual.[[1]](#cite_note-V1C1-1)

### Princess Alexia's Kidnapping

Claire hurriedly confronts Iris Midgar after learning that her brother is suspected of kidnapping Iris's sister, Alexia Midgar. She knew that whether or not Cid was a suspect, this would ultimately lead to his execution, and she tried vouching that her brother was innocent. This exhortation did not move Iris, causing Claire to nearly assault her, but Zenon Griffey dragged her out before that could happen[[2]](#cite_note-V1C3-2)

### Midgar Academy Terrorist Attack

Claire was not present during the attack on the academy as she and the other third-year students were away on a study trip.[[3]](#cite_note-V1C6-3)

## Volume 2

### Bushin Festival Tournament

When the Bushin Festival began, Claire became her school's representative after the previous one, Rose Oriana, became a fugitive and was disqualified. Claire went to Cid's dorm to invite him to see her matches, but Cid decided to avoid her. After waiting for a long time, Claire began envisioning beating Cid into a pulp and got increasingly angrier as the hours increased.

After Cid returns, in his dorm room Claire started strangling Cid for making her wait, and while strangling him Claire was able to guess that Cid was think of going to sleep while she strangles him. Claire threatened that if Cid broke another promise, she would make him pay. Cid promised that he would do better to keep his promises. Although Claire removed her hands from Cid's neck, she remained on top. Claire announced that the dogs mounted each other to establish dominance. After sufficiently calming down, Claire explained to Cid that she wanted him to watch her fight while giving him a ticket to special seating at the tournament. It appeared that Claire was satisfied, but Cid’s ignorance about past events caused Claire to go back to strangling him. An inquest began about her birthday, previous tournament results, and first win. She told him to remember these things and be more attentive toward her if he wanted to live a long, happy life.[[4]](#cite_note-V4C7-4)

Due to Mundane Mann hiding his identity, he was disqualified, but Iris’s loss was still approved. Claire ultimately won the Bushin Festival championship by default.[[5]](#cite_note-V3CP-5)

## Volume 3

### Red Moon Incident

After winning the Bushin Festival by default, Cid treated her to a celebratory dinner at Mitsugoshi's restaurant to appease her anger. Considering her brother’s poor grades and job prospects, Claire proposed a joint venture to defeat the Lawless City’s Blood Queen.[[5]](#cite_note-V3CP-5)

Once they arrived, Claire left Cid alone outside of the meeting at an Inn while she attended a meeting at the Magic Swordsmen Association forward base. After the meeting, she discovered that her brother was missing. Claire then heard a scream, and a man was being attacked in the corridor by a ghoul. Effortlessly killing the ghoul, Claire asked the man if he had seen her brother. In her search, she encountered the Vampire Hunter, [Mary](Mary.md "Mary"), who informed Claire that her brother might have been taken to Red Tower to be sacrificed. Because their goals aligned, the two agreed to work together to stop the vampire queen's revival.[[6]](#cite_note-V3C1-6)

Using a tunnel to bypass the Vampires and [Ghouls](Ghouls.md "Ghouls"), Claire and Mary meet [Beta](Beta.md "Beta") from Shadow Garden. Claire asked Beta if there was a way to cure Possession. Beta hesitated and refused to clarify particulars but informed the former not to worry.

The intrepid sister and legendary vampire slayers soon encountered [Juggernaut](Juggernaut.md "Juggernaut"), who decided to kill them. Overwhelming the pair, Mary was forced to drink Claire’s blood, revealing her secret. The newly found strength pushed Juggernaut back, but the stalwart warrior began to overpower the duo again. He was only defeated by a swift intervention and kick by Shadow. Mary revealed to Claire that she was a [Vampire](Vampire.md "Vampire") and admitted to being a past follower of the Blood Queen. After telling her story, Claire expressed indifference and continued her quest to save Cid together.[[7]](#cite_note-V3C2-7)

Eventually, the two finally reached the tower. Claire was dismayed at the sight of a dead boy and wept. Once emotions settled, the sad sister realized her error. The body did not resemble Cid at all. Ignorant to the revived queen, Elisabeth impaled Claire’s body. A quick suckle of blood allowed Elisabeth to regain power. Thankfully, Claire was saved by the spirit of [Aurora](Aurora.md "Aurora"), who placed a seal onto the dorsal surface of her right hand and temporarily took over her body and unlocked her full abilities to combat Elisabeth. This fight held the Vampire Queen long enough for Shadow to finish it.

After the battle, Claire reunited with Cid, and he apologized to Claire for wandering off on his own. The next day, Cid and Claire prepare to leave the Lawless City. Claire hugged and asked forgiveness for bringing him into the city, nearly jeopardizing his life. She expressed concern about the direction of her life, but Cid told her he would support his sister. Claire was thankful for his words. Closing her eyes, she rested her head on his shoulder during their ride back to Lawless City.[[8]](#cite_note-V3C3-8)

### Auxiliary Chapter

One day when Claire was 8, at home their father told them about the Scarface Gang and requested them to be circumspect. Claire, ignoring her father’s warnings, dragged Cid into a nearby forest to locate the Scarface Gang–a few hours of wandering revealed nothing. Not wanting to anger their mother if they did not return by lunch, she concluded their training. The two Kagenou siblings began to turn back, but they encountered the [Scarface](Scarface.md "Scarface") Gang. She began to fight against the Scarface members. Wanting to protect her brother, she begged him to flee while she fought off dozens of Scarface members. However, much to her horror, she saw him come to her aid, before falling unconscious she would recall events that happened when she was 3 years old. Scarface unceremoniously based the defenseless boy against the tree as she falls unconscious. She later woke up to find her brother unharmed and joyfully hugged him. She was told that a band of hunters chased them away.[[9]](#cite_note-V3CA-9)

## Volume 5

### The Academy Disappearances

Claire unexpectedly materialized into Cid's class to trample his teacher. She was embarrassed and left to be reprimanded by the head teacher. Initially contemptuous towards Alexia for her fake relationship with Cid, the two formed an uneasy alliance when she revealed her connection with Aurora.

The next day, Claire finds Cid at the school gate and puts a collar on him, where she drags him to her dorm room and mounts and straddles him and strangles him. Claire still mad at Cid for breaking his promise and lying to her. After talking to Cid about the situation happening with the academy, she tells Cid that he is the best brother while crying– having imagined the possibility of her death. After comforting words from Cid, she promises to come back alive, she would later give him a very tight hug.[[10]](#cite_note-V5C1-10) That night, Claire and Alexia decide to infiltrate the library. The Head Librarian soon ambushed the two girls; he revealed himself as an agent for the Cult. Before the situation devolved further, Shadow appeared and defeated the head librarian. In his final breaths, the librarian Slender Willow revealed information regarding the Cult, Beads of Diablos, and The Church’s complacency.[[11]](#cite_note-V5C2-11)

Alexia and Claire later continued their investigation before noticing white hazes suddenly enveloping the Academy. The two hurried to the Academy to the auditorium to see ghosts attack the students before realizing they both possessed magic collars that would detonate when their magic reached 0. After fending off the ghostly horde, the two ran into Nina and [Isaac](Isaac.md "Isaac"). Isaac accused Shadow Garden of orchestrating the event. Alexia refuted Isaac's accusation, emphasizing the lack of evidence to accuse the organization.

Anxious for a way out, an unassuming student named Suzuki suggested that the students low on magic could stay in the auditorium as defense while the rest investigate. Claire’s group traced the collars to a church and investigated for clues. The trail led them to a trap, and the group fell unconscious one by one, with Alexia finding out that Isaac was a Cult insider before collapsing.[[12]](#cite_note-V5C5-12)

Upon reawakening, Alexia and Claire found themselves restrained. They decided to escape to avoid their fate, but the 5th Knight of the Rounds, Fenrir, revealed himself. Aurora decided to intervene and free the two when the Round Knight proceeded to extract blood from Claire's neck. Freed from their confines, the two confronted the martial maniac but were overwhelmed. Suddenly, the unassuming student revealed himself to be Shadow. He defeated Fenrir and left the scene without a trace, cutting off the party's collar. Barely stable, Claire saw [Nina](Nina.md "Nina") regrouping with the team before she knocked them out. Being taken in further into the Santurary, she was placed on to a pedestal where Nina then proceeded to force Diablos' severed right arm into Claire under [Zeta](Zeta.md "Zeta")'s orders, resulting in excruciating pain. In the end, she fell into a comatose state, and her seal would have another seal would be placed onto her.[[13]](#cite_note-V5CE-13)

## Volume 6

### The Bloody Terror of Midgar

After falling into a coma, Claire would be placed in her dorm with medical equipment. She would be watched over by [Mu](Mu.md "Mu") until her body recovered.[[14]](#cite_note-V6CP-14)

## Volume 7

Following into spring, since Claire missed her exams due to her still being in a coma. Which will result in her having to repeat a year. During the spring break events, her parents plan to come to the royal capital to check on her condition.[[15]](#cite_note-V7CP-15)

## Master of Garden

### The Seven Shadow Chronicles

#### Future Unlocked

Claire heard a crash coming from Cid's room. She went to his room and asked if everything was alright. Entering Cid's room, she inquired about the loud crash. Cid assured her that he was fine, putting her at ease. However, because she had returned, she ordered him not to stay in his room.[[16]](#cite_note-16)

#### False Oracles

Claire would meet up with Cid to ask him about a favor he asked of her, the favor being that Cid wants to visit a trade city. Claire was happy to oblige it but under one condition. Since Cid was holding off on his entry for the Midgar Academy for a year and a half, Claire wanted him to switch for early enrollment. But Claire wanted him to come early to the capital to make things easier for her. which made her want to start planning their winter break trip.[[17]](#cite_note-17)

#### Violet Eyes

An excited Claire would ask Cid if he was looking forward in visiting the capital. Cid knew that she wanted to spend all her time outside of her lessons and training being glued to his side. Although it would be winter break when they arrive, she would excitedly ask Cid what he wanted to do. Although Cid didn't know due to him not nowing anything about the capital. Claire would take upon herself to be his guide ordering Cid to stay by her side so that he wouldn't get lost. As Cid was deep in thought, Claire askes Cid if he's listening, she would ask Cid if he has any idea how concern she is.[[18]](#cite_note-18)

### Masquerade

## Manga Special

### I Searched Everywhere for a Mythical Eight-Headed Serpent and Never Found It

When Claire was 14, she was displaying symptoms of [possession](Possession.md "Possession"), though she tried to hide it. Cid could tell that she was losing control of her magic. He decided to help her by stretching her as a way to secretly heal her. Claire tried to straighten her knees at Cid's request, though she didn't understand the purpose. Cid helped her deepen her stretch by pressing his hand against her back, ostensibly to cure her possession by transferring his magic through touch. He also checked on her condition. She heard Cid say that her body was loosening up and her swordplay was limbering up as well. She recalled having a longer range in the tournament the day before. However, her possession had actually changed the quantity and density of her magic, which he didn't tell her.

Cid told Claire that she should thank stretching and proceeded to work on her calves next. Despite her complaints and moans, she always agreed in the end. While stretching, Cid continued to treat her possession by running his magic into her body. He believed that within a few days, he would be able to stabilize her completely. Cid told her that her body had loosened up and that in a few days, everything would be fine with stretches. When he asked if they were done, she said that her glutes were tense, and they proceeded to loosen them up and continue with stretching. While doing stretches, Cid sensed that someone was watching them. He looked out the window, and Claire noticed this. She asked him what was wrong, but he said nothing. Later that night, Claire slept in Cid's room, while he dealt with the intruder who had been watching them.[[19]](#cite_note-MV1CS-19)

## Major Medium Differences

### Volume 1

### Volume 2

In the Web Novel, Claire barges in Cid's dorm room. In the Manga, Claire barges into Cid's dorm room through the window.

## References

1. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
2. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
3. Volume 1 Chapter 6: That Scene Where Terrorists Take Over the School
4. Volume 4 Chapter 7: Showing Off a Smidgen of My Strength!
5. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
6. Volume 3 Chapter 1: Lawless City Bandit Hunting!
7. Volume 3 Chapter 2: Storming the Crimson Tower!
8. Volume 3 Chapter 3: Pursuing the Blood Queen!
9. Volume 3 Auxiliary Chapter: Field Notes on a Little Brother—by Young Claire!
10. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
11. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
12. Volume 5 Chapter 5: Terrorists Attack the School… Again!!
13. Volume 5 Epilogue: I’d Let the Whole World Burn, If That’s What It Took!
14. Volume 6 Prologue: There Are People Ruling the Midgar Kingdom from the Shadows? I'm So Jealous!
15. Volume 7 Prologue: Spring is the Season for Departures!
16. Seven Shadows Chronicles - Chapter 2, Episode 5
17. Seven Shadows Chronicles - Chapter 26, Episode 5
18. Seven Shadows Chronicles - Chapter 39, Episode 5
19. Manga Special I Searched Everywhere for a Mythical Eight-Headed Serpent and Never Found It
