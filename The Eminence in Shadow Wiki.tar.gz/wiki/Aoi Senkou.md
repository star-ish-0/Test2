# Aoi Senkou

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Aoi%20Senkou](https://the-eminence-in-shadow.fandom.com/wiki/Aoi%20Senkou)

## Aoi Senkou

### Japanese

蒼い閃光

### Romaji

Aoi Senkō

## Information

### Artist(s)

Shadow

### Composer(s)

Ayato Shinozaki
Ryosuke Tachibana

### Arranger(s)

Ayato Shinozaki
Ryosuke Tachibana

Aoi Senkou is the character theme song for Shadow that is acquired by purchasing the Darling in the Night album. The song was performed by the voice actor of Shadow, Seiichirou Yamashita.

## Lyrics

- [Kanji](#)
- [Romaji](#)
- [English](#)

:   例え名高き天才も
:   古今無双の英雄も皆(何もできず)
:   灼け落ちる

:   “堕ちた太陽”に飲まれてなお
:   消えることのない力を人は宿せるか？

:   (One way！)
:   強靭な身体の限界
:   (One way！)
:   狂人は研鑽を止めない
:   (One way！)
:   凶変と転生の果て
:   辿り着く答え

:   「アイ・アム・アトミック」

:   蒼い閃光
:   放て無限の先を照らす光
:   脆弱な常識をただ超越て(こえて)

:   「これが我が最強」

:   蒼い閃光
:   眩き咆哮 果て無き意志の先
:   臨界の衝撃をいま刻め 漆黒の刃で

:   “凡人の刃”
:   決して偽りのない
:   研ぎ澄まされしそれこそ

:   借り物の力に意味などはない
:   仮初の姿じゃ立てない
:   最強へ至るその道
:   歩むべき剣

:   「アイ・アム・アトミック」

:   蒼い閃光
:   鋼の堅甲総て砕く光
:   制約も限界もない力

:   「我らはシャドウガーデン」

:   蒼い閃光
:   遥か流転の先で掴む証
:   輝きの奔流を今刻め
:   しかと、その目に

:   「かつて……核に挑んだ男がいた。
:   男は肉体を鍛え、精神を鍛え、技を鍛えた。
:   だがそれでも届かぬ遥か高みに核はあった。
:   しかし諦め切れぬ男は、狂気の修行を重ねた末、答えに辿り着く。」

:   時が世界が震え始める
:   静寂に今咲く　歓びの光

:   蒼い閃光
:   緻密な紋様　螺旋を描きここに
:   “最強”は顕現する

:   「アイ・アム・アトミック」

:   蒼い閃光
:   放て無限の先を照らす光
:   脆弱な常識をただ超越て(こえて)

:   「これが我が最強」

:   蒼い閃光
:   闇夜の残響　影から差す光
:   臨界の衝撃をいま刻め　漆黒の刃で

:   Tatoe na takaki tensai mo
:   Kokon musō no eiyū mo mina (Nanimo dekizu)
:   Yakeochiru

"Ochita taiyō" ni nomarete nao

:   Kieru koto no nai chikara wo hito wa yado seru ka ?

:   (One way !)
:   Kyōjin na karada no genkai
:   (One way !)
:   Kyōjin wa kensan wo tomenai
:   (One way !)
:   Kyōhen to tenshō no hate
:   Tadoritsuku kotae

:   "AI・AMU・ATOMIKKU"

:   Aoi senkō
:   Hanate mugen no saki wo terasu hikari
:   Zeijaku na jōshiki wo tada koete

:   "Kore ga waga saikyō"

:   Aoi senkō
:   Kurumeki hōkō hate naki ishi no saki
:   Rinkai no shōgeki wo ima kizame shikkoku no wa de

:   "Bonjin no wa"
:   Kesshite itsuwari no nai
:   Togisumasare shisore koso

:   Karimono no chikara ni imi nado wa nai
:   Karisome no sugata ja tatenai
:   Saikyō e itaru sono dō
:   Ayumubeki ken

:   "AI・AMU・ATOMIKKU"

:   Aoi senkō
:   Hagane no kenkō subete kudaku hikari
:   Seiyaku mo genkai mo nai chikara

:   "Warera wa SHADOU GĀDEN"

:   Aoi senkō
:   Haruka ruten no saki de tsukamu akashi
:   Kagayaki no honryū wo ima kizame
:   Shikato, sono me ni

:   "Katsute...... Kaku ni idonda otoko ga ita.
:   Otoko wa nikutai wo kitae, seishin wo kitae, waza wo kitaeta.
:   Da ga sore demo todokanu haruka takami ni kaku wa atta.
:   Shikashi akiramekirenu otoko wa, kyōki no shugyō wo kasaneta sue, kotae ni tadoritsuku."

:   Toki ga sekai ga furue hajimeru
:   Seijaku ni ima saku yorokobi no hikari

:   Aoi senkō
:   Chimitsu na monyō rasen wo egaki koko ni
:   "Saikyō" wa kengen suru

"AI・AMU・ATOMIKKU"

:   Aoi senkō
:   Hanate mugen no saki wo terasu hikari
:   Zeijaku na jōshiki wo tada koete

:   "Kore ga waga saikyō"

:   Aoi senkō
:   Yamiyo no zankyō kage kara sasu hikari
:   Rinkai no shōgeki wo ima kizame shikkoku no wa de

## Videos

蒼い閃光

## Trivia
