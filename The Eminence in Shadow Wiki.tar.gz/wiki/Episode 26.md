# Episode 26

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2026](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2026)

## John Smith

### Kana

ジョン・スミス

### Romaji

Jon Sumisu

## Special Title

### English

The Eminence in Shadow wants to act like a big pretend to know everything!

### Kana

陰の実力者は大物っぽく知ったかぶりたい！

### Romaji

Kage no jitsuryokusha wa oomottoppoku shitta kaburitai!

## Episode Information

### Season

2

### Episode

6 (26)

### Air Date

November 8, 2023 JP & EN

### Adapted From

Volume 3 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

Grayscale dominator

### Ending

Polaris in the Night (Nu ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| He Who Pulls The Strings | Something Precious |

John Smith (ジョン・スミス, Jon Sumisu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the sixth episode of the second season, and the twenty-sixth episode of [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

John Smith's skill is leagues above even the most skilled fighters! Who is this mysterious person?
[[1]](#cite_note-1)

ジョンの前に次なる刺客デルタが現れる。シドは一瞬で正体を見破られるが……。一方、デルタが戻らず悲嘆に暮れるシャドウガーデンでは、アルファが直接動き出すことに。[[2]](#cite_note-2)

## Summary

At Mitsugoshi Company headquarters, [664](664.md "664") concludes her report. [Alpha](Alpha.md "Alpha") is surprised to hear how three of their Numbers were bested by a new opponent. As [Gamma](Gamma.md "Gamma") has no information on this "John Smith," thinking he might be a Named Children of the Cult of Diablos, Alpha postulates he might be a resident of the Lawless City. But while the two leaders debate his origin, 666 interjects to clarify the strength of John Smith, much to the fright of 664 trying to keep her in line before their leaders. Panicked at the idea of punishment, 664 rushes 666 out of the office as [665](665.md "665") sings farewell to Alpha and Gamma. Resuming their briefing, Gamma updates Alpha that she assigned [Zeta](Zeta.md "Zeta") to search for an objective they previously discussed, with Alpha hoping Zeta's silence on reporting in is because her mission is progressing well-- as Zeta concurrently overlooks her objective alongside her [backup](Victoria.md "Victoria"). With the Cult holding a heavy resistance, Alpha voices wanting the fighting to finish soon so they can relax, worrying Gamma before deciding to send [Delta](Delta.md "Delta") to handle John Smith, with the therianthrope ready to hunt.

On a train leaving the Lawless city, "John Smith" reviews his notebook before noticing the prowling Delta pursing the train. She charges in breaching his cabin in her usual feral hunting, only for her attack to be halted by magical strings as John Smith casually holsters his notebook to continue fighting her. As Delta dodges the string attacks, she roars with enough force to rupture the train cabin outward, but John Smith immediately takes advantage of the debris to pin her down under the rubble. As John Smith stands above her to deliver a villainous monologue, Delta turns from raging to inquisitive upon smelling him so close, then jumps playfully once she realizes he's actually her master, Shadow. Cid is dejected that Delta found out and ruined his roleplay, but he gets over it to give her a back ride to another train cabin.

Cid asks why Delta was there and she confirms she was ordered by Alpha to hunt John Smith, only to realize Cid is John Smith so she knows she can't beat him. Stopping her from reporting back to Alpha, Cid tells her that she cannot tell Alpha because he's in the middle of a secret mission. While Delta playfully asks to accompany him, Cid declines as the mission is something only he can do and it could end in failure if she reports back to Alpha. But as Delta is conflicted since she's on a mission for Alpha, Cid reminds her that his authority overrides Alpha's so he gives her a special mission instead, promising a reward, within reason and his abilities, exciting Delta. Breaking off the window, Cid brings Delta to the opening and directs her to the Lawless City to hunt [Juggernaut](Juggernaut.md "Juggernaut") at his Black Tower. Delta reviews her assignment, Cid reminds her that the reward will be under his conditions, and she gleefully races off. Exasperated, Cid worries about the situation and thinks about Alpha, but is sure in himself Delta will be home once the weather is warm enough.

The next day, Gamma reports how their scouts found the battle scene of the train along with Delta's bell ornament from her tail, cracked and broken. Alpha is shocked as Gamma fears the worst, as both know Delta would never abandon a mission. Alpha orders the search continue, if at least to find her (presumed dead) body, cracking the window in quiet rage. As Gamma informs her of the continuation of counterfeit bills flooding the market, more than the assets needed to redeem the value for the bills, Alpha now believes John Smith planned for the credit collapse, wiping out the Major Corporate Alliance and Mitsugoshi distracted by their commerce war, and take what remained for himself. Gamma is stunned that such a man would be ambitious enough to have the market constantly generate profit for himself, while Alpha's rage reaches its peak and her mana begins to manifest in a blue flame.

In the MCA's office, [Gettan](Gettan.md "Gettan") meets with two agents of the Cult, relaying the organization's concerns of the credit collapse and the Cult losing substantial holdings. As one of the agents jests about Gettan's personal relation, he is decapitated in the blink of an eye by the still seated Gettan, leaving the other agent startled. When Gettan inquires if John Smith was the mastermind, the remaining agent affirms that their investigation led to John Smith who stopped them from ceasing his counterfeit operation. Gettan then orders Garter to institute inspection checkpoints at any exit from the royal capital. However, Garter attempts to clarify that, while they have clout with the city operations, the royals and knight orders will turn against them, prompting Gettan to kill the remaining agent to convince Garter to do as he is told. Gettan orders Garter to do whatever he must to find the source of the counterfeit bills as the scared Garter complies. Public sentiment starts to turn against Garter and the MCA over the checkpoints, with the minister of transportation and knight orders growing incensed by the overreach from a merchant alliance.

As Iris walks home from training, she encounters Alexia with a stack of books around the castle grounds. Surprised considering her sister is out from school, Alexia clarifies that the Academy is still under reconstruction and she thought it would be easier to find specialized books in the palace archives pertaining to various social studies. While Iris questions if her sister is reconsidering being a scholar, Alexia explains that she wishes to hone her mind to know better where to swing her blade. Since what has happened since the spring earlier this year, Alexia now knows that swinging her sword at random accomplishes nothing and will make her an outsider. Alexia concludes that, in order to wield her sword in a place that matters, she must earn the right to stand there by starting somewhere she doesn't necessarily have to wield a sword-- a hard earned lesson. As Alexia mentions she hardly has any time for anything else outside of training, Iris quickly and quietly walks off; much to her sister's confusion.

In Cid's dorm room, [Beta](Beta.md "Beta") is recounting how the counterfeit bills are affecting the capital's economy; with Shadow sneezing due to the cold air despite keeping a fire pot beside him. Beta elaborates more that the royal family will take action soon and Garter's imposed checkpoints actually worsened the economy, but stops to ask if Shadow was taking notes. He confirms as much, saying it will affect the future, but he mutters not understanding something after Beta continues how the inflation now compels a state-level response; prompting her to apologize for confusing her master and willing to restart the investigation. Shadow orders she continue while placing his hands over his fire pot to keep warm, and she sadly brings up no contact with Delta and is presumed dead; perplexing Shadow as to why she hasn't returned yet. Beta begins to bring up more information, but Shadow excuses himself under the pretext of "other matters," until she asks if he took notes. Per Shadow Garden regulations, all documents are to be encrypted or destroyed, but Shadow shows her the notes and she is amazed by the complexity of the unrecognized language. Shadow boasts he developed a coded method using five languages he "developed," gifting Beta a a page to decrypt to learn some of his wisdom.

Elsewhere, John Smith reads his notes from Beta's report as [Natsu](Natsu.md "Natsu") informs him that the train is approaching the MCA checkpoint, prompting him to put his notebook away. At the checkpoint, one of the MCA members asks if they can really enforce a checkpoint while his senior colleague reminds him of their orders to stop them or give them an "accident." While the junior member voices how the knights would stop them soon enough, the senior member shouts how they have no choice lest their black market lives end. Frustrated, the junior member summarizes Garter's role as nothing more than a simple merchant, while the senior member is more afraid of who Garter answers to. As the train nears, the checkpoint is effortlessly destroyed and the train unimpeded, prompting the senior member to hope they can go into hiding without being found by those monsters.

With John Smith atop the nose of the train, he sees a figure in shaded silhouette, and is met by Alpha who greets him before a sudden farewell. However, John Smith counters and pushes her into a defensive stance, with Alpha slowly realizing he is Shadow by his skill and technique. A devastated Alpha demands he explain himself, only for Shadow to claim he had forsaken his name for John Smith, confusing her even more as she demands to know what has happened to Delta. Darting his eyes behind his tinted mask to quietly improvise an excuse, John Smith tells the truth that he sent Delta to a far off place. Angered at an evasive answer, Alpha blazes with her magical energy as she retorts that his statement tells her nothing. Voicing how she can't understand what he does, Alpha still confesses that she wishes to be there for him, to help the man who saved her life, and asks if he doesn't need her anymore. John Smith evades the question by telling her that she'll soon see that this was the best choice, but Alpha swears she won't keep dragging him down and activates her new powers.

Although John Smith moves to restrain her, Alpha is able to replicate the Vampire mist form and eludes his magic threads. Alpha puts up a resistance, stating that she can still support him as she moves in for an attack. However, Cid catches her blade by the tip and explains that while enemy attacks cannot land, she can just as easily dodge, and the major weakness of solidifying in order to attack isn't enough return on the risk. Yet while her mist form is cool for flying, he points out that being mist reduces her mass, rendering her to intense blowback effects. Cid resumes his John Smith persona to use a Tiger Kung Fu stance, shattering the train car windows upon stomping his foot, and channeling the force of his footwork into an Iron Palm thrust. Alpha resolidifies, reaching out in vain to catch up to her mentor, only to land on the tracks as the train marches on and crying in the snow for him not to leave her.

At the abandoned mine, [Yukime](Yukime.md "Yukime") shows John Smith the hordes of gold collected from their counterfeiting operation, having drained the Major Corporate Alliance of all their reserves. Yukime also apprises John Smith that she has been concurrently gathering authentic bank notes, planning to cash them for the public to see how the MCA is insolvent, causing a credit crisis and destroying the Alliance for good, with the ripple effect reaching Mitsugoshi as well. And as the businesses that supported the Midgar Kingdom economy will systematically collapse, and when the government gets involved to quell the chaos, Yukime aims to destroy all the evidence leading to their operation and vanish without a trace. John Smith, sneakily citing Beta's report, concurs and notes how prices have increased, triggering inflation and forcing a response at the state level. Yukime is impressed by his foresight and he retorts he cannot take all the credit, much to her flattery.

Leaving their storehouse by train, Yukime brings up what she told him before[[3]](#cite_note-3) about her youth in her small village. Yukime narrates how when the Great Hero [Shiva](Shiva.md "Shiva") fell in battle, the various mighty clans warred for his crown, which had her Spirit Fox clan at their mercy. To survive, the Spirit Foxes forged an alliance with other likeminded clans, thus the Spirit Foxes made an alliance with the Great Wolves. Being the daughter of the only Three-Tailed Fox, Yukime was betrothed to Gettan, son of the Great Wolves patriarch. The two were joyous and the villagers were celebratory to their union, but war between two neighboring clans spilled over and destroyed their village, rendering the wisdom and strength of the lesser clans to nothing. However, Gettan had made a bargain with an outside force for more power using red pills, but Yukime's mother refused such a measure and the villagers followed suit in faith of her judgement.

Gettan angrily jeered her choice as his path could have stopped all the bloodshed, and confessed to killing her to protect Yukime from the war. However, Yukime rejected him and retaliated, leading to a wrathful Gettan to slice her back and leaving her barely alive. When he departed in pursuit of power, a barely cogent Yukime heard him succumb to injury by an undiscerned source. After losing her village, Gettan became Yukime's arch-nemesis as she lived as a prostitute in order to survive, learning and slowly acquiring power until she rose to become queen of the White Tower in the Lawless City. Yukime asks if John Smith realized her true motives now, not to build a fortune but to bring Gettan down and end him. However, in Cid's usual distracted mindset, he was wondering if circumstances were similar to someone else. Planning to conclude her story with Gettan, Yukime bids John Smith farewell and hopes he'll await her return trusting her to be successful.

Back in the Lawless City, [Delta](Delta.md "Delta") howls in the night over the raging inferno of where the Black Tower once stood.

## Characters

- [Alpha](Alpha.md "Alpha")
- [Gamma](Gamma.md "Gamma")
- [664](664.md "664")
- [665](665.md "665")
- Rose Oriana/No.666
- [Zeta](Zeta.md "Zeta")
- [Victoria](Victoria.md "Victoria") (Debut)
- [Delta](Delta.md "Delta")
- Cid Kagenou/John Smith/Shadow
- [Juggernaut](Juggernaut.md "Juggernaut") (Mentioned)
- [Gettan](Gettan.md "Gettan")
- Garter Kikuchi
- Iris Midgar
- Alexia Midgar
- [Beta](Beta.md "Beta")
- [Natsu](Natsu.md "Natsu")
- [Yukime](Yukime.md "Yukime")
- Klaus Midgar
- [Shiva](Shiva.md "Shiva") (Flashback)

## Promoional Videos

「陰の実力者になりたくて！ 2nd season」 第6話予告≪ノーマルVer.≫「ジョン・スミス」

『陰の実力者になりたくて！ 2nd season』 第6話予告≪スペシャルVer.≫「陰の実力者は大物っぽく知ったかぶりたい！」

## Trivia

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e026>
2. <https://shadow-garden.jp/story/#story6>
3. Episode 25

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • **Episode 6** • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
