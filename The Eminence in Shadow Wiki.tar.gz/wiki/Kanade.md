# Kanade

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kanade](https://the-eminence-in-shadow.fandom.com/wiki/Kanade)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Kanade?action=edit).

## Kanade

### Japanese

カナデ

### Romaji

Kanade

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

16

### Height

Unknown

### Hair Color

Black

### Eye Color

Black

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Midgar Academy Student

### Affiliation

Midgar Academy for Dark Knights

## Debut

### Light Novel

Volume 5 (Unnamed)
Volume 6

### Manga

Chapter 64

Kanade (カナデ, Kanade[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a student enrolled at the Midgar Academy for Dark Knights.

## Appearance

Kanade is a black-haired, black-eyed girl. Outsiders describe her appearance as ordinary, but emphasize that she maintains cute qualities.[[1]](#cite_note-V6C1-1)

She wears the Midgar Academy for Dark Knights uniform, she also wears black tights underneath her skirt and white loafers.[[2]](#cite_note-2)

## Personality

Kanade has average grades and appears to have a meek personality but is actually quite cheeky. She humbles herself before those above her and naturally looks down on those below. That is her way of life.

## Synopsis

She is from an impoverished noble family, as a result of this she did her best to avoid crossing paths with the higher ranked nobles. One such example was Eliza Despoht who was not only a high ranked noble but also her classmate.

During the ghost incident, when she and the other students were forced to wear mana collars that determined the amount of their mana as a numerical value. Kanade was forced to obey Eliza and was horrified by her cruel actions as she made her, and other lower ranking nobles fight each other to the death. As for those that tried to rebel against her, she had them restrained and stole their mana which led to their deaths. She also watched as Eliza forced some of her classmates out into the hallway as bait for the ghosts, eventually it was her turn to be bait.

Luckily for her, Alexia, Claire, and Cid (disguised as Suzuki) saved her from a ghost. Unfortunately, her mana was dropping quickly but luckily for her Cid transferred some of his mana to her which saved her. Kanade watched as Cid exposed Eliza for her crimes and how she murdered several of her classmates, she and the other nobles had kept their mouths shut out of fear. But when Cid pointed out that Kanade and her classmates were already aware of the collar’s function to transfer or steal mana, she immediately turned against Eliza and confirmed all of her evil deeds. This led her classmates to confess as well, as Eliza had been exposed and they no longer had a reason to keep quiet.

## Chronology

### The Midgar Academy Mist Terrorist Attack

### Bloody Midgar Serial Murder Terror

## Powers & Abilities

## Relationships

### Claire Kagenou

### Cid Kagenou

### Christina Hope

### Alexia Midgar

### Eliza Despoht

## Trivia

## References

1. Volume 6 Chapter 1: Enter "Jack The Rippler"!
2. Volume 6 Character Profile

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • Alexia Midgar • Christina Hope • [Isaac](Isaac.md "Isaac") • Suzuki Hope • **Kanade** | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |
