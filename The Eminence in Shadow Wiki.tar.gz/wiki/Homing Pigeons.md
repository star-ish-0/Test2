# Homing Pigeons

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Homing%20Pigeons](https://the-eminence-in-shadow.fandom.com/wiki/Homing%20Pigeons)

Homing Pigeons is an ancient technology that is still actively used for communication in the world and is used by Shadow Garden.

## Overview

A common method of communication, a message is tied to a pigeon's leg which is then sent to the intended recipient.

## Functions

- Messaging: To carry communiqués and letters containing messages to people anywhere within the bird's flight range.
- Inconspicuous: As pigeons are still a commonality, they normally go unnoticed by the general public, which is useful for bypassing security checkpoints in enemy territories.

## Curiosities

## References
