# 665/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/665/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/665/Chronology)

[Main](665.md "665")

[Relationships](665-Relationships.md "665/Relationships")

Image Gallery

## Chronology

### Red Moon Incident

665 participated in the assault on the red tower in the Lawless City alongside 664 and 666, under the command of [Beta](Beta.md "Beta"). Their mission was to gather information in researching a sample of the Vampires Progenitor blood with the [Possession](Possession.md "Possession") and help their lord Shadow if necessary.

When the vampire queen [Elisabeth](Elisabeth.md "Elisabeth") was resurrected, they immediately attended to help their lord's sister, Claire Kagenou, who was seriously injured and drained of blood by Elisabeth. 664, 665, 666 and [Beta](Beta.md "Beta") faced the vampire queen while protecting Claire, all as they were buying time until Shadow came to their aid.

Then the girls cooperated with the two rulers of the other towers, [Yukime](Yukime.md "Yukime") of the White Tower and [Juggernaut](Juggernaut.md "Juggernaut") of the Black Tower. Along with the guidance of [Mary](Mary.md "Mary"), the ancient vampire slayer, they all stood up to Elizabeth, but they were inevitably all seriously injured by her. However, Claire stood up and confronted Elizabeth while holding her back, until 665 and her team saw Shadow appear to face the vampire queen. At the end, Shadow attacks her with his opposite ultimate attack, "I Am Recovery Atomic", which heals everyone equally and destroys the red tower.

### Great Trading Company Conflict

During the secret internal dispute between the Mitsugoshi Company and the Major Corporate Alliance, when another faction was detected involved in the plot to cause the collapse of banknote credits, 665 was dispatched by [Alpha](Alpha.md "Alpha") and [Gamma](Gamma.md "Gamma") alongside 664 and 666. They were to find out the places of distribution and transportation of gold through secret caravans, but when they were about to find out the ringleaders, they were confronted by a man named John Smith, who immediately ordered them to turn back. The team refused and pressed an attack, but they were defeated and immobilized by John Smith by his magical steel threads. They then withdrew due to John's warning, returning to Headquarters to inform Alpha and Gamma about their failure and an incident report.

### Oriana's "Black Rose" Civil War Wedding Incident

During the civil war of the Oriana Kingdom, 665 along with 664 and 666, were called by [559](Victoria.md "Victoria") to the Oriana Kingdom for an infiltration mission to see and investigate some ancient ruins at the Saisho Stronghold that the Cult of Diablos was investigating. While they remained hidden, Queen Reina Oriana, Rose's mother, was among the cult group, to which 559 found irrelevant and prepared to strike down the queen with the 40 First Children of Diabolos. But 666 intervened to save her mother, resulting in 559 branding her a traitor and prepared to kill the cultists without caring about 666's situation. With 664 and 665 forced to attend to 559, the two were injured as 559 remained and continued fighting until only one cult lieutenant, [Kouadoi](Kouadoi.md "Kouadoi"), remained. While unconscious, their lord, Shadow, came to their rescue.

Shortly after recovering, 665 went out to explore the situation in the capital and came to report to Shadow, as he was in discussion with 559 and 664, about what 666 did. When she reports that Rose was announced to be going to marry Duke Perv Asshat, Shadow was enraged to the point of exclaiming that Rose Oriana would not be forgiven. 665 was, and still is, unaware that Shadow was unaware that Rose and 666 are the same person.

When the "Black Rose" was activated and hundreds of Magical Beasts appeared, 665 and [664](664.md "664") set out to help 666/Rose in their battle against the invading beasts. Despite everything, they wanted Rose to be their friend, not only as their partner.

### The Academy Disappearances
