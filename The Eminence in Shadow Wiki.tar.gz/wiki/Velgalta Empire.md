# Velgalta Empire

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Velgalta%20Empire](https://the-eminence-in-shadow.fandom.com/wiki/Velgalta%20Empire)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Velgalta Empire

### Japanese

ベガルタ帝国（ていこく）

### Romaji

Begaruta Teikoku

### Alias

Country of Swords

## Location Information

### Leader

Unknown

### Status

Active

### Affiliates

Cult of Diablos

### Type

Country

### Government

Unknown

### Location

Unknown

### Inhabitants

Humans
Elf

## Debut

### Web Novel

Chapter 47 (Mentioned)

### Light Novel

Volume 2 (Mentioned)

### Manga

Chapter 15 (Mentioned)

### Anime

Episode 15 (Mentioned)

Velgalta Empire (ベガルタ帝国（ていこく）, Begaruta Teikoku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), also known as the "Country of Swords", is home to Velgalta's Seven Blades and the Velgalta imperial family.[CITATION NEEDED]

## Geography

The Velgalta Empire's territory borders with The City-State Alliance.

## History

Velgalta is a very powerful nation that prizes swordplay.[CITATION NEEDED]

## Military

Velgalta Empire is a militaristic empire to which is referred to as the "Country of Swords" and is noted to be one of the most powerful military powers in the world, with their overall military abilities.[CITATION NEEDED]

Within the Velgalta military, there is a special group known as the Velgalta's Seven Blades, which consist of their seven strongest warriors.

## Known Locations

- Madlid

## Foreign Relations

### Midgar Kingdom

### Oriana Kingdom

### Altena Empire

## Inhabitants

- Annerose Nichtsehen
- [Rude](Rude.md "Rude")
- [Zinaida](Lambda.md "Lambda")
- [Karen von Herzog](Chi.md "Chi")
- Sergey Gorman (Deceased)
- Stan Bach (Deceased)
- [Olga](Omega.md "Omega")

## Trivia

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • **Velgalta Empire** • [Wakoku](Wakoku.md "Wakoku") | |
