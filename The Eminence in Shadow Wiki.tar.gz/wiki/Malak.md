# Malak

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Malak](https://the-eminence-in-shadow.fandom.com/wiki/Malak)

## Malak

### Japanese

マラック

### Romaji

Marakku

### Aliases

Malak the Malevolent

## Characteristics

### Race

Dragon / Artificial Dragon

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Yellow

### Birthday

Unknown

## Personal Information

### Status

Near extinct [One specimen remaining]

## Debut

### Game

Seven Shadows Chronicles - Chapter 18: Investigation! In search of oil.

[[Category:Near extinct [One specimen remaining]]]

## Description

Malak (マラック, Marakku?), also known as Malak the Malevolent, is a Dragon that resides near the City of Madlid in the Velgalta Empire.

Originally thought to be a real dragon, it was later revealed to be a man-made dragon.

## Appearance

Malak’s appearance resembles that of a big theropod dinosaur, covered in spikes and horns. His giant body covered in green scales have a small pair of wing. They were made to resemble true dragons.

## Personality

### Malaks's Personality

Malak lack any personality, this is due to being made to be controlled. However,when not controlled, it seems to roam around, claiming a territory and hunting. Their intelligence is none to zero.

## History

### False Dragon

The Malaks are thought to have been created inside a sanctuary with the intention of mimicking allmighty dragons to use them for combat. These Malaks lacked any kind of intelligence, allowing them to be controlled and commanded by people.

Eventually, the sanctuary was abandoned, and while most of the Malaks were trapped inside, one was able to escape and make himself home near the city of Madlid, getting himself the nickname of Malak the Malevolent.

Later on, Sergey would use the army of Malaks to fight the Shadow Garden, who would end up defeating Sergey and finding the sanctuary.

To their surprise, they were able to find out that the artificial Malaks were able to be defeated because the scientists who cloned them created a backup plan in case they turned against them. This backup plan was exhausting them and hitting them with a Malak egg,which would “deactivate” them permanently.

## Powers & Abilities

### Sharp Weaponry

The claws and teeth of Malak are very sharp, being able to cut through almost anything without much effort.

### Artificial Immortality

The malaks have an inferior version of immortality, being able to regenerate any attack,but having a very programmed way of being able to successfully die.

### Dragonic Assimilation

Consuming the flesh of Malak makes changes in the body and magic. If eaten too much, the person will obtain great strength in exchange of losing their mind. However, if consumed a moderate ammount over a period of time,it can boost someone's physical strength,as well as boosting their mana and reflexes.

This ability is also shared by Ragnarok, hinting that this is a common effect of consuming the flesh of higher class magical beings.

## Trivia

- Due to "Malak the Malevolent " residing around Madlid, the village that was visited by Gamma and Eta was abandoned. This is because the roads used by traders were inside of Malak's territory

## References

## Site Navigation
