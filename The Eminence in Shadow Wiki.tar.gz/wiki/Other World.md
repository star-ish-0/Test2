# Other World

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Other%20World](https://the-eminence-in-shadow.fandom.com/wiki/Other%20World)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Other World

### Japanese

世界

### Romaji

Sekai

## Location Information

### Leader

Unknown

### Status

Existing

### Affiliates

Unknown

### Type

Planet

### Government

Unknown

### Location

outer space, in translation with the sun

### Inhabitants

[Human](Human.md "Human")
Slimes
[Elf](Elf.md "Elf")
Dark Elf
[Therianthrope](Therianthrope.md "Therianthrope")
[Dragon](Dragon.md "Dragon")
[Ghouls](Ghouls.md "Ghouls")
[Vampire](Vampire.md "Vampire")

## Debut

### Web Novel

Volume 1

### Light Novel

Volume 1

### Manga

Volume 1

### Anime

Episode 2

Simply called World by its inhabitants, the Other World is the tentative name of the place where Cid Kagenou was reincarnated and in which the setting of The Eminence in Shadow takes place. It was revealed to be one of limitless [Realms](Realms.md "Realms").

## History

### Ancient Past

Millions of years ago there was no magic in this World, and countless living beings lived in diverse environments. Over time, the decomposition of organic matter resulted in oil fields around the World, such as the petroleum deposits found in Madlid. Among the living beings there was one that practically dominated the sky and lands of The World, [the dragons](Dragon.md "Dragon"), to the point that this world could once be called the Dragon World. With great vitality, the dragons kept their dominion over the World for countless eons.

Approximately 10 million years ago, there was a first contact between this World and another [Realms](Realms.md "Realms"), inhabited by infernal beings that possessed Magic. A catastrophic battle on a global scale took over everywhere, many magic beasts massacred several dragons and other creatures that lived there in this World. Unable to adapt to magic, the dragons went into decline and near extinction. Some survivors gained physical and magical mutations thanks to contact with magic, as their attributes were improved with gaining more powers and other abilities. With the dominant race now severally reduced in number and isolated in specific points on the planet, their global dominance was eventually succeeded by the three co-dominant races that came to be: [mankind](Human.md "Human"), [the elfs](Elf.md "Elf") and various [beast tribes](Therianthrope.md "Therianthrope"). These sapient races prospered where the dragons once thrived.

### Forgotten Past

Several millennia later, the remains of some magical beasts were discovered by the first investigators, scientists, and archaeologists, who embarked on a quest to uncover the origins and nature of these ancient beings; yet found no definitive information about them. In their pursuit of knowledge, some of these researchers resorted to unethical experiments, incorporating the magical genes of these creatures into kidnapped children. Over time, these initial researchers joined other members of the scientific community engaged in such practices, and they would eventually come together as the founders of the Cult of Diablos. From their relentless search for immortality, the Cult of Diablos made several experiments using direct material from magical beasts on children of different races and observed the side effects. One girl named [Aurora](Aurora.md "Aurora") showed great compatibility and contributed in their development of immortality via the Beads of Diablos.

Aurora ended up becoming a super-being with absurd magical quantities, even too much for the cult's scientists to contain. No longer willing to take the years of abuse and torture, Aurora rampaged and destroyed the installation where she was kept before proceeding to destroy everything else in sight. On that day, the whole World would know this singular event as the start of the "great catastrophe" that almost eradicated all civilization. While The World at that time had advanced science and technology, at most a century ahead of [Earth](Earth.md "Earth") before their ruin, their world would collapse and be rendered into a post-apocalyptic wasteland. As civilizations reverted to stone age recovery in terms of advancement, the original super technologies of old would remain frozen for centuries to come. The Demon Diablos continued destroying everything she found for many years, and the Cult were the only ones who managed to preserve part of their technology.

Isolated from the devastated world, the Cult implanted Diablos Cells into other children, attempting to replicate the method that made Diablos in order for them to attain equal power. The vast majority of those children exhibited a rejection reaction of the cells and ended up dying from what would become known as [Possession](Possession.md "Possession"). Only a few girls managed to display compatibility with the cells, such as [Olivier](Olivier.md "Olivier"), [Lily](Lily.md "Lily") and [Freya](Freya.md "Freya").

The Cult carried out more experiments to make them stronger and powerful, creating weapons and equipment for them so that when they were adults and ready, they would go fight the "Demon King" Diablos. After they were victorious and Diablos was contained in various parts, these events are where the myth of the Three Heroes, who heroically defeated the Demon Diablos, originate from. While Aurora was physically slain, her spirit was then sealed in isolation within the [Sanctuary](Sanctuary.md "Sanctuary") of [Lindwurm](Lindwurm.md "Lindwurm") for over 1,000 years.

### Recent Past

Having defeated Diablos and brought peace to the world, each of the Three Heroes then took on their respective roles to rebuild civilization from the ravages of chaos caused by the demon. As both [Olivier](Olivier.md "Olivier") became a paladin and [Lily](Lily.md "Lily") became an Archbishop, the two traveled the world together spreading the Divine Teachings' religion to help people in the devastated areas and bring order to the people. Whereas during that time, [Freya](Freya.md "Freya") helped the people living in Midgar, laying the foundation for what would become the Midgar Kingdom.[[1]](#cite_note-1)

After the devastation and civilization would expand again, the Three Heroes would have many children where the modern royal bloodlines would descend from. While the female descendants of the Heroes would suffer magical overload and be cared for under medical attention, the Cult would infiltrate key points of society, such as the Church of the Divine Teachings. By steadily working to rewrite history to discriminate the heroes' descendants as having [Possession](Possession.md "Possession"), they would claim these girls for experimentation to continue their immortality and covert rule over the new nations of the World. Such as developing the Velgalta Empire into a warrior empire dissuaded from anything but honing the sword, while conditioning Oriana Kingdom into a nation of arts to detest war and relying on neighbors for protection. The Cult molded the world after they destroyed it into how they desired it and used their weaponized revision of history to take the heroes' descendants to ensure their retained immortality.

### Present

Ironically, their goals and mission were exposed by a fantasy-indulging young boy as the impetus for Shadow Garden; despite him actually improvising the story to recruit the original members. From healing possessed girls and educating them, his story would be repeated to subsequent recruits as the insurgent organization found evidence to prove their evils. Eventually, Shadow Garden grew from a motley resistance into an existential threat for the Cult and their leaders, the Knights of Rounds. Due to their millennia of overstayed longevity, the Knights of Rounds have splintered into factions that squabble over resources while Shadow Garden steadfastly dismantles their assets and claims their treasures. Meanwhile, King Klaus Midgar covertly opposes the Cult in his own way and uses the chaos of Shadow Garden as the necessary justification to investigate where he needed.

Promised reinstatement into the Rounds, Lutheran Barnett incriminated Shadow Garden as terrorists, but they welcomed the infamy unimpeded in their aims, and Shadow killed Barnett. To combat both organizations, Iris Midgar founded the Crimson Order.[[2]](#cite_note-2) Shadow Garden raided the Goddess' Trial to infiltrate the [Sanctuary](Sanctuary.md "Sanctuary"), recovering substantial information of the Cult and Possession, eliminating the Nelson sect while flooding [Lindwurm](Lindwurm.md "Lindwurm") and freeing Aurora's spirit to possess Claire Kagenou, Shadow's sister. With the Bushin Festival, under command of 9th Seat [Mordred](Mordred.md "Mordred"), Chancellor Perv Asshat had brainwashed King Raphael Geerk Oriana to kill King Klaus Midgar to instigate war. However, Princess Rose Oriana mercy killed her father and Shadow revealed himself an undercover contestant, hindering the Cult's plans even further for the Midgar Kingdom and plunging Oriana Kingdom into civil war.[[3]](#cite_note-3) To reallocate their secret funds, the Cult's next plan to collapse Mitsugoshi Company backfired when a third party foe named "John Smith" printed counterfeit bills alongside [Yukime](Yukime.md "Yukime") of the Lawless City's White Tower. With their own scheme turned against them, the fiasco devastated the Cult's financial holdings in the Midgar capital and dissolving their merchant asset, the Major Corporate Alliance.[[4]](#cite_note-4)

To end the Oriana Civil War, King Raphael's last will exposed the Cult and forced Mordred into the spotlight to eliminate all witnesses. However, Shadow Garden intervened with Shadow eliminating Mordred, stopping the Black Rose and ultimately saving the Oriana Kingdom from eventual destruction.[[5]](#cite_note-5) But as Rose became queen, The Cult-control church branded Oriana as a heretic state, which hindered the recovering kingdom with trade sanctions, while Shadow Garden continued helping as best as possible covertly. When [Fenrir](Fenrir.md "Fenrir") and his faction moved to resupply Beads of Diablos, the abductions of Academy students led Shadow to battle and slay Fenrir. However, Claire Kagenou was forcefully bound to Diablos' right arm by [Zeta](Zeta.md "Zeta") of Shadow Garden, in the fanatic's plot to immortalize Shadow.[[6]](#cite_note-6)

## Geographical Features

### Nations

- Midgar Kingdom: A nation renowned for their Knight Order, military, education, and commerce. A major superpower on The World stage, and the center point of Shadow Garden's activities.
- Oriana Kingdom: A nation dedicated to the arts, so much so that their alliance with Midgar ensures their safety. After the Black Rose incident, they are rebuilding and branded a heretic state.
- Velgalta Empire: A warring empire who prize the sword, often trying to continue expanding their borders and power. A historic opposite and antagonist to Oriana.
- Altena Empire: An island state and a key member of The City-State Alliance. A vassal state of Velgalta.
- Holy State of Orum: A theocratic member of The City-State Alliance, the papal headquarters of the Divine Teachings' religion.
- [Wakoku](Wakoku.md "Wakoku"): A remote land far to the east.
- [Atlantis](Atlantis.md "Atlantis"): Once one of the ancient nations that existed in the other world, a Black Rose phenomenon opened and caused the entire nation to completely disappear.

### Cities

- [Lindwurm](Lindwurm.md "Lindwurm"): A holy city known as the "Sacred Land" that had been the place where the Goddess' Trial is being held, and Shadow destroyed the [Sanctuary](Sanctuary.md "Sanctuary") which flooded the city. It has undergone reconstruction from international aid and Mitsugoshi.
- [Alexandria](Alexandria.md "Alexandria"): The lost ancient capital of Midgar, now the secret headquarters of Shadow Garden, guarded by the Mist Dragon. A fully functional population center, Shadow Garden modernized the defenses with Shadow's Shadow Wisdom and [Eta](Eta.md "Eta")'s technology.
- Lawless City: A non-affiliated domain with unrestrained crime and where the monarchs live in luxury towers. However, both the Red Tower and Black Tower were destroyed by Shadow's involvement, defaulting rule to [Yukime](Yukime.md "Yukime") and the White Tower.
- [Laugus](Laugus.md "Laugus"): The academic city and mecca of learning, the current home to Sherry Barnett.
- Grazheim: A trading-focused city and the headquarters for the City-State Alliance, focused on opposing Velgalta's imperial expansion.

## Swordsmanship Practices

In this world, swordsmanship tends to be studies and refined within the nation of origin, with restricted knowledge divulged to outsiders. Due to this isolationist view of study, the techniques barely evolve and develop inconsistently. What's more, the swordsmanship of the world either relies on superficial presentations or an overwhelming charge of magic into one's attacks. Practical and refined swordplay is rare and sparse, or, in the case of Alexia Midgar, still in development. This is noted when she witnessed Shadow battle Zenon Griffey and noted how his swordplay was based on the basics of the art but refined to a degree where it was beautiful and unfettered by needless motions.

## Magic

According to Cid's research into magic, he was amazed that magic existed in the world where he reincarnated since he had finally obtained what he had yearned for. But over time, he realized that most races did not know how to properly use magic that inhabits the world, concluding they were utilizing it poorly, as magic users relied squarely on the destructive power, tremendous speed, and healing abilities. Until the current date, only the members of the Shadow Garden organization under their leader, Shadow, knew how to use magic correctly and efficiently while also increasing its capabilities. A few others outside the organization, like Claire Kagenou and partly Alexia Midgar, have been shown to use magic similarly to them in more developed and efficient methods compared to the general public, while still not to the degree of Shadow Garden proper

## Culture and Military Discipline

Other world's study, management and breeding in agriculture, and in everything related to commercial production at a civil level, among its branches, are identical to those of [The Land](Earth.md "Earth"), with the difference that they are one century behind in advancements of how to harvest and cultivate their yield, among other things, even better.

While his discipline, study, management, development, and training in the military, Cid Kagenou thought of the sword arts as deficient, especially in the management of fencing. This is due to the over-reliance of magic, as they only learn the normal handling of the sword to later reinforce and potentiate their sword attacks. According to Cid, regarding speed, strength, and resistance in both the swords themselves and their wielders is something unfortunate for him. This disappoints Cid often, since he rarely finds good opponents to face, in terms of swordsmanship or with melee combat.

This also applies to athletic attitudes, since most of those who exercise in the world where he reincarnated do not usually practice the basic parts of athletic training and warm-up. According to Cid in the anime and Light Novels, the usual fighters neglect to consider the basics, like normal stretching and flexing muscles in the arms and legs.

## Technology

The other world’s technological level when Cid began as Shadow is approximate to an early industrial era, with several key non-magical technologies like steam power, printing, and colorless photography already in use. Given the story progression, the existence of special artifacts and depictions from the anime, it is possible that technology used to be far more advanced, similar to 21st Century Earth or slightly more advanced by several decades to a century. [Aurora](Aurora.md "Aurora") once stated that the town where she lived, and presumably rest of the world, wasn't enjoying this much prosperity during the era she lived.[[7]](#cite_note-7)

As for the combat technologies and tools, swords and other medieval-era weapons, are a commonality among the populace with knights and ranking citizenry having bladed weaponry ready. Magic devices seem to be the most commonly used instruments of war, such as staffs or gem adorned items. Gunpowder based weapons are also available, albeit seen as "commoners' toys" due to their lack of firepower and uselessness against the Dark Knights. In addition, both magical and non-magical ranged attacks and tools to commit these attacks seems to be surprisingly unpopular. Melee combat is the preferred methodology of combat, at least in the Midgar Kingdom. The most notable user of ranged attacks so far is [Aurora](Aurora.md "Aurora") when using her blood-bending attacks, which evolved into a [Vampire](Vampire.md "Vampire") signature ability.

Additionally, the Cult of Diablos have access to advanced technologies and infrastructure that they hid from the rest of the world. Notably technologies and techniques linked to biological engineering and several laboratory complexes, including an ancient, advanced research facility like the [Sanctuary](Sanctuary.md "Sanctuary"). The Cult has ruled the world unopposed for so long that its hordes its technologies for themselves to maintain world dominion, which is entirely possible since they possess highly advanced weapons and devices at their disposal that no other present organization, nation, or person has access to.

It's not until Shadow Garden created their corporate front in Mitsugoshi Company, using the knowledge of "Shadow Wisdom" to them brought by Cid Kagenou from [Earth](Earth.md "Earth"), that new innovation began to spread around the world. From Mitsugoshi introducing advancements in trade, resource networking, food, and so-on, the Cult's public assets established in those markets began to lose efficacy and profit. Mitsugoshi brought an improvement and elevation with regards to the standard of living not simply for the nobility and royalties of the world, but also the commoners as everything they produced targets practically every notable demographic. For this reason, the technology level of this world is expected to advance further with the approaching [Automotive industry](https://en.wikipedia.org/wiki/Automotive_industry "wp:Automotive industry") and [Petroleum](https://en.wikipedia.org/wiki/Petroleum "wp:Petroleum"), as pioneered by Mitsugoshi.

## Religions

The Divine Teachings is a monotheistic religion that believes in the Goddess Beatrix (ベアートリクス, Beātorikusu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), which is the most widespread religion of this world. The Goddess Beatrix is said to have bestowed a divine duty onto the Three Heroes to slay [Diablos](Aurora.md "Aurora"), severing the left arm in [Lindwurm](Lindwurm.md "Lindwurm").

## Languages

The world seems to follow a nigh-global shared script and language, with small exceptions being the Therianthrope clans having their own style, such as Yukime's Spirt Fox clan having a script resembling Eastern Kana. Even in the past, as seen in the memories of the [Sanctuary](Sanctuary.md "Sanctuary"), the native script was seen in the computer data and keycards in the pre-apocalyptic times. In the Light Novel and Manga, the language of the other world is seen as unfamiliar to Earth's languages, similar to glyphs or symbols. From the anime, the world language appears to be similar to the ancient [Runic](https://en.wikipedia.org/wiki/Runes "wp:Runes") and [Phoenician](https://en.wikipedia.org/wiki/Phoenician_alphabet "wp:Phoenician alphabet") languages of Earth, with numbers sometimes sharing value to letters-- with a few letters resembling simple [Kana](https://en.wikipedia.org/wiki/Kana "wp:Kana"). To punctuate capitalization, a line mark is inscribed above a letter, such as names or bounties on wanted posters.

In the anime, the runic language follows similarly to English lettering but can be written in the Romaji or English style. An example would be Shadow's wanted poster, reading in native script as the English "WANTED: DEAD OR ALIVE" above his artistically rendered profile. Another is the book "Romio and Julieta" converted from the romaji "Ruoomio to Jyurietta" and the author's name "[Natsume Kafka](Beta.md "Beta")" spelled via the romaji "Natsume Kafuka." For packaging on a Mitsugoshi product, the translation is one-to-one "Mitsugoshi." Another example is the sign for the "Bushin Festival" in episode 15, where the runes converted to romaji spell "Bushin Maturi."

## Inhabitants

Basically all characters, except those that are living on planet [Earth](Earth.md "Earth"), reside on the other world where Cid Kagenou and Shadow Garden exist. Such as the majority [Human](Human.md "Human") nations and peoples, the long-lived [Elven](Elf.md "Elf") peoples who live among themselves or intermingle with humans, as well as the [Therianthrope](Therianthrope.md "Therianthrope") tribes and clans warring for dominance in the vast wildernesses between cities and countries. Among even these common populaces are the hidden [dragons](Dragon.md "Dragon"), such as [Nidhogg](Nidhogg.md "Nidhogg"), [Malak](Malak.md "Malak") or the Mist Dragon.

## Visitors

- Akane Nishino: Recruited into Shadow Garden.[[8]](#cite_note-V6C5-8)

## Map

## Trivia

- The Other World's time flow is observed to be approximately five times faster than [Earth](Earth.md "Earth")'s. This is concluded as it had been fifteen years after Cid Kagenou was reincarnated before venturing through the Black Rose, while it was three years after his death in Japan.[[9]](#cite_note-V4C4-9)
  - This was further verified when Cid and [Beta](Beta.md "Beta") were gone for a few weeks, the whole of his academy winter break, but were on Earth for nearly one week.[[10]](#cite_note-V4E-10)
- Both in the Novels and Manga, they treat the description, history, and development of the other world in the medieval style. Conversely, the Anime and Game depict the world from the industrial era of the 18th century to the modernization of the 19th and 20th century.
  - In both the Novels and the Manga, firearms have not been shown so far, such as normal pistols and semi-rifles, due to magic making up for the most part in combat. By combining them too, with swords, while in the anime and game, they do show firearms, from the first events of the story.
- It was revealed by the anime and the game that in ancient times, Dinosaurs also existed in the time of the [Dragons](Dragon.md "Dragon"). However, they went extinct with the arrival of magic to the other world, almost like the dragons.[[11]](#cite_note-:0-11) A case that is not related or mentioned in the light novel, manga, and web novel.
- To this day, the name of the four countries devastated in the past by [Elisabeth](Elisabeth.md "Elisabeth")'s rampage under the Red Moon remains unknown.[[12]](#cite_note-V3C3-12)
- In Episode 32, it is revealed that the other world has a solar system with several planets just like [Earth](Earth.md "Earth") in its home dimension.[[11]](#cite_note-:0-11)
  - It can be seen that within this solar system, there are some planets with a similar description to the planets from Earth.
  - One such planet has a green and brown color description, possibly indicating another planet with life within this solar system of the other World.

## References

1. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 3: Secret of Sacra, Chapter 3-2: The Hero Revealed!
2. Light Novel/Volume 1
3. Light Novel/Volume 2
4. Light Novel/Volume 3
5. Light Novel/Volume 4
6. Light Novel/Volume 5
7. Master of Garden
8. Volume 6 Chapter 5: Welcome to Shadow Garden!
9. Volume 4 Chapter 4: Lurking in the Darkness in Fantastical Japan!
10. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
11. Episode 32
12. Volume 3 Chapter 3: Pursuing the Blood Queen!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • **Other World** • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
