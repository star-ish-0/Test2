# Manga/Volume 11

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2011](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2011)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_11?action=edit).

## Manga Volume 11

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041136843

### ISBN EN

ISBN 978-1975393878

### Release Date

May 26, 2023 JP
December 10, 2024 EN

## Volume Information

### Pages

144

### Chapters

4

Publication Order

| Previous | Next |
| --- | --- |
| Volume 10 | Volume 12 |

This is the eleventh volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

Upon arriving at the Oriana Kingdom, Cid is broadsided by the news that Princess Rose is set to wed Duke Perv—an unexpected development that would throw a major wrench in his future shadowbroker plans! Seems like it’d be a good idea to crash the party and get the deets, but are there even bigger schemes at work behind this unholy matrimony?[[1]](#cite_note-1)

ローズ先輩は、王になりたかったんじゃなかったのか!?

異世界に転生し、あらゆる物事に陰から介入し実力を示す「陰の実力者」設定をエンジョイしているシド。ローズ王女結婚の噂を聞き、結婚阻止計画を実行するべくオリアナ王国の城に潜入する。シドはローズに、王妃ではなく光の覇王になってほしかったのだ。
なぜなら光あるところに「陰の実力者」はより濃く存在できるから――！

いつも通りの勘違いも、いつも通りに炸裂する異世界異聞奇譚、信念の第11巻!! [[2]](#cite_note-2)

## Summary

## Chapters

- Episode 42
- Episode 43
- Episode 44
- Episode 45

## Characters

:   In order of appearance:

## References

1. [The Eminence in Shadow, Vol. 11 (manga). YenPress](https://yenpress.com/titles/9781975393878-the-eminence-in-shadow-vol-11-manga/)
2. [The Eminence in Shadow (11). Kadokawa](https://www.kadokawa.co.jp/product/322301000485/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • **Volume 11** • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
