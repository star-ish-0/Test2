# Diablos Cells

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Diablos%20Cells](https://the-eminence-in-shadow.fandom.com/wiki/Diablos%20Cells)

The Diablos Cells (ディアボロス細胞（さいぼう）, Diaborosu Saibō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are part of Diablos’ body that the Cult of Diablos extract from [Diablos](Aurora.md "Aurora") and are usually harvest from the demon’s remains.

## Overview

Since long ago, the Cult of Diablos would gather orphans with no relatives to plant Diablos Cells inside the children's bodies in order for them to attain power equal to Diablos. The vast majority of those children exhibited a rejection reaction toward the cells and ended up dying. Only a few girls managed to display compatibility with the cells such as [Olivier](Olivier.md "Olivier"), [Lily](Lily.md "Lily"), ([Freya](Freya.md "Freya"), WN Only).

Because Diablos Cells hold astonishing vitality, the Cult managed to create Beads of Diablos, which grant enormous power as well as immortality. One side effect of Beads of Diablos is a certain part of the body keep aging no matter what.
