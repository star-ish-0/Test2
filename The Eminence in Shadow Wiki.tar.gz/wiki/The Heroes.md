# The Heroes

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/The%20Heroes](https://the-eminence-in-shadow.fandom.com/wiki/The%20Heroes)

The Heroes are a group of people consisting of the three races—[Human](Human.md "Human"), [Therianthrope](Therianthrope.md "Therianthrope"), and [Elf](Elf.md "Elf") who fought against the Demon [Diablos](Aurora.md "Aurora") a millennium ago. These heroines fought alongside the 3 heroines, being the ancestors of the central characters of the story.

## History

## Chronology

### Requiem for Scattered Shadows

## Equipment and Artifacts

## Known Members

- [Olivier](Olivier.md "Olivier"), the Elf Hero and [Alpha](Alpha.md "Alpha")'s ancestor
- [Lily](Lily.md "Lily"), the Therianthrope Hero and [Zeta](Zeta.md "Zeta")'s ancestor
- [Freya](Freya.md "Freya") (WN), the Human Hero and Alexia's and Iris Midgar ancestor.
- [Duet](Duet.md "Duet"), [Beta](Beta.md "Beta")'s ancestor
- [Pente](Pente.md "Pente"), [Epsilon](Epsilon.md "Epsilon")'s ancestor
- [Rouge](Rouge.md "Rouge"), Rose's ancestor.
- [Nonna](Nonna.md "Nonna"), Ancestor of Claire Kagenou and Cid Kagenou.
- [Sarasa](Sarasa.md "Sarasa"), [Gamma](Gamma.md "Gamma")'s ancestor.
- [Tessera](Tessera.md "Tessera"), [Delta](Delta.md "Delta")'s ancestor.
- [Shichy](Shichy.md "Shichy"), [Eta](Eta.md "Eta")´s ancestor.

## Gallery

## Trivia

- The characters of the other heroes (support) are exclusive to the Game, since in the [Manga](Manga.md "Manga"), Light Novel and Web Novel, they have not debuted yet.
- Within the story, in the city of [Lindwurm](Lindwurm.md "Lindwurm"), Nelson mentions that many heroes fought alongside Olivier against the [Demon Diablos](Aurora.md "Aurora"), which possibly referred in part to the heroes (ancestors).[[1]](#cite_note-1)

## References

1. Volume 2 Chapter 1: Fun Times at the Goddess's Trial!

## Site Navigation
