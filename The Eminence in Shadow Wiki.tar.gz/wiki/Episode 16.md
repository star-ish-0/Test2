# Episode 16

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2016](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2016)

## Unseen Intentions

### Kana

見えざる真意

### Romaji

Miezaru Shin'i

## Special Title

### English

The Eminence in Shadow Wants to Sneeze After Cracking His Neck!

### Kana

陰の実力者は首を鳴らしてクシャミをしたい！

### Romaji

Kage no Jitsuryokusha wa Kubi wo Narashite Kushami wo Shitai!

## Episode Information

### Season

1

### Episode

16

### Air Date

January 18, 2023 JP
April 10, 2023 EN

### Adapted From

Volume 2 (LN)

## Staff

### Director

Yoshinobu Tokumoto

### Writer

Kunihiko Okada

### Storyboard

Yoshinobu Tokumoto

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Gamma ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| The Strongest Weakest Man | Moonlight That Pierces the Darkness |

Unseen Intentions (見えざる真意, Miezaru Shin'i[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the sixteenth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Princess Rose flees to the north of the Royal Capital. The Oriana Kingdom wants to handle it internally as a “purely domestic” matter.[[1]](#cite_note-1)

ローズが逃亡する中、仲間の誓いを立てたアレクシアとナツメが救出に動く。いっぽう、ジミナに変装してブシン祭に参加中のシドは、偶然を装いながら着実に試合を勝ち抜いていた。[[2]](#cite_note-2)

## Summary

As Alexia and "Natsume Kafka" ([Beta](Beta.md "Beta")) look at Rose's situation, they track her movements to the north of the Royal Capital. The Oriana Kingdom wants to handle the matter themselves as a domestic matter, asking Midgar Kingdom to not interfere, to which both Alexia and Beta agree someone is pulling strings. Since Perv Asshat is a son to an Oriana Kingdom's duke, Rose will be in serious trouble but not face a death penalty due to her royal status. Knowing her father will take a wait and see attitude, Alexia wants to find Rose in order to hear her side of the story, but Beta guesses that Rose may not have told them anything to avoid the possibility of trouble between the kingdoms. Although Beta clarifies she wants to consider the next move carefully, Alexia takes her comment to mean she is thoughtless, getting physical with Beta thinking she's playing innocent and calling her acting obvious.

While Alexia understands, she is still angry as they are sworn allies, and gets upset with Beta over the thought of abandoning Rose. Beta will try gathering some more information on Perv Asshat, while Alexia goes to ask her sister for advice; leaving with an observation at how nothing seems to phase "Natsume." After Alexia leaves, Beta orders one of her subordinate Numbers to feed more intel on Perv Asshat, which will keep Alexia occupied, taking more time to process and think, thus staying out of trouble. As Shadow Garden cannot afford the princess to run headfirst into trouble, they must distract her with what she wants. Asking an update on their surveillance of Rose Oriana, Beta is informed that Rose made it through the sewers and into the underground ruins, hiding amid the complex tunnel network. Beta orders continued monitoring no matter how small, reading Rose's physical actions in the report sounding like [possession](Possession.md "Possession").

During another match, Cid is in the audience reading the newspaper about Rose stabbing her fiancé, impressed by her actions. Next to him, Skel Etal feeds his gambling addiction after the current fight ends with a loss for him. Wondering what to do next, he decides to continue his role as the Eminence in Shadow to play the "shadow war amid a grand tournament. Heading to prepare for his next fight, Cid encounters the War Goddess [Beatrix](Beatrix.md "Beatrix"), who smells the scent of elf on Cid and wonders if he knows an elf. Cid confirms he has a few elven friends and Beatrix explains she is looking for the daughter of her late sister, wondering if Cid had seen someone that looks like her. Cid is immediately reminded of Alpha but denies it. So Beatrix tests Cid by drawing her sword to cut Cid's head, while he realizes that she intends to stop before doing reaching him and acts as a background character, playing he's shocked by what just happened. Seeing his reaction, Beatrix then apologizes, stating thought he was stronger, but it seems she is mistaken. Helping him up, Beatrix's grasp of his hand predicts he will be a strong warrior someday, bidding farewell as Cid acknowledges to himself that she is quite strong.

After the round where Imatry Nottaloos wins, Annerose is met by [Quinton](Quinton.md "Quinton") guessing she is observing Mundane Mann, just like yesterday. Asking her thoughts on his fight, that while the consensus is his opponent supposedly tripped and lost, Quinton is sure that Mundane did something but couldn't see. He is sure that Annerose can explain it, and she Annerose explains she couldn't see it all, but didn't expect to see someone faster than her eyes can follow, as she only saw his right hand move before the fight ended. Quinton surmises he was wrong, having thought that Mundane used some artifact, like the one in the sword in the VIP spectator section. While it seems Mundane didn't break the rules, Annerose can't disprove that, yet the two are sure his fight with Goldy Gilded should yield an answer. While Annerose states that Goldy has never lost, she was paired to fight him three times only for Goldy to simply not fight anyone who could possibly beat him and just forfeits. Despite his "the Unbeaten" nickname, he hates that and uses his preferred "the Ever-Victorious" moniker. As the match between Goldy and Mundane is about to begin, Quinton realizes that Annerose means that either Goldy couldn't see Mundane's true strength or Mundane is cheating.

As the match starts and Goldy rushes at Mundane, he swings his sword and misses as Mundane cracks his neck to dodge. Goldy then feels how Mundane draws his sword and cuts him, only to snap back to reality seeing Mundane slowly draw his blade and wait. Quinton is surprised he managed to dodge it, but he couldn't see what happened and Annerose explains that Mudane cracked his neck and avoided the attack. Quinton can't believe such a coincidence, but Annerose wonders if it was as she barely could even see it, which is something no normal human should be able to do. Angry for humiliating him, an irate Goldy tells Mundane that he doesn't like him, having had a one in a million chance to beat him but not using it. As Mundane moves to scratch his nose, Goldy gets serious by creating a golden dragon from his magical power and rushes at Mundane. However, Mundane sneezes, blowing away both the dragon and Goldy, defeating him and winning the match.

Annerose notes that Goldy is stronger than she expected and could have become an outstanding dark knight had he fought more often with stronger opponents. Quinton wonders what Mundane did and Annerose explains that, if she saw right, he sneezed and swung his sword the moment he did, hitting Goldy as he crashed into it. Quinton finds that unrealistic and leaves, finding her narration a waste of time, and stating that if Mundane keeps winning, he will eventually face him and show him what he is made of. Annerose wonders if she can move like Mundane, cracking her neck and sneezing, only to realize a moment later that she's in public and leaves feeling embarassed.

In a royal sitting room, Iris gives Perv Asshat the security plan for the Bushin Festival, but he doesn't feel it needs more security. As Iris observes he looks in good health and Perv agrees, he claims that the news story exaggerated his injuries, and guesses that Midgar worries that easily because of Alexia's earlier kidnapping. He heard that Iris personally went looking for her, so he intends to follow the same example and asks they let Oriana solve their family problems themselves. King Raphael Geerk Oriana then agrees in a monotone daze with Perv Asshat, as the Chancellor "assures" Iris that nothing will disrupt the Bushin Fastival, much to her irritation of how he delivers his promise with a smugness.

The next day, Mundane easily defeats Quinton, as the crowd analyze Mundane's mysterious entry and dark horse odds in the tournament, as some are in disbelief how the odds of the next match, Mundane vs Annerose, are 9-to-1. Meanwhile, Skel is writing a letter to Po in a desperate bid for funds for his gambling addiction; to which Po denied him later. Cid as Mundane can't recall Quinton's name and is curious why he was so worked up, wondering if they met before. Back in the tunnel, Annerose faces Mundane and tells him she misjudged his strength, but she warns him that she has seen all of his moves and he must not assume he can win the same ways against her.

As Mundane smiles and she demands to know what is so funny, Cid was excited she said the line and removes one of his armor plates, dropping it to make a hole in the ground due to its weight. Mundane explains that the weights are holding him back, but now playtime is over as Annerose stares in disbelief. But Annerose tells him to not assume he won already, showing him that she can crack her neck too. With an awkward pause, Mundane moves past her while wondering what she was trying to do. At night, Rose continues underground while battling Oriana Dark Knights to escape capture. Leaving a knight to need medical attention, Rose flees deeper into the labyrinth as the Oriana dark knights swear to bring her to justice.

## Characters

- Alexia Midgar
- [Beta](Beta.md "Beta")
- Rose Oriana
- Cid Kagenou
- Skel Etal
- [Beatrix](Beatrix.md "Beatrix")
- [Alpha](Alpha.md "Alpha") (Flashback Image)
- Annerose Nichtsehen
- [Quinton](Quinton.md "Quinton")
- Goldy Gilded
- Perv Asshat
- Iris Midgar
- Raphael Geerk Oriana
- Po Tato (Cameo)

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第16話予告≪スペシャルVer.≫「陰の実力者は首を鳴らしてクシャミをしたい！」

TVアニメ『陰の実力者になりたくて！』第16話予告≪ノーマルVer.≫「見えざる真意」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e016>
2. <https://shadow-garden.jp/1st/story/#story16>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • **Episode 16** • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
