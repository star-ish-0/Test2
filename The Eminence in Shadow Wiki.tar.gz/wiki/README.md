# The Eminence in Shadow Wiki (Fandom) - Backup em Markdown

- **Fonte:** https://the-eminence-in-shadow.fandom.com/
- **Data do download:** 2026-10-15
- **Metodo:** API MediaWiki (action=parse) via navegador, Cloudflare contornado com patchright
- **Conteudo:** 481 paginas do namespace principal (artigos, sem redirects)
- **Formato:** Markdown (GFM) - tabelas, listas e negrito preservados; imagens removidas a pedido
- **Navegacao:** links internos da wiki foram reescritos para arquivos .md locais -
  extrair o ZIP e abrir `00-INDEX.md` para navegar como um site offline

## Estrutura

- `00-INDEX.md` - indice alfabetico de todas as paginas
- `<Titulo da pagina>.md` - um arquivo por pagina, nome = titulo original sanitizado

## Notas

- Paginas de "Image Gallery" ficam curtas pois continham quase so imagens (removidas).
- Predefinicoes de infobox foram simplificadas pelo conversor HTML->Markdown.
