# Epsilon

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Epsilon](https://the-eminence-in-shadow.fandom.com/wiki/Epsilon)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Chronology](Epsilon-Chronology.md "Epsilon/Chronology")

[Relationships](Epsilon-Relationships.md "Epsilon/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | After coming this far, I refuse to be exposed heeeere! | ” |
| — Epsilon, Light Novel Volume 02 | | |

## Epsilon

- Light Novel
- Manga
- Anime
- Game

### Japanese

イプシロン

### Romaji

Ipushiron

### Aliases

Epsilon the Faithful [[1]](#cite_note-V2CP-1)
Epsilon the Precise [[2]](#cite_note-WNC45-2)
Shiron [[3]](#cite_note-V4C1-3)

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

17

### Height

Unknown

### Hair Color

Azure

### Eye Color

Light Blue

### Birthday

February 2

## Personal Information

### Status

Alive

### Relatives

[Pente](Pente.md "Pente") (Ancestor)

## Professional Information

### Occupation

- 5th Seat of the Seven Shadows
- Pianist & Composer

### Affiliation

Shadow Garden

## Debut

### Web Novel

Chapter 45

### Light Novel

Volume 2

### Manga

Chapter 15

### Anime

Episode 1

### Game

Chapter 1 - Episode 1

## Portrayal

### Japanese

[Hisako Kanemoto](https://en.wikipedia.org/wiki/Hisako_Kanemoto "wp:Hisako Kanemoto")

### English

Ellen Evans

### French

Marine André

### Italian

Giulia Bersani

### German

Andrea Wick

Epsilon (イプシロン, Ipushiron[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Έψιλον) is the sixth initial member of Shadow Garden and the fifth seat of the Seven Shadows.[[1]](#cite_note-V2CP-1) Her public identity is Shiron, an award-winning pianist and composer of numerous pieces that are music from [Earth](Earth.md "Earth") taught to her by Shadow, which she uses to infiltrate influential circles.[[4]](#cite_note-V2C6-4)

## Appearance

Epsilon is a young [Elf](Elf.md "Elf") with sharp facial features who displays a “striking” body. To hide her usual petite proportions, she uses a slime suit to appear far more curvaceous, greatly amplifying her buttocks and breasts. She has long azure hair tied into pigtails with light blue eyes (purple in illustrations).[[1]](#cite_note-V2CP-1)[[5]](#cite_note-V2C2-5)

As a member of the Shadow Garden, she uses a dark-colored slime bodysuit with a distinctive pattern adorned on the chest. There is a gold decoration on the arms and shoulders as well as purple gem accessories on the arms, shoulders, and abdomen. Included in the outfit is a long purple scarf with gold accessories and purple gems at the edges.[[6]](#cite_note-6) Sometimes, she wears a mask to hide her identity.[[1]](#cite_note-V2CP-1)

## Personality

|  |  |  |
| --- | --- | --- |
| “ | I won! I beat Mother Nature! | ” |
| — Epsilon, Light Novel Volume 02 | | |

Epsilon's self-aggrandizement, haughty voice, and a penchant for misunderstandings lead many to call her intense or arrogant.[[1]](#cite_note-V2CP-1) Whether in combat or social situations, she will seize an advantage—major or minor, physical or psychological. Although her unyielding and stubborn approach may appear callous, she deeply cares for her allies and friends. If not for Epsilon's immense pride overwhelming other traits, her docile and compassionate nature would define her personality.[[7]](#cite_note-V2C3-7)[[8]](#cite_note-V6CE-8) Even through her pride, she acknowledges and takes full responsibility for her mistakes.[[9]](#cite_note-V4C2-9)[[10]](#cite_note-V6C5-10)

Pride does require something as its subject and her old noble life supplied plenty of achievements to fuel her confidence. Becoming a member of Shadow Garden forced her to recontextualize the notion of excellence. She wanted to claim a pillar of superiority, but marital perfection and genius are abundant at Shadow Garden. Desperate to retain the pride and independence that defines her, Epsilon decided that beauty was the only feasible option. However, her driving force for personal beauty does not come from narcissism. Epsilon desires to return the selflessness and generosity shown to her by Cid. She strives to make herself a titillating companion open to a physical relationship, believing that bodily magic engineering is the only option to appeal to Cid and overcome feelings of inferiority.[[5]](#cite_note-V2C2-5)[[7]](#cite_note-V2C3-7)

## Powers & Abilities

Epsilon has been noted by Cid to be the best at controlling her magic amongst the Seven Shadows.[[1]](#cite_note-V2CP-1) However, by her own admission, she is overshadowed by her comrades in every other category.[[5]](#cite_note-V2C2-5) Overall, Epsilon specializes in espionage, using her public identity to infiltrate social circles and gather information.

### Swordsmanship

Epsilon's sword skills are noted to rival Beta's. She was also capable of fighting on par with [Mordred](Mordred.md "Mordred"), the 9th seat of the Knight Rounds, and even pressured him.[[11]](#cite_note-V4C3-11)

### Magic

Early in Epsilon's training, she fastidiously explored the possibilities and limitations of slime to improve her appearance to male sensibilities. Although her purpose was entirely cosmetic, her magical development began to have applications in combat.[[1]](#cite_note-V2CP-1)[[5]](#cite_note-V2C2-5) The precision over her bodysuit's hardness and viscosity extended to offensive magic control. Epsilon later learned to manifest magic outside of the body—a rare feat without a medium. This feat allows her to launch powerful bursts of pure magic for bludgeoning or cutting attacks.[[11]](#cite_note-V4C3-11)

Epsilon's magic control is sufficient to reverse the adverse effects of [Possession](Possession.md "Possession"). Her technique further allows the healing of non-lethal injuries to herself and other combatants. Unlike Cid, her healing still leaves scars.[GAME ONLY][[12]](#cite_note-SSC-P1E5-12)[[13]](#cite_note-13)

### Physical Capabilities

Like all other Shadow Garden members, Epsilon utilizes the slime suit as protection against attacks. What differentiates Epsilon's approach is that extra padding for proportion shaping became another source of added defense.[[14]](#cite_note-V4CP-14)[[11]](#cite_note-V4C3-11)

### Intelligence

### Weapons & Equipment

- Slime Bodysuit: Epsilon wears her slime bodysuit the entire time to give herself the perfect body shape, which makes her slime suit become a Supreme Defense after she experimented on it multiple times as she made her perfect figure by altering her rear to be shapely, tightening her stomach, increasing her height and creating large fake breasts to look like a mature woman. Thanks to her thick slime padding all over her body, she has an incredibly high physical defense.[CITATION NEEDED]
- Slime Weapons: In all adaptations except the game, Epsilon uses a slime sword. Her in game weapon of choice is a slime scythe stylized as a harp. The weapon can perform powerful projectile attacks through magically enhanced string vibrations.[CITATION NEEDED]

1/2

### Other Talents

Noble Etiquette: Epsilon possess excellent abilities in both literary and military arts as well as mannerism for aristocratic society—supported by her upbringing as a noble and later polished by [Lambda](Lambda.md "Lambda")'s intensive training.[[5]](#cite_note-V2C2-5)[CITATION NEEDED]

Professional Pianist: Under the tutelage of Cid, Epsilon learned to play the piano and perform many famous arrangements from Earth. She continued her musical career, choosing Shiron as a stage name and presenting the works of many musical geniuses as her own. The high societies of the Midgar and Oriana kingdoms have praised her as the world's greatest pianist and the most influential composer of their time.[[4]](#cite_note-V2C6-4)[[3]](#cite_note-V4C1-3)

## Trivia

- Despite Epsilon's efforts to keep her padding her chest confidential, several members of Shadow Garden already know her secret. These include Cid, [Chi](Chi.md "Chi"), [Omega](Omega.md "Omega"), and [Delta](Delta.md "Delta").[DELTA MANGA ONLY][[15]](#cite_note-MC21.5-15)
  - In the extra chapters of the manga, Epsilon is seen bribing [Delta](Delta.md "Delta") with food so that she does not further investigate the secret of why Epsilon always smells like Slime.
- In the Web Novel, Epsilon infiltrated the Oriana Kingdom; however, [Mordred](Mordred.md "Mordred") discovered her identity and was almost killed by his surprise attack. Some of Epsilon's web novel actions would be later given to [Victoria](Victoria.md "Victoria").[[16]](#cite_note-WNC176-16)[[14]](#cite_note-V4CP-14)

## References

1. Volume 2 Prologue: To Lindwurm, the Scared Land!
2. Web Novel Chapter 45
3. Volume 4 Chapter 1: Putting the Kibosh on Rose Oriana’s Wedding!
4. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
5. Volume 2 Chapter 2: Investigating the Sanctuary!
6. Volume 2 Color Inserts
7. Volume 2 Chapter 3: When Things Get Boring, It’s Time for Explosives!
8. Volume 6 Epilogue: That Nostalgic Smell
9. Volume 4 Chapter 2: Begin Operation: Obstruction!
10. Volume 6 Chapter 5: Welcome to the Shadow Garden!
11. Volume 4 Chapter 3: Crashing the Ceremony!
12. Seven Shadows Chronicles 1-1: Episode 5
13. Seven Shadows Chronicles 2-5: Episode 1
14. Volume 4 Prologue: It's Time for a War in the Oriana Kingdom!
15. [Manga](Manga.md "Manga") Chapter 21.5
16. Web Novel Chapter 176

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • **Epsilon** • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
