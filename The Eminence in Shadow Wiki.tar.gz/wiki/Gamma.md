# Gamma

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Gamma](https://the-eminence-in-shadow.fandom.com/wiki/Gamma)

[Chronology](Gamma-Chronology.md "Gamma/Chronology")

[Relationships](Gamma-Relationships.md "Gamma/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | She fell into an abyss of pain and fear and disappointment—and the one who rescued her was the boy who produced the blue-violet light. She would likely never forget that glow for her entire life. To Gamma, it represents the light of survival. | ” |
| — Gamma's Reflections, Light Novel Volume 02 | | |

## Gamma

- Light Novel
- Manga
- Anime
- Game

### Japanese

ガンマ

### Romaji

Ganma

### Aliases

Gamma the Brain
Gamma the Weak
Luna (Public Identity)

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

15 (Volume 1)
17 (Currently)

### Height

Unknown

### Hair Color

Dark Blue

### Eye Color

Dark Blue

### Birthday

May 20

## Personal Information

### Status

Alive

## Professional Information

### Occupation

- 3rd Seat of the Seven Shadows
- President of Mitsugoshi Ltd. (Public Cover)

### Affiliation

Shadow Garden
Mitsugoshi Company

## Debut

### Web Novel

Chapter 23

### Light Novel

Volume 1

### Manga

Chapter 7

### Anime

Episode 1

### Game

Chapter 1 - Episode 1

## Portrayal

### Japanese

[Suzuko Mimori](https://en.wikipedia.org/wiki/Suzuko_Mimori "wp:Suzuko Mimori")

### English

Elissa Cuellar

### French

Sabrina Marchese

### Italian

Elisa Giorgio

### German

Tatjana Pokorny

Gamma (ガンマ, Ganma[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Γάμμα) is the fourth initial member of Shadow Garden and the third seat of the Seven Shadows. She administers the organization's daily operations and occupies the head of the administrative section. Outside of Shadow Garden, the public knows her as Luna, the face and president of Mitsugoshi, Ltd—a highly successful corporation and financial institution. She has produced many revolutionary products for Mitsugoshi by reverse-engineering Cid's vague descriptions of earthly concepts.[[1]](#cite_note-V1C4-1)

## Appearance

Gamma's mature atmosphere, accompanied by a slender yet buxom figure, belies her young age. She routinely keeps her indigo hair down, preferring a simple hairstyle that extends to her lower thighs. Described as stunning, even by royalty, the half-elf’s facial features offer a proportional appearance, with only a beauty mark under the left corner of her lips breaking Gamma’s symmetrical countenance.[[2]](#cite_note-V1C3-2)

Her Shadow Garden uniform consists of a standard decorating around her chest and arms. She wears a sleeved keyhole jacket with a popped collar and gold edge extending behind her back—the décolletage is covered with opaque fabric. The lower half of the bodysuit is strap-up heeled boots that end just above the knees, with a thick golden collar end with a thinner golden line underneath looping around from the lower inner knee to the upper outer thigh, holding a violet gem. The heels of her boots are similar to her work heels, but enclose her feet with gold lines around the ankles and gold rims over her wrists.

Outside of Shadow Garden, Gamma normally wears dark backless dresses whenever she is going about in her public persona of Luna, the president of the Mitsugoshi Company. Her footwear changes depending on the occasion, but she predominantly dons black or white heels.[[3]](#cite_note-V2C4-3)

## Personality

|  |  |  |
| --- | --- | --- |
| “ | “Forgive me… It must be something you can’t tell anyone about.” Gamma hasn’t been able to deduce so much as a shred of her master’s motives or emotions. She’s an utter failure... Gamma kneels, hiding her face to conceal the tears of chagrin welling up in the corners. | ” |
| — Gamma, Light Novel Volume 2 | | |

Exuding calm and refinement, Gamma presents a dignified figure to prospective business partners and customers of Mitsugoshi, Ltd. She harbors no qualms about being a shrewd businesswoman who engages in aggressive corporate maneuvers. Gamma continues to leverage Mitsugoshi’s monopolistic position to exploit ignorant consumers and uninformed merchants through predatory lending, market manipulation, and proprietary trading. [[4]](#cite_note-V2C3-4)[[5]](#cite_note-V5C3-5)[[6]](#cite_note-V3C5-6) Her calculating demeanor is not constant; It softens towards her fellow Seven Shadows and reflects their mutual sororal relationship.[[7]](#cite_note-V3CE-7)[[8]](#cite_note-8)

Gamma’s guise of grace disappears in the heat of battle or around Cid. Poor balance breaks her otherwise elegant posture and gait—leading to bloody noses. She frequently hides embarrassment by continuation of conversation and a plethora of excuses, but red cheeks betray Gamma’s true feelings. Frustrated by her physical limitations, Gamma struggled to increase her combat prowess after first joining Shadow Garden. Her lack of physical capabilities prompted Cid to call her Gamma the Weak privately.[[1]](#cite_note-V1C4-1) The futility of her efforts soon became apparent and the mounting failures led to suicidal ideations. On the planned day of action, Shadow fortuitously presented a new avenue of purpose—Shadow Wisdom. Enthralled with Shadow’s insight, Gamma threw her established genius at recreating Shadow Wisdom and the management of Shadow Garden.[[3]](#cite_note-V2C4-3)[[9]](#cite_note-9)

Gamma continues to struggle with chronic feelings of inadequacy, despite the success of Shadow Garden and Mitsugoshi, Ltd. She perceives that a retainer should anticipate the needs and wishes of their master or be able to interpret them. Cid’s capricious actions frequently fall outside Gamma’s intellectual foresight, reinforcing Gamma’s doubt and despondency. Weak combat prowess notwithstanding, she aspires to one day fight on the front lines, side by side with Shadow.[[3]](#cite_note-V2C4-3)

## Powers & Abilities

The higher echelons of Shadow Garden identify Gamma as the weakest of the Seven Shadows, crippled by her physical ineptitude. Instead, her strength lies in financial quantitative analysis and combat directives. She serves as a rear commander, supervising tactile commands and maintaining the position of directing manager at Mitsugoshi, Ltd.[[1]](#cite_note-V1C4-1)

### Swordsmanship

Despite Gamma's established intelligence, she lacks basic combat intuition. Cid eventually gave up trying to teach Gamma the refinement of sword techniques.[[1]](#cite_note-V1C4-1) Gamma's movements are "amateurish" and "sloppy." Over time, she developed a combat style to counteract her lack of coordination. The basics of Gamma's approach to battle rely on fast thrusts or swings reinforced by large amounts of magic. She overwhelms her opponents through force rather than technique.  Per Cid's advice, she says the onomatopoeia fwoosh with every strike as he claimed that it would increase the perceived severity of the attack. Although foolish looking with poor posture and screaming fwoosh, the power behind her attacks possesses enough strength to take down a dozen Dark Knights.[[1]](#cite_note-V1C4-1)[[6]](#cite_note-V3C5-6)

### Magic

Whatever Gamma lacks in physical technique, she compensates for it with what enemies describe as a "crazy" amount of magic. Like other Dark Knights, Gamma displays the ability of reinforcing her body for augmented movement and she uses that crazy output to her advantage. Each magic strike leaves devastation in its wake.[[6]](#cite_note-V3C5-6)

### Physical Capabilities

Gamma's most significant fault is her coordination and lack of athletic ability. Even walking in heels can pose a challenge.[[1]](#cite_note-V1C4-1) Her frequent faceplants from stumbles lead to bloody noses and flinging objects.[[10]](#cite_note-10) This clumsiness hinders her combat capabilities, but sometimes offers advantageous circumstances, such as flying projectiles hitting enemies or unpredictable movements.[[6]](#cite_note-V3C5-6)

Despite her uncoordinated presentation, Gamma possesses uncharacteristic supernatural strength, speed, and resistance. Attacks that have proven fatal to others, even to unguarded necks, simply bounce off her body and cause pain akin to bumping one's head.[[6]](#cite_note-V3C5-6) She correspondingly demonstrates monstrous strength by lifting large objects with apparent ease.[GAME ONLY][CITATION NEEDED] The dichotomy between her phenomenal physique and ditzy approach to combat frightens the opponents she faces.[[6]](#cite_note-V3C5-6)

### Intelligence

Gamma's natural trait is her innate intelligence. Even Alpha acknowledges that Gamma's intellect surpasses all other Shadow Garden members—including herself.[GAME ONLY][[11]](#cite_note-11)

Outside combat, Gamma focuses on managing and coordinating Shadow Garden. She primarily focuses on the organization's financial gain and political connections. Interpreting Cid's descriptions of Earth goods and structures, she and Eta successfully recreated many future innovations, such as chocolate and steam engines.[[2]](#cite_note-V1C3-2)[[12]](#cite_note-12) Those many other products turned the company into a highly successful enterprise, aided only by vague business knowledge taught by Cid. Economic changes accompanied their inventory. After the Major Corporate Alliance bankruptcy, Mitsugoshi effectively monopolized fractional reserve banking for the Kingdom of Midgar.[[7]](#cite_note-V3CE-7)

Apart from Gamma's business and entrepreneurship genius, her intelligence proves sufficient to coordinate large-scale military operations or discern enemy combat styles while in active combat.[[1]](#cite_note-V1C4-1)[[2]](#cite_note-V1C3-2) However, with the significant growth of Mitsugoshi, Ltd, Gamma focuses more on the business than Shadow Garden activity.[[4]](#cite_note-V2C3-4)

### Weapons and Equipment:

- Slime Bodysuit: Similar to the other members of Shadow Garden, Gamma wears a suit made of slime, which allows 99% magical conductivity.
- Slime Weapons: Gamma's weapon in the game is Ōdachi.
  - Tessens: Within the game, Gamma uses slime-based Tessens (Japanese war fans) as a weapon and accessory.

## Trivia

- Unlike all other medians of TEIS, Gamma does not lead the assault on Midgar Academy for Dark Knights in the manga. Instead [Alpha](Alpha.md "Alpha"), [Beta](Beta.md "Beta"), and [Delta](Delta.md "Delta") participated in it.[[13]](#cite_note-13)
- Gamma displays a low alcohol tolerance. Merely eating a few alcohol-laced chocolates is enough to make her drunk.[KAGEJITSU ONLY][[14]](#cite_note-14)
- Gamma's civilian name was appropriated from the original founder and president of Luna, Ltd.[GAME ONLY][[15]](#cite_note-15)

## References

1. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
2. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
3. Volume 2 Chapter 4: This Situation Calls for a “Who Is That Guy?!”
4. Volume 2 Chapter 3: When Things Get Boring, It’s Time for Explosives!
5. Volume 5 Chapter 3: The Case Is Closed, So, It’s Time for a Flashback!
6. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
7. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
8. Volume 5 Chapter 4: Peace in Our Time!
9. Volume 6 Epilogue: That Nostalgic Smell
10. Anime Season 1 Episode 6: Pretenders
11. Master of Garden Part 2, Strum of Velgalta. Episode 4: Prophetess’ Doubts
12. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
13. Manga Chapter 12
14. KAGE-JITSU! Operation 3: The Seven Shades Want to Make Delicious Chocolate!
15. Seven Shadows Chronicles Part 1, Chapter 1, Episode 2: Garden Policy

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • **Gamma** • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
