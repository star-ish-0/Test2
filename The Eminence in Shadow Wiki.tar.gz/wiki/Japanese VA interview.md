# Japanese VA interview

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Japanese%20VA%20interview](https://the-eminence-in-shadow.fandom.com/wiki/Japanese%20VA%20interview)

Date: 2022-10-17

The Eminence in Shadow Interview #1 with Yamashita Seiichiro as Cid/Shadow and Seto Asami as Alpha | After seeing the OP video, Yamashita and Seto were also curious about a scene that they never thought they would see! [animate Times]

The TV anime of the popular light novel by Aizawa Daisuke (original story) and Tozai (illustration), The Eminence in Shadow TV anime will start airing from October 2022!

Kageno, a high school student, spends his days in intense and harsh training, dreaming of acting behing the scenes and manipulating the world in the shadows, instead of outwardly ruling it. In the middle of this dream, he lost his life in a traffic accident, but was reincarnated as Cid, the second child of a country aristocrat, Baron Kageno. Using the knowledge and abilities he has accumulated, he forms Shadow Garden to fight against the Cult of Diabolos. With his overwhelming power that transcends good and evil and his subordinates named Seven Shadows in hand, what is Cid's ambition under the name of Shadow?

The recently aired episode 1 depicted Kageno in the real world and episode 2 depicted his reincarnation and the formation of Shadow Garden, but at the end of episode 2, the Seven Shadows abruptly leaves Cid. Although the story is about reincarnation into another world, we cannot take our eyes off the main character, Cid, who has an overwhelming presence and even a sense of strangeness.

To commemorate the start of the broadcast of this remarkable work, a series of interviews with the cast and staff of this work has begun!　In the first installment, Yamashita Seiichiro, who plays Sid/Shadow, and Seto Asami, who plays Alpha, the first seat of Seven Shadows, look back on episodes 1 and 2, talk about the secret recording, introduce the ED song "Darling in the Night" sung by Seven Shadows, and discuss future highlights of the show.

--What are your thoughts on the second episode?

Yamashita: The first episode started with the episode when Cid was still living as Kageno, and those who watched it without knowing the original story may have thought it was a different anime and checked the channel, saying "I thought it was about a reincarnation into another world." (laugh) But in just one episode, I think it showed what kind of person Cid was and why he went to such lengths to seek strength.

And then there was Horie Yui who played Nishino Akane, a classmate who hated Kageno but was kidnapped and saved by Kageno. She was a secret until the broadcast, so she must have been a surprise. And the first kidnapper was played by Furukawa Makoto. It's really a luxurious line-up of cast, isn't it (laughs)?

Seto: I was also impressed by the piano performance of "Moonlight Sonata" several times during the first episode. It was like it was suggesting the very future of Shadow Garden, which lives in darkness, here.

--I wonder if he had practiced it as much as he practiced martial arts?

Yamashita: He could have been doing it. And then he saves Nishino, and I thought they had a bit of a heart-to-heart, but he died in a traffic accident without a moment's notice. As the song "Moonlight Sonata" was playing, the end credits was rolling in the middle of the episode, and it was amazing when he appeared in his reincarnated form as Shadow with the Seven Shadows.

--The beginning of the second episode began with a conversation between Cid, who had been reincarnated as Cid, as a boy, and Alpha, as a girl. The scene also includes the shocking line of "This elf is a pushover"!

Yamashita: He was reincarnated as a child of the Kageno family and was portrayed from birth, but I didn't expect to be playing a baby as well.

Seto: I watched him play the role, and it was very interesting (laughs).

--I thought he was just a boy with no other interests, but then he destroys a band of thieves. The encounter with Alpha, the formation of the Shadow Garden, and the farewell were all important elements of the story.

Seto: But just when I thought that the Seven Shadows were all gathered together, Alpha said to him, "It's time for us to leave you." From the third episode onward, we will see him in action as Shadow, and there will also be episodes where each of the Seven Shadows will be depicted, so please look forward to those episodes.

Yamashita: Two years after his sister Claire entered Midgar Academy in the capital, Cid also entered the same school. There, many strong characters will appear. The cast playing the guest characters is also very luxurious (costly). The story revolves around Alexia, the second princess of the kingdom, so please look forward to it. ...... I ended up saying it (laughs). Oh, in the one-on-one battle scene with the enemy who kidnapped Claire in episode 2, he was lecturing him on how to fight. He counted lesson 1 and 2, and I did my best to say it that way (laughs).

-- What was your impression of the character you play and what were you conscious of when you played him?

Yamashita: It is complicated to be Shadow and to be Cid, but I was conscious of the fact that he is a strange but honest child at heart, without thinking too much. He is not purely calculating, but is motivated only by curiosity, by the feeling that "it would be fun to do this" or "it would be cool to do that. But it is not ego-driven, it is pure, and I was conscious of that as the point where Cid never wavers. The director also directed me to "joke around more here" so I was able to do so quite freely.

In fact, since Cid was in a meta(abstract) position in the story, there were parts that did not need to follow the flow of the main story, so there was no rigid framework that said, "This is the kind of person Cid is." For each scene, we would say, "Let's just go with the momentum here" or we would focus on the theatrical interactions with the other actors, and we would often say, "It was fun, so it's OK".

Seto: When Alpha first met Cid as a child, she had a hard time understanding the situation and was very young, so her emotions would come out and she would sometimes get upset. But after she fell in love with Shadow, she remained calm and perfect, always knowing the next move ahead of time, no matter what happened. Since she was the first seat in the Seven Shadows supporting Shadow, she was also in a leadership position. So she guided the members of the Seven Seven and rarely panicked when something happened.

There wasn't much direction either, but the only thing that made a deep impression on me was when Shadow, who was supposed to see further ahead than Alpha, told her that she could do even more when she complimented him with "Shadow, you are amazing after all". She thought "I'm in a story that Shadow created, so I can just go with the flow and dance around more."

In the second episode, Shadow and Seven Shadows parted ways, and it wasn't detailed in the original story or in the anime until they came together again under Shadow. I like that it gives the viewers room to think and imagine. However, from episode 3 onward, he often lurks in the shadows (laughs).

--I felt that of the seven, Alpha was the most distant from Shadow.

Seto: Of course, she has respect for Shadow, but perhaps it is because of her pride in being the first seat that I could sense the closeness in her behavior and attitude.

Yamashita: I see. I do feel a special distance between them, and I think they are the only ones who treat each other like buddies among the seven of us.

Seto: Maybe it's because they met each other first?

Yamashita: Because she was the first child whom Shadow freed from demon possession, talked about the cult of Diabolos, and was the first member of Shadow Garden.

Seto: Maybe their senses match. They also share a similar atmosphere in that world.

Yamashita: Perhaps Alpha is the embodiment of Shadow's ideal.

--I think it is the norm to do separate recording, but did you two often record together?

Yamashita: Yes, we did. We also had dialogue with the person who played the main character in each episode. We had a large room and a small room in the studio, and I often recorded alone while listening to everyone else's voices.

Seto: I'm alone in the studio, listening to everyone else's voices while recording.

Yamashita: There is a good thing about being able to record without being covered by other people's voices, but I also felt lonely. But I was also thinking, "This loneliness is also like a person who has a lot of talent behind the scenes" (laughs). I was happy to be able to work with such wonderful people.

--Was there anything interesting that happened when you two were together?

Seto: I always have fun when we record together. Since Shadow is the core of the story, without Shadow, the recording would be done scene by scene. But with Shadow, I could see the whole story on set, and Yamashita's acting was interesting (laughs). I am lucky to be with him because I get to see him take on the director's suggestions and challenges.

Yamashita: It was worrying when I was doing it, and I thought, "Ah, they are listening!" (laughs).

--Do you talk with the cast members during breaks or after recording?

Yamashita: We often chatted in the lobby. Seto-chan talked a lot with the other Seven Shadows members. (For example, she talked to Minase (Inori) who played Beta.)

Seto: I think I was often together with Inori. I was happy to be able to record with everyone in Seven Shadows because I could feel the atmosphere.

--What did you think of the anime?

Yamashita: As the title "The Eminence in Shadow" suggests, the color palette is dark, and the action is flashy. The Seven Shadows have different specialties, so I felt that the picture was created by taking advantage of each of their characteristics. I think Delta is probably the most flashy in terms of action, but I also felt the difference between each of them and the attention to detail in their different movements.

Seto: I couldn't see the backgrounds and props during recording. And when I saw the video, I thought that they were very beautiful to see in person....... Shadow is quite particular about them (laughs). The first episode was set in the real world where he was still Kageno, but when he was reincarnated, the background made it immediately clear that the landscape had changed to a medieval European setting. I was also drawn in by the music, which was not included in the recording. Also, Shadow has a lot of monologues, but there were also some effects that made the dialogue stand out, such as when the sound was cut off. The combination of the pictures, music, and acting made it more colorful and made me realize once again how fun animation is.

--The ED song is "Darling in the Night" sung by the members of Seven Shadows, and we heard Alpha's solo version for the first time in episode 2.

Seto: First of all, I was surprised when I heard that we were going to sing the song together. But we recorded a full song for each member. Since Seven Shadows lives in the shadows, I wondered if it would be a cool, and quiet song. But it turned out to be bright and girlish.

Yamashita: It's a cute idol-like song.

Seto: The melody is in a high key, and the chorus builds up to the chorus. I thought it would be difficult for Alpha to sing it because of her character, but the lyrics expressed her gratitude and respect for Shadow's help, so I thought I could express what Alpha was thinking in her heart in a girlish and cute way, which she normally can't show in public. But I guess some people were surprised at the gap between the song and the main story (laughs). The video is like a puzzle, and little by little, you start to see the characters, and I enjoy that kind of direction.

--Please tell us about the highlights of the next three episodes and beyond.

Seto: They've said goodbye (laughs).

Yamashita: So, Cid, what is he going to do? Cid will be entering Midgar Academy. The world settings will expand further and more interesting characters will appear. His penchant for being the "power behind the scenes" is on full display. On the other hand, the school is under the threat of a terrible evil, and we can see a glimpse of something terrible about to happen in this world.

There are many comedic elements, but there are also serious elements, and I think it is no exaggeration to say that the real "Eminence in Shadow" is finally about to begin. The encounter with Alexia, the second princess of the Midgar Kingdom, is a major event for Cid and it is also Alexia's story, so I hope you will pay attention to it.

Seto: Starting from episode 3, big events are happening one after another, so I don't think you can take your eyes off of them. In episode 3, it is interesting to see Cid's feelings and vindictiveness toward mob characters overflowing from his monologue (laugh). The friends chosen by Cid are also interesting.......

Yamashita: Hyoro (Skel) and Jaga (Po) are the best!

Seto: It will be interesting to see how the number of characters surrounding Cid will gradually increase, and how the drama of human relationships and fates will unfold.

Yamashita: Another highlight is the overwhelming strength and coolness of Shadow and Seven Shadows in their battle scenes.

--By the way, from the third episode, it looks like a school story. Is the fact that Seven Shadows and her friends are wearing school uniforms in the OP video a foreshadowing for this?

Seto: I was curious about that too! But they are the uniforms of the real world where Kageno was, right?

Yamashita: Yes, that's right!

Seto: After they were in their uniforms, they were dressed like superwomen.

Yamashita: And they all beam at each other.

Seto: Is there a meaning to that too?

Yamashita: I wanted to ask the director sometime too. Even if there was no meaning to it, it's still cute though (laughs).

--A message to everyone please.

Seto: I am sure that some of you who have read this article to the end have enjoyed the original story and manga of "The Eminence in Shadow" and are big fans who have been waiting for the anime adaptation. The other day, when the anime started airing, I think the first episode, including the elaborate introduction, has not only met but exceeded everyone's expectations. After watching the first episode, you may think it is a scary work. But there are many comedic scenes from the second episode, and I hope you will enjoy it and realize that it is a world made possible by his hard work and strength.

There will be more characters and a series of developments and impactful events in the future, so I hope you will watch and enjoy the show until the end.

Yamashita：I had a firsthand experience of the large number of "Eminence" fans and their high expectations even before the program went on air, and when the PV was shown on YouTube before the broadcast, it was filled with comments from people not only in Japan but from all over the world. I was happy to see that the fun elements of the show, such as the chuunibyou moves, the "behind-the-scenes" moves, and the "comedy" elements, could be shared with the rest of the world. The fact that the original work has such appeal also gave me confidence in my performance, saying, "I'm sure you will enjoy it!"

In the first episode, I was able to make everyone who was looking forward to the show say, "Oh, that's what I thought!". The special moves and dialogue of Shadow are faithfully and well-paced when compared to the original work and manga. And I am sure that new viewers will also enjoy the crazy characters and the story. I hope you can also feel the love and commitment of the production staff and our cast members to "Eminence". The recording itself was finished long ago, so I hope you will enjoy watching it on-air every week, and be surprised to see how many ad-libs were used in the production.

Source:

https://www.animatetimes.com/news/details.php?id=1665728939

The Eminence in Shadow Interview with Minase Inori as Beta

Date: 2023-01-24

TV Animation "The Eminence in Shadow" Interview with Minase Inori, who plays Beta｜What was the most memorable scene in which you crossed paths with Alexia, Rose, Epsilon and many other characters? [Part 5 of series]

Based on the popular light novel by Aizawa Daisuke, the TV anime "The Eminence in Shadow". The story has entered the second half of the season and will be more interesting.

Animate Times will be featuring a series of interviews with the cast and staff of the anime "The Eminence in Shadow".

This time we have Minase Inori, who plays Beta, a silver-haired, blue-eyed elf with a cute crying face, the second seat of the "Seven Shadows" in Shadow Garden.

How does she play the role of a novelist, "Natsume Kafka"? She also talked about her memories of the recording sessions.

--Did you take part in the audition of Beta?

Minase Inori (Minase): I only took part in Beta's audition. At that time, I could sense from the dialogue that Beta is a character who is fascinated by the main character, Cid Kageno, Shadow. I also got the impression that in "Seven Shadows", she is not only powerful, but is also intelligent.

However when I opened the lid (on the work itself), it was quite unexpected that it was a huge gag. The more the main character tried to be cool, the more it became a joke, and I thought it was beautiful when the chuunibyou was twisted to this extent (laugh).

From the script alone, it was difficult to tell whether the story was serious or a gag. And I often found out during post-recording that it was a gag.

--Shadow's character setting have always included the "Seven Shadows". It's how they set him up as the "funny man"(boke).

Minase: But there is no one to correct (Tsukkomi) him for his antics (laughs). In a work where the "behind-the-scenes" part would stand out more, the figure of Beta who is intoxicated by Cid's monologue, the very determined lines he is saying, was like watching a comedy.

--Did you find this aspect of Beta interesting as well?

Minase: When I auditioned for the role, there wasn't much excerpted about Beta, so I thought she would be a cool character whose character wouldn't fall apart. In fact, there were a lot of places where I could have gone wrong. So, when I was playing the role, I felt like my expectation was being betrayed in a good way.

I also realized that when the "Seven Shadows" get together, they talk to each other like this! I got to know the power balance of the girls during the post-recording, so my impression of them changed a lot from when I auditioned.

--In reference to the title of the work "The Eminence in Shadow", do you have any little-known aspects or special skills?"

Minase: People seem to have the impression that I am not athletic, but in fact, I have attended swimming and gymnastics classes, as well as karate, so I am surprisingly not bad at sports. It's not that I've been hiding in the shadows, but it may not be well known that I do actually exercise!

--So you were seen as not being athletic.

Minase: Why is that? My body is definitely stiff, so maybe it was because of the unnaturalness of my poses and so on.

But in fact, I was having lessons and I can even double jump properly, and I was active in dodgeball. Those athletic abilities from my illustrious school days have somehow been overshadowed in this industry....... (laughs).

--What kind of girl was Beta when you actually play her?

Minase: In my mind, Beta was a calculative woman who could dashingly take advantage of the situation without showing any blunders or screw-ups.

She also has a surprisingly pure side, with a strong sense of gratitude to Alpha-sama (CV Seto Asami) and a sense of belonging to Shadow Garden. She also felt that Shadow Garden was her place in the world! "The Eminence in Shadow Master of Garden" delves deeper in this aspect.

Beta was not confident in her childhood, but she became the person she is today because she pursued her interests. I felt the humanity and sympathized with the fact that her confidence was built up from the effort she put in.

In the mini-anime "Kagejitsu," Beta also plays the role of a comedian, and I thought that her ability to tease someone was one of her charms.

--I guess knowing a character's past can be a good foundation for your acting.

Minase: Yes, it is. Serious aspects such as conflicts, which are not depicted that much in the main anime, are depicted in the app game. Since I was recording the game in parallel with the anime, I was able to play the role while feeling that each of the "Seven Shadows" had a past, even though it is obvious.

Beta writes stories based on the fairy tales that Shadow-sama taught her, which is also depicted in the anime, but the game goes deeper into how she came to love stories and writing so much.

--She was writing the novels based on the stories she heard. Cid was disappointed with her for doing so (episode 10).

Minase: It's very noble of Cid to go that far (laughs). But since it's a different world, there's no chance of being found out.

--How did you manage to express a mellow tone when you are intoxicated and a stronger tone when you are fighting with someone?

Minase: She is very passionate about Shadow-sama, to the point where you would say, "Isn't that a bit too much?"

She speaks fast when she is writing up a novel and I was directed to make her "breath heavily" and "in a nerdy way". Normally, she is a cool and intelligent woman, so I wanted her to be a "regrettable" person for those parts. All of the characters have their weirdness, but Beta's weirdness usually comes out when she is involved with Shadow-sama, so I try to portray the breaking of her character.

When faced with Alexia (CV Hanazawa Kana), it's more like a catfight behind the scenes between the women. She's very tactful, and I felt a little stabbing pain when I played her, because she was trying to make fun of Alexia, who is very emotional, from a high place (laughs).

-Beta was in contact with Alexia as Natsume, the novelist, and I thought the recording was a lot of fun.

Minase: Alexia quite enjoyed stomping Beta's feet (episode 11). It was scary though (laughs).

I think Kana-san is a pro at this kind of confrontation, so when Alexia, who usually has a dignified demeanor, would say in her usual voice, "Oh my, is something the matter?", I tried to match her voice.

--From episode 14, in addition to Natsume and Alexia, Rose (CV. Shiraishi Haruka) also joins in the action.

Minase: With the three of us, there is an atmosphere of mutual checks and balances, a kind of gut-wrenching competition. You'd think the girls would get together and cackle, but their personalities clash and they don't get along so well! I think they are incompatible!

--Alexia was in a lover's relationship with Cid, albeit disguised, and we know she hates him a lot, but Rose will not follow the same path, right?

Minase: That's right. I was able to record with Haruka-chan, who play Rose, around the time when the three of them were working together. And at that time I thought Rose was really cute and a classic heroine. The rest are liars while she is the only honest one. I was thinking during recording that, "She is cute and graceful, and I think she will be popular".

Because Haruka's performance is so direct, Rose's devotion, common sense, and normality makes her very attractive. Her kindness, ability to make others fall in love with her, makes her a very cute heroine!

For Natsume, I think she was happy to have Rose as a fan. I hope that they will get to know each other better in the future, since they share the same feeling of being excited about what they like.

--Speaking of dialogue, I was also impressed by your interaction with Epsilon (CV Kanemoto Hisako), who sees Beta, with her natural breasts, as a rival.

Minase: Indeed (laughs). However, Beta doesn't seem to think of Epsilon as a rival. I personally think that they are just bickering. I don't think it would be like Beta to compete with her. But Beta always has the upper hand, even though there may be times when she is annoyed (by Epsilon).

I like the way the two of them interact, with Epsilon getting into an ending where she just can't win. In "Kagejitsu!" I love Epsilon's "regrettable cuteness," which, coupled with Hisako-san's acting, makes me love her even more. I want her to suffer even more "regrettable cuteness" (laughs).

--Epsilon's chest sways unnaturally every time she appears in the show, doesn't it?

Minase: But sadly, it's all slime (laughs).

-- And Cid knows it too. Did you record with Kanemoto-san?

Minase: We were able to talk with each other several times. Hi-chan is usually a soothing and calm older sister, so it was refreshing to see her turn on the switch and get into a clash like that.

--I think that the characters in this work are all very appealing and have a great impact on the audience.

Minase: Of all the characters that have an impact, I was a bit surprised by "Doem Ketsuhat" (laughs). I hestitated and wondered if I could call him "Doem Ketsuhat"?

--The fact that Hayami Show is a veteran. The casting is really luxurious.

Minase: That's right. The fact that veterans and senior members of the cast are playing the roles is also a gag. Koyama Rikiya, who played the role of Orba, only had a brief moment in the show, but he played the role with great passion (in the second episode).

--Matsuoka Yoshitsugu, who played Hyoro Gali, also gave an enthusiastic performance.

Minase: They put all their energy into the recording, and their voices echo through the lobby every time. It seems like they are having a lot of fun. I can't help but feel that they are determined to "leave their mark" (laughs).

The recording of gag scenes is difficult. Gamma's cute make-believe scene is also noteworthy.

--If you had to pick an interesting scene in the first half, what would it be?

Minase: Alexia has a strong heart....... In episode 11, when she was in the hot spring, Yamashita-san performed the advent of the "Excalibur" and asked, "Am I doing this right?". The sound director told him, "That's how it's done" (laughs).

I could only watch from the back, but I realized how hard it is to make a gag scene. It is not just saying, "This is a gag!", but a natural way to make the audience laugh.

--I think it's good that the characters are serious.

Minase: That's right. Instead of smugly saying, "Please laugh!", they drop a joke in a perfectly normal manner, which makes us laugh.

When we were recording, there were no sound effects, so it must have been difficult to record a gag scene in a space where there was only dialogue and the sound of the turning of pages.

--The gag in the hot spring scene is the sound of Alexia clapping with a towel? When I watched the anime, I often don't notice the funny parts, and then I go back to the scene and thought, "Maybe I should have laughed?"

Minase: There are too many gags scattered throughout that I don't think anyone is able to pickup all of them. That's what I think while watching the back of Yamashita (laughs).

Yamashita-san is amazing at all of them, and his acting is so different that I wonder which one he is really good at. He can go from a chuunibyou, a obedient young man, to a slacker at will, just like Cid. However, he has a lot of lines, so he is always nervous during post-recording. It seems that if I say, "Don't worry," it pressures him even more, so I have to be careful (laughs).

--Did you say something before that made him nervous?

Minase: Not at all! Seto-chan called him "Yamapi," so I just imitated her and called him that (laughs).

--Back to the conversation about gag, what was the funniest scene in "Seven Shadows"?

Minase: I didn't get to work with Mimori Suzuko, who plays Gamma, very often. But when I saw the character PV "Beta/Gamma version" and the main story, I thought the way Mimori played Gamma when Gamma failed was "comical and cute!" .

In "Seven Shadows" she is the older sister who hides her clumsy side, but when she makes a mistake, it makes her seem all the more "regrettable". It is funny because she tries too hard. I thought it was admirable that she decided to follow the path of perfection.

--Finally, please introduce some of the highlights of what we can expect to see in the future.

Minase: Beta will be temporarily working hand in hand with Alexia and Rose for her own purposes. And while they don't like each other in some ways, they seem to be set on using each other.

We will find out what Beta is thinking and why she is with them later in the story, and Beta's intellectual side will also come out. Although there are many gag scenes, I hope you will enjoy the dark side of Beta as she has fun in her own way.

Source:

https://www.animatetimes.com/news/details.php?id=1674111285

The Eminence in Shadow Interview with Shiraishi Haruka as Rose

Date: 2023-02-07

TV Animation "The Eminence in Shadow" Interview with Shiraishi Haruka as Rose｜The highlight of the second half is "Who should she reach out to and how will she find her own path" [Part 07 of series]

Based on the popular light novel by Aizawa Daisuke, the TV anime "The Eminence in Shadow". The story starts to become more exciting with only two episodes left.

Animate Times has been conducting a series of interviews with the cast and staff of the anime "The Eminence in Shadow".

This time we have Shiraishi Haruka, who plays Rose Oriana, princess of the Oriana Kingdom and student council president of the Midgar Academy, who follows the path of the sword.

We asked her to talk about Rose, who mistakenly believes that Cid is thinking of her and feels a sense of destiny, and who showed us not only her serious side but also her cute side.

--Please tell us your impression of the work.

Shiraishi Haruka (Shiraishi): I really love the main character, Cid-kun (CV. Yamashita Seiichiro). I think he is new in terms of his existence in that he is manipulating various events in order to become a powerful figure in the shadows. That is exciting to watch, and I think Cid-kun's cold-heartedness and the gap with his monologue is also an attractive part of this work. I enjoyed reading those aspects in the original work as well as in the anime.

--For those who have never thought about "wanting to be Eminence in Shadow", was it like, what are you doing (laughs)?

Shiraishi: I guess it's the same thing as when a child is young and thinks, "I want to be a hero". I think it's cool that they hold on to that feeling even as adults, and in a way, it's like a strong will, but what they do is so surreal that it's really interesting.

I like the way "The Eminence in Shadow" make you focus on that side of things. I'm the type of person who wants to be a behind-the-scenes powerhouse (laughs).

--You wanted to manipulate behind the scenes?

Shiraishi: I really admire it. Maybe that's why I am a voice actor. I believe people who originally aspire to be voice actors have that kind of thing. Nowadays voice actors are often allowed to do that on "stage", but I think recording that is my main job, or rather, I have to bring that to fruition in post-recordings.

--For example, do you feel happy when people say that the character you played is "cute!".?

Shiraishi: Of course I am happy!　There are many times when people watch the anime without realizing it was me, and then they say, "I only realized it was you in the credits". Rose is the same way, and that makes me very happy. I think it makes me very happy as an actor to be able to blend into the role that well.

--In reference to the title of the work "The Eminence in Shadow", do you have any little-known aspects or special skills?"

Shiraishi: I am a direct person who voice everything I think. Is that something you do behind the scenes?

I'm tempted to say something funny, but it's not that kind of thing. I don't like that one strand of hair that sticks out when I trim my bangs, so I pull it out, and the makeup artist gets angry with me. When I do this, I feel a sense of relief.

-- It's not something you will say "Everyone, please try it! (laughs), but how did you come to do that?

Shiraishi: I tried it out of curiosity when I was little and it was an interesting feeling, and I haven't gotten over that habit even now. Please try it (laughs).

--Now, about Rose, the character you are playing, was there an audition?

Shiraishi: I auditioned for various characters, but the one I was selected was Rose. It was about that time that I read the original story, but I didn't think I would have such a chance to appear as her in the anime, so I was very happy to be selected.

--What kind of character is Rose?

Shiraishi: Rose is a princess of the Oriana Kingdom, so she has the elegance that comes from having been raised as a princess. Oriana is a country of arts, but Rose herself is strong-willed enough to leave the country because she wants to improve her swordsmanship. So I played the role while thinking that she is a pretty straightforward person.

She met Cid at the Midgar Academy (their first encounter is explained in episode 15), and after he protected her life, she suddenly went into romantic mode! I wanted to make her look as cute as possible, which is a completely different aspect from her dignified appearance as the student council president. In terms of direction, I was told to "go all out," so I played the role as if I were the main character in a romantic drama or melodrama.

--While holding Cid, who was cut down while defending Rose, she said, "You loved me so much that you risked your life for me......!" (Episode 8).

Shiraishi: After that, in episode 10, she says to Cid, who is safe and sound, "I accepted all your feelings for me. I will give my heart to you since you saved my life.......". Here, too, I tried to act in a stern manner.

Because she is so pure, you can see that she is honestly responding to what happens in front of her. Although she looks cool at first glance, she is actually a wonderful character with a cute, straightforward, and pure side.

--Even though Cid is alive after being so boldly cut down, it was also very ladylike of her to convince herself that "a miracle happened".

Shiraishi: I think there are many facts that we can ignore because she is Rose (laughs).

--When you were playing the role, was there anything you are conscious of in your performance?　For example, a certain pride in your character?

Shiraishi: I would say she is direct. She is straightforward in everything, whether it is when she is facing the sword, or when she is making a decision for Cid-kun, or when she is making a decision on her own afterwards.

--That's what makes her so attractive, isn't it?

Shiraishi: Yes, I think it will have quite a big impact on her in the future!

ーYou appeared in full swing in the episode when the school was attacked by terrorists. Do you have any memories or memorable scenes from the post-recording sessions?

Shiraishi: It was the scene on the train in episode 10. That response by Cid was so cold that even while recording, I thought, "How cold! That was terrible!". But as a viewer, I enjoyed it very much. From Rose's point of view, she was trying her best to express her love to Cid, and I think she would be more than happy if he received it.

When I saw the actual animation, Cid was trying to get out of Rose's tight grip on his hand. I thought, "Oh, that's how it's supposed to be!". I was also amused by Rose, who was saying with a relaxed smile, "I am certain after we pass through the thorny path together, a happy future is surely waiting for us". I had a lot of fun during the recording.

--Cid being the same Cid clears up the situation by thinking, "I'm sure it's a religious invitation".

Shiraishi: "What's an expression!" I thought. That's Cid's vocabulary and that little quip or punchline made a lot of sense. I think it was Aizawa-san's explanation, but it was interesting.

--Most guys would fall for a cute Rose if she made a pass at them.

Shiraishi: Rose is very cute. If it wasn't for Cid-kun, I'm sure the person would have been overjoyed. ...... Cid-kun is too uninterested.

We saw many other aspects of Rose in episode 10. She attended the autograph session by Natsume-sensei (Beta/CV. Minase Inori) and got so excited that she spoke about her fascination with the author.

--I personally enjoyed Cid's fight in episode 7 when Cid and Rose were fighting, and Cid was just getting beaten up by invoking all sorts of mob-style techniques.

Shiraishi: That was great too. The scene was slowed down, and his judgment at that timing was really amazing!　From an actor's point of view, I thought Yamashita-san's ability was amazing; he was switching and playing two or three roles at once, so I was able to see his mastery right in front of me. Finesse is required in order to take up Cid's role.

--I have the impression that Rose is a very nice girl who treats everyone without malice.

Shiraishi: She is always kind to everyone except those who try to disrupt her duty of protecting public order in the school.

When the school was attacked, she suddenly became very dignified, and perhaps she is the most decent person. But she also has a mischievous side.

--There are many attractive characters in this work.

Shiraishi: I really like Hyoro Gali (CV: Matsuoka Yoshitsugu) and Jaga Imo (CV: Matsushige Shin)!　They are such great characters!　I also really enjoyed the part where they went to Mitsugoshi Company department store (episode 6).

I think Cid may have chosen them because he thought he could fit in with the mob if he hung out with them, but when he was with them, he seemed to enjoy their company as friends, and his interactions with them were really good!

--They did spread rumors about Cid, who had a stomach ache on the way back from going to Mitsugoshi Company......

Shiraishi: It was an odd but moving performance!　I laughed so hard when I saw it and thought, "They changed the style of the picture just like that!".

--In episode 10, when Cid is in the hospital, Hyoro and Jaga are sleeping next to his bed, so it's nice that they are somewhat worried about him.

Shiraishi: They're cute, aren't they? And they're crazy nice!　There are a lot of girl characters, so I tend to focus on them, but Hyoro and Jaga are my personal favorite (laughs).

--They have terrible names, though.......

Shiraishi: Still, it's better than "Doem Ketsuhat" (CV. Hayami Show)! (laughs)

--I think one of the highlights of this work is the splendid casting, was there any character that caught your attention in that respect?

Shiraishi: In the first episode, when Horie Yui appeared as Nishino Akane, I thought, "That was fast!". I wasn't part of the recording for the first episode, so I was surprised when I saw the broadcast. In a way, he was the one who started it all, and I was surprised that a character who would appear as a guest much later in the series suddenly appeared.

Then there was Ootsuka Houchuu, who played Ruslan Barnett. The character was too ghastly, and the most terrifying thing about him is that he seems so kind but is actually scary!　That episode was heartbreaking.

--By the way, who is your favorite of the "Seven Shadows"?

Shiraishi: Personally, I really like the voice of Seto Asami who plays Alpha.

--In the second half of the show, Rose, Alexia (CV. Hanazawa Kana) and Natsume are working together. Alexia and Natsume fight like cat and dog though.

Shiraishi: Rose is so close to them that I don't think it's possible that they don't hear her, but they seem to not notice her. I guess she is a natural.

--How is the balance between the three of you?

Shiraishi: Aside from the fact that the two of them are bickering, Rose's presence helps to ease the tension. In episode 15, the three of them made memories of going to Maguro Narudo (Tuna King) together, and I don't know how she was spending time with her friends in the school, but the fact that something like friendship was portrayed here deepen my impression of the relationship between the three. I think Maguro Narudo (Tuna King) will become important later on.

--Lastly, what are some of the highlights of the future work?

Shiraishi: It will be a much more serious story. There are many scenes where Rose is suffering when she is carving out her own future. In the presence of her father and Doem Ketsuhat, she tries to fulfill her role as a princess properly. In that sense, I think you will see a different direction in the story.

Rose tries to hold on alone, but I think Rose is probably the type of person who is not good at relying on others, so I would be happy if you could watch her and pay attention to who reaches out to her and to how she finds her way.

Source:

https://www.animatetimes.com/news/details.php?id=1675746267
