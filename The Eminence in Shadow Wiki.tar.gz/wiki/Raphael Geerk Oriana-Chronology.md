# Raphael Geerk Oriana/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Raphael%20Geerk%20Oriana/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Raphael%20Geerk%20Oriana/Chronology)

Main

Relationships

Image Gallery

## Background

King Raphael belonged to a long line of monarchs who was aware of the deal made between the Oriana Royal Family and the Cult of Diablos. Raphael married Reina and the two sired their first child, Rose. Having discovered high levels of magic within the baby, the Cult demanded that Raphael gave up Rose to them as per the conditions of their deal.

However, Raphael refused to give up his child to the Cult like his predecessors had done and chose to break the cycle as he want to end the Kingdom's old tradition. He started his plot to gain independence from the Cult by forged an alliance with the Midgar Kingdom to build a force to rebel against the Cult and established an friendship with King Klaus Midgar. When his daughter wanted to study at the Midgar Academy for Dark Knights, Raphael approved it and sent Rose there to ensure her safety and protect her from harm.

Raphael then discovered that Duke Asshat's adopted son, Perv was in league with the Cult and began gathering evidence of the man's crimes. However, Raphael would noticed that he was being drugged which he correctly deduced that his food might be laced with the mind-controlling drug and realized this was a scheme plotted by the Cult. Raphael tried to ask his wife to change his meal, but unfortunately his wife which he trusted to switch out his meals is a Perv's collaborator and she make sure that he ate the laced meal without his knowledge.

Knowing he will lose sanity and become a mindless puppet, Raphael did one final act; he altered the Ring of Succession which was actually the key to the "Black Rose" so that the gateway could only be activated by Rose. Not only that, he recorded his last will and testament inside the Ring along with all evidence of Perv and Cult's crimes. After finishing the task, Raphael hid the Ring from the Cult on the ruins site, close to the Saisho Fortress.

When Raphael already become Perv's puppet, he is forced by Perv to do his order by going the Midgar royal capital to seize his daughter, Rose Oriana on the pretext of their engagement.

## Bushin Festival Tournament

Upon reaching the capital city of Midgar, Perv showing Raphael's state to Rose which his mind already controlled until Rose's shocked after seeing her own father's lifeless eyes and decides to attack Perv. But, she fails in her attempt and decides to flee before Perv gives a warning that he will make her father to kill King Klaus Midgar if she does not turn herself in at the end of the Bushin Festival.[[1]](#cite_note-1)[[2]](#cite_note-V2C4-2)[[3]](#cite_note-V2C6-3)

The next day, Perv drags Raphael to meet with Princess Iris Midgar to discuss a security plan and due to the influence of the drug Raphael is forced to follow Perv's orders in giving answers from Perv so he can cover up the conversation and not look suspicious.[[4]](#cite_note-4) After the meeting, Raphael waited in the room until the end of the Bushin Festival under the pretense of unwell conditions.[[5]](#cite_note-V2C7-5)[[6]](#cite_note-6)

Before going to the final tournament and meeting King Klaus Midgar, Perv again drugged King Raphael and told his men to cover his sweet smell with perfume. Upon arriving, he is bumped into by [Beatrix](Beatrix.md "Beatrix") who briefly notices his current state, but Perv has defuse the situation and he waits and watches Iris and "Mundane's" match to end.

It was then that Rose suddenly appeared in public and apologized to her father, stating she made a mistake and would likely make another one, but she decided to follow the path she believes in. Raphael then say to her that he forgave all her sins, which surprised Perv as he didn't tell him to say that. Rose cries and jumps at Perv, who then uses Raphael as a shield, but Rose goes ahead and stabs him. In his final moments, Raphael tells Rose that he loves him.[[7]](#cite_note-V2C8-7)[[8]](#cite_note-8)

## Oriana Civil War and "Black Rose" Wedding Incident

When Rose Oriana confronted Perv Asshat on their wedding day and accuses him of treason, he demanded a proof, which she had nothing to show. Instead, she wore the ring of succession, which suddenly reveals the deceased king's final message prior to his death. It is revealed that he was well-aware that he is being drugged and he had already suspected the Duke to be behind it, though he failed to realize that his own wife and queen was collaborating with him. Knowing that he may die eventually, he devised the message to tell the Oriana kingdom to trust his daughter, Rose, for he believes that she will lead them to the right path. The message ends with him telling his daughter that he loves her.

## The Academy Disappearances

Unfortunately, despite Raphael's final message exposing the cult's faction within his country, the larger organization managed to use its influence to suppress the truth.

## References

1. Episode 17
2. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
3. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
4. Episode 16
5. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
6. Episode 18
7. Volume 2 Chapter 8: Lay Your Eyes on My True Powers!
8. Episode 19
