# Magical Power

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Magical%20Power](https://the-eminence-in-shadow.fandom.com/wiki/Magical%20Power)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

In the New World, there is a concept of Magical Power (魔力, Maryoku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), but there is no concept of Magic such as releasing fire or water, and Magical Power is generally used as energy to strengthen the body and weapons, and healing exists, but is difficult.

## History

### The Other World

It is theorized by the Cult of Diablos that 10 million years ago, the world of "The Eminence in Shadow" originally did not possess Magical Power. That is until the [realms](Realms.md "Realms") collided, with one of these realms pouring Magical Power into the world. The [Dragons](Dragon.md "Dragon") went extinct due to their inability to adapt to the Magical Power while [Humans](Human.md "Human"), [Elves](Elf.md "Elf") and [Therianthropes](Therianthrope.md "Therianthrope") thrived.

### [Earth](Earth.md "Earth")

Originally prior to the death of Minoru Kageno, earth had no possession of magic. Until sometime later when mysterious creatures suddenly appeared and began to attack humanity. Since conventional weapons did not work, with the passage of time suddenly magic suddenly appeared. Having researched them, Akira Nishino would create the first knight of Japan, his younger sister Akane Nishino, becoming known as an "Awakened".[[1]](#cite_note-1) Later, humans with magical power were created who would be in charge of fighting the magical Beast and protecting humanity. These warriors would be known as "knights."

## Capabilities

The presence or absence of Magical Power is determined by talent, but it is not uncommon to have Magical Power, and it is possible to develop Magical Power with effort.

Fighting an opponent with Magical Power without Magical Power is a clear difference and can be called suicidal. For this reason, although there are several schools of martial arts, they can be won by forceful push with Magical Power, and from the perspective of Cid, who learned various martial arts in his previous life, pure fighting techniques have not been refined.

Because of the nature of Magical Power to dissipate uncontrollably as soon as it leaves one's body, the use of Magical Power to send out slashes of Magical Power requires an enormous amount of Magical Power and the ability to control Magical Power to a degree that is almost beyond the norm.

Magical Power can sometimes physically manifest itself depending on the user's skill, giving off colors and other visual depictions. People who can do this can create Special Techniques, what kind of power they possessed depends on the one who creates the Special Technique.

## Weapon Strengthening

Weapon Strengthening (武器強化, Buki Kyōka[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the core uses of magical power used in the world of The Eminence in Shadow. All types of materials exhibit conductivity with magical power.

Shadow Garden uses a unique material for their equipment: slime jelly. The weakest monster in the world has a ridiculous conductive ability, reaching 99%, allowing it to be easily shaped and controlled by magical power. The clothing and weapons used by Shadow Garden are made entirely of slime jelly, granting their weapons and clothing extreme adaptability and durability, all dependent on the magic capabilities of the individual.

### Magic Conductivity:

- Paper: <10% [[2]](#cite_note-2)
- Steel: 10%
- Iron: 10%[WEB NOVEL ONLY]
- Mithril: 50%
- Slime: 99%

## Body Strengthening

Body Strengthening (身体強化, Karada Kyōka[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the most basic form of using magical power in the world. With varying degrees of ability, magical power allows the human body to go beyond its normal limits and achieve amazing feats.

## Cure

Cure (治癒, Chiyu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")): TBA

## References

1. Volume 4 Chapter 5: Sneaking Around in Japan, Just Like the Old Days!!
2. Volume 6 Chapter 1: Enter Jack the Ripper!
