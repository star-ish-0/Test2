# Kagejitsu - Episode 3

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%203](https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%203)

## Operation 3

## Special Title

### English

The Seven Shades want to make delicious chocolate!

### Kana

七陰は美味しいチョコを作りたい！

### Romaji

Shichi kage wa oishī choko o tsukuritai!

## Episode Information

### Season

1

### Episode

3

### Air Date

November 9, 2022

### Adapted From

Light Novel

## Staff

### Director

Minoru Ashina

### Writer

Daisuke Aizawa

Episode Navigation

| Previous | Next |
| --- | --- |
| Operation 2 | Operation 4 |

Operation 3 is the third episode of the spin-off series [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu").

## Summary

[Gamma](Gamma.md "Gamma") proudly holds up her latest creation to [Alpha](Alpha.md "Alpha"), chocolate with a whiskey filling. She made it by distilling grain and aging it in a wooden cask—Shadow first proposed the idea. Alpha raises questions about the production time, but Gamma explains that [Eta](Eta.md "Eta")’s latest invention has reduced the distillment period while delivering bigger batches. Eta sets down a plate covered with more chocolate, offering Alpha to try some. Popping one into her mouth, she admits the chocolate tastes good despite her questions about its practicality. Eta mutters that Shadow first proposed the combination of whiskey and chocolate. Gamma continues the explanation, claiming that making them bite-sized would make them “more delicious.’’ It might not be a perfect recreation of Shadow’s enigmatic vision; however, it will prove beneficial as a Mitsugoshi product. A name for the creation has yet to be decided, and Alpha suggests that they discuss possibilities while eating. Eta begins to stuff Gamma’s face with the spirit core chocolates, ignoring protests. The lightweight Gamma soon finds herself intoxicated and complains that her head is bounding. Alpha asks if she misspoke and meant pounding. Finishing her chocolate, Eta announces the new name for the product: Whiskey Bonbon.

## Characters

- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Gamma](Gamma.md "Gamma")
- [Delta](Delta.md "Delta")
- [Epsilon](Epsilon.md "Epsilon")
- [Zeta](Zeta.md "Zeta")
- [Eta](Eta.md "Eta")
- [Nu](Nu.md "Nu")

## Gallery

## Trivia

- Eta's product name mirrors the real-world word bonbon. While bonbon can be used in a general sense to describe sugary confederacy—a piece of candy—the most prominent definition associates it with a specific type of chocolate dessert. The treat has a hard chocolate layer outside, the couverture, and a soft core filling of liquor, fruit, more chocolate, or other miscellaneous foods.[[1]](#cite_note-:0-1)
- Eta's choice to name the product after the word bounding differs from bonbon's real-world etymology, although they both have French derivations. The French word bon definition is good, making the direct translation good-good. Bounding derives from the French word bondir, meaning jump or leap.[[1]](#cite_note-:0-1)[[2]](#cite_note-2)

## References

1. (1949). Webster’s New Twentieth Century Dictionary of the English Language. New York: The World Publishing Company.
2. (2003). The Oxford Compact English Dictionary. Oxford: Oxford University Press.

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • **Episode 3** • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
