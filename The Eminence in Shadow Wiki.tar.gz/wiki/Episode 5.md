# Episode 5

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%205](https://the-eminence-in-shadow.fandom.com/wiki/Episode%205)

## I Am...

### Kana

アイ・アム......

### Romaji

Ai amu...

## Special Title

### English

The Eminence in Shadow Wants To Cast a Special Move at the Best Timing!

### Kana

陰の実力者は最高のタイミングで必殺技を放ちたい！

### Romaji

Kage no Jitsuryokusha wa Saikō no Taimingu de Hissawwaza wo Hanachitai!

## Episode Information

### Season

1

### Episode

5

### Air Date

November 2, 2022 JP
January 23, 2023 EN

### Adapted From

Volume 1 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Mio Inoue

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Delta ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Sadism's Reward | Pretenders |

I Am... (アイ・アム......, Ai amu...[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the fifth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Cid is not facing a minion but a would-be Knight of the Rounds. Normally, that is cause for concern, but an atomic bomb has no reason to fear the gnashing of a lowly pest.[[1]](#cite_note-1)

アイリス率いる騎士団は、王都に突如現れた謎の怪物に大苦戦。そこに“怪物の素性”を知るアルファが現れる。　一方、シャドウに追い詰められたゼノンは、不穏な赤い薬の力で覚醒するが――[[2]](#cite_note-2)

## Summary

As Shadow introduces himself in front of the curious Princess Alexia Midgar and Zenon Griffey whom the latter recognizes the man in black as the one who has been hunting down the Cult lately which has destroyed several small facilities, but calls him a coward because he was only targeting the weakest minions without fighting any of the Cult's core members. Zenon arrogantly said to Shadow that what the man he was facing in front of him right now is the person who would hunt him today by declaring himself to be a core member of Cult while boasting of being the future Twelfth Seat of Rounds and Zenon said that he would take Shadow's life to become Rounds. When Zenon's attack was aimed at Shadow that caused a shock wave large enough to create thick dust, but he was shocked after finds that his opponent was not in front of him with Shadow has already moved quickly behind Zenon, placing himself between him and Alexia, even mocks Zenon further by asking him where the Cult's core members he spoke of.

On a rainy night, Midgar Kingdom was thrown into chaos with the Knight Order mobilized in a state of emergency to begin the process of evacuating all citizens in every affected district. As the Cult-enhanced monster that escaped above ground had suddenly appeared in the capital, the knights engage the creature while carrying out the evacuation, but their attacks proved ineffective as the monster's wounds had healed instantly which made the Order have to mobilize all nearby units and hold back the monster with all their might to protect citizens who have not been evacuated.

Seeing the destruction that caused from the monster's rampage, Iris Midgar arrives on scene and inflicts a more serious wound on the monster then ordered the knights to retreat, but surprisingly the wounds from Iris' attack were still recovering as well. Adding severity to her next attack, Iris severs the monster's right arm and pushed the monster towards the building with her immense magic power, but that damage is easily regenerated. After seeing the monster instant regeneration, Iris decides to cut it into such small pieces so that the monster cannot regenerate.

Just as Iris deflecting the monster's attack and giving several wounds from her swords slash before she could readies herself to resume her attack to inflicting more damage on the monster, a mysterious woman stopped her and states that the princess is just making the poor creature suffer as she knows the monster pain and suffering and she will put an end to it. Due to the figure's sudden interference, Iris demand to know who is she, which she replied as [Alpha](Alpha.md "Alpha"). Engaging the monster, Alpha states that she knows the monster's pain and suffering but will put an end to it. Alpha, concentrating magic into her sword, slashes at the monster, defeating it in one hit and returning the monster to its original form. Alpha picked up a pendant held by a young human girl that had fallen on the ground, revealing a photo of Viscount [Grease](Grease.md "Grease") along with his daughter, [Millia](Millia.md "Millia"). The dismissive Alpha tells Iris that she should just stay back and enjoy the show like a good audience member while they deal with this situation, as well as saying not to get in Shadow Garden's way.

Meanwhile at the same time in the capital's underground, Shadow battles Zenon as the latter admits that he apparently to have underestimated him a little after realizing how Shadow managed to destroy so many of the Cult's bases, even if they were small ones which makes Zenon decide to get more serious about showing his opponent the power of a future Knights of Rounds as he uses more magical power in his attacks, where Alexia felt Zenon's magic which was greater than before the princess knew. However, Shadow easily overpowers Zenon as he effortlessly outmaneuvered his attacks despite his increasing magic power.

By the time Shadow scoffs at Zenon's so-called superior swordsmanship and mocked his underwhelming strength as Shadow point his swords at Zenon and belittled call him "Future Rounds", Zenon became furious which completely driving him into a rage as he emotionally engage Shadow with continuous fierce attacks, which Shadow easily parries his attacks until the backlash from their exchange of devastating blows had quaking the underground sewers around them to the point of creating numerous cracks that resulted from a one-sided fight.

Seeing the fight, Alexia who watched the two combatants fight is amazed by Shadow's extraordinary swordsmanship and the princess saw that the core of his swords technique is so ordinary, like the ideal swordplay that she dreamed of when she was young without any innate talent for swords that Iris had, which Alexia believed that she could be as strong as her sister if she worked long and hard enough, but could never became an equal or strong than her sister. Recalling her past memories where Alexia was clashing swords with her sister, she felt that she saw Iris starting to become distant from her because the princess knew that she would never catch up to the genius no matter how hard she tried, which made Alexia always being compared to Iris and laughed at by everyone for her swords style with no strength and skill that eventually earned the nickname: Fencer Ordinare.

Even though she wanted to abandon the imperfect technique that she hated, Alexia didn't want to give up on swordplay that only honed the basics, which at this time Shadow had showed the path after displaying his swordsmanship skills as how she envisioned and Alexia suddenly realized what Iris' praise for her fencing style really meant. Once Shadow instantly attacked Zenon by giving him a fatal slash, a badly injured Zenon angrily demands Shadow to reveal his true name as he confused why the mysterious black swordsman hiding his identity even though he was that strong all along, only for Shadow smiled at the comment by stating that they are Shadow Garden who lurk in the darkness and hunt down from the shadows, which is the sole purpose of their existence with Zenon who heard the declaration thinking that Shadow was insane, even Alexia who left baffled by their conflict is more inquiring as to the nature of the two organizations.

With his arrogant ego, Zenon intends to take Shadow's seriousness when he takes out a bottle of red pills and explains that by taking them will awaken a new nature beyond human limitations, where if an ordinary person who takes these pills will have their body overwhelmed by their extraordinary power and die. Taking a large amount of the pills to empowered himself, Zenon then transforms and stating he is the Third Awakened, all while Shadow looks on in disappointment. Having far more destructive power than before, Zenon declares that only the real chosen ones who can control this power and worthy to join the Knights of Rounds as he concentrates his strengthened magical energy into his sword with Zenon saying that he will show Shadow his almighty power, to which he directs his attack at Shadow, but is easily blocked yet again and says Zenon's power is disgusting.

After saying that while still withstands the attack, Shadow emphasized to Zenon not to claim his strength as the strongest because it was an insult against the almighty, where immediately Shadow pushed Zenon back by throwing away his sword and using hand-to-hand techniques to beat him, even kicking him in the head as Zenon is still no match for Shadow, who overwhelms him after taking a multiple hits despite being strengthened from the red pills. At that moment, Shadow rebuked Zenon that there's no road to almightiness from borrowed power, stomping the pill bottle and activates his magical powers by setting a magic circle around Zenon but shielding Alexia. Zenon is frightfully astonished by the amount of magical energy, aghast at how powerful it is.

It was then Shadow recounts how there once was a man who wanted to withstand a nuclear bomb by developed his muscles, honed his mind, perfected his skills, however there were still heights he could not attain. But, Shadow was unwilling to give up on his goal until he realized a single solution after years upon years of training that if he didn't want to be vaporized by a nuclear explosion, then all he needed to do is simply have to become nuclear himself. The terrified Zenon believes him to be crazy and tries slashing him, but his swords breaks as it hits Shadow, slumping back down in resigned defeat. Shadow then tells him to witness his almightiness as he unleashed his almighty power, chanting "I... Am... Atomic."

Moment later, a huge explosion ensues in the underground tunnel, with Alexia safely outside the magic blast zone. while an despaired Zenon is instantly vaporized into oblivion. The damage of Shadow's ultimate attack obliterates the Cult's hidden facility as well several cities blocks, leaving a large crater in the middle of the royal capital. Alpha and the other Seven Shadows witness in awe as Shadow's magic illuminates the night sky, while Iris sees the inconceivable power and rushes towards the said location which was definitely where Alexia was. Under a now clear night sky, Alexia finds herself unharmed and alone at the crater's epicenter, taking her sword from the ground and tests her fencing, finding better quality with her renewed dedication. Soon after, Iris sees her and races over to hug her sister, exclaiming how she is glad that she is alive.

Next morning at the Academy, Cid met again with Alexia who returned to school to tell him about what happened yesterday, where Cid's name had been cleared of all suspicion and was free from charges of kidnapping the princess with the case having been resolved on the surface as far as the public is concerned, even though Alexia can sense that there was something brewing from behind the incident that felt more hidden than meets the eye. As Cid can take his leave, Alexia thanks him for liking her fencing and tells Cid that she also finally learned to like her sword techniques thanks to 'someone'.

The moment before he decide to leaves the princess alone, Alexia admits that they were pretended to be a couple for a while and wonders if Cid is interested in the princess's suggestion as she might want to keep their relationship a little longer with Zenon is dead from yesterday's incident. However, Cid refuses, shocking Alexia, who feigns a smile before slashing Cid until his blood splashed on the wall where people found a massive amount of blood behind the school building, but no bodies were found in the vicinity nor were any of the students and faculty staff reported to be injured or missing, from which the never solved case would then eventually became one of the school's seven mysteries: The Bodiless Murder.

Elsewhere at a certain giant building within the central district located in the heart of the Midgar capital, the Seven Shadows review their progress against the Cult with the success of their mission in destroying all of [Fenrir](Fenrir.md "Fenrir")'s faction's hidden bases, especially Shadow who had annihilate the facility where the Cult were holding Princess Alexia captive and Zenon Griffey had certainly evaporated without a trace by the attack. The girls remain excited over how powerful Shadow is, recounting his Atomic spell from last night where his magic had colored the entire capital, like seeing a heavenly paradise and hope from this operation must be enough to learn the Cult a lesson that they are merely prey to be hunted as the girls waiting for a time on how all of their enemies will one day vanish from his light.

Continuing the meeting, [Beta](Beta.md "Beta") received a report from [Zeta](Zeta.md "Zeta") who had currently found the target as she was approaching and would investigate it while deciding to wait for good news from her, while [Eta](Eta.md "Eta")'s research is also going smoothly. However, the last topic this time is a serious problem when Alpha showed a blood-stained flyer from a group of people who pretended to be from Shadow Garden and delivering "death judgment" through defamatory acts of indiscriminate slaughter. The result of this problem has caused disturbances that have an impact on the organization, where [Delta](Delta.md "Delta"), who was previously cheerful, became annoyed and [Epsilon](Epsilon.md "Epsilon") at the same time expressed her silent anger towards the idiot who used their name, to the point that even the traces of the killers' movements in carrying out atrocity were well covered, but [Gamma](Gamma.md "Gamma") is sure they will catch them because it is absolutely impossible for the perpetrators to escape from Shadow Garden's watch.

In the destroyed area where the crater site was located, Iris held a private meeting with [Glen](Glen.md "Glen") and Marco Granger in her tent where the princess discussed upon learning the existence of the two secret organizations; the Cult of Diablos and Shadow Garden as she felt there might be a movement somewhere beyond their grasp. Coupled with Iris' anxiety when Glen thought about the princess's distrust in her suspicions on the Knight Order after learning that Zenon, who was known as the pride of kingdom's most renowned sword instructor was an adherent of the Cult. Understanding what the princess meant by Glen wanting to provide certainty in carrying out the plan that had been discussed previously, Iris intended to form a new investigation team under her command with the aim of investigating both parties as she requesting Glen and Marco, who were two known knights she could trust, to join her new conceptualized order.

Learning the situation, Glen and Marco are honorably agree to join in helping the princess as Iris opened a suitcase containing an artifact which is the only clue had left amid the crime scene among all the secret documents and items that had been confiscated after hearing the news about the warehouse had burned down, but need to find someone who can decipher its functions. Meanwhile, as she's carrying a stack of books and reading her research, a distracted Sherry Barnett bumps into a blood-soaked Cid, who offers to help her up. The scholarly schoolgirl accepts, smitten by the bloody boy.

## Characters

- Alexia Midgar
- Zenon Griffey (last appearance)
- Cid Kagenou
- [Millia](Millia.md "Millia")
- Iris Midgar
- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Delta](Delta.md "Delta")
- [Epsilon](Epsilon.md "Epsilon")
- [Gamma](Gamma.md "Gamma")
- [Zeta](Zeta.md "Zeta")
- [Eta](Eta.md "Eta")
- [Nu](Nu.md "Nu") (Cameo)
- [Glen](Glen.md "Glen")
- Marco Granger
- Sherry Barnett

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第５話予告≪ノーマルVer.≫「アイ・アム……」

TVアニメ『陰の実力者になりたくて！』第５話予告≪スペシャルVer.≫「陰の実力者は最高のタイミングで必殺技を放ちたい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e005>
2. <https://shadow-garden.jp/1st/story/#story5>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • **Episode 5** • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
