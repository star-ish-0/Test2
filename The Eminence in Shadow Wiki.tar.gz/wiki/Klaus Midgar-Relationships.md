# Klaus Midgar/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Klaus%20Midgar/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Klaus%20Midgar/Relationships)

Main

Chronology

Image Gallery

## Family

### Iris Midgar

Klaus's relationship with his eldest daughter has shown to be stern and strict, focusing on trying to teach her restraint and discipline but often failing. Unlike the rest of Midgar's citizens, who overly praised Iris' skills, Klaus can clearly see his daughter's shortcomings, especially her fiery temperament. He tried to teach Iris to play smart, but this failed since she would rather force her way through problems.

In the anime, upon seeing Iris's defeat at the hands of Mundane Mann, he just sighed in disappointment and left the stadium, implying that he has an idea what caused Iris to fail.

### Alexia Midgar

Klaus' relationship with his second daughter can be inferred to not be as strained as the one with his first. While Iris brushes off her shortcoming, Alexia is more coolheaded, humbled, and forward-thinking in her actions for the most part. As a result, Klaus trusts her enough to investigate the Church following Archbishop [Drake](Drake.md "Drake")'s mysterious death. However, following the Sanctuary Incident, he retracted his orders, likely fearing his daughter would get targeted by the Cult.

## Oriana Kingdom

### Raphael Geerk Oriana

The two kings have had a long history of friendship together, holding a truce between their nations for Midgar to protect Oriana in the event of any external conflict. It is most probable that King Klaus observed the long-term brainwashing of his old friend by Perv Asshat, that when he was killed by his daughter, Rose, King Klaus ensured King Raphael's body was protected and returned safely, but through the anti-Duke faction. Even in death, Klaus knew Raphael would have wanted to support the opposition to Perv Asshat.

### [Grant](Grant.md "Grant")

King Klaus knew Marquess Grant long and well enough to entrust him with the safe return of King Raphael's body. This was also a low-key political move to help the anti-Duke faction in Oriana gain public support. By these actions, Klaus most likely trusts Marquess Grant, almost as much as his friendship of King Raphael.

### Perv Asshat

While not blatant or emphatic about his feelings, King Klaus likely uncovered Duke Asshat's brainwashing of his old friend, King Raphael, and possibly held a grudge or hatred for the duke. To subtly and legally oppose Duke Asshat, King Klaus sent Raphael's body to Marquess Grant in a power move to fuel support for the anti-Duke faction.

## Enemies

### Cult of Diablos

In fact, Klaus already knows about the Cult of Diablos and understands the organization's strength, knowingly hiding the organization's existence from both of his daughters in order to protect them and the country from the ancient cabal. It is a consideration as a father who does not want his daughters involved with the Cult, whether in opposition to them or as a pawn.

With the Cult's exposure by Shadow Garden, Klaus has maintained a vigilance over Iris and her Crimson Order, likely aware of the Cult's targeting the newly formed order. When Iris was defeated at the Bushin Festival, Klaus looked initially disappointed and sighed in relief before taking his leave, likely removing any openings to assassinate himself.

## Others

### Shadow Garden

While Klaus has yet to make proper contact with Shadow Garden, he has benefitted from the organization's war against the Cult of Diablos, allowing him to investigate the Cult's Midgar base following the attempted kidnapping of his daughter and return Raphael's corpse to the Oriana Kingdom after the king's assassination.
