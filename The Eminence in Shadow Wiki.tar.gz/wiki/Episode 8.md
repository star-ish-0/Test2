# Episode 8

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%208](https://the-eminence-in-shadow.fandom.com/wiki/Episode%208)

## Dark Knight Academy Under Attack

### Kana

狙われた魔剣士学園

### Romaji

Nerawareta Makenshi Gakuen

## Special Title

### English

The Eminence in Shadow Wants To Fulfill His Dream as a Kid!

### Kana

陰の実力者は少年の夢であるアレを叶えたい！

### Romaji

Kage no Jitsuryokusha wa Shōnen no Yume Dearu Are wo Kanaetai!

## Episode Information

### Season

1

### Episode

8

### Air Date

November 23, 2022 JP
February 13, 2023 EN

### Adapted From

Volume 1 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Mio Inoue

### Storyboard

Daisuke Takashima

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Eta ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| A Fencing Tournament of Intrigue & Bloodshed | The End of a Lie |

Dark Knight Academy Under Attack (狙われた魔剣士学園, Nerawareta Makenshi Gakuen[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the eighth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Cid sacrificed his life to save Rose. At least, that’s what everyone thinks. Unbeknownst to anyone else, Cid survived exactly as planned, and now his counterattack can begin.[[1]](#cite_note-1)

黒づくめの集団に抵抗したローズが斬殺されそうになった瞬間、モブとしての役割をまっとうしたいシドが身代わりに。その後、“テロリストの学園占拠”という夢に見た展開に嬉々として暗躍し始める。[[2]](#cite_note-2)

## Summary

As terrorists attack the academy, Cid is secretly excited as they are fulfilling a "terrorist takeover" fantasy. Seeing that they are about to kill Rose, he jumps in front of the attackers. From his perspective, it is the role of a background character to be killed first in that scene. As blood gushes out and Rose is in shock, Cid grins, satisfied with the scene. A distraught Rose wonders why he gave his life away to save her. Remembering his drive to keep standing when he fought her and this recent sacrifice, Rose concludes he fell in love with her. Threatening Rose further, the terrorists then move all the students to the auditorium, leaving the dead Cid in the classroom.

Finally alone, Cid starts pounding his heart until it begins beating again. Cid tells himself how lucky he was to be successful with his secret technique. The technique stops his heart for ten minutes but maintains regular blood flow to his brain via magic. Although his magic is still obstructed, Cid circumvents the restriction once he narrows internal mana into threads. Donning his jacket to take his leave, Cid feels it would be rude to ignore the terrorists' magic-blocking scenario, given their effort.

At the Midgar Academy of Science, [Rex](Rex.md "Rex") breaks into Sherry's room and claims to be from Shadow Garden but then wonders if their name was Shadow Guardian. He states that his job is simply to retrieve the artifact. Once they complete the mission, the Cult permitted Rex to unleash unbridled carnage. Rex moves to take the artifact in Sherry's hands but is stopped by Glen. The fact that Glen managed a counter-move without magic compels Rex to acknowledge the feat. Glen claims such is easy when his opponent is weak. While Glen and Marco keep the terrorists busy, they let Sherry run away with the artifact.

On a rooftop of the academy building, Cid observes the movement of the terrorists; he is quite excited about the whole situation. However, he is annoyed and disappointed that they all wear black at midday—he wears black robes at night. Predicting their formula, Cid decides to play out things slowly until nightfall, as he can make his grand appearances easier. Cid notices a pink-haired girl running around and almost begging to be captured. He realizes she is Sherry and snipes away any terrorists that move toward her. After enough close saves, Cid approaches Sherry and catches her before she trips down a stairwell. Before continuing their trek, Cid asks Sherry to remove her to remove her noisy slippers.

Sherry finds the book she needs and explains that the artifact is called the Eye of Avarice. It absorbs and stores the magic from any user, but it can be programmed to ignore some magical frequencies. Sherry postulates that it cannot absorb magical traces that are too small or powerful spells exceeding its capacity. Once the artifact reaches maximum capacity, it will release all the stored energy. If it reaches a critical state, it will kill all the students in the auditorium. She further explains that the artifact she was researching is used to control the Eye of Avarice. Sherry plans on using the hidden backrooms to reach the auditorium safely. Once close, she will activate her artifact and stop the Eye of Avarice from exploding.

In the auditorium, Rex reports to a tall, fully armored knight about the status of the Knight Order. The armored individual dismisses concerns, demanding Rex retrieve the artifact, threatening compulsory deception. Before he leaves, Rex informs the Cult Knight that some of their men have been killed by someone truly skilled, and he guesses that Shadow Garden is there.

As Rex is walking with four of his men, Cid intercepted them. Thinking Cid's speed is from an artifact, Rex creates a net around himself but Cid is already in the net and sends the Named Child flying. After being kicked into a classroom, Rex discovers the room is filled with the corpses of cultists. Rex realizes that this is beyond the powers of an artifact and starts panicking before Cid finishes him off.

In another part of the school, Nu finds the deceased Glen, noting how a prestigious knight was no match for the Cult with their magic sealed away. She sees an unconscious Marco and prepares to kill him. A moment later, Cid surprises Nu with his arrival, looking for Sherry's tools. Nu explains that Marco was once her betrothed. After a quick deliberation, the two decided to leave him. Nu then reports that Shadow Garden has infiltrated the academy and awaits orders. However, most reinforcements will be unable to use magic, as their Slime Bodysuit will likely malfunction. The Seven Shadows would be the only members who could retain magic control in these circumstances. Out of the seven, only Gamma is in the capital, but this type of mission is not her forte. She will act as the rear commander.

Outside the school, Princess Iris Midgar continues debating with the Knight Order Commander over jurisdiction due to objections from the palace.

After obtaining all the tools, Nu inquires why he needs them. Cid explains that the tools are to fine-tune an artifact that can counter and neutralize the Eye of Avarice, which is the reason for their magic suppression. Nu expressed awe for Cid's genius in identifying and remedying an artifact's effects. Cid promises the artifact's readiness by sundown, and Nu replies that their forces will be prepared. Once Cid is out of sight, Nu turns to the unconscious Marco to tell him he has been spared another day.

As the Knights retain their jurisdiction and magic-deprived stalemate, Gamma and her Shadow Garden contingent stand atop the auditorium, ready for Cid's signal. Cid brings the tools to Sherry, and she starts fine-tuning the artifact, calling out for the assistance of her father.

## Characters

- Cid Kagenou
- Rose Oriana
- Lutheran Barnett
- Sherry Barnett
- [Rex](Rex.md "Rex")
- [Glen](Glen.md "Glen")
- Marco Granger
- Iris Midgar
- Alexia Midgar
- [Nu](Nu.md "Nu")
- [Gamma](Gamma.md "Gamma")

## Promotional Video

TVアニメ『陰の実力者になりたくて！』第８話予告≪ノーマルVer.≫「狙われた魔剣士学園」

TVアニメ『陰の実力者になりたくて！』第８話予告≪スペシャルVer.≫「陰の実力者は少年の夢であるアレを叶えたい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e008>
2. <https://shadow-garden.jp/1st/story/#story8>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • **Episode 8** • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
