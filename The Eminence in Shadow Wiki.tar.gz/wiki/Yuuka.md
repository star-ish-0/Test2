# Yuuka

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Yuuka](https://the-eminence-in-shadow.fandom.com/wiki/Yuuka)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Yuuka Asakura

### Japanese

ユウカ

### Romaji

Yūka

## Characteristics

### Race

[Human](Human.md "Human") (Earthling)

### Gender

Female

### Age

Unknown (possibly in her 20's)

### Height

Unknown

### Hair Color

Brown

### Eye Color

Brown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Unnamed Husband (Deceased)

## Professional Information

### Occupation

- Nurse
- Spy

### Affiliation

[Arcadia](Arcadia.md "Arcadia") (formerly)
The Alliance
[Messiah](Messiah.md "Messiah") (undercover)

## Debut

### Light Novel

Volume 4

### Manga

Chapter 49

### Movie

The Eminence in Shadow Movie: Lost Echoes

## Portrayal

### Japanese

[Yukari Tamura](https://en.wikipedia.org/wiki/Yukari_Tamura "wp:Yukari Tamura")

Yuuka Asakura (ユウカ, Yūka[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a physician of [Messiah](Messiah.md "Messiah") and a spy working for the 'Alliance'.

## Appearance

Yuuka was a woman with long brown hair. She donned over her turtleneck sweater with a lab coat as part of occupation at the Messiah.

## Personality

Yuuka was once a happy woman until the death of her husband. Due to Arcadia's fall and her husband's death, she radically changed into a wicked woman who solely desired vengeance upon those who wronged her. Yuuka would manipulate, undermine and murder anyone to accomplish her goals. While undercover as Messiah's physician, she presented herself as a kind and concerning woman.[[1]](#cite_note-V4E-1)

## Background

Yuuka lived in [Arcadia](Arcadia.md "Arcadia") with her husband who was one of Arcadia's scientists that produced Japan's Original Knight. Tragedy struck however when the Original Knight went on a rampage due to Akira Nishino's experimentations resulting in countless deaths, including Yuuka's husband. Yuuka held her husband as he died.[[1]](#cite_note-V4E-1)

Years later, Yuuka joined a group called The Alliance who tasked her to infiltrate [Messiah](Messiah.md "Messiah") and sabotaged the group alongside their mole, Yuudai Saejima so that they could claim their base as their own. Having successfully infiltrated Messiah, Yuuka learned to her outrage that not only Akira Nishino was still conducting his experiments but Akane Nishino, the Original Knight had forgotten what happened to Arcadia. Yuuka spent her time getting close to Akane all the while secretly planning her revenge against the Nishino's siblings.[[1]](#cite_note-V4E-1)

## Chronology

### The Return to Japan Arc

When Akane brought back two survivors, a boy named Minoru and a girl named [Natsume](Beta.md "Beta") from a Magical Beasts nest, Yuuka did her best in taking care of them. She would explained to Minoru about the Magical Beasts and their nests, believing he had lost much of his memories.[[2]](#cite_note-V4C5-2) While tending to Natsume, Yuuka found her watch was missing but concluded that it must have fallen off.

After a Magical Beast stampede was stopped by the Black Knight, Yuuka offed Yuudai Saejima per the Alliance's orders. However, the woman took advantage of her former co-conspirator's death to further her own goals of revenge. She axed Yuudai's corpse into pieces with a chainsaw and framed the death as Akane's doing. When Yuuka provided Akane the "evidence", Akane went into a nervous breakdown until Yuuka sedated her and took her away to tend to her. Unbeknownst to Messiah, Yuuka actually kidnapped Akane.[[3]](#cite_note-V4C6-3)

Yuuka meet up with Minoru who revealed proof of Akane's innocence. Wary of the boy discovering the truth, Yuuka secretly ordered two hitmen to take Minoru out.[[3]](#cite_note-V4C6-3) During another Magical Beast stampede, Yuuka took the chance to find Akira Nishino and killed him along with Natsume. She took the [Brute](Mordred.md "Mordred")'s head that Akira wanted to use. Yuuka coldly stated down at Akira, telling him that she hoped his death will hurt.[[1]](#cite_note-V4E-1)

Having escaped Messiah, Yuuka returned to the spot where she had kept the unconscious Akane Nishino. Suddenly, she was confronted by Minoru who deduced her as the Alliance spy. Yuuka explained her past and intentions to Minoru before injecting Akane with the Brute's blood. With Akane now transformed into her Original Knight state, Yuuka allowed herself to be killed at the Original Knight's hands. Despite nearing her end, Yuuka hugged the Original Knight before laughing, having finally gotten her revenge.[[1]](#cite_note-V4E-1)

Despite achieving her goals as a spy, Yuuka would not receive the last laugh in her quest of vengeance when the Black Knight saved Akane and restored her back to her normal condition. After saving and returning to the Other World with her, Akane would come to terms with herself and accept what she had done in [Arcadia](Arcadia.md "Arcadia") with a new purpose in life of saving as many lives as she can as her way of atonement,[[1]](#cite_note-V4E-1) thus invalidating Yuuka's intentions in her quest of vengeance.

## Powers & Abilities

Yuuka was just an ordinary human with no magical abilities whatsoever. However, being Messiah's physician, it can be assumed she knew medicine. She was also a skilled spy, capable of infiltration the human refuge without anyone deducing her true identity until it was too late.

## Relationship

### Unnamed Husband

Even after the invasion by magical beasts, Yuuka lived happily with her husband until the birth of the Original Knight where the knight lost control and destroyed Arcadia taking her husband's life alongside it. His death would result in Yuuka changing for the worse as she swore allegiance to the Alliance and becoming hellbent on avenging his death.[[1]](#cite_note-V4E-1)

### [Messiah](Messiah.md "Messiah")

#### Akane Nishino

Yuuka is aware of her identify as the Original Knight and despised her for taking her husband's life. As a spy, she would put on a facade of a nurse and would help her alongside other habitants of the Messiah. When the opportunity shows, she would try to frame Akane for murdering Yuudai[[3]](#cite_note-V4C6-3) and eventually get revenge when she made her recall her memories of the Original Knight thus causing her to go berserk and contemplate suicide.

#### Akira Nishino

Brother of Akane and researcher for the Messiah, Yuuka is also aware that he was responsible for the destruction of Arcadia as well of the death of her husband and held it against him. As a spy, she and Akira would work together when it comes to research and medical care. She would eventually have revenge on him when he tried to run off with [Brute's](Mordred.md "Mordred") head.[[1]](#cite_note-V4E-1)

#### Yuudai Saejima

Fellow co-conspirator for the Alliance, Yuuka at one-point bribed Yuudai into their side as their mole and worked together as spies. However, after a magical beast stampede, she would betray and kill him when she got what she needed. She would also use his death as an attempt to out Akane as a murderer.[[3]](#cite_note-V4C6-3)

#### [Haitani](Haitani.md "Haitani")

Commanding Knight for the Messiah, not much is known of their interaction aside from performing tasks ordered by him. Haitani was unaware that Yuuka was the spy for the Alliance during Minoru and [Natsume](Beta.md "Beta")'s time on Earth.

### Others

#### Minoru / The Black Knight

Initially, Yuuka did not think much of Minoru when he first woke up in the infirmary. However, much of it changed when he found out more details regarding Yuudai's murder where she tried to put a hit on him after he elaborated on the evidence.[[3]](#cite_note-V4C6-3) As the Black Knight, Yuuka would not get the last laugh in her quest of vengeance when Shadow saved Akane from going berserk and helped her accept what she's done with a new purpose in life.[[1]](#cite_note-V4E-1)

#### [Natsume](Beta.md "Beta")

Yuuka was wary of Natsume, believing that she is awakened like Akane. Initially she was going look after her before Akira cut her off and decided to run experiments on her.[[2]](#cite_note-V4C5-2) When Akira tried to experiment on Natsume with the Brute's head, Yuuka stopped him by gunning down the two.[[1]](#cite_note-V4E-1) However, no one but Shadow was aware that Natsume can survive gun shots thus only leaving her alive from the ordeal.

## Trivia

## References

1. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
2. Volume 4 Chapter 5: Sneaking Around in Japan, Just like the Old Days!!
3. Volume 4 Chapter 6: Something Smells Fishy... But an Eminence in Shadow Always Cracks the Case!
