# Therianthrope

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Therianthrope](https://the-eminence-in-shadow.fandom.com/wiki/Therianthrope)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Therianthrope?action=edit).

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Therianthrope (獣人, Jūjin[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the races in the world of The Eminence in Shadow. They have a human-animal hybrid appearance, typically having a human body with animal ears, lot of fur and tails.

They have a wide variety of different tribes. However, about 80% of them are people whose inherent abilities are their physical strength.

## Culture

## Power & Abilities

Therianthropes have greater physical ability, sharper senses, better reflexes, higher amounts of magical power, longer life spans and higher fertility rates.

The Therianthropes are a diverse race. There was a Therianthrope tribe with intelligence. The fox tribes are famous for their cunning intellect.

Tribes are always looking to others first. But when the supply line extends, those with the right mind took care of themselves. But powerful Therianthropes abuse them as cowards and attack them.

## Species

- Dog
- Fox
- Cat
- Rabbit
- Wolf

## Notable Tribes

- Spirit Fox Clan (妖狐族, Yōko-zoku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets"))
- Great Wolf Clan (大狼族, Ō Ōkami-zoku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets"))
- Golden Leopard Clan (金豹族, Kinhyō-zoku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets"))
- Lakshmi Clan (吉祥族, Kisshō-zoku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets"))

## Known Individuals

- [Delta](Delta.md "Delta")
- [Zeta](Zeta.md "Zeta")
- [Yukime](Yukime.md "Yukime")
- [Natsu](Natsu.md "Natsu")
- [Kana](Kana.md "Kana")
- [Zabra](Zabra.md "Zabra") (Deceased)
- [Gettan](Gettan.md "Gettan") (Deceased)
- [Shiva](Shiva.md "Shiva") (Deceased)
- [Iota](Iota.md "Iota")
- [Lily](Lily.md "Lily")
- [Pi](Pi.md "Pi")
