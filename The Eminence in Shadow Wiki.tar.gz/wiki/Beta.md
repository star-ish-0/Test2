# Beta

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Beta](https://the-eminence-in-shadow.fandom.com/wiki/Beta)

[Chronology](Beta-Chronology.md "Beta/Chronology")

[Relationships](Beta-Relationships.md "Beta/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | The clouds cascade over the moon tonight. How fitting for us. | ” |
| — Beta, Light Novel Volume 01 | | |

## Beta

- Light Novel
- Manga
- Anime
- Game

### Japanese

ベータ

### Romaji

Bēta

### Aliases

Beta the Steadfast
Natsume Kafka (Public Identity)
xXxSilverhairedElfBabeXx (Online)

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

15

### Height

Unknown

### Hair Color

Silver

### Eye Color

Blue

### Birthday

October 27

## Personal Information

### Status

Alive

### Relatives

[Duet](Duet.md "Duet") (Ancestor)

## Professional Information

### Occupation

- 2nd Seat of the Seven Shadows
- Author (Public Cover)

### Affiliation

Shadow Garden

## Debut

### Web Novel

Chapter 4

### Light Novel

Volume 1

### Manga

Chapter 2

### Anime

Episode 1

### Game

Episode 1

## Portrayal

### Japanese

[Inori Minase](https://inoriminase.com/)

### English

[Annie Wild](https://www.anniewild.com/)

### French

Emilie Marié

### Italian

Laura Cherubelli

### German

[Anna Ewelina](https://anna-ewelina.com/en/home/)

Beta (ベータ, Bēta[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Βήτα) is the third initial member of Shadow Garden and the second seat of the Seven Shadows.[[1]](#cite_note-V1C1-1) Functioning as an archivist, she accumulates information through research or pilfering.[[2]](#cite_note-V3C2-2) Her public identity is Natsume Kafka, a renowned author whose novels are stories from Earth—recounted to her by Shadow and distributed without his knowledge or permission.[[3]](#cite_note-V2CP-3)

## Appearance

Beta is a young, voluptuous [elf](Elf.md "Elf") with blue irises and a beauty mark underneath the corner of her left eye. She keeps her silver hair shoulder-length with an accent braid on the left.

Her Shadow Garden uniform is a cutout dark slime suit with golden decorations around her chest, shoulder, arms, and waist. Beta's collar is styled with shoulder guards that latch onto two ribbon capes, each ending with golden clasps adorned with tassels. The sleeves are black with matching bracers and gloves. Below the neckline, two golden stripes run parallel to a black belt with golden buckles. The legs on the suit are asymmetrical—a single belt loops around her right thigh with no ornamentations on the left thigh.

As Natsume Kafka, Beta's civilian attire comprises of a white ruffled top, a high-waisted mid-thigh skirt, black tights, heels, and a scarf that wraps around her body. Beta frequently wears glasses for Natsume's responsibilities and general writing. Her appearance has been described as beautiful by many others.[CITATION NEEDED]

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Under the moonlight, she smiles innocently—as if she’s a lovely flower fraught with danger in the night. Beta has no doubts. If it would make him happy, she would even walk down the path of evil. | ” |
| — Light Novel Volume 01 | | |

Beta is a dedicated and loyal subordinate to Shadow Garden with the intent of pleasing Shadow. She has articulated her devotion towards him, accepting all theoretical paths, including one of evil. Beta will unhesitatingly sacrifice herself for the mission or things she deems valuable to Shadow.[[1]](#cite_note-V1C1-1)

Her internal dialogue is antithetical to her personal demeanor presentation. She maintains an air of sophistication and serenity when conversing with others, not expressing her genuine thoughts and saving outbursts for private moments. Miss Natsume is an extension of her public persona as a calm and humble young woman to her adoring fans.[[4]](#cite_note-V2C1-4)

Shortly after joining Shadow Garden, Beta's lack of direction and motivation made it difficult to become desensitized to bloodshed. Violet physical reactions and trouble sleeping were common occurrences. Cid later recounted to Beta tales from Earth—her favorites were Cinderella and Snow White. A self-proclaimed bookworm, she found solace in Shadow's bedtime stories. Over time, Beta conquered her trepidation and found a reason to fight, forever grateful to Shadow for the wisdom he bestowed.[[1]](#cite_note-V1C1-1)

## Powers & Abilities

Beta demonstrates proficiency in many combat-related fields while never reaching any degree of mastery. [[5]](#cite_note-5) Although indifferent to combat, seeing it as a means rather than a passion, fellow members recognize Beta as the closest to replicating Shadow's fighting style amongst the Seven Shadows, a feat that earned her the moniker of Beta the Steadfast. Content with her comparative average performance, Beta's true specialties lie outside the battlefield, handling numerous Shadow Garden intelligence operations and deconstructing literary information.[[6]](#cite_note-6)

### Swordsmanship

Beta is an experienced swordswoman, one of the seven direct pupils under Shadow. Her fencing performances are limited relative to other Shadow Garden personnel; however, she has engaged and survived prolonged exchanges against powerful monsters and senior Cult members.

#### [Game] Archery

The sword is not Beta's only weapon for engagement. Emboldened by Alpha's promotion of adapting personal techniques, she abandoned the vanguard position and took up a compound-like bow made of slime. Her archery focuses on ranged support and bombardment. She has exhibited precision in exactitude, but piercing attacks against high magical enforcement remain inadequate.

### Magic

Irrespective of her relative capacity towards the Seven Shadows, Beta's magic ability dramatically surpasses the average Midgarian magic knight. Control over internal magic circulation is sufficiently adept at preventing further degradation by forced demonic possession relapse—magic overlord.[[2]](#cite_note-V3C2-2)

### Physical Capabilities

Beta has demonstrated proficiency in body reinforcement, increasing her endurance. After magical reinforcement, her body becomes impenetrable to modern firearms and can endure rapid attacks from significantly more powerful opponents.[[7]](#cite_note-V4E-7) Beta is also capable to stop a punch from a First Knight state Akane Nishino with one hand.[[8]](#cite_note-V6C5-8)

### Intelligence

As one of the academic Seven Shadows, Beta's Shadow Garden administrative role manages intelligence assimilation and discernment. Frequently employed in the field, she has developed versatile faculties, utilizing everything from strength to sex appeal.[[2]](#cite_note-V3C2-2)[[4]](#cite_note-V2C1-4)

Reflective of her role in Shadow Garden, Beta has shown proficiency in linguistics. She is fluent in several Other World languages—modern and dead.[[4]](#cite_note-V2C1-4)[[9]](#cite_note-P1C10-9) Regarding learning new languages, slight immersion and exposure are adequate circumstances for her to learn foreign languages—even from another world. Beta could roughly communicate in Japanese after a few days had elapsed. According to Cid Kagenou and No. 712, her Japanese has improved, but it remains crass and ineloquent.[[7]](#cite_note-V4E-7)[[8]](#cite_note-V6C5-8)

### Weapons and Equipment

- Slime Bodysuit: per the Shadow Garden standard, Beta is equipped with a Slime Bodysuit based on Shadow's original design, improved and upgraded upon by Eta.
- Slime Weapons: her weapon in the game is a bow and arrows created using slime.

## Trivia

- Beta is secretly writing a book titled The Chronicles of Master Shadow, a recounting of Shadow's escapades. It is a popular series among the Shadow Garden ranks.[KAGEJITSU ONLY][[10]](#cite_note-10)
  - The transcriber has taken creative liberties and changed some elements, such as describing the princess who Shadow rescues as an "elf with silver hair and a mole under her blue eyes.
- Beta shares her pen name, Natsume Kafka, with the real word Japanese author [Natsume Sōseki](https://en.wikipedia.org/wiki/Natsume_S%C5%8Dseki "wp:Natsume Sōseki") (1867–1916) and the Austria-Hungarian—now the Czech Republic—author [Franz Kafka](https://en.wikipedia.org/wiki/Franz_Kafka "wp:Franz Kafka") (1883-1924).
- Beta's participation in the assault on Midgar Academy for Dark Knights is a manga exclusive appearance. In all other adaptations, [Gamma](Gamma.md "Gamma") was the only available Seven Shadow.[[11]](#cite_note-11)
- Beta used a push-up bra made by [Eta](Eta.md "Eta") to increase her breasts further when she was in her Natsume alias.[KAGEJITSU ONLY][[12]](#cite_note-12)

## References

1. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
2. Volume 3 Chapter 2: Storming the Crimson Tower!
3. Volume 2 Prologue: To Lindwurm, the Scared Land!
4. Volume 2 Chapter 1: Fun Times at the Goddess's Trial!
5. Volume 2 Chapter 3: When Things Get Boring, It’s Time for Explosives!
6. Volume 4 Chapter 3: Crashing the Ceremony!
7. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
8. Volume 6 Chapter 5: Welcome to the Shadow Garden!
9. Seven Shadows Chronicles Part 1. Chapter 1-10, Episode 2
10. KAGE-JITSU! Operation 2: The Seven Shades Want to Perfect an Amazing War Chronicle!
11. Manga Chapter 12
12. KAGE-JITSU! Operation 16: The Seven Shadows Want to Put on Amazing Underwear!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • **Beta** • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
