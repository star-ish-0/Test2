# Juggernaut/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Juggernaut/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Juggernaut/Chronology)

[Main](Juggernaut.md "Juggernaut")

[Relationships](Juggernaut-Relationships.md "Juggernaut/Relationships")

Image Gallery

## Background

## Volume 3

### Red Moon Incident

#### Manga/Light Novel

He is first seen during the Red Moon Incident, where he rushes towards the Crimson Tower because some of his men were attacked by [Ghouls](Ghouls.md "Ghouls") and [Vampire](Vampire.md "Vampire"). On the way, he has a brief confrontation with [Yukime](Yukime.md "Yukime") until Shadow intervened the fight, where he threatens to kill them before changing his mind and heading to the tower. Before entering, Juggernaut ran into White Demon and was passed over him after he found out who he really was, followed by Yukime before Shadow killed him.

Once inside, Juggernaut is seen interrogating the vampire for [Crimson](Crimson.md "Crimson")'s whereabouts and decides to kill him as he would tell nothing before attacking Claire and [Mary](Mary.md "Mary"), even able to overpower them and nearly kill them before getting defeated by Shadow who swiftly kicks him, causing him to smash through the wall. Unfortunately, the wall leads outside which resulted in him falling towards the bottom of the tower while cursing Shadow for his interference.[[1]](#cite_note-V3C2-1)

Juggernaut is able to climb back up the tower just in time to battle the Blood Queen, [Elisabeth](Elisabeth.md "Elisabeth"). However, due to her immense amount of magic, he gets severely injured and becomes unable to fight her. However, Shadow later arrives and is able to defeat her.[[2]](#cite_note-V3C3-2)

#### Anime/Game

The events remain almost the same, except that Juggernaut saw a brilliantly fast fight between Shadow and Elisabeth while he complained about why Shadow fought in the air and after Shadow healed everyone present in the Lawless City, the A few days after the event, Juggernaut returns to his territory of the Black Tower, talking to himself while drinking in his office, thinking and believing that he could have a lot of fun going to fight against Shadow and his organization.[[3]](#cite_note-3)

### Great Trading Company Conflict

During the spread of counterfeit while there is a feud between Mitsugoshi Company and the Major Corporate Alliance, Cid sends [Delta](Delta.md "Delta") to Lawless City when she learns of his true identity as "John Smith" to kill Juggernaut in order to avoid damaging his plans, which he presumed to be dead at the hands of Delta.[[4]](#cite_note-V3C6-4)

## References

1. Volume 3 Chapter 2: Storming the Crimson Tower!
2. Volume 3 Chapter 3: Pursuing the Blood Queen!
3. Episode 23
4. Volume 3 Chapter 6: Circulating Counterfeit Cash!
