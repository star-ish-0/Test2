# Yukime/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Yukime/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Yukime/Chronology)

[Main](Yukime.md "Yukime")

[Relationships](Yukime-Relationships.md "Yukime/Relationships")

Image Gallery

## Background

### Beginning of Losing Everything

Yukime is born to the daughter of the Spirit Fox tribe's leader. One day when Yukime was age 14, a rival therianthrope tribe (presumably one of the invaders sent by the Cult of Diablos) invaded the village, and she was about to be taken by them as a slave. That is until [Gettan](Gettan.md "Gettan"), the son of the Dire Wolves' Elder, rescued her and slaughtered the attackers. Yukime and Gettan fell in love ever since then. The Spirit Fox and Dire Wolf tribes chose to form an alliance to better defend themselves against the upcoming war by having Yukime and [Gettan](Gettan.md "Gettan") get married which is something both of them were happy to comply. However, Yukime had to reach the age of 15 before they could officially get married.

When the war had occurred, both tribes fell victim with only Yukime and [Gettan](Gettan.md "Gettan") the only survivors. While Yukime tried to comfort her fiancée, [Gettan](Gettan.md "Gettan") pushed Yukime away and revealed that he tried to save their tribes by gaining aid from a Cult but Yukime's mother refused leading to [Gettan](Gettan.md "Gettan") murdering her. Yukime tried to flee but unfortunately, [Gettan](Gettan.md "Gettan") brutally attacked her and left slashed marks on her backs. Just as Yukime was about to be killed by Gettan, a mysterious figure intervened in blocking his intentions while she was unconscious but felt the figure's magic healing her wounds.

When she woke up, Yukime finds that her wounds have healed and realizes that Gettan has disappeared, but that's not all because she sees the invaders have been killed. Yukime walks to her village which has been scorched by the aftermath of the war and found her mother's corpse, confirming what Gettan had done. With her hometown gone after the loss of her mother and tribe, Yukime only had grudges against her former fiancée and vowed to get revenge on him for what he did.[[1]](#cite_note-V3E-1)

### Quest for Vengeance

Driven by severe rage and grieve, Yukime began to seek revenge on Gettan ever since then after losing her mother and tribe by gathering strength after leaving her burned hometown. But with no money, power, or relatives, Yukime spend her days traveling from place to place as a battle prostitute and working her way up.

By the time she turned seventeen, Yukime's hard work has finally paid off after she became the White Tower Monarch in the Lawless City and owning countless brothels in the red-light district. For years, Yukime kept watch on Gettan's activity before enacting her revenge.[[1]](#cite_note-V3E-1)

At some point, Yukime also founded Snow Fox Corporation and ran her business that operates outside the Lawless City.

## Chronology

### Red Moon Incident

Yukime took part in fending off the [Vampire](Vampire.md "Vampire") and [Ghouls](Ghouls.md "Ghouls") forces during the Red Moon to protect her girls that she is not wanting to lose any more girls again as several of them have been killed. On the way, she has a brief skirmishing with a battle crazed [Juggernaut](Juggernaut.md "Juggernaut") before Shadow arrived and the three agreed to work together in stopping [Elisabeth](Elisabeth.md "Elisabeth")'s revival and the resurgence of vampires. Before entering, Yukime ran into White Demon and was passed over him after he found out who she really was, since Juggernaut open the Crimson Tower gate before Shadow killed him.[[2]](#cite_note-V3C2-2)

Once inside, Yukime is able to reach the tower room top floor just in time to battle the Blood Queen, [Elisabeth](Elisabeth.md "Elisabeth"). However, due to her immense amount of magic, she gets severely injured and becomes unable to fight her. However, Shadow later arrives and is able to defeat her.[[3]](#cite_note-V3C3-3)

After the crisis was averted, Yukime heard news about the conflict that had occurred in the Midgar Kingdom. Knowing that [Gettan](Gettan.md "Gettan") was involved in the conflict plus her thought about Shadow that single-handedly stopping Elisabeth's rampage, Yukime decided that this is the right time to get revenge on her ex-fiancé for his actions that caused her everything.

Therefore, Yukime asked [her](Natsu.md "Natsu") [servants](Kana.md "Kana") to secretly invite Shadow to her White Tower since she believed that he is still in the Lawless City by giving him a proposition, aiming for an alliance between the two of them after witnessing his strength which would later be useful for her revenge plan.

### Great Trading Company Conflict

Soon after, Shadow receive Yukime's invitation and comes to visit her as she informed him of the detail situation regarding Mitsugoshi Company and the Major Corporate Alliance have currently been engage in a covert trade war at Midgar Kingdom, then tells him that a confrontation between the two major trading company firms is a lucrative business proposal for gaining a huge profit, plus telling Shadow that Yukime also ran a company on her own called Snow Fox Corporation.

Yukime secretly invited Shadow intending to propose an alliance to him for assisting her in executing the plan to deliver a huge blow after both sides have been weakened whilst waiting for the right time, without telling him her real reasons. Shadow went on Yukime request and ended up agreeing to help her, on the condition that will help him get a new outfit so as not to revealing his identity to which Yukime agreed, accompanied by her favor of handing over [Gettan](Gettan.md "Gettan") who is a leader of the MCA to her.

When the battle dispute between the two corporations still continues in vying for power, Yukime and Shadow, now taking the identity of "John Smith" devise ways to usurp both factions. It was at that time that Shadow proposed to cause a "counterfeit note" to Yukime, which is different from her original plan and after she understood how credit works as such, she agreed to his plan.[[4]](#cite_note-V3C4-4)

Following their conversation, Yukime orders her workers to build a counterfeits printing factory at the empty hideout that Shadow suggested located between the Midgar's royal capital and the Lawless City which was originally a secret underground facility where Shadow's older sister, Claire Kagenou has been detained long ago and immediately begins in manufacturing counterfeit money to spreading the MCA's fake bills at the citizens and carrying the stolen gold from the capital to the Lawless City, which serves as a natural barrier to avoid being investigated before being brought to a base safely which already hidden with Yukime handling the money by organize them in the vault, while Shadow is tasked with protecting the carriage transport line of counterfeits’ distribution chain under the identity as "John Smith".[[5]](#cite_note-V3C5-5)

As time passes, Yukime and Shadow celebrated the success in their plan which had paid off with all the gold coins collected so far until it was then that Yukime decides to retell him the story about her past and revealed to Shadow that the reason for requesting his aid was to get revenge on Gettan who had destroyed her life by killing him. After their victory is assured, Yukime confronts [Gettan](Gettan.md "Gettan") and the two former lovers' battle. Despite being in her most powerful state, Yukime lost the fight. Thankfully, Shadow arrives to turn the tide and declaring to [Gettan](Gettan.md "Gettan") that Yukime was special to him. This touches Yukime, believing that Shadow came to her aid out of love for her.

Following Gettan's death and Shadow healing her past wounds, Yukime then heads to the hideout to allocate the money kept in the vault while leaving Shadow who at the time is taking care of something which she thoughts that Shadow is digging a grave for Gettan. It was then that Yukime was surprised that the money that had been collected had disappeared until suddenly she was surprised by the arrival of [Alpha](Alpha.md "Alpha") from Shadow Garden to inform her that all the gold coin that was in the vault had been taken by them and Alpha's goal to meet Yukime was to give her an open letter regarding from Gettan's will that is addressed for Yukime containing an apology to her along with all people of her tribe in the village, accompanied by curses on his own weakness and revealing the true identity of the organization which were responsible for Gettan's actions that set him along his path till Yukime then learns that the real perpetrator who had ruined her life was the Cult of Diablos.

By the time Yukime comprehends this shocking revelation, Alpha also tells her that the Cult is Shadow Garden's nemesis who is currently fighting off against, even unveiling that Mitsugoshi is Shadow Garden's front. Upon hearing her statement, Yukime had come to a realization while Alpha surmised that all the course of events which transpired so far had been according to Shadow's prediction which already played out exactly how he wanted it to from the very beginning as he sets his plan into motion by leveraging her partnership in raising money to help Mitsugoshi through a credit crisis.

Grateful that Shadow saved her twice, Yukime chooses to ally with Shadow Garden under her desire to end the Cult of Diablos when she forge an alliance with the Snow Fox Corporation to forming a partnership with Mitsugoshi Company in cooperated for arrangements of managing and handling the dirty work, as well as acting as Lawless City's liaison for Shadow Garden.

### Mitsugoshi Once Land

Sometime later, Yukime along with her two guard followers, [Kana](Kana.md "Kana") and [Natsu](Natsu.md "Natsu"), attend the new Mitsugoshi hot spring hotel as guests, and throughout the day until nightfall, they spend their time enjoying the relaxation and the place, without intervene in anything, despite the problems or inconveniences that arise.[[6]](#cite_note-6)

## References

1. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fakes Bills!
2. Volume 3 Chapter 2: Storming the Crimson Tower!
3. Volume 3 Chapter 3: Pursuing the Blood Queen!
4. Volume 3 Chapter 4: I'll Destroy It All and Start from Scratch!
5. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
6. Episode 28

## Site Navigation
