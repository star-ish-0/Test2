# Yuudai Saejima/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Yuudai%20Saejima/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Yuudai%20Saejima/Chronology)

Main

Relationships

Image Gallery

## Background

Former student of Sakurazaka High School and classmate of Minoru and Akane, he was considered by many fellow students handsome and was popular except from Akane and Minoru who both viewed him as a brute. He was a member of the school's Judo club and competed in the nationals before Japan was invaded by magical beasts.

## The Birth of the Original Knight

Not many details were given of his whereabouts during the birth of the Original Knight. However, he was aware of the identity and would use it as leverage against her when possible. Sometime after the destruction of [Arcadia](Arcadia.md "Arcadia"), Yuudai would rose up into the ranks of the [Messiah](Messiah.md "Messiah") to Vice Commander and would eventually be bribed into the Alliance as their mole by [Yuuka](Yuuka.md "Yuuka").[[1]](#cite_note-V4E-1)

## Reunion

After Akane took Minoru into her care, Yuudai introduced himself and chastised her for taking him in and suggested that they should've left him for dead. The conversation between the two grew tense after the suggestion as the Vice Commander reminded her of their positions within the ranks of Messiah and reached a breaking halt when Akane protected Minoru from him. However, this enraged Yuudai as he revealed his knowledge of the Original Knight before leaving the two much to her denial.[[2]](#cite_note-V4C5-2)

Sometime after, Yuudai would break into Minoru's room and accused him of being a spy. He attempted to "interrogate" him until Akane stepped in to stop him. Yuudai leaves the room and reminds Akane that they had an emergency meeting later. During the meeting, Yuudai was shocked to see photographs of dozens of mangled magical beasts and demanded to know who's responsible of such feats. Initially, [Haitani](Haitani.md "Haitani") deducted that the Original Knight was responsible but concluded that there was another Knight of her caliber much to their relief.[[2]](#cite_note-V4C5-2)

During a magical beast stampede, the Messiah Knights were overwhelmed as Akane was almost killed when Shadow (who took on the alias "Black Knight") saved her alongside the group much to Yuudai's ire and suspicion of his affiliation. Yuudai would meet his end when he slipped off to the back of Sakurazaka Senior High to meet up with his Yuuka regarding intel she gave him. He was caught off guard and killed when the double agent shoots him multiple times before asking "why?".[[2]](#cite_note-V4C5-2)

## References

1. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
2. Volume 4 Chapter 5: Sneaking Around in Japan, Just like the Old Days!!
