# Nu/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Nu/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Nu/Relationships)

[Main](Nu.md "Nu")

[Chronology](Nu-Chronology.md "Nu/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

Nu has deep admiration and respect for Cid, after he gave her a second chance in life following her disownment by her family. After being by his side and observing his power and determination, Nu began to develop romantic feelings for Cid, once imagining that had she not been disowned, she would have Shadow as her lover. Her feelings for him are so strong that she would immediately brutalize and outright kill those that oppose him.

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

Being second in command, Nu deeply respects Alpha, following her orders to the best of her ability. In episode 28, when Nu said she wanted to go to the hot springs with shadow, alpha threw several daggers at her. which Nu dodged, clearly showing her possessive animosity to not let her get close to shadow, despite not acting this way with the other 7 shadows in the anime.

#### [Gamma](Gamma.md "Gamma")

Nu is Gamma's assistant and personal bodyguard, due to her intelligence and the latter's lack of fighting prowess. She greatly respects Gamma and will loyally carry out any of her commands, causing her to be surprised upon learning that her superior is actually younger than her.

#### [Delta](Delta.md "Delta")

Nu is usually in charge of Delta's care, such as feeding her and taking care of her personal appearance. Due to the difference in power, Delta usually bites Nu out of a therianthrope sign of affection and playfulness. Delta also listens to Nu sometimes as she direct Delta to certain decorum, as Nu may contact Alpha to discipline Delta otherwise.

#### [Eta](Eta.md "Eta")

### Numbers

#### [Iota](Iota.md "Iota")

#### [Lambda](Lambda.md "Lambda")

Lambda is Nu's senior in regard to time in Shadow Garden's service, as well as a senior in rank. Lambda is 11th of the Numbers, two steps above Nu's number 13, as well as having been a member since Shadow Garden's establishment when Cid was roughly 10 years old.

#### [Chi](Chi.md "Chi")

Chi is Nu's junior in Shadow Garden, as Nu joined at no93 before Chi originally joined at no111. Chi is also Nu's inferior in the ranking hierarchy-- Nu at no13 with Chi at no22. Yet both retain a positive and friendly relationship in service to Alpha and Gamma during active hours within Mitsugoshi. Chi even joked about Nu's paid leave on the opening day of the Mitsugoshi Hot Springs.[[1]](#cite_note-1)

#### [Omega](Omega.md "Omega")

Omega, like Chi, is Nu's junior in terms of time and hierarchy within Shadow Garden, as Omega was originally no122 before rising to Numbers at No. 24, the last of the Numbers.

### Regular Members

#### Rose Oriana (666)

Nu knows of the princess and likely encountered her during Rose's missions as no.666 for Shadow Garden. However, while Nu is aware of Cid's identity as Shadow and stands as Rose's superior officer, Nu is likely jealous of Rose having received her master's power directly.

#### Akane Nishino / "Akane Nishimura" (712)

## Others

### Claire Kagenou

### Marco Granger

Nu was once engaged with Marco back when she was a noble, Nicoletta Marquez. Despite their engagement being arranged by their aristocratic families, Nicoletta was neutral regarding her feelings to Marco, but she would have been nonetheless content with the arrangement. The arrangement did not last long because she developed the possession and her parents disowned her, setting her on the path to be found and revived by Shadow Garden.

When Nu and Shadow found Marco's unconscious body, Nu coldly told her unconscious ex-fiancée that if he ever learned a speck of truth of Shadow's identity, she wouldn't hesitate to kill him.

### House Marquez

As Nicoletta, she once loved her family and would fulfill duties and obligations without question. But as Nu, she grew to hate her family for abandoning her, abandoning them for her new family in Shadow Garden.

### Skel & Po

Nu has nothing but disdain towards the two. Not helping matters was that she was within earshot when Skel and Po made fun of Cid's failed relationship with Alexia Midgar. Nu would intentionally invited Cid to Mitsugoshi Company under the guise of a survey, while rejecting Skel and Po when they tried to join in, subtly mocking them as being unnecessary.

Her animosity towards them resurfaced once more in Episode 28, when she discovered Skel and Po possessing the hot spring tickets belonging to Cid, leading to her to have an intense interrogation on them. It's implied that if the two had not lied that the tickets were given to them by Cid, Nu would likely be ready to kill them on the spot.

## References

1. Episode 28
