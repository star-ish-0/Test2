# Earl Parton

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Earl%20Parton](https://the-eminence-in-shadow.fandom.com/wiki/Earl%20Parton)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Earl_Parton?action=edit).

## Parton

### Japanese

パロトン

### Romaji

Paroton

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Earl

### Affiliation

Oriana Kingdom

## Debut

### Light Novel

Volume 4 (Mentioned)

### Anime

Episode 30

Parton (パロトン, Paroton[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is an Earl from Oriana Kingdom.

## Appearance

## Personality

## Chronology

### Oriana's "Black Rose" Civil War Wedding

Earl Parton attends a staged to witness the performance of a student by the famous pianist, [Shiron](Epsilon.md "Epsilon"). After seeing the performance, Parton complimented his skills to have caught Earl attention and asked [Margaret](Margaret.md "Margaret") to get Shiron's student to work as her pianist with an annual salary of at least one hundred million Zeni.

## Powers & Abilities

Earl Parton is one of the most influential nobles in the Oriana Kingdom.

## Relationships

### [Margaret](Margaret.md "Margaret")

## Trivia

## References

## Side Navigation
