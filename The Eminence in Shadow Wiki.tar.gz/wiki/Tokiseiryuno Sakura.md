# Tokiseiryuno Sakura

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Tokiseiryuno%20Sakura](https://the-eminence-in-shadow.fandom.com/wiki/Tokiseiryuno%20Sakura)

Chronology

Relationships

Image Gallery

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Tokiseiryuno_Sakura?action=edit).

|  |  |  |
| --- | --- | --- |
| “ | I understand... but be careful, Lallanoa. This War of Succession will be chaotic. And the way the world looks at you is harsh. Please, at least keep your life. | ” |
| — Sakura talks to Lalanoa, Light Novel Volume 7 - Chapter 2 | | |

## Sakura

### Japanese

遠き清流のサクラ

### Romaji

Tookiseiryūno Sakura

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

13

### Height

Unknown

### Hair Color

Pink

### Eye Color

Pink

### Birthday

Unknown

## Personal Information

### Status

Alive

### Relatives

- [Alpha](Alpha.md "Alpha") (Same clan)

## Professional Information

### Occupation

Swordswoman

### Affiliation

Distant Clear Stream family

## Debut

### Light Novel

Volume 7

### Manga

Chapter 81

Sakura (サクラ[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the candidates for the war of succession for the elven throne and a member of the Tokiseiryuno clan which distanced itself from society a long time ago. Called to action by her old acquaintance Kikyo—now calling herself [Alpha](Alpha.md "Alpha")—she heads for the elven throne with the help of the Mitsugoshi Company.[[1]](#cite_note-:0-1)

## Appearance

## Personality

Sakura has shown to deeply care for Lalanoa to the point where she even considers Lalanoa to be her sister.[[1]](#cite_note-:0-1) She has also been stated by Lalanoa to be generally composed, kind and always giving of charity.[[1]](#cite_note-:0-1)

## Powers & Abilities

## Trivia

## References

1. Volume 7, Chapter 2

## Site Navigation
