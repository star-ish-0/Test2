# Midgar Academy for Dark Knights

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Midgar%20Academy%20for%20Dark%20Knights](https://the-eminence-in-shadow.fandom.com/wiki/Midgar%20Academy%20for%20Dark%20Knights)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Midgar Academy

### Japanese

ミドガル魔剣士（まけんし）学園（がくえん）

### Romaji

Midogaru Makenshi Gakuen

## Location Information

### Leader

Unknown Principal
Vice Principal Lutheran Barnett (Deceased)

### Status

Active

### Affiliates

Midgar Kingdom

### Type

Academy

### Government

Unknown

### Location

Royal Capital

### Inhabitants

Humans

## Debut

### Web Novel

Chapter 9

### Light Novel

Volume 1

### Manga

Chapter 3

### Anime

Episode 3

The Midgar Academy for Dark Knights (ミドガル魔剣士（まけんし）学園（がくえん）, Midogaru Makenshi Gakuen[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the most prestigious knight academy on the continent, which pulls talented students from both inside and outside of the Midgar Kingdom. This academy used to be a place where the demon [Diablos](Aurora.md "Aurora")'s right arm was sealed in the [Sanctuary](Sanctuary.md "Sanctuary") protected by hero [Lily](Lily.md "Lily") which was controlled by the [Fenrir](Fenrir.md "Fenrir") Sect faction territory.[CITATION NEEDED]

## Overview

The Midgar Academy is known as one of the top leading magic swordsman academies on the continent, where promising knights gather to hone their talents not only from Midgar Kingdom, but all over the world. In Midgar, all royalty and nobility must attend this academy as a formality. When the children of aristocrats with magical powers turn 15 years of age, they are obliged to enroll in the Academy when they begin to attend their education at a school in the royal capital for a period of 3 years.

There are disparities depending on the status and ability of the family, and those with high status and ability can live near the school, while the students of lesser status live in dormitories off-campus. The Academy itself is a massive building that apparently shares their campus with the Midgar Academy of Science, where they conduct scientific research with item development-- such as train engines or artifact studies.

## Uniform

### Male

The uniform for male students consists of a white shirt, a navy-blue blazer jacket with gold accents, a navy-blue tie, navy blue trousers, and a pair of shoes.

### Female

The uniform for female students consists of a white dress shirt under a cropped navy-blue cadet tunic with gold accents. The tunic has long sleeves, a standing collar closed by one clasp, an open front, and turned-back cuffs with a white gold-edged facing. A long black shoulder cape hangs from the shoulders. At the waist is a navy-blue corset belt with gold edging and a gold buckle, worn with a white pleated skirt trimmed in navy and gold. Footwear is either knee-high heeled boots with gold crisscross laces or loafers.

## Facility Layout

1. Dormitory: Where select students are permitted to live on campus for their stay.
2. Cafeteria: Large eatery area with quality food provided by Mitsugoshi Company.
3. Gymnasium: School training hall where students refine and perfect their sword and martial prowess.
4. Laboratory: Study location for learning magic through scholastic examination.
5. Research Facility: School building for studies into science or engineering.
6. Library: It’s an enormous resource shared between the academies for dark knights and sciences.
7. Arena: Where students can display their training progress for a crowd.
8. Infirmary: Recovery location for students injured from training or attacks upon the school.
9. Auditorium: Public gathering location for venues, from plays to presentations and more.

## Academic Personnel

### Staff

- Lutheran Barnett (Assistant Principal; Deceased)
- Zenon Griffey (Swordsmanship Instructor; Deceased)
- [Willow](Willow.md "Willow") (Head Librarian; Deceased)
- [Doctor Medi](Mu.md "Mu") (School Doctor)

### Students

- Claire Kagenou
- Cid Kagenou
- Alexia Midgar
- Skel Etal
- Po Tato
- Christina Hope
- [Nina](Nina.md "Nina")
- [Isaac](Isaac.md "Isaac") (Cult Infiltrator; Deceased)
- Suzuki Hope (Deceased)
- Eliza Despoht (Student Council Vice President; Deceased)
- [Kanade](Kanade.md "Kanade")

### Former Students

- Iris Midgar (Student Council President; Graduated)
- [Millia](Millia.md "Millia") (Presumed Deceased, later found alive)
- Sherry Barnett (Transferred to [Laugus](Laugus.md "Laugus"))
- Rose Oriana (Ex-Student Council President; Expelled)
- [Nicoletta Marquez](Nu.md "Nu") (Ex-Student)

## Trivia

- With the Cult of Diablos having staff and students as their inside sources, Shadow Garden followed suit with the assignment of [Mu](Mu.md "Mu") to the role of school nurse (useful for finding those with [possession](Possession.md "Possession"))
  - Zeta also has [Nina](Nina.md "Nina") undercover at the school to observe Claire Kagenou and Cid, but without Shadow Garden's hierarchy being aware of it.

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  **Midgar Academy for Dark Knights** | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • Alexia Midgar • Christina Hope • [Isaac](Isaac.md "Isaac") • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • **Midgar Academy for Dark Knights** • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
