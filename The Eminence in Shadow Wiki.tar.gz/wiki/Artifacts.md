# Artifacts

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Artifacts](https://the-eminence-in-shadow.fandom.com/wiki/Artifacts)

Artifacts (アーティファクト, Ātifakuto[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are items that were created by ancient magical civilizations.

## Functions

## Known Artifacts

- Eye of Avarice: The artifact that is able to absorb and gathering magic from its surroundings, which gains an immense magical power and curing its ailments by combining the artifact and the control unit to its full potential.[[1]](#cite_note-V1C6-1)
- Ring of Succession
- Invisible Blade: The long-lost Elven artifact sword, which is invisible to the naked eye.[[2]](#cite_note-V4C3-2)

## Trivia

## References

1. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
2. Volume 4 Chapter 3: Crashing the Ceremony!

## Site Navigation
