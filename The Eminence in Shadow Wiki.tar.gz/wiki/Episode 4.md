# Episode 4

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%204](https://the-eminence-in-shadow.fandom.com/wiki/Episode%204)

## Sadism's Rewards

### Kana

加虐への報酬

### Romaji

Kagyaku e no Hōshū

## Special Title

### English

The Eminence in Shadow Wants To Be Surrounded by Treasure Collections!

### Kana

陰の実力者は秘蔵コレクションに囲まれたい！

### Romaji

Kage no Jitsuryokusha wa Hizō Korekushon ni Kakomaretai!

## Episode Information

### Season

1

### Episode

4

### Air Date

October 26, 2022 JP

January 16, 2023 EN

### Adapted From

Volume 1 (LN)

## Staff

### Director

Hazuki Mizumoto

### Writer

Kunihiko Okada

### Storyboard

Hazuki Mizumoto

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Gamma ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Fencer Ordinaire | I Am... |

Sadism's Rewards (加虐への報酬, Kagyaku e no Hōshū[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the fourth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

The mistake those with power always make is believing that they are the ones in control.[[1]](#cite_note-1)

拉致されたアレクシアを救うため、王国最強の魔剣士と呼ばれるアイリスが陣頭指揮を執るが、手掛かりはなし。一方でシドは、“シャドウガーデン”の盟主シャドウとして、敵のアジトを急襲する。[[2]](#cite_note-2)

## Summary

Beneath the city in a labyrinth of passages, Alexia Midgar awakens chained in a cell as she realizes that all her four limbs are put Magic Sealing Chains while contemplating Cid's state and is shocked to see an entity of a humanoid monster in the next cell over. She nonchalantly concludes she has been abducted when a deranged man then arrives in a lab coat, excited to get "royal blood." Alexia passively greets him and wonders why he wants her blood, as the man states its demon blood and he will resurrect the demon. Alexia just accepts the motions of events, resorting to await her rescue soon enough.

Meanwhile, having been accused of kidnapping Alexia, Cid Kagenou is detained by the Knight Order and continuously beaten while questioned by the two interrogators, gleefully forcing him to reveal the princess' location. Enduring physical pain, Cid gets excited finding himself in such a classic minor character interrogation and decides to act the part properly so they don't outshine him. When the interrogator wanted to torture Cid with three large needles, Cid starts panicking while crying, even begging for mercy because he doesn't know anything. Feeling he is performing well, Cid continues to feign panic while quietly bored in his mind, wondering how long this act will take.

At the Academy, Zenon Griffey meets with Princess Iris Midgar with an update to the investigation. He also states how he feels responsible for her sister's kidnapping, to which Iris tries to reassure Zenon that no one will blame him in order to prioritize their search efforts to find and save Alexia. But as Iris wonders if a suspected responsible student named Cid Kagenou could be the most likely perpetrator, Zenon states that there is circumstantial evidence of a kidnapping against him, but there are doubts that Cid could have overpowered Alexia given considering his level of skill. Seeing reports that the student did not give any confession during the interrogation process after being undergoing torture for five days and the suspect's lack of testimony by only stating his innocence, Iris decides to release Cid with orders of continued surveillance upon his released.

Though agreeing with the necessary precautions based on the princess's assessment as long as Cid remains a suspect, Zenon is inclined in the hope of trusting Cid and Iris herself also prefers not to suspect Alexia's school friend with the two of them decide to waiting for the report before making a decision. Still anxious about her sister who was still kidnapped while looking at a photo of Alexia and Cid together, Iris reveals that she doesn't have enough personnel to look for her with Zenon saying that everyone knows about Iris' abilities which are stronger than average knights, but also makes herself a target due to her royal status as a princess and Iris was sure that the highest officials would have difficulty knowing what to do with her because of her unruly personality. Feeling understanding of Iris' feelings, Zenon is willing to help the princess in doing whatever she directed, with Iris orders to assist in maintaining order at the Academy as Zenon said that all students had been instructed not to go out and were asked to remain in the dormitory when there were no classes.

Outside the building, Claire wants to speak with the knights and profess Cid's innocence, but she is impeded by other students to not complicate the situation. After telling Zenon to continue to keep the students safe, Iris reflects on the worry she felt for Alexia when she saw Claire's reckless actions to ensure Cid's innocence, where everyone would care about family as Iris remember the time when she and her sister understood each other just by crossing swords until Alexia had started to distance herself from Iris, even didn't remember the last time they spoke ever since. As Claire refuses to listen, Rose Oriana is forced to intervene in stopping her by trying to lock her body and decide to put her on detention, but Claire soon escapes her obstacle by dislocating Rose's shoulder before more students move to restrain her.

Having no leads on Alexia, Cid who was still in his underwear is already freed when he was thrown out by his interrogators from the Knight Order building and threw all his confiscated belongings. In the evening, Cid, who is already dressed, took the train to his dorm while showing a tired expression on his face as he thought about healing his wound instantly, but didn't because it wasn't a background character's action and noticing two people who were actually an undercover knights that had been following him since leaving the Order building. Arriving at the train stop, Cid immediately got off the train and then two tailing knights also got out to pursue him until Cid passed a white hooded figure who is whispering to him in a low voice saying "later" and walk over him when Cid saw a long blonde hair as he continued walking which was then heard the sound of two people being neutralizes.

When he wanted to entering his room after arrive at the dormitory, Cid surprise to see [Alpha](Alpha.md "Alpha") shows up in his dorm room, dressed in an girls Academy uniform. Thanking her for being given a sandwich, Cid asked Alpha about her matters as he thought that today's task was Beta's turn to be his assistant, with Alpha saying that she came back because he had a call and heard that Cid was gotten into serious trouble, which he admits it. When Cid tries to ask how he is doing while eating a sandwich, Alpha tells him that Shadow Garden has grown into the most powerful organization thanks to their hard work efforts that have been made more progress in their investigations and gained many information on the Cult of Diablos, as well as explaining the organization's rising influence which is currently continue to steadily increased although not yet comparable to the Cult. Hearing everything Alpha said, Cid notes to himself that the girls are visiting him often while they are likely living normal lives, but is happy that they would occasionally stop by and still play his game to the point that Cid really appreciated the girls' intentions.

When Cid threw the sandwich wrapper under the trash after finishing his food and immediately lying on the bed, Alpha advised him to change clothes while she threw the wrapper in the trash and tried to remind Cid to understand the position he was currently in because he would be blamed for the crime if the problem left unchecked, by Cid declares that his status as the son of a poor Baron is suitable for being the perfect patsy. As Alpha starts to remove the attributes of his academy uniform, she elaborates that the Knight Order cannot be trusted with Cid saying whether the Cult infiltrated the Order and has confirmed that Alexia is indeed being kidnapped by the Cult with the intention of taking her blood from the royal family who have a higher concentration of hero's blood in their veins, even stated that the princess is still alive because if Alexia dies then the Cult can't extract any more of her blood.

However, Alpha does not understand Cid's reasons for deciding to have a relationship with Princess Alexia with him only responding that there is nothing romantic about it whatsoever. Alpha also understands this because she feels that Cid must be carrying a heavy burden on his shoulders, hoping he can trust their efforts with him, and Cid promises to show more trust in them. Switched to her Slime Bodysuit, Alpha tells Cid that he owes her a tuna sandwich once the case is resolved, as he ate hers, wanting to be treated to Tuna King, and for Cid to lie low in the dorms until she sends word when they were ready. Before leaving, Alpha asks Cid if he doesn't mind if the two knights who interrogated him want to be disposed of first, only for Cid to explain that they just did their jobs, smiling as he thinks they deserve a 'reward'. Although accepting his words, Alpha is available should he reconsider, and informs him that [Delta](Delta.md "Delta") is in the capital because she has been missed him, leaving Cid surprised to hear about this update.

Later that evening, Claire angrily wants to punish the knights who hurt Cid, but Rose once again stops her and forces her to return to her room. Once Cid, who had been waiting for the day after waiting for two days straight, prepared everything in arranging his room as he sets the room to befit the "Eminence in Shadow" by moving all the contents of the room into the storeroom, where he then took out an expensive wine, masterpiece paintings, antique lamp, and other expensive decor. Recalling his efforts to make money by hunting bandits and crawling to collect gold coins from Alexia, all of these actions Cid did to complete his 'Eminence in Shadow' collection, especially as well Cid give the final touch when he took out a letter that just arrived today and placed it on the table under wine bottle while he just waited for the right time.

As night falls, [Beta](Beta.md "Beta"), who had arrived, entered Cid's room and was amazed by the view of the entire room which looked magnificent and filled with a collection of luxury items until she heard Cid's words that the time has come, where tonight is a world of shadow when Cid drank wine from a glass. The excited Beta replied that the world of shadow is a night with the moon hidden which is indeed a suitable world for them and then explained that all preparations were ready and under Alpha's orders, Shadow Garden had gathered all available personnel in the capital, 114 people. When Cid is surprised to hear such number of people, Beta told him that only that said number of personnel could be deployed at this time and suddenly fell silent when slightly hearing Cid said they would hire extras, but decided to ignore it.

Beta explains that Shadow Garden planned to launch a simultaneous attacks on the Cult by carrying out a night raid on all the [Fenrir](Fenrir.md "Fenrir")'s sect faction hideouts spread across the capital while looking for traces of Alexia's magic at the same time and intending to secure the princess after being found, which then elaborates the roles taken by Alpha, [Gamma](Gamma.md "Gamma"), Delta, and [Epsilon](Epsilon.md "Epsilon"). When she wanted to inform about the formation of each unit, Cid stopped Beta's report when he showed her a letter which was given to Beta, where the letter came from the knights who interrogated him and also asked for his apology to Delta by stating that Cid himself would be taking her spot to start the prelude which then Cid walked towards the open window and turned around as the wind blew towards his room declaring the statement that "tonight the world will know us".

In the dark alley, two interrogator knights were waiting for contact with the surveillance team who had not yet provided observation report to monitor Cid, thinking they were playing somewhere until they thought that the team didn't know about the horrors of the Cult organization. When Cid intends to meet two knights who are waiting for him, they throw Alexia's boot at him and starts giving false justification by frame him as the perpetrator. Even though they wanted to arrest/kill Cid for kidnapping the princess when they finished their baseless accusation, Cid, who understood the knight's evil actions, casually gave a calm response as he then drops the bodies of the two men that were following him behind the knights much to their shocked and proceeds to kill the two corrupt knights by slashing them which makes one of the injured knights say to Cid that his fate is doomed when he doesn't realize that his life has already been sealed for antagonizing the Knight Order. However, when Cid turns into Shadow, he replied back on the corrupt knight before killing him by saying that everything will end at sunrise.

Beta, who was in a happy mood, wrote down Cid's actions that had thwarted the corrupt knight's attempt to frame him in the novel Chronicles of Master Shadow book and was suddenly interrupted by a loud noise heard across the city with Cid thinking that the distant sound made was from Delta, which marked the start of the Shadow Garden attack. Delta eliminates all the Cult members in one of the hideouts, even destroying it by splitting the building in two, while Alpha observes the progress of the Shadow Garden operation. Iris heard reports from her men about the situation of several ambushes that occurred in the city simultaneously at various locations until it was confirmed that there were eight demolition sites carried out in groups until several buildings were destroyed. Realizing that the situation become more complicated, Iris ordered the security team to focus on the Academy as she and her men headed to the scene to stop the chaos.

Somewhere at the underground lair, Alexia hears a commotion from above and tells her cellmates to wake up immediately because there will be fun until the Doctor rushes enter the princess' cell with his equipment, stating that "they" are coming to slaughter everyone. Guessing help came to save her, Alexia tries to tell him that the Knight Order does not kill without reason, but the man is not afraid of the knights and still babbles that he will kill them, perplexing Alexia. Terrified, the doctor takes the large syringe device, notes that he made a prototype and shifts his bloodshot eyes towards the creature which he claims that should work even on "failed result".

Upon desperately administering an injection while saying the name Diablos to demonstrate the power of the devil, the disfigured creature's body turns much bigger and stronger to which the mad doctor is blissfully amazed by the thrilling sight from the result of his prototype creation despite Alexia's warning, whereupon the creature then immediately kill the madman once free. To Alexia's surprise, the monster then cuts her chains and frees her. As the creature climbs out to rampage in the streets above, Alexia initially notes herself lucky before she finds the upward escape from the creature is sealed off by rubble.

While Alexia looks for an exit, she suddenly encounters Zenon at a sewer junction, who revealed his true colors to the princess by explaining that this hidden facility to him and he was the one who funded the doctor for his research. Although Alexia snarls in rage considering the week she spent as a test subject and was very irritated to find out that Zenon was the one who kidnapped her, but voices she's happy and glad that her guess was proven right about him as the princess always felt Zenon wasn't right in the head.

But nonetheless, Zenon still doesn't care about Alexia's assumptions as long as he have the princess' blood with him explaining that with her blood and the dead man's research, he will be guaranteed the Twelfth Seat in the Rounds and say goodbye to his ridiculous post as Swordsmanship Instructor. Just as Alexia thinks that the Rounds must be a group for lunatics, Zenon define her mark that the "Knights of Rounds" are the twelve highest ranking knights in the Cult who have wealth and fame that doesn't even compare to his current status of any status above most in society, even insulting the princess that he actually wants Iris to be made a more suitable reward but is satisfied with Alexia as his settle preferred choice.

Enraged by hearing his statement, Alexia attacks him but Zenon easily counters her sword swings as he insincerely apologized the princess' hate for being compared to her sister, Iris and belittling her abilities are mediocre that will never be more than a 'Fencer Ordinaire'. At that time Alexia angrily show Zenon just how "ordinary" she is by the time the princess increases her magic power energy to flow into her sword while using her sister's swordsmanship technique, which makes Zenon get a small wound from the attack. Surprised that Alexia didn't expect to be able to hide such power, it was then that Zenon had the opportunity to demonstrate the skills of a future Knights of Rounds as he easily disarms her before punching the princess into the sewer
water. As Zenon stands thinking himself superior as he tells a shocked Alexia that she will never be like Iris and forces her to come with him, Cid then walks up and appears in front of the two of them as he introduces himself as Shadow.

## Characters

- Alexia Midgar
- [Millia](Millia.md "Millia")
- Cid Kagenou
- Zenon Griffey
- Iris Midgar
- Claire Kagenou
- Rose Oriana
- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Gamma](Gamma.md "Gamma")
- [Epsilon](Epsilon.md "Epsilon")
- [Delta](Delta.md "Delta")

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第４話予告≪ノーマルVer.≫「加虐への報酬」

TVアニメ『陰の実力者になりたくて！』第４話予告≪スペシャルVer.≫「陰の実力者は秘蔵コレクションに囲まれたい！」

## Trivia

- Alpha's outfit for the dorm scene was the subject of conversation at Nexus. If the story had followed the light novel, she would have worn slime the entire time. The director, Kazuya Nakanishi, expressed that while lore-accurate, seeing Alpha in a tight bodysuit partially undressing and lying on top of Cid—an anime original scene—would be strange. Instead, they opted for the academy uniform. Nakanishi gave it a lore reason, declaring it was Alpha's method of challenging Princess Alexia's forced familiarity with Cid.[[3]](#cite_note-3)

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e004>
2. <https://shadow-garden.jp/1st/story/#story4>
3. [Director Notes: Episode 4](https://x.com/Shadowgarden_PR/status/1585466314352574464)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • **Episode 4** • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
