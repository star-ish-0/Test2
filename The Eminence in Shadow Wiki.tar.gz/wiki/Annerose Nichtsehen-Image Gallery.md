# Annerose Nichtsehen/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Annerose%20Nichtsehen/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Annerose%20Nichtsehen/Image%20Gallery)

Main

Chronology

Relationships

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Annerose to the Goddess' Trial

Annerose and Number 11 (Chi): They fight together against the members of the Cult

Wandering Swordswoman: Annerose Nichtsehen

Dedicated Sword: Annerose Nichtsehen

Event Game: Annerose gets angry with Goldy Gilden (remembering)
