# Divine Teachings

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Divine%20Teachings](https://the-eminence-in-shadow.fandom.com/wiki/Divine%20Teachings)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Divine_Teachings?action=edit).

Divine Teachings is the most popular religion in the world with one of its holy sites being located at [Lindwurm](Lindwurm.md "Lindwurm").

The divine teachings are a monotheistic religion which believes in the Goddess Beatrix as the one true deity who is said to have granted the heroes powers in the legends.
