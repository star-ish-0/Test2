# Shinobi

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Shinobi](https://the-eminence-in-shadow.fandom.com/wiki/Shinobi)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Shinobi?action=edit).

## Shinobi

### Japanese

シノビ

### Romaji

Shinobi

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- Viscount

### Affiliation

Thirteen Nightblades

## Debut

### Light Novel

Volume 6

### Manga

Chapter 70

Shinobi (シノビ, Shinobi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), also known as Viscount Shinobi, was a nobleman of the Midgar Kingdom and was the member of the Thirteen Nightblades.

## Appearance

## Personality

## Chronology

### Bloody Midgar Serial Murder Terror

He was tasked to assassinate [Kanade](Kanade.md "Kanade") and Christina Hope when the Thirteen Nightblades suspected that the Hope family hired Jack The Ripper to kill them however he ended up getting killed himself alongise [Marquis Jet](Jet.md "Jet") by Jack The Ripper.[[1]](#cite_note-1)

## Relationships

## Powers & Abilities

## Trivia

Viscount Shinobi's surname Shinobi means ninja in japanese.

## References

1. Volume 6 Chapter 2 - Surprise Assassins at the sleepover

## Site Navigation
