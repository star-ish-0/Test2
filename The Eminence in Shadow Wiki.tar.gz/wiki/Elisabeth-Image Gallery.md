# Elisabeth/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Elisabeth/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Elisabeth/Image%20Gallery)

[Main](Elisabeth.md "Elisabeth")

[Chronology](Elisabeth-Chronology.md "Elisabeth/Chronology")

[Relationships](Elisabeth-Relationships.md "Elisabeth/Relationships")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Vampire Progenitor: Elisabeth

Lady of Elegy: Elisabeth

Scarlet Blood Queen: Elisabeth

Game Event: Elisabeth and Aurora wearing a Yukata

Game Event Apocrypha: Elisabeth and Aurora

Apocrypha "Requiem for the Falling Shadow" Chapter 5: Demoniac Yukime and Elisabeth
