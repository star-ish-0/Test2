# Shiva

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Shiva](https://the-eminence-in-shadow.fandom.com/wiki/Shiva)

## Shiva

### Japanese

シヴァ

### Romaji

Shiva

### Aliases

Great Hero

## Characteristics

### Race

[Therianthrope](Therianthrope.md "Therianthrope")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Saurva (Lakshmi Clan's Tribe God)
Unnamed Daughter (Deceased)

## Professional Information

### Occupation

- Tribe Chieftain
- 5th seat of the Knights of Rounds (Former)

### Affiliation

Lakshmi Clan
Cult of Diablos

## Debut

### Web Novel

Chapter 132 (Mentioned)

### Light Novel

Volume 3 (Mentioned)

### Anime

Episode 26 (Mentioned)

Shiva (シヴァ, Shiva[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the late chieftain of the Lakshmi Clan. Therianthropes celebrate him as the "Great Hero" (大（だい）英雄（えいゆう）, Dai Eiyū[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets"))—the man who received the Beast God Saurva's blessing, and united the therianthrope lands under his domineering power. In reality, Shiva was the 5th Seat of the Cult of Diablos's Knights of Rounds. Despite possessing a strong position in the Cult, Shiva eventually abdicated his seat over the guilt of condemning his [possessed](Possession.md "Possession") daughter to a life of torment and experimentation. He later committed suicide by locking himself up inside a casket to live out the rest of his lifespan.[[1]](#cite_note-1)

## Appearance

An artistic representation has Shiva depicted as having four humanoid arms, nine fox tails, and a spotted deerskin-pelt loin cloth around the torso with a strap over his left shoulder. He is in a meditating Buddha posture with two hands in his lap, while the other two are aloft. The second right hand holding a Khakkhara staff with the Holy Teachings triangle sigil atop it and his second left hand holds a small drum.[[2]](#cite_note-2)[ANIME ONLY]

## Personality

## Chronology

## Relationships

## Trivia

- Shiva is named for the eponymous Hindu god of destruction, including features such as clothing and anatomy in his anime depiction.[CITATION NEEDED]

## References

1. Master of Garden Seven Shadows Chronicles, Chapter 34: Beast God and Fake Legends
2. Episode 26

## Site Navigation
