# Holy Sword

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Holy%20Sword](https://the-eminence-in-shadow.fandom.com/wiki/Holy%20Sword)

An immense powerful weapon that was used by [Olivier](Olivier.md "Olivier"), one of the Three Heroes, to cut down right hand of [Diablos](Aurora.md "Aurora").

## Overview

It is now located inside the [Sanctuary](Sanctuary.md "Sanctuary") with the purpose to cut down the chains that seal the core of the [Sanctuary](Sanctuary.md "Sanctuary"). However, Cid could destroy the chains easily with his "I Am the All-Range Atomic" move.

The ancient rune on the base that holds the sword are written as "Only the blood of the hero can pull out the sword". [Aurora](Aurora.md "Aurora") was surprised because Cid Kagenou can decipher the ancient runes in a mere moment, even though he just said it randomly.

The Diablos' right arm holding the Holy Sword is a popular souvenir of Holy City of [Lindwurm](Lindwurm.md "Lindwurm").

## Functions

## Curiosities

## References
