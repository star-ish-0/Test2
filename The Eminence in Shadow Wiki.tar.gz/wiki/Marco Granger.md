# Marco Granger

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Marco%20Granger](https://the-eminence-in-shadow.fandom.com/wiki/Marco%20Granger)

Chronology

Relationships

Image Gallery

## Marco Granger

### Japanese

マルコ・グレンジャー

### Romaji

Maruko Gurenjā

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Dark Blue

### Eye Color

Dark Blue

### Birthday

Unknown

## Personal Information

### Status

Alive

### Relatives

Nicoletta Marquez (ex-fianceé)

## Professional Information

### Occupation

Knight of the Crimson Order

### Affiliation

Knight Order (Formerly)
Crimson Order

## Debut

### Web Novel

Chapter 34

### Light Novel

Volume 1

### Manga

Chapter 10

### Anime

Episode 5

## Portrayal

### Japanese

[Rikuya Yasuda](https://en.wikipedia.org/wiki/Rikuya_Yasuda "wp:Rikuya Yasuda")

### English

Blake Weir

### French

Vincent Pierrard

### Italian

Mosè Singh

### German

Nino Kerl

Marco Granger (マルコ・グレンジャー, Maruko Gurenjā[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a knight of the Crimson Order and [Nu](Nu.md "Nu")'s ex-fiancé.

## Appearance

Marco is a handsome young man with a dark bluish hair matched with the color of his eyes.[[1]](#cite_note-V1C6-1) He used to wear a green Knight Order uniform, now wears the red uniform of the Crimson Order under Princess Iris Midgar.

## Personality

He has a strong sense of justice[[1]](#cite_note-V1C6-1) and holds steadfast commitment to his position as a knight. He was honored to serve in Princess Iris's new Knight Order and also demonstrated a connection to his fellow knights, such as visiting [Glen](Glen.md "Glen")'s grave after his death. He is also young and will often act his age, such as eating snacks from a maid outside a meeting between Princess Alexia Midgar and Sherry Barnett.

## Powers & Abilities

It is said that Marco is one of the strongest dark knights in the kingdom to which rumored that he will become the future commander of the Order.[[1]](#cite_note-V1C6-1)

Marco was among the first to join the Crimson Order after it's foundation; having be scouted by Princess Iris Midgar herself, and is a senior knight to any supplemental recruits.

## Trivia

## References

1. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School

## Site Navigation
