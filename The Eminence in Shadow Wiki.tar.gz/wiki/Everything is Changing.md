# Everything is Changing

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Everything%20is%20Changing](https://the-eminence-in-shadow.fandom.com/wiki/Everything%20is%20Changing)

## Everything is Changing

## Information

### Artist(s)

[Mayu Maeshima](https://mayumaeshima.com/)

### Composer(s)

Tomoyuki Nakazawa

### Arranger(s)

Tomoyuki Nakazawa

### Lyrics

[Mami Kawada](http://mami-kawada.jp/)

### Release date

November 16, 2023

Everything is Changing is the insert and the ending theme song for the seventh episode of the second season of the anime adaptation The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). The song was performed by Mayu Maeshima.

## Lyrics

- [Kanji](#)
- [Romaji](#)
- [English](#)

ふっ、と　浮かぶ白い息

すっ、と　溶けて消えた

そっと手繰り寄せたのは

遠い過去か…夢か？

手のひらがまだ少し

熱いような　冷めたような 痛いような…

握りしめていた指先がどこも指せず

見上げれば

無情に降る雪は季節を知らせるだけ

掴めないままに追い越してゆく時を

今は見送った

「そうだ…」

古い思い出が今日は優し過ぎて

そっと呟いた空を抜ける風

抱いてた

叶わぬもしもを思う

「このままに　あの時を…」

言いかけた

時の色彩は褪せてゆくものと知って

見渡せば

霞む街が白に埋もれて色を無くす

でもここにあると

胸に重ねた街の色とこの想い

あの日結んだ小さな約束

結び目が解かれるとき 気づくの

Everything is changing

見続けた夢の後を

すべて連れ去り舞う粉雪

散りばめた光 ただ見惚れてた時を


今は信じていたい

Futsu, to ukabu shiroi iki

sutsu, to tokete kieta

sotto te kuriyoseta no wa

tōi kako ka… yume ka?

tenohira ga mada sukoshi

atsui yōna sameta yōna itai yōna…

nigirishimete ita yubisaki ga doko mo sasezu

miagereba

mujō ni furu yuki wa kisetsu o shiraseru dake

tsukamenai mama ni oikoshite yuku toki o

ima wa miokutta

"sōda…"

furui omoide ga kyō wa yasashi sugite

sotto tsubuyaita sora o nukeru kaze

dai teta

kanawanu moshimo o omou

"kono mama ni ano toki o…"

ii kaketa

toki no shikisai wa asete yuku mono to shitte

miwataseba

kasumu machi ga shiro ni umorete iro o nakusu

demo koko ni aru to

mune ni kasaneta machi no iro to kono omoi

ano hi musunda chīsana yakusoku

musubime ga toka reru toki kidzuku no

Everything is changing

mi tsudzuketa yume no ato o

subete tsuresari mau konayuki

chiribameta hikari tada mihore teta toki o


ima wa shinjite itai

## Videos

「陰の実力者になりたくて！ 2nd season」 偽札編スペシャルムービー

Episode AMV

Everything is Changing

Music Track
