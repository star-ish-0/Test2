# Annerose Nichtsehen

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Annerose%20Nichtsehen](https://the-eminence-in-shadow.fandom.com/wiki/Annerose%20Nichtsehen)

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | I’ll admit it: You’re strong. | ” |
| — Annerose, to Mundane Mann, Light Novel Volume 02 | | |

## Annerose Nichtsehen

### Japanese

アンネローゼ・フシアナス

### Romaji

Annerōze Fushianasu

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

21

### Height

Unknown

### Hair Color

Blue

### Eye Color

Blue

### Birthday

September 19

## Personal Information

### Status

Alive

## Professional Information

### Occupation

- Member of the Seven Blades (Formerly)
- Swordswoman

### Affiliation

Velgalta Empire

## Debut

### Web Novel

Chapter 47

### Light Novel

Volume 2

### Manga

Chapter 15

### Anime

Episode 11

## Portrayal

### Japanese

[Shion Wakayama](https://en.wikipedia.org/wiki/Shion_Wakayama "wp:Shion Wakayama")

### English

Chelsea McCurdy

### French

Alice Orsat

### Italian

Giuliana Atepi

Annerose Nichtsehen (アンネローゼ・フシアナス, Annerōze Fushianasu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a powerful wandering swordswoman, hailing from the Velgalta Empire who was formerly a member of the Velgalta's Seven Blades.

## Appearance

Annerose is a beautiful woman with both blue hair and eyes with a slim built.

As a swordsman, she wears a dark blue armor with gold accents covering his shoulders and back, as well as a black cloth body armor that covers the chest along with a white cape that covered her back, white armor pants with dark blue accents, a pair of gloves and metal boots, and a light green headband with green gems. She also did not forget to bring her sword.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | You’d best give up now..., If you don’t, you’ll die. | ” |
| — Annerose, to Mundane Mann, Light Novel Volume 02 | | |

As a proud swordswoman, Annerose presented herself as cynical and aloof. When she first met Mundane Mann (Cid in disguise), she assumed that he was not skilled as a swordsman and condescendingly told him that. Despite this, she's a good person deep down and will step in to defend others, especially those she unwittingly placed in trouble.

However, she was passionate about swordsmanship to the extent that she left her home to become stronger. Alas, during the time she spent wandering the world, she had repeatedly failed to find and face any opponent that could match her skills, causing her love for swordsmanship to fade.

It was only when she met Mundane that she finally found a worthy opponent and showed she is capable of changing her opinion when facing him. Once that happened, she became confused and suddenly flustered whenever the two met. It was after her defeat at Mundane's hands that she regained the love for swordsmanship she had before she left her home.

## Powers & Abilities

Annerose is renowned for her skill with the sword, to the point where she earned a spot among Velgalta's Seven Blades before resigning from the position. During the Goddess' Trial, she was the only one, besides Shadow, who managed to defeat an ancient warrior's projection, which impressed even Cid himself.[[1]](#cite_note-V2C1-1) She was also a favorite to win the Bushin Festival tournament.[[2]](#cite_note-V2C7-2)

### Swordsmanship

Annerose is considered a prodigy at wielding a sword. She was so skilled that she went without a worthy opponent for the longest time until she met "Mundane Mann" after leaving her home. She was also able to see through some of his moves and was his first opponent during the Bushin Festival tournament to not be defeated in a single blow.

### Weapons and Equipment

- Battle Maiden Armor:
- Iron Sword:
- Training Weights:

## Trivia

- Annerose Nichtsehen can be attributed based on her characteristic personality.[CITATION NEEDED]
  - Annerose's surname Nichtsehen (Fushiana) means "cannot see" translates from both German and Japan, which is ironic, as she is the only one who notices the true might of Mundane Mann (Cid in disguise) yet simultaneously fitting as she is unable to follow Mundane's moves at all in their fight and thus underestimated him.
  - The first name Annerose means "favor; grace" in German, since she accepts defeat gracefully and takes the opportunity to train harder.
- In the specials of the manga, Annerose is seen putting on training shoulder pads, after her defeat against Mundane, not caring that said shoulder pads had spikes on the sides. This as such only appears in the manga, it will not appear in the anime, light novel, web novel, or the game.[ANNEROSE MANGA ONLY][[3]](#cite_note-MC25.5-3)

## References

1. Volume 2 Chapter 1: Fun Times at the Goddess's Trial!
2. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
3. [Manga](Manga.md "Manga"): Chapter 25.5

## Site Navigation
