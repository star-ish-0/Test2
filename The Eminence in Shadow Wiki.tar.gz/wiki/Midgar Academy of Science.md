# Midgar Academy of Science

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Midgar%20Academy%20of%20Science](https://the-eminence-in-shadow.fandom.com/wiki/Midgar%20Academy%20of%20Science)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Midgar_Academy_of_Science?action=edit).

## Midgar Academy of Science

### Japanese

ミドガル学術（がくじゅつ） 学園（がくえん）

### Romaji

Midogaru Gakujutsu Gakuen

## Location Information

### Leader

Unknown

### Status

Active

### Affiliates

Midgar Kingdom

### Type

Academy

### Government

Unknown

### Location

Royal Capital

### Inhabitants

Humans

## Debut

### Light Novel

Volume 1

### Anime

Episode 7

Midgar Academy of Science (ミドガル学術（がくじゅつ） 学園（がくえん）, Midogaru Gakujutsu Gakuen[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets"))

## Background

## Chronology

## Known Characters

### Staff

### Students

### Former Students

- Sherry Barnett (Transferred to [Laugus](Laugus.md "Laugus"))

## Trivia

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • **Midgar Academy of Science** • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
