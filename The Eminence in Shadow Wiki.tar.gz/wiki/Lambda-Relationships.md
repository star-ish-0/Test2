# Lambda/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lambda/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Lambda/Relationships)

[Main](Lambda.md "Lambda")

[Chronology](Lambda-Chronology.md "Lambda/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

Like the other members of Shadow Garden, Lambda shows great devotion and respect for her lord, as Shadow was the one who saved her by bestowing a new purpose through Shadow Garden's mission and witnessing what he was capable of achieving when he bested the Mist Dragon. Due to her duties training new recruits, Lambda has had little interaction with Shadow during their early days, when the organization was still less than one hundred strong, and even after the claiming of [Alexandria](Alexandria.md "Alexandria") as their official headquarters. Being a one of the Numbers, seated at no.11, Lambda has the exclusive privilege of knowing Shadow's true identity as Cid Kagenou, even having visited him at his home estate when he was a boy.

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

With Alpha as Shadow Garden's second-in-command and highest seated executive under Shadow, Lambda follows her orders loyally and carries out assigned tasks to the best of her ability. Lambda also provides her knowledge as a former Velgalta soldier when Alpha plans Shadow Garden missions internationally.

#### [Beta](Beta.md "Beta")

Lambda often relays to Beta, who leads coordination between squadrons and mission teams. Lambda's military experience also grants insight for Beta when determining the efficacy of specialized teams and the partners therein. As Beta is Lambda's superior officer and senior, Lambda gives all pertinent information immediately, so Beta has all the details she needs.

#### [Gamma](Gamma.md "Gamma")

Lambda relays intelligence and training reports to Gamma, who routinely employs new members as her staff in the Midgar capital. Given Gamma's zero coordination, Lambda also trains recruits best suited to aid her senior officer-- such as newer members [Nu](Nu.md "Nu"), [Chi](Chi.md "Chi"), and [Omega](Omega.md "Omega").

#### [Delta](Delta.md "Delta")

Lambda respects Delta as one of the Seven Shadows, even impressed with her heavy training that she always does. However, Lambda doesn't interact much with Delta aside from telling her where she can hunt her enemies under Alpha's orders.

#### [Epsilon](Epsilon.md "Epsilon")

Lambda hold a debt of gratitude and is close to Epsilon, who cured her of the possession symptoms. Epsilon always gave advice to her not to bear the burden alone and solve problems together, even tasks assigned by Alpha to manage the membership structure in the organization, which led to Lambda assigning units in trios. Lambda even trained Epsilon in aristocratic manners before her debut to becoming the pianist "Shiron," which benefited Epsilon in establishing her public persona and gave Shadow Garden a route for infiltrating areas controlled by nobility.

#### [Zeta](Zeta.md "Zeta")

Lambda has had little known interaction with Zeta, and her opinion of the wandering executive is unclear. However, similarly to Alpha, Lambda likely provides or receives intelligence from Zeta regarding international or intercontinental information.

#### [Eta](Eta.md "Eta")

Lambda respects Eta as one of the Seven Shadows and tries to help with her projects concurrent to building training grounds and residential quarters in Alexandria. Impressed with her genius, Lambda still feels somewhat fearful of Eta due to her "mad scientist" personality, similarly to other Shadow Garden members who know her.

### Numbers

#### [Iota](Iota.md "Iota")

#### [Nu](Nu.md "Nu")

Lambda is Nu's senior by a couple years, as well as her superior by two ranks and mentor. Lambda likely held great pride for Nu, originally number 93, for having impressed even Alpha and joining the Numbers at no.13. When Lambda told Nu to fight against 666, she told her to not show her mercy during their match, even though both of them are humans.

#### [Chi](Chi.md "Chi")

When she was still Karen von Herzog, Lambda knew of her when she was one of Velgalta's Seven Blades, and even advised her not to underestimate the highest officer in Shadow Garden. Lambda was also present when Alpha shared Shadow Garden intel, and Karen confessed more information to fill in their gaps. Lambda established a rapport with Karen and, after the latter's defeat by Alpha in combat, became her mentor after she officially joined as no.111.

She later developed some reservations regarding her when she learned that she was originally a member of the Cult of Diablos. During their time together, she made her dislike for her obvious, along with repeatedly reminding her that if she were to go against orders in the slightest, she would kill her on the spot. However, after she proved her loyalty to Shadow Garden, Lambda began to respect Chi and the effort that she had put in to turn a new leaf.

With her training, Lambda raised Karen through the numbers until she was seated as Numbers No.22, Chi.

Lambda would then coordinate missions with Chi's knowledge of the Cult for their advances. Given her specialty with infiltration and intelligence gathering, Lambda assigned Chi with [Omega](Omega.md "Omega") and [Epsilon](Epsilon.md "Epsilon") frequently-- notably infiltrating the [Sanctuary](Sanctuary.md "Sanctuary") of [Lindwurm](Lindwurm.md "Lindwurm").

#### [Omega](Omega.md "Omega")

The two know each other quite well as they were fellow instructors in the Velgalta military prior to either of them suffering from [Possession](Possession.md "Possession"). However, after they were both cured, their relationship took a turn for the worse as Omega continued to treat Lambda the same way as she did prior to being possessed. However, at this time, Lambda had already been promoted to a Numbers, while Omega was still a rank and file member, which annoyed Lambda to no end.

However, at Cid's recommendation, Lambda decided to let the matter go and allow Omega to continue to address her casually.

### Members

#### [664](664.md "664")

Lambda began instructing 664 around the time Cid Kagenou began his enrollment into the Midgar Academy for Dark Knights. Following the Bushin Festival, Lambda assigned 664 to lead a team with 665 and 666.

#### [665](665.md "665")

Lambda began instructing 665 around the time Cid Kagenou began his enrollment into the Midgar Academy for Dark Knights. Following the Bushin Festival, Lambda assigned 664 to lead 665 and 666.

#### Rose Oriana (666)

Lambda is interested in Rose and a little jealous because she inherited a beautiful sword technique that only Shadow and Alpha could master before joining the organization. In fact, Lambda thought Rose would surpass her and admitted to herself that Rose's potential could rise to become the strongest of the Numbers, possibly on par with Seven Shadows.

#### Akane Nishino / "Akane Nishimura" (712)
