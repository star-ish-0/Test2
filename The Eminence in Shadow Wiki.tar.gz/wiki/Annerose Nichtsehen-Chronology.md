# Annerose Nichtsehen/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Annerose%20Nichtsehen/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Annerose%20Nichtsehen/Chronology)

Main

Relationships

Image Gallery

## Background

Annerose was once one of Vegalta's symbolic Seven Blades, but she has abandoned the title name and is on a journey of training in search of her long desires to find a strong opponent that can match her skills. Unfortunately, years of not finding one leave her cynical and bored.

## Sanctuary Infiltration

Annerose was one of the participants who took part in the Goddess' Trial at [Lindwurm](Lindwurm.md "Lindwurm"), winning her duel against an ancient warrior spirit that was summoned to fight her, called [Borg](Borg.md "Borg").[[1]](#cite_note-V2C1-1)

## Bushin Festival Tournament

Days after the chaos in [Lindwurm](Lindwurm.md "Lindwurm") with the news of the [Sanctuary](Sanctuary.md "Sanctuary") being obliterated by Shadow, Annerose arrived at Midgar Kingdom's capital to participate in the Bushin Festival tournament for the first time. It was there that she met Mundane Mann who she perceives him as a weak swordsman. She tried to dissuade Mundane from participating out of concern, but this act unknowingly caused the other participants to harass Mundane. Initially, she withheld from taking action so Mundane would receive a harsh reality check but finally stepped in to defend the man when [Quinton](Quinton.md "Quinton") went too far in the assault. Annerose apologized to Mundane, but then observed that Mundane sports no visible wounds from the assault.[[2]](#cite_note-V2C4-2) Annerose then watch Mundane fight against Gonzales Machom on the qualifying thirds round match and saw that Mundane won the fight as she notices his strike by observing his movement.[[3]](#cite_note-3)

Curious about the dark horse, she, along with Quinton watched Mundane's match against Goldy Gilded in the qualifying fourth round. To their surprise and the shock of the entire audience, Mundane instantly won upon witnessing Goldy's humiliating defeat in an unconventional manner. While everyone ponders how this had happened, Annerose did noticed the methods Mundane did that allowed him to win his match. Unfortunately, this is met with laughter by Quinton as Mundane's ways are so over the top ridiculous to be possible.

The Vegalta swordswoman met up with Mundane after winning the qualifying final round by decisively take down Quinton and told him about their match-up together the day after tomorrow and that she knew how he won. Regardless of Mundane's skills, Annerose boasted that she's more than match for him as she already understands his fighting style. To her shock and surprise, Mundane merely scoffed at her and revealed that he had been holding back; having used weights during his entire run.[[4]](#cite_note-V2C5-4)

Once their match began, the two clashed but her attacks hardly faze him, and he was able to swat her aside. Annerose realized she was being fooled into thinking she could get an advantage and admitted she should have expected him to be skilled after seeing his true strength. She continued to attack but Mundane easily overpowers her and defeats her.

After the match, she gets medical attention and finds Mundane in the halls and talks with him, admitting defeat and thanking him for good battle. She inquired on his true identity, but he answers that he was only a wanderer who abandoned everything in search of power and Annerose said that she would return to Velgalta Empire and train from scratch, also asked Mundane if he would join her empire to become a great warrior though he refuses and walks off, despite her asking he do so if he changes his mind. Since Mundane left the venue before revealing his true identity, she does not know that he is Shadow.[[5]](#cite_note-V2C7-5)

In the anime, Annerose was seen leaving Midgar expecting Mundane to appear and didn't notice the battle between Shadow and [Beatrix](Beatrix.md "Beatrix") that was happening in her back.[[6]](#cite_note-6)

## References

1. Volume 2 Chapter 1: Fun Times at the Goddess's Trial!
2. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
3. Episode 15
4. Volume 2 Chapter 5: A Battle to Attract Only MVPs!
5. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
6. Episode 20
