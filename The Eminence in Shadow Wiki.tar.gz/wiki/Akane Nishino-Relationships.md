# Akane Nishino/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Akane%20Nishino/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Akane%20Nishino/Relationships)

Main

Chronology

Image Gallery

## Family

### Unnamed Parents

Akane's mother and father deeply loved and cared for her. After she was kidnapped during middle school, they had a driver wait for her to safely get between school and home. They cared for her enough to ensure she wasn't involved in another scandal after Minoru saved her by not going public with the case. They were also worried of her going to school the day after her second kidnapping.

In turn, Akane loved both her parents and clung to them after her rescue.

### Akira Nishino

Akane's older brother; despite being siblings, there was no familial affection between them. She was fully aware that he used her and her status as a "Knight" to advance his political agenda. He even went as far as to experiment on her by injecting her with blood from multiple Beasts, turning her into the "First Knight", though she initially had no memory of what he had done to her.[[1]](#cite_note-:3-1)

It is unknown if she discovered his death.

## Shadow Garden

### Cid Kagenou / Shadow (Minoru Kageno)

Minoru was Akane's classmate and savior in his previous life. Initially, Akane despised Minoru, not because he wouldn't remember her name but because he as she put it, "he never looked at her" albeit he technically turned his eyes at her and looked past her to set his sights elsewhere. She actively tried her best to avoid him and kept their conversations brief.[[2]](#cite_note-:2-2)

Upon her second kidnapping, a ski-masked vigilante rescued her. Before he left, the vigilante told Akane to be careful and not to get kidnapped. After the incident, Minoru finally paid attention to her and remembered her name. Akane was quite surprised by this and realized that like her, he was also masking his true self. At some point in time, Akane would spend some time watching him and figured out that he was the vigilante and developed immense romantic feelings for him.[[3]](#cite_note-:0-3) Akane who was scared of the eyes of people staring at her in the distance, also known as stalker, ironically becomes Minoru's stalker after he saved her from her second kidnapping. Alas, their relationship was cut short due to his death. Minoru's death deeply affected her to the point she kept his school uniform, yearning that he'll return years later.[[4]](#cite_note-:4-4) During her time in Messiah, Akane would often reminisce her time back in high school, and often fantasizes Minoru coming to save her again when things get tough.[[5]](#cite_note-5) But after reincarnating, Cid never knew what happened to her and his previous world.[[6]](#cite_note-6)

The two would meet again in his next life in an abandoned hospital when Cid and Beta accidentally traveled to [Earth](Earth.md "Earth"). After being found and taken to the Messiah, Cid used his name from his previous life when he was asked by Yuuka. Despite knowing that her savior had long passed, Akane was taken aback and noted the resemblance between the two. Sometime after, she decided to take him under her care out of suspicion that the resemblance had a correlation and an unknown feeling when she's around him as if she has known him forever. She would cry tears of joy when she gave his old school uniform when she saw him wearing it. She openly admits to Minoru (Cid) that she had spent a long time watching him, before and after her kidnapping, and a long time more before his death. As a result, Minoru being shuddered and questioned her being a stalker. And in the manga, as Cid (going as Minoru) spotted a dried blood on his old uniform's left wrist, the same spot where he beat up some thugs in his past life, he was surprised and asked inwardly why Akane kept his old uniform as a something precious to her (although in Light Novel, he brushed that thought off as if it is just his imagination).[[7]](#cite_note-7) She defended him when Yuudai Saejima suspected him to be a spy. After the death of her former classmate, Minoru in return came to her defense and investigated the incident. After a magical beast stampede, he confronted the nurse who revealed herself and the former student as the perpetrator and First Knight respectively.

During The First Knight vs The Black Knight, Akane stated that Minoru is her biggest inspiration to become a Hero, someone who could help many people in despair as how he did to her when she was kidnapped 3 years ago, and so she partakes in the First Knight Creation Project as a test subject.

Minoru, as Cid, would become Akane's savior again, after being forced into her First Knight state, she was returned to normal by the Black Knight who told her the same lines his past incarnation had said when he rescued her. After being brought to the Other World by Beta, she woke up to realize that the Black Knight was Minoru. Overjoyed to realize that he was still alive and that he hasn't changed, she yearned to reunite with him. After being again saved by her former classmate, she had come to terms with her past and vowed to atone for them before she could reunite with him once more.[[1]](#cite_note-:3-1)

Currently, Cid is unaware that Akane has been brought to the same world as him and joined Shadow Garden. While living in another world, Akane is unaware that Minoru had reincarnated as Cid Kagenou and that he is Shadow. When speaking to Beta, she had a familiar notion of Shadow Garden being a group taking matters in the shadows, being similar to Minoru. After meeting Eta, Akane had misunderstood and was enraged at Eta, when she showed her a note that Cid wrote, Akane was able to recognize his handwriting. After Eta tried to explain that she tried to perform experiments on him, Akane mistakenly believed that the accident was fake and that he was kidnapped and brought to another world and was experimented on by Eta in a harsher way just like her. Akane would vow to save him someday.

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

Shadow Garden's second in command. After Beta smuggled the former student into the Other World, Alpha reprimanded the elven and ordered her into her custody after she dreaded the various things Eta would do to her in her experiments.[[1]](#cite_note-:3-1) While discussing plans with Rose, [Gamma](Gamma.md "Gamma") dragged the mad scientist into reporting her research on the former student.[[8]](#cite_note-:5-8)

#### [Beta / Natsume](Beta.md "Beta")

Akane assumed the Natsume was an "Awakened" like her due to her silver hair and long ears.[[9]](#cite_note-:1-9) She was against her brother's custody of her and subconsciously realized that he was experimenting on her as he did on herself. Despite her protests, she was ultimately overruled and was forced to pray for her safety. She was later brought to the Other World by the elven under her care by Alpha's orders after she dreaded of the things [Eta](Eta.md "Eta") would do her in her dozens of experiments on an alien like her. Akane believes Natsume/Beta is the younger sister of Minoru (the name Cid used when he travelled back to Earth)

#### [Epsilon](Epsilon.md "Epsilon")

Whilst the two has never met until the former Knight's introduction into Shadow Garden, Epilson is aware of Akane's existence after Beta returned from Japan to report to both her findings and former Knight.[[1]](#cite_note-:3-1) Nevertheless, the elf was concerned for the new recruit and intervened when Eta wanted to run experiments on her after her introduction to the other members of the organization.[[10]](#cite_note-:6-10)

#### [Eta](Eta.md "Eta")

Shadow Garden's scientist: Alpha ordered Beta Akane into her care after dreading what the mad scientist would do to her.[[1]](#cite_note-:3-1) After being dragged by Gamma, Eta gave her report on the former student. She reported to Alpha that her language was incomprehensible and only Beta could understand her. She also added that she had a name and that she should stay under Beta's care.[[8]](#cite_note-:5-8) In her report, she noted that she shares the same biology as a human and her magic was underdeveloped. She lastly noted that the technology Beta smuggled in was impossible to repair and it'll take 20 years for the Other World's technology to possibly catch up with [Earth](Earth.md "Earth")'s.[[11]](#cite_note-11)

### Numbers

#### [Lambda](Lambda.md "Lambda")

Shadow Garden's drill instructor; Lambda is responsible for overseeing and training new recruits thus making her responsible for Akane's initiation into the organization. While the instructor is harsh towards Akane as equally as any other numbered members, the latter would take her time to save her now reincarnated classmate.

#### [Nu](Nu.md "Nu")

[Ganma](Gamma.md "Gamma")'s personal assistant, bodyguard, and fellow numbered member, neither Nu or Akane has ever directly interacted. However, this did not stopped Nu as she alongside other members assisted Beta in intervening Eta from running experiments on the new recruit.

#### [Chi](Chi.md "Chi")

#### [Omega](Omega.md "Omega")

### Members

#### [Millia](Millia.md "Millia")

Akane seems to be quite fond of Millia, mainly on the grounds of her being a hardworking little girl.

Akane was originally introduced to her during her tour of Alexandria.[[10]](#cite_note-:6-10) They were originally quite hostile to one another during their duel as they both believed they needed to win in order to prove their worth to Shadow Garden. However, when their fight resulted in a draw, they were both quite distraught at the result, but Akane decided to put her own feelings aside in favor of consoling the girl.[[10]](#cite_note-:6-10)

## [Messiah](Messiah.md "Messiah")

### [Yuuka](Yuuka.md "Yuuka")

Nurse for the Messiah and agent for the Alliance; Akane was betrayed by the nurse after she revealed herself as a survivor of [Arcadia](Arcadia.md "Arcadia") and sought revenge on the "First Knight". She did this by forcing her into going berserk by injecting [Brute's](Mordred.md "Mordred") blood in her, regaining her memories in the process. She was happily killed by the rampaging Akane after she was able to make her suffer with the recollections of her crimes. Unfortunately for her, the First Knight was instantaneously incapacitated and healed by Minoru. This allowed her to come to terms with her past instead of being sunken by it after being brought to the Other World by Beta.[[1]](#cite_note-:3-1)

### [Haitani](Haitani.md "Haitani")

The Knight commander of Messiah and thus Akane's superior; Haitani seemed to be one of the few people who Akane genuinely respected whilst he in return showed care and concern for the former Knight.

### Yuudai Saejima

The vice-commander of Messiah's "Knights" and Akane's former classmate; Yuudai repeatedly tried to coerce her into a relationship with him and was even willing to blackmail her with knowledge of her past. Akane on the other hand, not only held no respect for her superior but was utterly repulsed by him. The two also argued on various instances, such as him being critical of her for bringing more people into the already overcrowded Messiah and taking Minoru under her care.

In a fit of jealous rage and attempt at scapegoating, the former student confronted Minoru and accused him of being a spy before attempting to have him eaten by magical beasts. Enraged, Akane furiously intervened and defended Minoru. Due to her poor relationship with her former classmate, she was accused of murdering him when he was found dead in the aftermath of a stampede.[[12]](#cite_note-12) Unbeknownst to her and the Messiah, Yuudai was an agent for the Alliance who supported the actual spy.[[13]](#cite_note-13)

### Unnamed Squadron

Members within the Messiah's Knights; much of Akane's relation with her squad are yet to be elaborated. However, they have cared enough for her to accompany her to the abandoned hospital where the other missing members were. Despite her protest, she ultimately caved into their concerns and investigated the missing members where she protected them on numerous occasions. When they found Minoru and Natsume, Akane took the initiative in taking them in despite her squadrons' apprehension. When Akira reprimanded Akane for the investigation, she was willing to take responsibility for them stating that their accompany was under her orders. However, he saw through and knew that her squadron acted their own accord.[[9]](#cite_note-:1-9)

## References

1. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
2. Episode 1
3. Volume 4 Auxiliary Chapter: Rise of the Fancy Hoodlum Slayer!
4. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
5. Volume 4 Lurking in the Darkness in Fantastical Japan!
6. Volume 12 Chapter: 47
7. Manga Chapter 51
8. Volume 5 Chapter 4 The World is at Peace Today
9. Volume 4 Chapter 4: Lurking in the Darkness in Fantastical Japan!
10. Volume 6 Chapter 5: Welcome to Shadow Garden!
11. Volume 5 Eta’s Research Journal
12. Volume 4 Chapter 5: Sneaking Around in Japan, Just like the Old Days!!
13. Volume 4 Chapter 6: Something Smells Fishy... But an Eminence in Shadow Always Cracks the Case!
