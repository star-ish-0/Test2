# Nu/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Nu/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Nu/Chronology)

[Main](Nu.md "Nu")

[Relationships](Nu-Relationships.md "Nu/Relationships")

Image Gallery

## Background

### Tragic Life

Nu was once a noble daughter who dutifully followed the demands of her parents named Nicoletta Marquez from the Marquess Marquez family, which are the prestigious family that has produced gifted dark knights' generation after generation who are particularly well-known in the fields of interrogation and espionage.

She once attended the Midgar Academy for Dark Knights and was engaged to Marco Granger, content with the easy life her station afforded her. Nicoletta attended the pianist composer [Shiron](Epsilon.md "Epsilon")'s debut event which brought a very beautiful song with an elegant musical groove with her fiancé and met [Luna](Gamma.md "Gamma") as the president of the company that sponsored the event along with Shiron's debut.

But in a year and a half ago, Nicoletta had been suffering from the symptoms of [Possession](Possession.md "Possession"). When her parents saw that Nicoletta had developed these symptoms, they were horrified that her parents had to disowned her and imprison Nicoletta in the mansion's basement. Afraid that the information about their daughter's symptom case will reach the ears of some other noble families that they used this news to destroy their prestige class, the Marquez Family purchased a drug that erased all traces of magic in large quantities in order to cover up the traces of possession and be able to save their aristocratic face.

For 2 weeks, Nicoletta had been in the basement dungeon under surveillance and given very strict guard in the protection of the Cult of Diablos so that their targets could not be taken by the [Templars](Templars.md "Templars"). Two days later, the Marquez family had resolved everything in this matter themselves to deal with Nicoletta's condition by "officially" declaring her to have died suddenly due to illness and having held her fake funeral, with Marquess Marquez cast her out intending to pay the Cult to take their possessed daughter using the transportation route to travel [Lindwurm](Lindwurm.md "Lindwurm") as a convoy carriage under the guise of transporting artworks.

At night while on the way to the Sacred Land, the carriage carrying Nicoletta had been intercepted until all the Cult's escort in the convoy had been wiped out by Shadow Garden and brought Nicoletta to be taken to [Alexandria](Alexandria.md "Alexandria") to cure her symptoms while they are holding back the Templars. With her [Possession](Possession.md "Possession") already been healed by [Epsilon](Epsilon.md "Epsilon") and [Alpha](Alpha.md "Alpha"), Seven Shadows told the truth to Nicoletta until she swore allegiance to Shadow and brought her into Shadow Garden as 93.

Even though she recently joined the organization, her intelligence and fighting skills are recognized by the Seven Shadows, including [Alpha](Alpha.md "Alpha") herself validated her abilities which make her a valuable asset to the organization and having quickly risen through the ranks to become one of Shadow Garden's double-digit Numbers to which she earn a "Named" Rank no. 13 and becoming one of the Numbers when she would identify herself as Nu. Also, Nu was assigned and established a strong and direct relationship with [Gamma](Gamma.md "Gamma"), one of the original Seven Shadows, and become Gamma's direct subordinates.

## Volume 1

### Midgar Academy Terrorist Attack

Although the newest member at the time, Nu swiftly earned a Numbers rank and was recognized by Alpha herself and assigned to service under [Gamma](Gamma.md "Gamma"). Nu first appeared greeting Cid Kagenou and his friends outside the Mitsugoshi branch in the Midgar Capital, and led Cid to the executive residence where Gamma awaited their master. After being informed about the impostors, Cid decided to head out and Gamma formally introduced Nu to assist him. The two successfully captured one of the impostors, who Cid ordered Nu to personally deal with, and Nu proceeded to torture her captive, informing him that she wouldn't be as merciful as her master. She then hanged the corpse to deter any more impostors from attempting the same thing he did.

Shortly after, Nu disguised herself as a student and met her master as he was continuing as Cid at the Midgar Academy to inform him about the imposters who called themselves "Shadow Garden." She told him as much as she could from her interrogating the imposter, but since his mind was already broken, she couldn't give much of a report. She relayed to Cid about the hierarchy within the Cult of Diablos, from the Third, Second, and First "Children", elaborating the lieutenants known as a "Named Children," and those in control of the Knights of Rounds.[[1]](#cite_note-1)

When the terrorist attack on the Midgar Academy was perpetrated by the Cult's pretenders acting as Shadow Garden, Nu managed to sneak in among the students and found the corpse of [Glen](Glen.md "Glen"), part of Iris Midgar's Crimson Order, and her injured ex-fiancé, Marco Granger. As Nu discovered that Granger was still alive but unconscious, she planned to silence him until she was met by Shadow, who informed Nu about the magical sealing artifact in the Academy, much to Nu's surprise. While she believed that Cid had solved the mystery of the sealing, she did not know that it was really Sherry Barnett, and Nu congratulated him while helping attain the materials he needed to investigate the problem, believing Shadow would fix it.

When Cid left, Nu threatened her ex-fiancé in a severe tone, believing he overheard the entire conversation, only to find he was still unconscious. Nu coldly told him that he is lucky, because she would not hesitate to kill him if he were to learn the identity of her master.[[2]](#cite_note-2)

## Volume 2

### Bushin Festival Tournament

When the Bushin Festival was approaching, Cid visited Gamma at the Mitsugoshi Company executive residence for help. As Cid wanted to dress up to participate in the tournament, Nu helped Cid disguise himself under the identity of "Mundane Mann" with a slime makeup that Nu uses. With the process complete, Nu was in awe of his acting as he made himself look like a miserable weakling for the role of Mundane Mann and helped equip him with whatever he needed to complete his look.[[3]](#cite_note-3)

## Volume 3

### Great Trading Company Conflict

During the Trade Dispute Incident, Nu arrived to inform Gamma and [Alpha](Alpha.md "Alpha"), puzzled and saddened by their lord's alleged betrayal, that [Gettan](Gettan.md "Gettan") was the leader of the Trade Alliance and had relations with the Cult of Diablos. Nu relayed that Gettan had planned to cause the collapse of trust once the Cult's finances within the Trade Alliance was securely relocated but had yet to enact the scheme. As Alpha began to doubt Gettan was a collaborator of the Cult, this led them to conclude that Shadow already knew of Gettan's plan and did what he did wanting to destroy was something else.

Immediately after, [Beta](Beta.md "Beta") arrived after having [Eta](Eta.md "Eta")'s help in translating an encrypted message by Shadow. In the translation, the message informed each of them that Cid did not betray them, but rather that he was helping a [partner](Yukime.md "Yukime") with collecting coins through counterfeits. Between Shadow playing Gettan's plan against him and the timing of the translated message, Alpha, Beta, Gamma, and Nu were convinced Shadow deceived them to help Mitsugoshi overcome the financial crisis of counterfeit bills and protect their secret association with Shadow Garden from being made public.

With this conclusion, they were relieved to know their master still cared, and Nu was also happy to relay that [Delta](Delta.md "Delta") was not dead, having arrived mid-conversation. With everything resolved, a relieved Alpha commanded the Seven Shadows present and Nu to assist in acquiring the funds Shadow secured for them to withstand the financial crisis. Afterward, Nu was among the Mitsugoshi employees who honored the bill exchanges for customers seeking their coins back.[[4]](#cite_note-4)

## Volume 4

#### Masquerade

## Volume 6

## References

1. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
2. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
3. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
4. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fakes Bills!
