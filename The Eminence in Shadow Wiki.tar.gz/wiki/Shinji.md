# Shinji

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Shinji](https://the-eminence-in-shadow.fandom.com/wiki/Shinji)

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Shinji?action=edit).

## Shinji

## Characteristics

### Race

Elf

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Debut

### Light Novel

Volume 7

Shinji (?[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the candidates for the war of succession being the leader of the reformist faction with [Beatrix](Beatrix.md "Beatrix") as his knight.

## Appearance

## Personality

## Chronology

## Relationships

## Powers & Abilities

## Trivia

## References

## Site Navigation
