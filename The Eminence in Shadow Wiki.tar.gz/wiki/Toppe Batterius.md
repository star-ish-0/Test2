# Toppe Batterius

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Toppe%20Batterius](https://the-eminence-in-shadow.fandom.com/wiki/Toppe%20Batterius)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Toppe_Batterius?action=edit).

## Toppe Batterius

## Characteristics

### Race

Human

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

Toppe Batterius is a magic swordman.

## Appearance

## Chronology
