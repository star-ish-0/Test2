# Reina Oriana/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Reina%20Oriana/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Reina%20Oriana/Chronology)

Main

Relationships

Image Gallery

## Oriana's "Black Rose" Wedding

Reina Oriana is brought to a Diablos memorial in the Oriana Kingdom. Her escort is [Kouadoi](Kouadoi.md "Kouadoi") the Gale, a leading figure in the Cult of Diablos, and various children. The death of her husband has ignited a kingdom civil war, and the Cult is secretly supporting the Perv Faction. At the behest of Kouadai, Reina disrobes and positions her hand on a shrine. Various runes begin to illuminate, eliciting a response from the Diablos leader about royal blood being the answer. The glow dimmed to darkness, leaving a ring in its place. A sudden shout from one of the children shifts attention away from the shrine and to the Cut of Diablos' surroundings. The unspoken call to arms is promptly followed by cries and screams in the crowd. The Shadow Garden Numbers [559](Victoria.md "Victoria"), [664](664.md "664"), [665](665.md "665"), and 666 were in hiding and have now engaged in combat. Number 559, seizing the opportunity given to her by the Cult of Diablos scattering formation, charges at Reina. The blow misses its target by a swift 666 intervention. Reina recognizes her daughter and dubiously asks her reason for such actions. Kouadai takes Reina and 666 hostage and asks for 559’s numerical designation, believing her to be one of the Seven Shadows. Incredulous of the answer, he reveals three other cult leaders in the crowd; Number 559 is not deterred by their appearance or Kouadai's threat. 666’s defense of Reina has left her unfit for the position in 559’s eyes. The mother and daughter are removed from the shrine as 559 prepares for combat.

At the Oriana Kingdom’s Caste, Queen Reina and Duke Perv share an intimate conversation. Reina asks to make their relationship public but Perv declines this appeal. He explains that he needs to finalize the marriage to Rose. A premature reveal may compromise the filial love, his sole leverage. Reina makes him swear to uxoricide after Rose and Perv’s matrimony. Perv agrees and seals the deal with a kiss. Embracing one another, they continue talking about the conspiracy behind the king’s death. Unbeknownst to them Shadow has shown Rose the Queen’s betrayal.

The wedding ceremony begins, and Reina Oriana is seated comfortably watching the whole precession. Perv says “I do” and everyone focuses on Rose. She breaks free from the gazes and proclaims her refusal of marriage. She takes full responsibility for killing her father but Perv is guilty of manipulating the Kingdom and Reina. Rose’s story is promptly collaborated by a magical hologram the king left in a ring. King Oriana said he suspected a mind manipulation drug was in his food and asked Reina to exchange his meals. Even after his efforts to thwart the poisoning, it was still eating at his mind.

Chaos befell the wedding as Perv and Rose dueled. Perv’s death came swiftly but not at the hands of Rose. He was decapitated by [Mordred](Mordred.md "Mordred"), ninth seat of the Knights of the Rounds. Reina's last moments were clutching the bloodied body as Mordred made the queen join her love.
