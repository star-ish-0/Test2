# Maai

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Maai](https://the-eminence-in-shadow.fandom.com/wiki/Maai)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Maai?action=edit).

[Maai](https://en.wikipedia.org/wiki/Maai "wp:Maai") is a concept that Cid Kagenou discusses and measures often when he is in battle. It is the essence of space between two combatants. In the world of The Eminence in Shadow, Maai has been greatly increased due to the concept of magic, which can enhance the human body way beyond the capabilities of Earth.

At the same time, Cid also discusses that the defensive techniques of the world are underdeveloped, leading to an increase in Maai due to the ability to disengage from combat entirely. To Cid, this increase in Maai is worthless because no attacks can actually reach the opponent without first closing the distance.

Cid's concept of Maai exists where evasion of an attack uses a minimal amount of movement. Instead of being out of range by a meter, he uses the space of a millimeter to trade blows.
