# Alexia Midgar/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Alexia%20Midgar/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Alexia%20Midgar/Chronology)

Main

Relationships

Image Gallery

## Background

Prior to the events of the series, Alexia grew up with her older sister and they to spend entire afternoons training together, although Iris always defeated Alexia. As a result, Alexia devoted herself to becoming stronger in the hopes of surpassing her. With the passage of the next years, their relationship became very distant and strained due to her job as the first princess and leader of the Royal Knights.

She was later arranged to marry Zenon Griffey, who had a very prestigious reputation, but Alexia was suspicious of him because he didn't seem to have a flaw.

## Volume 1

### Princess Alexia's Kidnapping

She found herself receiving unwanted advances from Zenon Griffey, her arranged betrothed. This made her suspicious of him and decided to find a way to get rid of him. Alexia decided it was best to form a relationship with a person of a lower status to anger him, so she rejected a fellow high noble and accept Cid Kagenou as her boyfriend when he presented a fake confession. As a result, the school was surprised by the union but Zenon was not fooled. Eventually, Cid found out as Alexia revealed her knowledge of the bet that Cid's friends arranged after talking to them. She casually insults Cid and manages to bribe him with gold coins to get him to comply. Despite initially abusing her relationship, mainly to vent her frustrations, Alexia starts to warm up to Cid by confiding him of her problem with Cid and becoming the first to compliment her on her sword skills.[[1]](#cite_note-V1C2-1)

She was later kidnapped by Zenon's men and was sent to a laboratory for her blood to be harvested. She managed to escape with the help from [Millia](Millia.md "Millia") but was stopped by Zenon, who revealed his true colors to her. Enraged, the princess confronted the Knight but to almost no avail when she was overpowered. Alexia was almost recaptured until Cid Kagenou|Shadow came to her aid and overwhelmed Zenon into using unrefined Beads of Diablos. Mutated, the Knight attempted to overpower the mysterious figure but this was backfired when he used his "I Am Atomic" to annihilate him alongside his hideout. After being rescued, Alexia was reunited with her concerned sister who she shares a hug with. She also became determined to learn more about Shadow as she came to realize her swordsmanship after witnessing him in action.

Afterwards, she met Cid and remarked her freedom from her betrothal while showing she has genuinely fallen for Cid by thanking him for complimenting her swordsmanship. Thinking his job was done, he tries to leave but Alexia asks Cid to continue their relationship a little longer, but Cid rudely refused to do so, causing an angry Alexia to attack him.[[2]](#cite_note-V1C3-2)

### Midgar Academy Terrorist Attack

Curious about Shadow Garden and the Cult of Diablos, Alexia decided to take a more active role in the internal affairs of her kingdom by joining Iris' investigations. During a night patrol, she encountered three imposters who are disguising themselves as part of Shadow Garden. They had a brief fight until Shadow saves her. Alexia warns Shadow to not become an enemy of her kingdom, which is met with cold indifference. After the event, Alexia was put on lockdown by her sister.[[3]](#cite_note-V1C4-3)

In the anime, Alexia returned to Academy to see the gates are closed and that the school guards were already dead.

## Volume 2

### Sanctuary Infiltration

Alexia made preparations by visiting Mitsugoshi along with Iris Midgar for her departure to [Lindwurm](Lindwurm.md "Lindwurm") as a special guest of the Goddess's Trial. Her order was to investigate the Archbishop [Drake](Drake.md "Drake") regarding dark rumors of corruption and missing orphans. While at the hot springs, she saw Cid arrive and was surprised by his nudity though he does not ogle her. They casually talked about their arrival and she apologized for the spiteful response to his rejection. Alexia told him of the event and that she alongside Rose Oriana will be attending as special guests. Cid thought she would participate as she clarified that she is unable to due to important matters and offered him into the Crimson Knights for her reiteration of her withdrawal. Despite her insistence, Cid bluntly refused as the conversation ended when he left while retorting her fixation on his "Excalibur".[[4]](#cite_note-:1-4)

Hearing the news of the Archbishop's death, Alexia went to the church and had an audit with acting archbishop Jack Nelson, explaining that she was there to investigate the previous archbishop's death, to which he replied that the Church will be handling the investigation and that she will need to be reapproved to conduct an investigation on the issue as Nelson already send the letter to the king Klaus Midgar while lastly telling her to enjoy the "Goddess's Trial" event. Seeing through that they were destroying evidence and obstructing an thorough investigation, Alexia seethed that she was able to do anything regarding the deceased Archbishop.

At the trial, she was irritated by the Archbishop Nelson being flirted with by Miss [Natsume Kafka](Beta.md "Beta"). When Cid was called up for the challenge, Alexia alongside the three were shocked to see Shadow instead of him. There, he would call out [Auroa](Aurora.md "Aurora") and challenge her as the princesses was informed of the Witch in elaborate detail to much of Alexia's peeve on the writer's approach. Although Nelson and many of the spectators believed that the Witch would win, Alexia disagreed to Natsume's delight when she was able to analyze the closing distance and positions of the two combatants.[[5]](#cite_note-:2-5)

Upon Shadow's victory, chaos ensued as the Paladin Knights attempt to capture him, the Door of Beckoning appearing, and lastly members of Shadow Garden appearing. She and Rose went to the gateway alongside members of [Alpha's](Alpha.md "Alpha") squad with the captured Nelson to find themselves in the sanctuary. Alexia and Rose would then come to learn the connection with the recent events with the two organizations and the truth about the Cult of Diablos.[[6]](#cite_note-:3-6)

After the destruction of the Sanctuary taking Nelson with it, Alexia alongside Rose and Natsume made an alliance in hopes of protecting what's most dear to them (Cid).[[7]](#cite_note-V2C3-7)

### Bushin Festival Tournament

Alexia heard the news about Rose going into hiding after stabbing her fiancé Perv Asshat and tried to investigate the incident with Natsume Kafka when she gave her information that she didn't had access to. The two thought that if Rose was caught, she would be in serious trouble, but confident that she would not receive the death penalty due to her royal status. Alexia wanted to confirm Rose's predicament by finding her before the Oriana Kingdom does, in the matter in hopes of getting her side of the story much to Natsume's protest. Despite being irritated by her words, Alexia understood her reasonable advice and decided to consult her older sister. Natsume will try to gather more information about Rose, especially about the Chancellor as she heard unsavory rumors about him.[[8]](#cite_note-V2C4-8) In the anime after Alexia left, she was given more info about Perv by [Beta](Beta.md "Beta") without her knowing, so as to keep her busy and not do anything to get into trouble.[[9]](#cite_note-9)

While investigating, Natsume provided Rose's whereabouts to Alexia and went to Midgar's tunnel systems to track her. Natsume then shared some information to Alexia about the Chancellor to confirm their suspicions of him by recalling the incident that Rose instigated when he was attacked by her without any injuries and thought he was possibly connected with the Cult of Diablos. Natsume noted that it will be difficult to provide evidence of his involvement with the Cult the situation is a matter of national and religious relevance which meant that normal evidence will not suffice. Alexia added that her father told her that they needed something that would convince the masses and the neighboring countries, if they wanted to link the Cult's relationship with the Divine Teachings Holy Church and she thinks that some of their top brass were involved with the Cult. Even Natsume stated that if they continued to deny the Church, they would be considered as heretics.

Alexia was irritated by her father's inaction due to his long-standing policy of not showing any antagonism with the Church and told Natsume that Iris told her that King Raphael Geerk Oriana doesn't seem to be affected by Rose's actions which made her suspicious as when Iris had said that the King seemed to have a somewhat hollow. Alexia intended to meet him and she slightly smelled the sweet scent from the King's body. Hearing the King's irregularity, Natsume notices it and tells Alexia that it seems they are too late. Alexia is also sure that the Cult is definitely make their move and if they continue to do nothing as her father suggests, the Cult will end up causing a lot of trouble for the kingdom.

While still doing their search, Alexia and Beta suddenly feel a burst of magic and they run towards it and upon finding Rose Oriana, the two witnessed her bloodied with dozens of assailants corpses. Alexia demanded Rose what happen and her side side of the incident and tried to beat her into answering. This backfired as Rose incapacitated her with ease and left the sewers to confront her father and fiancé.[[10]](#cite_note-V2C6-10)

In the anime, Alexia went to meet Natsume but already left, leaving a document which contained information that Alexia needed there.[[11]](#cite_note-11) Alexia was practicing her swordsmanship skills when Shadow was about to release his "I Am Atomic", but ignored it as continued her practice.[[12]](#cite_note-12)

## Volume 3

### Major Corporate Alliance Conflict

Sometime after the Bushin festival and Red Moon incident, Alexia came to check up on a pondering Cid and the two sparred. The two noticed improvement in Alexia's swordsmen ship but she dwelled in her defeat against Rose and sought to continue improving. The two parted ways as Cid started his collaboration with [Yukime](Yukime.md "Yukime") as "John Smith".[[13]](#cite_note-V3C5-13)

## Volume 5

### The Midgar Academy Mist Terrorist Attack

After the Academy's Winter break, Alexia investigated the disappearance of Claire to find Cid's collar. There she discovered ancient texts on the collar and questioned Cid about it. Later in the night in the aftermath of [Delta](Delta.md "Delta") and [Zeta's](Zeta.md "Zeta") fight, Alexia found Shadow and misunderstood the situation as she was almost ready to apprehend him before he knocked the knights unconscious and fled the scene.

Sometime after Claire's reappearance, Alexia talked to Claire much to her protest for her fake relationship with her brother. The two discussed that Cult of Diablos infiltrated the Academy and Knights with Diablos' right arm being revealed to be sealed in the Academy. The two formed an uneasy alliance to further investigate the matter with their first hint being a book from the Forbidden Library. Alexia along with Claire then went to meet Claire's friend, [Nina](Nina.md "Nina") because she heard a story that she helped Cid to get forbidden books from the library.

At the Library, they were able to translate the book before being ambushed by the head librarian. In the ambush, the head librarian revealed himself as a agent for the Cult. Alexia started to feel strange and became incapacitated when the head librarian told them the stories of [Fenrir](Fenrir.md "Fenrir") and confirmed his existence after Alexia concluded that Fenrir is a Cult's member. Before he went to incapacitate Alexia and Claire after taking the effect of the drugs scent, Shadow then appeared to defeat the head librarian and in his last moments, the dying librarian revealed that he was a Bushin Festival champion and Knight who sought justice until he found the evidence regarding the corruption of the Holy Church without knowledge of the Cult's existence and investigated. The investigation went horribly wrong as his subordinates were massacred and his arms was cut off by Fenrir while finding out that his wife became a hostage. In exchange for his wife's safety, he forewent his identity to join the Cult and told Alexia that he was powerless to rebel against the Cult while warning the princess that she'll walk the same path as him.

After Alexia stated her resolve to protect her kingdom as a princess, the Head Librarian revealed the Cult's true objective is to gain more power as he revealed to truth abut the Three Heroes, [Possession](Possession.md "Possession") and Diablos Cells are only customize for woman through using the red pills that Zenon Griffey used to have, which he called him as a poor student. The Head Librarian didn't take the drugs because it's a shame for a swordsman, but he stated the potential of these drugs that if the Cult can bring the Demon Diablos back to life and success to develop the perfect drugs, which is very effective without side effect, the Cult of Diablos will have extraordinary power that even surpass the heroes.

The Head Librarian also revealed that the quantity for the Beads of Diablos have been decreasing and that he doesn't know what cause of it. Because the eternal life from the Beads will soon disappear if the number continues to decrease, even the Cult's leadership will not tolerate it as they want to revive the demon so they can harvest the Beads of Diablos again in large quantities. With the perfect eternal life in mind, their leaders could rule over the world and run it with their hands from the shadows. However, if that Beads disappear, they will lose their eternal life.

The Head Librarian stated that it was no coincidence that Shadow Garden appeared in this era as they'll bring the end of the Cult's long reign and warned Alexia to be careful as the organization are the strongest people in the world to which he questioned if they even really are on the side of justice to protect the peace of the world or they want to take everything on the eternal life and the world from the Cult after the Cult's fall. As the Head Librarian breathed with pain, he entrust the kingdom's future to Alexia before passing.

Alexia collected the testimony and book as evidence and tried to use them to convince her sister of their involvement. To her dismay, Iris became a puppet for the cult as she was being manipulated by [Adder](Adder.md "Adder") into believing that the cult doesn't exist and it was a fabrication done by Shadow Garden. Adder provided fabricated evidence of an insider's document with Alexia refuting them as she tried to reach out her sister. However, her plea was rebuked by her sister as she threaten her with no mercy if she were to obstruct her in the matter before leaving.[[14]](#cite_note-V5C2-14)

Trapped that the Knights and her sister couldn't be trusted, Alexia ran into Claire and continued their investigation before noticing white hazes were suddenly enveloping the Academy. The two hurried to the Academy to the auditorium to see ghosts attack the students before realizing they're both strained with an magic collar that'll denote when their magic reaches 0. After fending off the ghostly horde, the two ran into [Nina](Nina.md "Nina") and [Issac](Isaac.md "Isaac") for a briefing of the situation. Issac accused Shadow Garden of orchestrating the event when Claire grieved on how things escalated quickly to which Alexia retorted Issac's accusation that there is little to no evidence to accuse the organization of their involvement.

Anxious for a way out, an unassuming named Suzuki suggested an idea that the students low on magic will stay in the auditorium as defense while the rest investigate. A relative of his named Christina tried to interrupt him before he could finish out of fear to save face which in response Alexia stopped her and allowed him to finish. He would finish his suggestion that the magic being absorbed is traceable and that the investigation will have to cut through the ghost surroundings. Issac protested that he's an unremarkable and inferior student and that he is not trustworthy. Suzuki sneered at Issac before the rest of the group agreed to his plan except Christina. It did not took long to convince her otherwise as Suzuki was willing to be left behind if he were to slow down the group. On their way around campus, the group ran into some of the students who fled the auditorium. One of them was Eliza Despoht. Alexia noticed an abnormal amount of magic on her collar but was too exhausted to question her when they were ambushed.

During the ambush, one of the students was fighting a losing battle when Suzuki asked Eliza whether she was going to fight or not. Eliza's entourage tried to sneer him away from further questioning as he lamented that the student in question was going to die with her magic running to 0. Suzuki decided to take action by dissipating the ghost and save the student. He explained that magic can be transferred to the collars and by extension, it can postpone its denotation. Alexia was impressed by his deduction as he went onto accuse Eliza of extorting other students magic. Eliza admitted to the crime as she thought to have leverage over the party due to her high noble status till Suzuki restrained her. He clarified to everyone including Eliza of the situation she's in that no one will testify if he were to kill her because by the time it'll be discovered, no one would live to testify and not even her status can save her. In the end, Eliza was forced to share her ill earned magic to those running low and return to the auditorium with Alexia handing out her punishment later.

Alexia and the group traced the collar source and noticed that ghost encounters have become sparse. She asked Christina who Suzuki was to which even she was unsure and Issac was suspicious of him. They traced the collars to a church and investigated for clues to find a dungeon. However by the time they realize it was a trap, the group fell unconscious one by one with Alexia finding out that Issac was the insider for the Cult before collapsing.[[15]](#cite_note-15)

## Volume 6

## Bloody Midgar Serial Murder Terror

## References

1. Volume 1 Chapter 2: Assuming the Role of a Side Character at School!
2. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
3. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
4. Volume 2 Prologue: To Lindwurm, the Scared Land!
5. Volume 2 Chapter 1: Fun Times at the Goddess's Trial!
6. Volume 2 Chapter 2: Investigating the Sanctuary!
7. Volume 2 Chapter 3: When Things Get Boring, It's Time for Explosives!
8. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
9. Episode 16
10. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
11. Episode 18
12. Episode 20
13. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
14. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
15. Volume 5 Chapter 5: Terrorists Attack the School…Again!!
