# Shichy

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Shichy](https://the-eminence-in-shadow.fandom.com/wiki/Shichy)

## Shichy

### Romaji

Shichy

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

[Eta](Eta.md "Eta") (Descendant)

## Professional Information

### Occupation

Hero

### Affiliation

The Heroes
Cult of Diablos

## Debut

### Game

Apocrypha: Chapter 2 Part 3

Shichy (, Shichy[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the Heroes that took part in the battle against the [Demon Diablos](Aurora.md "Aurora"). She is the ancestor of [Eta](Eta.md "Eta").

## Appearance

## Personality

## Chronology

### Requiem for Scattered Shadows

## Powers & Abilities

## Relationships

### [Olivier](Olivier.md "Olivier")

### [Lily](Lily.md "Lily")

### [Freya](Freya.md "Freya")

### [Duet](Duet.md "Duet")

### [Pente](Pente.md "Pente")

### [Nonna](Nonna.md "Nonna")

### [Rouge](Rouge.md "Rouge")

## Image Gallery

## Trivia

## References

## Site Navigation
