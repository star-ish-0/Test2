# Sword Demon

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sword%20Demon](https://the-eminence-in-shadow.fandom.com/wiki/Sword%20Demon)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Sword_Demon?action=edit).

## Sword Demon

### Japanese

剣の悪魔

### Romaji

Ken no akuma

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Affiliation

Thirteen Nightblades

## Debut

### Light Novel

Volume 6

### Manga

Chapter 70

Sword Demon (剣の悪魔, Ken no akuma[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), was an associate of the Thirteen Nightblades. He previously trained in [Wakoku](Wakoku.md "Wakoku") however he was expelled from there for killing nine other students at the school in the pursuit of strength.[[1]](#cite_note-:0-1)

## Appearance

## Personality

## Chronology

### Bloody Midgar Serial Murder Terror

He was tasked to assassinate Jack The Ripper as backup in case Jack showed up at the hope mansion and [Marquis Jet](Jet.md "Jet") and [Viscount Shinobi](Shinobi.md "Shinobi") were unable to defeat Jack.[[1]](#cite_note-:0-1) However Sword Demon was unable to kill Jack The Ripper leading to Sword Demon getting his head exploded into confetti by Jack The Ripper.

## Relationships

## Powers & Abilities

## Trivia

## References

1. Volume 6 Chapter 2 - Surprise assassins at the sleepover

## Site Navigation
