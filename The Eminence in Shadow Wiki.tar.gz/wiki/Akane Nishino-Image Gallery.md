# Akane Nishino/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Akane%20Nishino/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Akane%20Nishino/Image%20Gallery)

Main

Chronology

Relationships

- [Light Novel](#)
- [Manga](#)
- [Anime](#)

Profile Pictures

Akane's profile in English

Akane's profile in Japanese

Volume IllustrationsLight Novel Volume Cover

Volume 4 Cover Japanese

Volume 4 Cover English

Akane on Manga Vol.12 Cover Japanese Version

Akane on Manga Vol.13 Cover Japanese Version

Sketch

Anri's Thanks For The Over 6 Million Copies That Where Sold Illustrations Akane & Cid by SakanoAnri

Season 1DesignSketch

Akane Nishino by Director, Nakanishi Kazuya

Akane Nishino Character Design by Makoto Iino
