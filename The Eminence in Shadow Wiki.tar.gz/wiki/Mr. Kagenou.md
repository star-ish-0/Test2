# Mr. Kagenou

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mr.%20Kagenou](https://the-eminence-in-shadow.fandom.com/wiki/Mr.%20Kagenou)

## Mr. Kagenou

### Japanese

オトン・カゲノー

### Romaji

Oton Kagenō

### Aliases

Baldy

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Black (Balding)

### Eye Color

Black

### Birthday

Unknown

## Personal Information

### Status

Alive

### Relatives

Mrs. Kagenou (Wife)
Claire Kagenou (Daughter)
Cid Kagenou (Son)

## Professional Information

### Occupation

Baron

### Affiliation

Midgar Kingdom

## Debut

### Web Novel

Chapter 4

### Light Novel

Volume 1

### Manga

Chapter 2

### Anime

Episode 2

## Portrayal

### Japanese

Yasuhiro Mamiya

Mr. Kagenou (オトン・カゲノー, Oton Kagenō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) also known as Baldy, is the head of the Baron Kagenou family from Midgar Kingdom, and father of Claire Kagenou and Cid Kagenou.

## Appearance

Mr. Kagenou has the stature of an old man with a thin mustache, beard and has some facial black hair on the back of his head but has fallen out or is bald on other parts, being called "Baldy" by many people including by his own wife and daughter due to his cowardice.

As the head of the Baron Kagenou family, he always wears a shirts and suit that looks neat.

## Personality

Mr. Kagenou is a cowardly and neglectful man who constantly tries to get out of his responsibilities as family head. While pretending to always think critically, when a problem arises, he will quickly resort to excuses and attempt to distance himself from the issue. His negligence and cowardice also negatively impact his relationship with his family, with neither of his children holding any respect for him while his wife straight-up resents him as well being called a "baldy" by his wife and daughter.

While he places no responsibility upon himself, Mr. Kagenou still hypocritically has expectations for his children. This is seen in how he neglects his son, Cid, due to his seeming ineptitude while focusing on his daughter. However, as seen when Claire was kidnapped, he will abandon his daughter too if it suits him.

## Chronology

At some point in time Mr. and Mrs. Kagenou met and got married. And at some point, in time, they had Claire.

### Birth of Cid Kagenou

Like his wife, Mr. Kagenou was happy to have one more possible heir, however, as Cid grew up, he showed no aptitude for anything, so Mr. Kagenou decided to focus more on Claire's growth, allowing Cid to do what he wanted, without paying any attention to him.

### Claire Kagenou Abduction

Following the discovery of Claire's abduction, Mr. Kagenou, sensing that nothing could have prevented it, accepts it and tries to lay it off. In doing so, he incurs the wrath of Mrs. Kagenou because of his cowardliness.[[1]](#cite_note-V1C1-1)

### Bushin Festival Tournament

In the anime after hearing that Claire had won the Bushin Festival, Mr. Kagenou was very excited to hear of his daughter's victory. But would receive his wife's wrath for not doing anything for their son.[[2]](#cite_note-2)

## Relationships

### Claire Kagenou

He is very fond of Claire because not only she is the heir to the Baron Kagenou Family, but she is also very talented having been trained in swordsmanship and magic at a young age. Even though he is a cowardly father, he is very worried about Claire's situation when he finds out that his daughter has been kidnapped despite, he never bothered sending out of search party for her.

Claire, however shown her disrespects and resentment for her father and has no issues of calling him "Baldy" just as many people calls him for his cowardice.

### Cid Kagenou

He loved Cid like any father could, but not more so than Claire. Because he considers his own son not to have good abilities in all fields. In fact, he often keeps himself quiet. Like Claire, Cid has absolutely no respect for his father, and in fact, he's afraid he'll go bald like him when he grows up.

### Mrs. Kagenou

As a husband, he loves his wife very much. But he was very afraid and even begged for mercy when his wife was angry, because she did not hesitate to call him "Baldy" and hit him mercilessly for his cowardice.

## Image Gallery

### Anime

### Manga

## Trivia

- His surname Kagenou (カゲノー, Kagenō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). The word カゲ in her surname means "shadow" in Japanese.
- Cid privately fears that he might one day go bald like his father.

## References

1. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
2. Episode 20

## Site Navigation
