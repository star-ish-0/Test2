# Goldy Gilded/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Goldy%20Gilded/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Goldy%20Gilded/Image%20Gallery)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Goldy_Gilded/Image_Gallery?action=edit).

Main

Chronology

Relationships

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)
