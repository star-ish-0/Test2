# Ring of Succession

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Ring%20of%20Succession](https://the-eminence-in-shadow.fandom.com/wiki/Ring%20of%20Succession)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Ring_of_Succession?action=edit).

The Ring of Succession (契約（けいしょう）の指輪（ゆびわ）, Keishō no Yubiwa[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets"))

## Overview

## History

## Functions

## References
