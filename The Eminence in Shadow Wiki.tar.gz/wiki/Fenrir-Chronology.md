# Fenrir/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Fenrir/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Fenrir/Chronology)

[Main](Fenrir.md "Fenrir")

[Relationships](Fenrir-Relationships.md "Fenrir/Relationships")

Image Gallery

## Synopsis

### Background

Fenrir was once known as the strongest magic swordsman who lived centuries ago, as he had made a name for himself around the world using his weapon "Blood Fang", the sacred sword of the strongest swordsman.

He is also a greedy assassin, who only wanted to increase his own power by indiscriminate slaughter, which made him a feared assassin in the Midgar Kingdom, known as the "Devil of Midgar," to which everyone who lived in the kingdom knew and even feared his moniker.

At some point, Fenrir joined the Cult of Diablos which used to occupy the 6th position in the "Round Table" to become the 5th seat in the Knights of Rounds, as he and his faction controlled the Midgar Kingdom's criminal underworld for so long, as he annually consumed one of the "Beads of Diablos" to maintain his strength and immortality. Fenrir and his faction had been engaged in a feud with [Loki](Loki.md "Loki")'s faction for a long time.

### Cult's First Unusual Report

About five years earlier, there was a report of an attack on their [possessed](Possession.md "Possession") carriage by an unknown group. Fenrir wanted to handle the issue because of his suspicions on the report, wanting to ensure there wouldn't be eventual problems, but the other Rounds postulated that a monster attacked the carriage, so they let it go.

Unbeknownst to them, it was a group of bandits that attacked the carriage until they were decimated by Shadow, who found the possessed figure, which he cured and would eventually become known as [Alpha](Alpha.md "Alpha"). The two would find Shadow Garden soon after.

### Decline of Fenrir's Sect Faction

Fenrir heard several reports about carriage attacks, their branch headquarters being destroyed and several of their personnel being killed. Fenrir even noticed the repeated operation failures, including [Grease](Grease.md "Grease")'s death and the failure of securing Claire Kagenou. Because of the suspicious activity in Midgar Kingdom, his territory was systematically targeted by an as yet unknown group that made his faction fall into decline for the last five years.[[1]](#cite_note-V1C1-1)

It was then Fenrir noticed that the Shadow Garden was responsible for destroying his operation after Zenon Griffey's failed attempt at securing Princess Alexia Midgar.[[2]](#cite_note-V1C3-2) After the release of [Diablos](Aurora.md "Aurora")' left arm during the destruction of the [Sanctuary](Sanctuary.md "Sanctuary") at [Lindwurm](Lindwurm.md "Lindwurm"), and the failed operation of retrieving Rose Oriana during Bushin Festival, Fenrir went to the meeting with his fellow Rounds to have them act seriously about crushing Shadow Garden.

After the meeting, Fenrir decided to revive the Diablos' right arm at the Midgar Academy to resupply Beads of Diablos. But just as he was about to start on his mission, Fenrir ran into a dire situation upon learning that the Major Corporate Alliance had collapsed due to John Smith and [Yukime](Yukime.md "Yukime")'s actions during their secret commercial trade war with Mitsugoshi Company by seizing all Alliance assets and Cult funds, causing his faction received substantial financial damage, scraping funding only to afford sending Second and Third Children to support Fenrir's Sect. Because of this, Fenrir and his faction could only seek cooperation from other factions because the threat of Shadow Garden and his Sect was already devastated economically.

### The Academy Disappearance

## References

1. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
2. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
