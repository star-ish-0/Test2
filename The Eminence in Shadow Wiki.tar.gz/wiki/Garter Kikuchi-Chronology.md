# Garter Kikuchi/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Garter%20Kikuchi/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Garter%20Kikuchi/Chronology)

Main

Relationships

Image Gallery

### Major Corporate Alliance Conflict

After another failed interception of the Mitsugoshi Company transport vehicles, Garter and [Gettan](Gettan.md "Gettan") discuss recourses. The corpulence merchant felt pressured by Mitsugoshi’s strengthening monopoly on commerce. Threatened by Garter and Mitsugoshi's position, Garter yielded control of the Garter Company to Gettan. He then proceeded to dispatch his private army to disrupt trade routes on behalf of the Major Corporate Alliance, a consortium of merchants conspiring against Mitsugoshi’s economic dominance. The mercenaries and the [Clovers](Clovers.md "Clovers")—the four strongest of the forces—initially found success in targeting traveling merchants that carried Mitsugoshi currency or goods, but direct assaults on the company’s caravans ended in defeat. Third-party skirmishes did not affect the Misugoshi Company's urban trade, the primary source of revenue, leaving their net income within the boundaries of market volatility. Anxiously, Garter awaited Gettan’s instructions. This time, the Major Corporate Alliancewas going to attack Mitsugoshi’s primary headquarters. Garter dashes away from the Therianthrope warrior, hoping this would be the last remnants of bad news.[[1]](#cite_note-V2C5-1) The later discovery of counterfeits made that desire unfounded.

The merchant met defeat for the third, failing to raid the Mitsugoshi Company’s headquarters and eliminating John Smith, the suspected counterfeiter.[[2]](#cite_note-V3C6-2) His trail ended in Lawless City, making further pursuit a fool’s errand. Garter reported another development about a large liquidation of Major Corporate Alliance bank notes. Gettan dismissed him, exacerbated by his incompetence with only concern for the future. After Gettan’s death and Major Corporate Alliance’s collapse, insolvency was the final fate of the portly merchant.[[3]](#cite_note-V3CE-3)

## References

1. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
2. Volume 3 Chapter 6: Circulating Counterfeit Cash!
3. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
