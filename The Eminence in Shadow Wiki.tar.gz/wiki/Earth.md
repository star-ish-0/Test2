# Earth

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Earth](https://the-eminence-in-shadow.fandom.com/wiki/Earth)

Earth is the third planet of the Solar System and former home of Cid Kagenou. Both its culture and its civilization are normal as it is known from the beginning of the 21st century, with much more advanced technology than that of the other world, where Cid reincarnated, but with the difference that of course, there is no magic as such.

## History

### Background

Following the death of Minoru Kageno, Magical Beasts began to appear in Japan and in all parts of the world, in a random way, at first they were docile, staying in dark and green places such as large forests and caves, which the people in the public believed were defenseless that could be visited in zoos, but then a few days after their arrival on earth, they began to destroy everything in their path. As conventional weapons such as pistols, machine guns, among other things, were of no use against these creatures, the human population in just a year was reduced to 1/10 of its population in each country, if not that 1/100 worldwide.

Soon after, the few civilizations still standing used all their scientific ingenuity and other researchers to find out the strange phenomenon that plagued the entire world.

Shortly after, an investigation from outside the world managed to find out that magic existed as such, that it had arrived on earth almost at the same time that the demonic beasts appeared, so researchers from both parties, both from The Japanese scientific part, as well as the foreign ones, began to work in collaboration, to create magical soldiers to be able to fight the demonic Beasts.

During the trials and errors that the researchers and scientists had, they managed to create a human with magical powers capable of fighting the magical beasts that had invaded the earth, this "knight" was a girl with beautiful golden hair, who had won a tremendous force, that allowed to create more of its kind in part, and that humanity had a ray of hope. which converted her and named her the "First Knight".

After that, an advanced, well-fortified city called [Arcadia](Arcadia.md "Arcadia"), the last ray of light was said to be the good hope of humanity, but after a while, said city was completely destroyed by a person who had uncontrolled magical power who would be the "first knight of humanity".

### Return to Earth

Then, the realms collided once again allowing Minoru, now reincarnated as Cid Kagenou and [Beta](Beta.md "Beta") to enter Earth. Cid targeted and eliminated a large number of magical beasts and their nests.

## Equipment and Weapons

As conventional weapons were of no use against magical beasts, a desperate attempt began to produce weapons of the highest caliber, with more powerful ammunition, discarding normal weapons made from normal resources, such as iron, steel and lead, and they began to use the strongest resources, such as uranium in bullet ammunition of more than 10 mm, in an attempt to stop the beasts, and if possible kill them. but because those had magical skin as tough as normal tanks, little effect could be achieved, since due to their natural generation factor, unless the head or heart was destroyed, the demonic beasts would still remain alive. Think, and since no one in the world knew how to use magic as such, the result was the reduction of more than 90% of the human species among other things.

The magical knights of the earth, although they could use magic as such to defeat beasts, weapons such as swords among other things, it was not very effective for them, since its conductivity at the magic level was only 10 to 15%, but this as such they could not know, and although they could defeat the magical beasts, not all the magic knights could destroy the largest and most dangerous beasts that inhabited as such, for which they were considered, as a semi-failed creation as such.

The arms most used by people, both civil and military, are weapons such as pistols, machine guns, rifles, grenades, among others, well improved to the military limit, and swords such as katanas, and some axes, among other fencing-type weapons, (but as studied by scientists, katanas proved to be very effective in fights against magical beasts).

## Magic

Originally Earth didn't have Magic until they were invaded by magical beasts. Akane Nishino would be the first individual to possess magic after being injected with the blood of magical beasts. Individuals who would possess magic would become known as an "Awakened".

## Inhabitants

- Minoru Kageno (Formerly; Deceased)
- Akane Nishino
- Akira Nishino
- [Yuuka](Yuuka.md "Yuuka")
- Yuudai Saejima
- [Haitani](Haitani.md "Haitani")

## Visitors

- [The Brute](Mordred.md "Mordred")
- Cid Kagenou (Post-Reincarnation)
- [Beta](Beta.md "Beta")

## Known locations

- [Arcadia](Arcadia.md "Arcadia")
- [Messiah](Messiah.md "Messiah")
- Nishino University
- Sakurazaka High School

## Trivia

- Earth's flow of time is five times slower than the Other World, as it been three years after Minoru's death. But only has been fifteen years after he had reincarnated.
  - During the days that Shadow and Beta were on earth, without completing the week, they were practically a month in the other world. (Confirmation missing)
- The details, position and other situation of the other countries on earth and their population, at the crisis level, are currently unknown, but it is known that they are in the same position as Japan, at the disaster level.
- It is unknown if the governments of the large countries on earth tried to use nuclear weapons against the Demonic Beasts, but according to what was related by Akane Nishino and by Cid Kagenou deductions, (according to the manga and light novel), they could not. exercise them or refused to use them, due to the tremendous damage that would be caused to the environment and mainly the population. (To the present date, no details have been given.)
  - It is unknown if the world leaders managed to save themselves from the world massacre, caused by the magical beasts, by trying to take refuge in underground bunkers, but as seen and related by Akane, most of them died.

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • **Earth** • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
