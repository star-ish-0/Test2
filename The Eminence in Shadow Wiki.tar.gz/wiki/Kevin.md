# Kevin

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kevin](https://the-eminence-in-shadow.fandom.com/wiki/Kevin)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Kevin?action=edit).

## Kevin

### Japanese

ケビン

### Romaji

Kebin

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Black

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Guardsman (formerly)

### Affiliation

Oriana Kingdom

## Debut

### Light Novel

Volume 4

### Manga

Chapter 42

### Anime

Episode 30

## Portrayal

### Japanese

[Shinji Kawada](https://en.wikipedia.org/wiki/Shinji_Kawada "wp:Shinji Kawada")

### French

Boris Agondanou

### Italian

Loris Bondesan

Kevin (ケビン, Kebin[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a royal palace guardsman in the Oriana Kingdom until his dismissal due to a dispute with Cid.

## Appearance

## Personality

## Chronology

Kevin confronted Cid Kagenou when he got too close to his crush, [Margaret](Margaret.md "Margaret"), and threatened him. Not long after, Kevin was fired from his duties after Margaret accused him of stealing goods from Rose's room.[CITATION NEEDED]

## Powers & Abilities

Kevin possesses exceptional strength surpassing that of an average individual.

## Relationships

### Margaret

Kevin is infatuated with Margaret.

## Trivia

## References
