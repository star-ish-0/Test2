# Sigma

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sigma](https://the-eminence-in-shadow.fandom.com/wiki/Sigma)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Sigma?action=edit).

## Sigma

### Japanese

シグマ

### Romaji

Shiguma

### Aliases

No. 18

## Characteristics

### Race

Unconfirmed

### Gender

Female

### Age

14

### Height

Unknown

### Hair Color

Silver

### Eye Color

Blue

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Numbers

### Affiliation

Shadow Garden
[Wakoku](Wakoku.md "Wakoku") (Formerly)

## Portrayal

### Japanese

Ayane Sakura

Sigma (シグマ, Shiguma[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Σίγμα) is a member of Shadow Garden, being one of the Numbers. She is [Beta](Beta.md "Beta")'s subordinate.[[1]](#cite_note-:0-1)

## Appearance

Sigma is revealed to have a silver hair bob cut that reaches her shoulder, with a bang that covers her left eye and a braid that almost reaches her knees. Her shadow garden outfit resembles [kunoichi](https://en.wikipedia.org/wiki/Kunoichi "wikipedia:Kunoichi") outfit and she also wears a black bandana and a purple scarf.

## Personality

When she is working, Sigma tends to act stoic and keeps conversations brief and in a business-like matter. However, she secretly is a hardcore fan of [Beta](Beta.md "Beta") and her works as "Natsume Kafka". She enjoys lazing around reading her works, gushing and idolizing about her superior's "originality".[[1]](#cite_note-:0-1)

## Chronology

Sigma hails from a remote land in the east called [Wakoku](Wakoku.md "Wakoku") and belonged to a ninja organization. After showing signs of [possession](Possession.md "Possession"), she was driven out of the organization, where she would then flee to Midgar Kingdom but later got captured by the Cult of Diablos. She was then freed by Shadow Garden and healed by [Epsilon](Epsilon.md "Epsilon") while being transported by a convoy. Having lost the will to live, she decided to join Shadow Garden after reading one of Natsume Kafka's books. [[1]](#cite_note-:0-1)

## Powers & Abilities

As a former member of a ninja organization from Wakoku, Sigma possessed enough skills to quickly rise through the ranks and became a member of the Numbers. She specializes in stealth missions for reconnaissance and infiltration. [[1]](#cite_note-:0-1)

## Relationship

### Shadow Garden

### Cid Kagenou / Shadow

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

#### [Beta](Beta.md "Beta")

Sigma holds Beta in high esteem as her senior and holds her public persona of "Natsume Kafka" in reverence as she buys all of her original books.

#### [Epsilon](Epsilon.md "Epsilon")

#### [Eta](Eta.md "Eta")

Despite being her superior, Sigma dislikes Eta because she is constantly used as a test subject for her inventions and nearly dies many times.

## Trivia

- Sigma is one of two Numbers to be mentioned and revealed within the Master of Garden game; the other being [Iota](Iota.md "Iota").
- Sigma is one year younger than Beta.[[1]](#cite_note-:0-1)

## References

1. Secret of Sacra Ch. 8: Shadow Ninja Girl! | Kagemasu: Seven Shadows Chronicles Story

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • **Sigma** • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
