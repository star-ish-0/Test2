# Leaf Three

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Leaf%20Three](https://the-eminence-in-shadow.fandom.com/wiki/Leaf%20Three)

## Leaf Three

### Japanese

三葉（みつは）

### Romaji

Mitsuha

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Black

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Assassin

### Affiliation

Major Corporate Alliance
[Clovers](Clovers.md "Clovers")

## Debut

### Web Novel

Chapter 121

### Light Novel

Volume 3

### Anime

Episode 25

## Portrayal

### Japanese

Yoshihito Sasaki

Leaf Three (三葉（みつは）, Mitsuha[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was one of the members of the [Clovers](Clovers.md "Clovers"), a small personal group under the Garter Corporation.

## Appearance

## Personality

## Chronology

### Great Trading Company Conflict

Leaf Three alongside his fellow Clovers were ordered by their [superiors](Gettan.md "Gettan") to infiltrate the Mitsugoshi Company's Headquarters. He was tasked with pillaging along with kidnapping important personnel. When inside, Leaf Three encountered a [Mitsugoshi employee](Nu.md "Nu") and was killed. His head was delivered to a horrified Leaf One.

## Powers & Abilities

## Relationships

## Trivia

- In the manga, Leaf Three is the code name for Zabra, replacing Leaf Four who died at the beginning of Chapter 34.

## References
