# Eta/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Eta/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Eta/Relationships)

[Main](Eta.md "Eta")

[Chronology](Eta-Chronology.md "Eta/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

Eta recognizes that her research will always be trivial compared to Shadow, but she seeks further knowledge. She venerates Shadow's presumed wisdom and profoundly believes that Shadow's mind is the ultimate resource. Eta knows Shadow wants her to continue research; however, it almost feels like he keeps avoiding her. Their infrequent discussions do not satisfy her, and she continues to escalate attempts to pick his brain, figuratively and literally.[[1]](#cite_note-V5CE-1)[[2]](#cite_note-V5CS-2)

Already eschewing typical moral constraints, she endeavored to dissect Shadow's brain but found it impossible. It is difficult to attack someone who never puts their guard down, even while asleep. Spiking his coffee with drugs strong enough to kill dragons likewise proved ineffective. Eta physically suspended operations at present but mentally continues possibilities. Despite her analytic and callous mind, Eta acknowledges Shadow's kindness.[[1]](#cite_note-V5CE-1)[[3]](#cite_note-V6C5-3)

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

Eta finds Alpha's research interference vexing and openly jeers her dissatisfaction. Always under threat of budgetary decreases, Eta stopped some of her more questionable experiments under Alpha's order. It is not a perfect deterrent as she always tries to sneak a few by her.[[3]](#cite_note-V6C5-3)[[4]](#cite_note-V5C2-4)

#### [Beta](Beta.md "Beta")

A fellow member of the "Seven Shadows". Beta has shown respect for Eta's intelligence, yet also somewhat fears her due to Eta's seeming lack of morals. During the Hot Springs Land grand opening,[[5]](#cite_note-5) Eta was initiated to use Beta as a test subject regarding the surge of magical energy under the location and voiced fatigued annoyance for the elven novelist. This included her opinion on Beta being an airhead with her nourishment only going to her chest, as well as other ego hurting commentary, similar to Lambda's drill sergeant method of breaking self-esteem. However, this could have been partly Eta's views on Beta, as noted by Zeta.[CITATION NEEDED]

#### [Gamma](Gamma.md "Gamma")

A fellow member of the "Seven Shadows". While Eta's views on Gamma are unknown, the latter dislikes how much of Shadow Garden's finances the former wastes on her experiments. But this is adequately compensated with the technologies she develops, both for Shadow Garden and Mitsugoshi.[CITATION NEEDED]

#### [Delta](Delta.md "Delta")

A fellow member of the "Seven Shadows". In the anime, Eta and Delta have a somewhat troubling relationship, as the latter often has trouble understanding the former's scientific remarks due to her low intelligence. In turn, Eta has shown to become uncharacteristically angry whenever Delta accidentally breaks one of her inventions.[CITATION NEEDED]

#### [Epsilon](Epsilon.md "Epsilon")

A fellow member of the "Seven Shadows". In the anime, Eta and Epsilon maintain a cordial relationship. However, Eta has been shown to get angered whenever she feels like Epsilon is mocking her inventions.[CITATION NEEDED]

#### [Zeta](Zeta.md "Zeta")

Eta knows about Zeta's dissent and the actions of her faction. Although she supplied some resources for Zeta's operations, she does not view herself as an accomplice for one side or the other. Eta remains unconcerned about the internal politics of Shadow Garden. As long as her research is not affected, their direction or the leader is incidental.[[1]](#cite_note-V5CE-1)[[4]](#cite_note-V5C2-4)

### Numbers

#### [Lambda](Lambda.md "Lambda")

#### [Nu](Nu.md "Nu")

#### [Sigma](Sigma.md "Sigma")

#### [Chi](Chi.md "Chi")

#### [Omega](Omega.md "Omega")

### Members

#### [Victoria](Victoria.md "Victoria") (559)

#### Akane Nishino / "Akane Nishimura" (712)

## Others

### Claire Kagenou

### Sherry Barnett

### Skel Etal & Po Tato

## References

1. Volume 5 Eta's Research Journal
2. Volume 5 Character Sheet: Eta
3. Volume 6 Chapter 5: Welcome to Shadow Garden!
4. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
5. Episode 28
