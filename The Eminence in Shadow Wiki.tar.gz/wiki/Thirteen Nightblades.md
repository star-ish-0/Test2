# Thirteen Nightblades

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Thirteen%20Nightblades](https://the-eminence-in-shadow.fandom.com/wiki/Thirteen%20Nightblades)

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

## Thirteen Nightblades

### Japanese

十三の夜剣

### Romaji

Jūzō no Yoru Ken

## General Information

### Leader(s)

Brad Despoht (Deceased)

### Status

Defunct

### Affiliates

Cult of Diablos

### Base of Operation

Midgar Kingdom

## Debut

### Light Novel

Volume 6

### Manga

Chapter 67

The Thirteen Nightblades (十三の夜剣, Jūzō no Yoru Ken[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a secret society of thirteen corrupt noble families headlined by Marquis Brad Despoht.[[1]](#cite_note-V6CP-1) Recognized as the shadow rulers of the Midgar Kingdom, they built a strong relationship with the Cult of Diablos to maintain their established wealth and power.[[2]](#cite_note-V6C1-2)[[3]](#cite_note-V6C3-3) The aristocratic cabal fell apart after Shadow, posing as Jack the Ripper, eliminated all leading members and ended their rampant oppressive rule.[[4]](#cite_note-V6C4-4)

## History

The group of prominent noble families began their illicit activities by making contact with the Cult of Diablos[[3]](#cite_note-V6C3-3) , which also makes them a target of Shadow Garden.[[1]](#cite_note-V6CP-1) Through the assistance of the [Fenrir](Fenrir.md "Fenrir") sect, the Thirteen Nightblades received money, slaves, assassins, monsters, and artifacts to control the Midgar Kingdom.[[4]](#cite_note-V6C4-4) In the final years of their existence, the Thirteen Nightblades’ authority surpassed the sovereignty of the Royal Midgar Family.[[1]](#cite_note-V6CP-1)[[3]](#cite_note-V6C3-3)

## Power & Influence

Due to their noble status and Cult connections, members of the Thirteen Nightbladess and their families held significant power. The Midgar Kingdom government exercised rules and laws, but the Thirteen Nightbladess operated outside the state, imposing unregulated violence and authority.[[5]](#cite_note-V6C2-5)[[3]](#cite_note-V6C3-3) Such a privilege allowed them to commit crimes with impunity and invoke special privileges or immunities to alter official proceedings.[[1]](#cite_note-V6CP-1)

The Thirteen Nightblades’s sway extended beyond the public sector, associating with criminal gangs and paramilitary organizations. They created illegal militias consisting of the best dark knights and mercenaries.[[2]](#cite_note-V6C1-2) Many Bushin Festival tournament participants, Lawless City assassins, and martial artists from [Wakoku](Wakoku.md "Wakoku"), resided within their ranks.[[5]](#cite_note-V6C2-5) As a testament to their influence, the organization hired all the best warriors and mercenaries on the continent to exterminate Jack the Ripper.[[3]](#cite_note-V6C3-3)

After Fenrir's death and his sect's subsequent destruction, The Thirteen Nightblades lost significant underworld backing.[[2]](#cite_note-V6C1-2) Immediately, they sought out alternative benefactors. Members started negotiations with the [Loki](Loki.md "Loki") sect to supersede previous connections.[[3]](#cite_note-V6C3-3) The speed of the assassinations outpaced their discussions, and the entire upper echelons of the organization were killed.[[4]](#cite_note-V6C4-4)

## Membership

## Known Members And Associates

- Marquis Brad Despoht (Deceased)
- Earl Korrupt White (Deceased)
- [Count Battler](Battler.md "Battler") (Deceased)
- Earl Haushold Hedd (Deceased)
- Earl Dunder Hedd (Deceased)
- [Marquis Jet](Jet.md "Jet") (Deceased)
- [Viscount Shinobi](Shinobi.md "Shinobi") (Deceased)
- [Count Azukay](Azukay.md "Azukay") (Deceased)
- [Baron Stergang](Stergang.md "Stergang") (Deceased)
- Earl Shoddi Goodz (Deceased)

### Relatives

- Eliza Despoht (Deceased)
- Shoddi Goodz's Unnamed Father (Deceased)

### Associates

- Sword Demon (Deceased)
- [Butcher](Butcher.md "Butcher") (Deceased)

## Legacy

The Midgarian authorities took immediate action against the houses of Despoht, Goodz, and other nobles implicated in the Thirteen Nightblades. On the order of Klaus Midgar, king of Midgar Kingdom, the Knight Order confiscated the families’ wealth and estates.

Eliza Despoht aimed to rebuild the collapsing Thirteen Nightblades, lost power and influence notwithstanding. She planned to create a new generation to fill vacant seats and surpass their predecessors. These preparations never came to fruition, as Christina Hope thwarted the plan. Christina took up Jack the Ripper's mantle and eliminated Eliza.[[6]](#cite_note-V6CA-6)

## Trivia

## References

1. Volume 6 Prologue: There Are People Ruling the Midgar Kingdom from the Shadows? I'm So Jealous!
2. Volume 6 Chapter 1: Enter Jack the Ripper!
3. Volume 6 Chapter 3: Deciphering the Calling Card!
4. Volume 6 Chapter 4: The Monster Becomes a Legend!
5. Volume 6 Chapter 2: Assassins at the Sleepover!
6. Volume 6 Auxiliary Chapter: Following in the Monster's Footsteps!

## Side Navigation
