# Dark Knight Association

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Dark%20Knight%20Association](https://the-eminence-in-shadow.fandom.com/wiki/Dark%20Knight%20Association)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Dark_Knight_Association?action=edit).

## Dark Knight Association

### Japanese

魔剣士協会

### Romaji

Makenshi Kyōkai

## General Information

### Leader(s)

Unknown

### Status

Active

### Affiliates

Unknown

### Base of Operation

Lawless City

## Debut

### Web Novel

Chapter 98

### Light Novel

Volume 3

### Manga

Chapter 29

### Anime

Episode 21

Dark Knight Association (魔剣士協会, Makenshi Kyōkai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is an external bureaucratic subversive independent security organization that operates in the Lawless City and enact order.

The Association has been given the assignment of forming a team to annihilate the Blood Queen, [Elisabeth](Elisabeth.md "Elisabeth"). However, the Association was unable to carry out their mission due to their disparity in strength and their inability to deal with the [Ghouls](Ghouls.md "Ghouls")' simultaneous attacks until their team had on the brink of annihilation until being rescued by Shadow.

## Overview

The Dark Knight Association is a non-governmental protective enforcement service agency built for the purpose of dealing with and overcoming all levels of threats where magic swordsmen work together to fight against monsters and criminals, even the organization has had a long-standing “Don’t get involved with the Lawless City” policy.

But today, it is corrupted with egotistic old men who abuse their power and authority to molest female members.

## History

It is not known exactly when the Dark Knight Association was formed, possibly at the time when the [Blood Queen](Elisabeth.md "Elisabeth")'s underlings often caused a lot of chaos outside Lawless City, affecting the surrounding countries.

## Organization Strength and Influence

So far, each Association member's individual strength is overwhelming enough that they were handily outmatch a ghoul.

It seemed that the Dark Knight Association is only prevalent in the Lawless City, hinting at a limited sphere of influence even though the Association mostly had strong connections with a few other countries.

## Membership

The Dark Knight Association is comprised of all expert magic swordsmen, where there is very little information known about their hierarchy.

## Chronology

### Red Moon Incident

The Dark Knight Association had to break their no-intervention rule in the Lawless City, after the surrounding countries that affected by many recent incidents that caused by the Blood Queen, [Elisabeth](Elisabeth.md "Elisabeth") and are having taken serious action to send joint request to the Association to subjugate the Blood Queen.

The Association started making preparation to invade the Crimson Tower by gathering their finest magic swordsmen to mount a counteroffensive against [Ghouls](Ghouls.md "Ghouls") and [Vampires](Vampire.md "Vampire"), in order to stop the rampage of Blood Queen from reviving and annihilate everything again.

[Claudia](Claudia.md "Claudia"), the leader of the Anti-Blood Queen task force, orders a full retreat when they got overwhelmed by the Blood Queen's ghouls and holds the line for the retreat of her fellow Dark Knights. She almost succumbs to death until she was saved by Shadow after he single-handedly decimate entire Ghouls all by himself.

## Known Members

- [Claudia](Claudia.md "Claudia")
- Graine (Deceased)

## Trivia

- In the Web Novel, the Association has declared a bounty on both Shadow and his organization, Shadow Garden.[[1]](#cite_note-WN98-1)
- In the Anime, the Association is also responsible for keeping order in the kingdom’s remote regions.[[2]](#cite_note-2)

## References

1. Chapter 98: Tough Lady
2. Episode 19

## Site Navigation
