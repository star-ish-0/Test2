# Beta/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Beta/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Beta/Chronology)

[Main](Beta.md "Beta")

[Relationships](Beta-Relationships.md "Beta/Relationships")

Image Gallery

## Assault on Viscount Grease's Base

After Cid's elder sister, Claire Kagenou, was abducted by the Cult of Diablos, Beta later meets with him to report the results of Shadow Garden's investigations. Supported by Cid's insight, they can determine their enemy's and his sister's location.

Afterward, Beta, along with the other members of Shadow Garden, would participate in the assault on the Cult's hideout, eliminating many of their members before confronting the culprit behind the kidnapping, [Viscount Grease](Grease.md "Grease"). Despite the cultist's escape, the girls allow him to proceed, realizing that their master had foreseen the count's actions and left the issue to Shadow to handle.

Following the successful rescue, the Shadow Seven would later report the fruits of their research into the Cult of Diablos to Cid. Determining that leaving was necessary to expand the organization, the girls would tearfully depart after receiving permission from their master.[[1]](#cite_note-V1C1-1)

Several years later, Beta would reunite with Cid as he was being framed by the Cult for the abduction of Princess Alexia Midgar, discovering him among a collection of rare antiques and luxury items to her admiration. Supporting Shadow Garden's raid on several of the Cult's secret locations, she was able to witness her master eliminate several members during another attempt to entrap him while recording the event in her secret chronicles. Following the incident, the two would separate and she would continue to support the operation.[[2]](#cite_note-V1C3-2)

## Sanctuary Infiltration

Under the disguise of her pen name, "Natsume Kafka", Beta accepts an invitation to participate in the Goddess' Trial event as a V.I.P. guest to perform reconnaissance for Shadow Garden. While performing her duties, she also happens to encounter her master, Cid, secretly providing details of their plans to him.[[3]](#cite_note-V2CP-3)

Later, she is joined by Princess Alexia and Rose Oriana during the opening ceremony, however, due to her dislike of the princess because of the former's previous relationship with Cid, the two become irritated with one another, while the latter remains unaware of the atmosphere. During the Trials, Beta is shocked by the unexpected participation of Shadow and the appearance of the Witch of Calamity, [Aurora](Aurora.md "Aurora"). However, she nonetheless quickly adapts to the situation and orders the continuation of the plan while witnessing the battle between her master and the witch. Following the conclusion with victory for Shadow, Natsume is captured by Shadow Garden and forced to enter the [Sanctuary](Sanctuary.md "Sanctuary") with them along with acting Archbishop Jack Nelson, before Alexia and Rose also compulsively joins them as well.[[4]](#cite_note-V2C1-4)

Inside, the history of the Hero [Olivier](Olivier.md "Olivier") and the Cult of Diablos is revealed, as well as Nelson's connection with the Cult as the Eleventh Seat of the Knights of Rounds. Upon this revelation, the Archbishop unveils his true nature and begins his assault on the group, but Alpha and Delta can withstand his onslaught. Eventually, the party decides to temporarily retreat and return to the normal world.[[5]](#cite_note-V2C2-5)

In the aftermath, Beta is reported to be guiding the two princesses while further developing her relationship with them.[[6]](#cite_note-V2C3-6)

## Bushin Tournament

During the Bushin Festival, Natsume and Alexia learn of Rose's assassination attempt on her fiance and becoming a fugitive from the law. Despite the political nature of the crime, Alexia still intends to search for her friend, despite the author's insistence on avoiding causing an international issue. Nevertheless, the princess refuses to abandon Rose, forcing Beta to relent and provide support.[[7]](#cite_note-V2C4-7)

From their investigation, the two then follow a lead on Rose's location, believing their friend is hiding in the capital's tunnel system. Despite Beta's reluctance, the elf nevertheless decides to follow Alexia to protect the princess as part of her job.

After exploring for a while, the duo has yet to find success until a tremendous surge of magic suddenly is detected, leading them to discover Rose among a group of fresh dead bodies. Realizing the situation, Beta silently observes as Alexia attempts to learn the truth behind her friend's motivation, however, the former student council president refuses to involve them in her plight to the former's anger. As a result, the two princesses confront one another in a duel which ultimately concludes with Rose's victory as Alexia is left unconscious. Subsequently, Natsume then allows the princess of Oriana to depart after giving her farewells before tending to the immobile princess of Midgar, pondering the decision of her master, Shadow.[[8]](#cite_note-V2C6-8)

## Red Moon Incident

While reporting the latest developments regarding Shadow Garden, Beta is suddenly surprised to learn from her master that a Red Moon will soon occur. Despite her initial concerns due to the event's dark history, she nevertheless becomes confident in Shadow's strength and accepts an invitation to participate as well.[[9]](#cite_note-V3CP-9)

On the eve of the Red Moon, Beta infiltrates the Crimson Tower in Lawless City along with a squad consisting of [664](664.md "664"), [665](665.md "665"), and 666 to research the blood of the vampire's progenitor. However, they are unexpectedly interrupted by the arrival of Claire and the Ancient Vampire Hunter [Mary](Mary.md "Mary"), who are attempting to rescue her brother from being sacrificed to revive the Blood Queen. Despite being suspicious of one another's motivations, both parties agree to leave each other alone and resume their original goals.[[10]](#cite_note-V3C2-10)

Unfortunately, Claire is gravely injured by the awakened Blood Queen, [Elisabeth](Elisabeth.md "Elisabeth"), forcing Beta's party to intervene but the progenitor's strength overwhelms them even with two of Lawless City's Monarchs present, [Yukime](Yukime.md "Yukime") and [Juggernaut](Juggernaut.md "Juggernaut"). Luckily, they are still able to stall for time for Shadow to arrive and duel against the vampire himself. Although Beta believes strongly in her master, she becomes worried when he initially struggles during the battle before assuming that their presence has become a hindrance to him. Nonetheless, her fears are assuaged when he finally unleashes his magic and performs his ultimate spell.

Upon regaining conscience, Beta discovers that her leader has already departed after destroying the Crimson Tower and healing every person's injuries. Notably, while retrieving the progenitor's blood sample, the elf unexpectedly learns that she has become capable of controlling the red liquid itself. With the mission a success, the member lastly witnesses the reunion between Mary and Elisabeth, wishing them success in achieving their dream before retreating into the night along with her team.[[11]](#cite_note-V133-11)

## Major Corporate Alliance Conflict

As the Great Trade Alliance begins to escalate, Beta participates in an operation to dispose of several of the Alliance's assassins while also acquiring information in the process. Unfortunately, the hostility between them continues to result in innocent deaths.[[12]](#cite_note-V3C5-12)

Later, Beta would provide her report to Shadow regarding the recent circulation of counterfeit bills, as well as Delta's disappearance after a confrontation with the enigmatic John Smith. Although her master is unable to support them, she does receive a memo from him which the elf proceeds to send to [Eta](Eta.md "Eta") for decryption.[[13]](#cite_note-V3C6-13)

Luckily, Eta can decipher their master's message, which Beta promptly reveals to [Alpha](Alpha.md "Alpha") and [Gamma](Gamma.md "Gamma") that Shadow had not betrayed them. In the message, he explains his intentions while securing the funds to reimburse the counterfeit banknotes while increasing their influence in relief and joy. When [Delta](Delta.md "Delta") also soon returns, the group then proceeds to the destination to retrieve the coins their master had hidden for them.[[14]](#cite_note-V3CE-14)

## References

1. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
2. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
3. Volume 2 Prologue: To Lindwurn, The Sacred Land!
4. Volume 2 Chapter 1: Fun Times at the Goddess’s Trial!
5. Volume 2 Chapter 2: Investigating the Sanctuary!
6. Volume 2 Chapter 3: When Things Get Boring, It’s Time for Explosives!
7. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
8. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
9. Volume 3 Prologue Heading to the Lawless City over Fall Break!
10. Volume 3 Chapter 2: Storming the Crimson Tower!
11. Volume 3 Chapter 3: Pursuing the Blood Queen!
12. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
13. Volume 3 Chapter 6: Circulating Counterfeit Cash!
14. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
