# Reina Oriana/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Reina%20Oriana/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Reina%20Oriana/Relationships)

Main

Chronology

Image Gallery

## Raphael Geerk Oriana

Reina's late husband. Initially, she appeared to have been quite loyal to Raphael, serving as his food taster in case it was poisoned. At some point, however, she began a long-term affair with Perv Asshat and betrayed her husband by allowing the chancellor to drug him.

In the end, the "Ring of Succession" projected an image of Raphael, who exposed Reina's crimes.

## Rose Oriana

Reina's daughter. Initially, Rose saw her mother and protected her from [559](Victoria.md "Victoria")'s attack, unaware of her true nature. Because Reina's love for Perv, she saw her own daughter as nothing but a hinderance and wanted her dead as soon as possible and Perv promised Reina that Rose will be dealt with once the wedding ceremony is over.

In the end, Reina received her comeuppance when Rose activated the Ring of Succession which exposed Reina's crimes. When Reina saw Rose killing Perv by beheading him (unaware that it was [Mordred](Mordred.md "Mordred")'s doing), she called her daughter a monster.

## Perv Asshat

Reina expresses the downright insidious desire for Perv to kill her own daughter, Rose, after he's married into the family so they can finally be officially together as lovers. She thinks that she and Perv are in love but Perv only sees her as a means to claim the throne.

This never came to fruition as she watches in horror as Rose mortally wounds and seemingly decapitates her beloved on their wedding day, followed up by Mordred finishing her off in her despair.
