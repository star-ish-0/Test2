# Zenon Griffey

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Zenon%20Griffey](https://the-eminence-in-shadow.fandom.com/wiki/Zenon%20Griffey)

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | I’m Zenon Griffey, the next person who will fill the 12th seat of the Rounds. Taking your life will become my achievement for the Rounds. | ” |
| — Zenon, Light Novel Volume 01 | | |

## Zenon Griffey

### Japanese

ゼノン・グリフィ

### Romaji

Zenon Gurifi

### Aliases

Marquis Zenon

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

28

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Light Blue

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- Marquis[[1]](#cite_note-V1C3-1)
- Knight Order High Officer (undercover)
- Swordsmanship Instructor of Midgar Academy for Dark Knights (Publicly)

### Affiliation

Midgar Kingdom
Cult of Diablos

## Debut

### Web Novel

Chapter 11

### Light Novel

Volume 1

### Manga

Chapter 3

### Anime

Episode 3

## Portrayal

### Japanese

[Masaya Matsukaze](https://en.wikipedia.org/wiki/Masaya_Matsukaze "wp:Masaya Matsukaze")

### English

Scott Gibbs

### French

Alexandre Bierry

### Italian

Mattia Bressan

### German

Felix Auer

Zenon Griffey (ゼノン・グリフィ, Zenon Gurifi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a swordsmanship instructor at the Midgar Academy for Dark Knights and Alexia Midgar's fiancée. In truth, however, he was secretly a member of the Cult of Diablos who sought to become the Knights of Rounds' 12th seat by kidnapping Alexia for experimentation, only to be thwarted and killed by Shadow.[[1]](#cite_note-V1C3-1)

## Appearance

Zenon appeared to be a blue-eyed blonde man in his late twenties with a soldier's physique. He was described as handsome by female students and was admired by several of them.[[2]](#cite_note-V1C2-2) Befitting his occupation and rank, he dons a sword on his side.

After taking dozens of Beads of Diablos, the wounds on his body instantly regenerated with his muscles tightening, eyes becoming bloodshot, and his capillary vessels protrude to the point of bulging out as if he’s being crushed by a tremendous force.

In the Manga, his sclera eyes turn black, and his pupils turn red. His veins were also visible all over his body.

In the Anime, when Zenon mutated, his hair volume risen straight up with the sclera of his eyes and pupil turned black and red respectively. His body mass increased into a monster-like figure to the point where his clothes were ripped apart with his skin turning dark. His veins on his body were also visible as a result of engulfing dozens of Diablos' Tears.[[3]](#cite_note-:0-3)

## Personality

|  |  |  |
| --- | --- | --- |
| “ | I’ll show you the power of the Rounds next generations. | ” |
| — Zenon to Shadow, Light Novel Volume 01 | | |

While several students at the Academy regarded Zenon as friendly and popular in due to his prominence within the kingdom, all of it was a façade as the real Zenon was an egotistic self-entitled man. He was delusional to the point he constantly boasted about his accomplishments and believed he deserved fame and glory. He looked down on others like Alexia when he took the opportunity to belittle her mediocre skills and performance before he insincerely apologized for comparing her to her sister, Iris Midgar.

However, his ego became his undoing as he severely underestimated his opponents when Shadow bested him numerous times and mocked his so-called superior swordsmanship. Being beaten by Shadow caused his ego to become completely shattered when the dark figure enraged him, shouting constantly at him and further highlighting his bratty nature. His defeat revealed a pitiful side of him when he begged for mercy whilst disregarding his condescension towards others including Alexia.

Despite his prominence and popularity, he drew suspicion from Alexia who hated his façade.[[2]](#cite_note-V1C2-2) He was also noted to be a terrible student by his instructor who was also a Bushin Festival Champion.[[4]](#cite_note-V5C2-4)

## Powers & Abilities

Zenon was a renowned swordsman within the Midgar Kingdom's Knight Order. His strength was noted to stem from his raw magic power, which made his sword strikes sharper and denser than the average Dark Knight.[CITATION NEEDED] Even the Cult of Diablos acknowledged his strength and made him a candidate for the vacant 12th seat of the Knights of Rounds.[CITATION NEEDED]

### Swordsmanship

Zenon was a master swordsman skilled enough to create his own style of fighting and teach it. Because of his experience and proficiency in the art, he was considered by many to be the best sword instructor in the Academy.[CITATION NEEDED] In his fight against Alexia, he easily outmaneuvered her in both technique and strength.

### Mutation

After engulfing dozens of Diablos' Beads, Zenon's physical and magical abilities increased exponentially though at a steep cost. Due to the side effects of the pills distributed throughout the Cult, users of the pills would often suffer from the physical mutilation of their bodies.[[2]](#cite_note-V1C2-2) The most notable examples of the mutation would be the former himself and Lutheran when he consumed them in an attempt to down the mysterious figure.[[5]](#cite_note-V1CF-5) The reasoning behind this was explained by the Head Librarian was that they were meant to be compatible with females specifically, descendants of the Three Heroes.[[4]](#cite_note-V5C2-4)

### Weapons and Equipment

- Sword (A standard equipment and weapon used by all Knights)
- Beads of Diablos (An unfinished product thought to grant immortality. Zenon used a normal version distributed to all members of the Cult to become a Third Awakening)

## Trivia

- After his death, [Beta](Beta.md "Beta") attempted to write a fantasied version of Zenon's confrontation where he made an exaggerated description of Shadow when he confronted him to save Alexia. She attempted to rewrite the princess as herself out of jealously and spite towards her upon learning the things she did with Cid.[[6]](#cite_note-6)

## References

1. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
2. Volume 1 Chapter 2: Assuming the Role of a Side Character at School!
3. Episode 5
4. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
5. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
6. Episode 10

## Site Navigation
