# Manga/Volume 8

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%208](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%208)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_8?action=edit).

## Manga Volume 8

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041129364

### ISBN EN

ISBN 978-1975370916

### Release Date

September 26, 2022 JP
November 21, 2023 EN

## Volume Information

### Pages

144

### Chapters

4

Publication Order

| Previous | Next |
| --- | --- |
| Volume 7 | Volume 9 |

This is the eighth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

Cid’s engaging in a little “fundraising” in the treasure vaults of the Crimson Tower to finance his future shadowbroker activities when he senses the presence of an upcoming boss battle! The newly resurrected Blood Queen is hosting a grisly banquet, and Shadow’s not the only one on the guest list. With Cid’s sister, Claire, diving into the fray on a misguided mission to save him, will she realize she’s getting in over her head before it’s too late…?![[1]](#cite_note-1)

安息の地を作りましょう。吸血鬼も人間も分け隔てなく幸せに暮らせる地を。
異世界に転生し「陰の実力者」設定を楽しむシド。最凶の吸血鬼「血の女王」復活が迫り、宝物目当てに紅の塔へ向かったシドにも血の刃が迫り来る――!?　強大な力と重度の勘違いで突き進む最強奇譚、第８弾！[[2]](#cite_note-2)

## Summary

### Lawless City Incident

## Chapters

- Episode 30
- Episode 31
- Episode 32
- Episode 33

## Characters

:   In order of appearance:

- Cid Kagenou
- [Juggernaut](Juggernaut.md "Juggernaut")
- [Yukime](Yukime.md "Yukime")
- Claire Kagenou
- [Mary](Mary.md "Mary")
- [Crimson](Crimson.md "Crimson")
- [Elisabeth](Elisabeth.md "Elisabeth") (Debut)
- [Beta](Beta.md "Beta")
- [664](664.md "664") (Debut)
- [665](665.md "665") (Debut)
- Rose Oriana
- [Aurora](Aurora.md "Aurora")
- [Alpha](Alpha.md "Alpha")
- Mr. Kagenou
- [Scarface](Scarface.md "Scarface") (Debut)
- [Natsu](Natsu.md "Natsu") (Debut)
- [Kana](Kana.md "Kana") (Debut)
- [Gettan](Gettan.md "Gettan") (Mentioned)

## References

1. [The Eminence in Shadow, Vol. 8 (manga). YenPress](https://yenpress.com/titles/9781975370923-the-eminence-in-shadow-vol-8-manga)
2. [The Eminence in Shadow (8). Kadokawa](https://www.kadokawa.co.jp/product/322205000503/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • **Volume 8** • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
