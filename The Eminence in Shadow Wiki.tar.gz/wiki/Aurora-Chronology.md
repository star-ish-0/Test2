# Aurora/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Aurora/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Aurora/Chronology)

[Main](Aurora.md "Aurora")

[Relationships](Aurora-Relationships.md "Aurora/Relationships")

Image Gallery

## Volume 2

### Sanctuary Infiltration

Aurora first appears as a memory when Shadow is forced to participate in the yearly Goddess' Trial at [Lindwurm](Lindwurm.md "Lindwurm"). Shadow defeats Aurora and uses the ensuing chaos to flee the premises.[[1]](#cite_note-V2C1-1)

Later, Cid Kagenou is surprised when a magical door crosses his path and stops him from going further. Cid opens the door and finds Aurora chained. He reluctantly saves Aurora who admits that she has been imprisoned for over a millennia. The two work together to escape the Sanctuary, which is actually a labyrinth of memories. They are arrived at the chained door with the Holy Sword.[[2]](#cite_note-V2C2-2) But, they were assailed by Acting Archbishop Jack Nelson and the memory of [Olivier](Olivier.md "Olivier"), but Cid defeats them and destroys the core of the prison, which is actually Diablos' left hand.

The Sanctuary is destroyed and Cid has a conversation with Aurora. Aurora tells him that she will cease to exist, but doesn't regret it at all. She also reveals that she was the one who summoned Cid and is glad to have met him. Before disappearing, Aurora tells Cid that if he ever finds the real her, he should kill her. Unknown to Cid, Aurora is the true identity of the great demon Diablos.[[3]](#cite_note-V2C3-3)

## Volume 3

### Red Moon Incident

When Claire went to the top of the red tower of the Lawless City, to rescue her brother Cid, unaware that he was not in danger, Claire was gravely wounded by the Vampire Progenitor [Elisabeth](Elisabeth.md "Elisabeth") and she began to experience a type of blood curse similar to "[Possession](Possession.md "Possession")", while the others fighting while she was unconscious. Aurora appeared to her in a sub-space inside Claire, starting to talk to Claire and helping her with her current state, giving her a spell that will allow her to control the 2 types of blood that flow and now inhabit her body, to later provide her support in combat.

By borrowing Claire's body, Aurora joins the battle manifesting a slight change of character Claire's eyes color from red to violet, with a portion of her power, enough to slow down, damage, and push back the vampire queen Elisabeth, until Claire's body she has possessed reaches its limit due to the magical pressure exerted on it. But luck of all and as Aurora expected, Shadow appears to face and defeat Elisabeth once and for all.

But then at the end the battle the next day, Aurora disappears again, leaving the mark of the Spell on Claire, so that she can help her in the near future.[[4]](#cite_note-V3C3-4)

## Volume 4

### Oriana's "Black Rose" Wedding

Later, after learning of the existence of [Realms](Realms.md "Realms") from [Mordred](Mordred.md "Mordred") the 9th Seat Knight of Rounds, Beta questions him whether Aurora also came from one of these other worlds. However, he claimed that her assumption was false and that Aurora was a genuine inhabitant of their world, and telling her that the demon isn’t the true form of the original Diablos. Mordred elaborated that they were the organism that became the basis for Diablos and theorized that Diablos called the original in from the First Realm.[[5]](#cite_note-V4C3-5)

## Volume 5

### The Academy Disappearances

## Master of Garden

### Masquerade

## References

1. Volume 2 Chapter 1: Fun Times at the Goddess's Trial!
2. Volume 2 Chapter 2: Investigating the Sanctuary!
3. Volume 2 Chapter 3: When Things Get Boring, It's Time for Explosives!
4. Volume 3 Chapter 3: Pursuing the Blood Queen!
5. Volume 4 Chapter 3: Crashing the Ceremony!
