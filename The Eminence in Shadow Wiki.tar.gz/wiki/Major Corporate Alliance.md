# Major Corporate Alliance

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Major%20Corporate%20Alliance](https://the-eminence-in-shadow.fandom.com/wiki/Major%20Corporate%20Alliance)

## Major Corporate Alliance

### Japanese

大（だい）商会（しょうかい）連合（れんごう）

### Romaji

Dai Shōkai Rengō

## General Information

### Leader(s)

[Gettan](Gettan.md "Gettan")
Garter Kikuchi (Figurehead)

### Status

Dissolved

### Affiliates

Garter Corporation

### Base of Operation

Midgar Kingdom

## Debut

### Web Novel

Chapter 120

### Light Novel

Volume 3

### Manga

Chapter 34

### Anime

Episode 24

The Major Corporate Alliance (大（だい）商会（しょうかい）連合（れんごう）, Dai Shōkai Rengō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), abbreviated as MCA, was a coalition of merchant companies in the Midgar Kingdom. Officially led by Garter, president of the Garter Corporation, the alliance sought to prevent the Mitsugoshi company from establishing a commercial monopoly.[[1]](#cite_note-V3C4-1)

## History

Merchants from the Midgar Kingdom noticed the rapid expansion of the Mitsugoshi Company, unaware it was the public front for Shadow Garden. Many merchants viewed Mitsugoshi as a threat, as their products were in high demand and the company's position was solid. To counter Mitsugoshi's influence, the merchants formed a coalition. They envied Mitsugoshi's popular banknotes, which had gained widespread acceptance among the kingdom's citizens.

The Cult of Diablos also saw Mitsugoshi's success as a future threat but couldn't act directly due to their ongoing conflict with Shadow Garden. Seeking to destroy Mitsugoshi without direct involvement, the Cult had [Gettan](Gettan.md "Gettan") volunteer for a mission to lead the MCA through his Garter Corporation, aiming to earn a seat in the Knights of Rounds.

After the introduction of Mitsugoshi's banknotes, the Major Corporate Alliance attempted to replicate the idea. However, their bills were easier to counterfeit. Gettan exploited this by using the Cult's plan to mass-produce counterfeit bills, aiming to create a credit crisis that would bring down Mitsugoshi. The plan was to withdraw the Cult's assets safely and let the Alliance take the fall.

Unbeknownst to the Major Corporate Alliance and the Cult of Diablos, Shadow had a similar plan. He teamed up with [Yukime](Yukime.md "Yukime"), the Spirit Fox and White Tower monarch, to join the secret war between the MCA and Mitsugoshi. Under the alias "John Smith," Shadow implemented the credit collapse plan to manufacture counterfeits using the Alliance's replicate paper money, working with the Snow Fox Corporation of the Lawless City.

## Organization Strength and Influence

By forming a coalition of all trading companies into becoming the Major Corporate Alliance, their power of influence was able to rival Mitsugoshi Company in trade commerce thanks to their many years of business experience.

Another factor in the Alliance's rising influence was the fame of [Gettan](Gettan.md "Gettan"), also known as the "Sword Devil". Not only did he bring a tremendous amount of legitimacy to the organization due to his cunning and charismatic character, but he also provided the Alliance with a strategic plan and manpower.

It was said that the MCA's private army, particularly those from the Garter Corporation, had their strength on par with a small nation. The Alliance's best mercenaries, the [Clovers](Clovers.md "Clovers") were highly skilled assassins from the personal team within Garter Corporation whose members were all handpicked by Gettan himself.

However, all of their best members in the Alliance's raid force, including The Clovers had been unable to stand up against some of the formidable members from Shadow Garden as they have successfully killed all the assassins they sent and gradually whittling down their combat assets, depleting their resources as time goes on.

## Membership

Major Corporate Alliance was created from the union of all the trading companies in Midgar Kingdom's region, who have all merged together into a singular organization brought together by the president of the Garter Corporation, Garter Kikuchi, who became leader of the alliance.

The reality, however, is that despite Garter's contributions to the Alliance, he is not its actual leader, as [Gettan](Gettan.md "Gettan") is the one controlling the alliance behind the scenes and his orders are carried out by Garter.

## Chronology

### Formation of the Alliance

The Major Corporate Alliance was founded at an unspecified time (possibly due to Mitsugoshi's popularity and the company's rapid expansion) created for the sole purpose of destroying Mitsugoshi Company with the president of the Garter Corporation, Garter Kikuchi as the Alliance's leader. Even though Garter had hired Gettan to help him, the Alliance was currently being headlined by [Gettan](Gettan.md "Gettan") as the de facto shadow leader with Garter becoming his subordinate and serving as the figurehead leader.

Gettan had done everything he could to put Mitsugoshi at a disadvantage by giving his orders to Garter to carry out his plan. However, the MCA's only successful effort was making the losses from the traveling salesmen that used to carry Mitsugoshi's goods to the commoners out in the countryside had suffered because of their actions after raiding them, while Mitsugoshi Company isn’t flinching at all for whatever reason due to their urban trade was completely unaffected.

Moreover, the Major Corporate Alliance tried to make paper money just like Mitsugoshi per Gettan's direction without realizing that they have been manipulated by Gettan who is actually acting on behalf of the Cult of Diablos as their collaborator by presenting a plan to the Alliance, with the promise of occupying the 12th seat in the Knights of Rounds.

The Cult intended to start the credit crisis with counterfeit banknotes which will eventually destroy Mitsugoshi along with the Major Corporate Alliance when they finish creating the bills and liquidating them in the marketplace to raise substantial capital, after they relocated their funds to a designate place away from the public eye and intend to sever their ties with the MCA.

### Great Trading Company Conflict

The Major Corporate Alliance attempted to sabotage Mitsugoshi by attacking their carriage supply lines and eliminating employees. However, these efforts were thwarted by the well-trained forces of Shadow Garden, resulting in many deaths and captures among the Alliance's assassins. Despite these attacks, Mitsugoshi's supply lines remained unaffected, leaving the Alliance bewildered.

Gettan ordered his elite mercenaries, the [Clovers](Clovers.md "Clovers"), to infiltrate Mitsugoshi's headquarters, aiming to steal confidential documents, money, and manufacturing details, and to sabotage and kidnap key personnel. This mission failed disastrously, with the Clovers being killed one by one. Even the rear guard, tasked with reporting back in case of failure, did not return, leading Gettan to believe his mercenaries had been eliminated.

When rumors of counterfeit bills reached Gettan, he consulted his superiors. His original plan was to circulate counterfeit bills to undermine both the Alliance and Mitsugoshi, but this plan was compromised when he learned from the Cult's messenger that their counterfeits hadn't been distributed. Suspecting Mitsugoshi of using the Cult's plan against him, Gettan ordered Garter to find 'John Smith' and recover their funds.

As rumors of counterfeits spread, the capital faced a run on the bank, with people exchanging their bills for gold. The Alliance's company presidents, doubting their reserves, pressured Gettan to halt exchanges. Sensing something amiss, Gettan confronted [Yukime](Yukime.md "Yukime"), who revealed she had collaborated with 'John Smith' to cause the credit collapse. During their confrontation, Gettan fatally wounded Yukime.

John Smith appeared and overpowered Gettan, demanding a confession. Misunderstanding John Smith's demand, Gettan took the red pills to augment himself but was ultimately beaten to death.

## Known Members

### Leadership

- [Gettan](Gettan.md "Gettan") (Deceased)
- Garter Kikuchi, president of Garter Corporation (Figurehead; Arrested)

### Enforcers

- [Clovers](Clovers.md "Clovers") (Defunct)
- Garter's private army

## Legacy

After [Gettan](Gettan.md "Gettan")'s death, the MCA went bankrupt and all merchants involved were arrested. Their fall caused the Cult of Diablos to suffer significant losses, and their influence in the Midgar Kingdom waned.[[2]](#cite_note-V3E-2)[[3]](#cite_note-3)

## Trivia

## References

1. Volume 3 Chapter 4: I’ll Destroy It All and Start from Scratch!
2. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fakes Bills!
3. Episode 27

## Side Navigation
