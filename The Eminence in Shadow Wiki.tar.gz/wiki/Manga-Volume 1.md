# Manga/Volume 1

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%201](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%201)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_1?action=edit).

## Manga Volume 1

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041084717

### ISBN EN

ISBN 978-1975325183

### Release Date

July 25, 2019 JP
November 23, 2021 EN

## Volume Information

### Pages

164

### Chapters

4

Publication Order

| Next |
| --- |
| Volume 2 |

This is the first volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

Cid Kagenou has a dream. Not of being some typical protagonist or the Final Boss—he has his eyes set on becoming a hidden mastermind working in the shadows! Now that he’s been reborn in another world, Cid has been hard at work building the perfect stage to act out his long-desired role. The only issue? His imaginary adversaries and plot devices seem to actually exist in this new realm…and he alone is left in the dark![[1]](#cite_note-1)

「我が名はシャドウ。陰に潜み、陰を狩る者…」みたいな設定が現実に…？

主人公でもラスボスでもない。物語に陰ながら介入して密かに実力を示す「陰の実力者」に憧れていた少年、シド。
異世界に転生し、「自分は陰の実力者として、闇の教団を倒すべく暗躍している…」という「設定」を楽しんでいたところ、どうやらその「闇の教団」は実在しているようで…？

シドが率いる陰の組織「シャドウガーデン」が繰り広げる、 最強の勘違いシリアスコメディ、爆誕!![[2]](#cite_note-2)

## Summary

### Kidnapping of Claire Kagenou

## Chapters

- Episode 1
- Episode 2
- Episode 3
- Episode 4
- Special: I Searched Everywhere for a Mythical Eight-Headed Serpent and Never Found It

## Characters

:   In order of appearance:

- Cid Kagenou (Debut)
- Claire Kagenou (Debut)
- [Alpha](Alpha.md "Alpha") (Debut)
- Mr. Kagenou (Debut)
- Mrs. Kagenou (Debut)
- [Beta](Beta.md "Beta") (Debut)
- [Grease](Grease.md "Grease") (Debut)
- [Millia](Millia.md "Millia") (Mentioned)
- Skel Etal (Debut)
- Po Tato (Debut)
- Alexia Midgar (Debut)
- Zenon Griffey (Debut)
- Iris Midgar (Debut)
- [Delta](Delta.md "Delta") (Mentioned)

## References

1. [The Eminence in Shadow, Vol. 1 (manga). YenPress](https://yenpress.com/9781975325183/the-eminence-in-shadow-vol-1-manga/)
2. [The Eminence in Shadow (1). Kadokawa](https://www.kadokawa.co.jp/product/321903000913/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | **Volume 1** • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
