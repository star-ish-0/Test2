# Mundane Mann

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mundane%20Mann](https://the-eminence-in-shadow.fandom.com/wiki/Mundane%20Mann)

## Mundane Mann

### Japanese

ジミナ・セーネン

### Romaji

Jimina Sēnen

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

22

### Height

Unknown

### Hair Color

Black

### Eye Color

Black

### Birthday

June 4

## Personal Information

### Status

Deceased

### Relatives

Baron

## Professional Information

### Occupation

- Aristocrat (Revoked)
- Mercenary
- Guard

### Affiliation

Altena Empire

## Debut

### Web Novel

Chapter 63 (Mentioned)

### Light Novel

Volume 2 (Mentioned)

### Manga

Chapter 20 (Mentioned; Picture)

### Anime

Episode 15 (Mentioned; Picture)

### Game

Seven Shadows Chronicles: Chapter 22

## Portrayal

### Japanese

[Hikaru Midorikawa](https://en.wikipedia.org/wiki/Hikaru_Midorikawa "wp:Hikaru Midorikawa")

### English

Joe Daniels

Mundane Mann (ジミナ・セーネン, Jimina Sēnen[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was an aristocrat of the Altena Empire who later lost his title.[[1]](#cite_note-V2C4-1) He subsequently became a mercenary to sustain himself, taking on various guarding jobs. His final escort job's cargo contained the [possessed](Possession.md "Possession"). Unaware of the danger and contents, he died after a confrontation with [Delta](Delta.md "Delta").[GAME ONLY][[2]](#cite_note-MGC22-2)

A couple of years after Mann's death, [Gamma](Gamma.md "Gamma") and [Nu](Nu.md "Nu") constructed Cid's Bushin Festival disguise after his likeness.[[1]](#cite_note-V2C4-1)

## Appearance

Mundane's face offers no notable traits and presents to others a plain countenance. Bedraggled black hair, a drooping mouth, a five-o'clock shadow, pale skin, and heavy dark bags under dark, sleepy eyes give him a feeble impression.[[1]](#cite_note-V2C4-1)

## Personality

Described as lazy and weak by his peers, Mundane's indolent behavior and low aptitude towards magic caused issues in his house.[WEB NOVEL ONLY][[3]](#cite_note-3) The consequences of his ineptitude to be disowned by the Mann family and aristocratic society.[[1]](#cite_note-V2C4-1) Mundane's circumstances did not stop secret dreams and aspirations to take root in his mind. In the end, they were only dreams and were never realized.[GAME ONLY]

## Death

The 20-year-old Mundane accepted an escort job from the Cult of Diablos to deliver cargo to a transport ship at the port of [Laugus](Laugus.md "Laugus"). One night, Mundane asked about the delayed departure; the main carriage had been wheeled onto the ship. A Cult member replied that there was a delay in loading the goods. When Mundane continued to ask about the contents, the cult member warned that further prying would result in him losing pay. Later attacked by an unknown enemy, he pleaded for his life, claiming wealth and standing. The attacker ignored the plea and killed him.[[2]](#cite_note-MGC22-2)

## Power & Abilities

Mundane Mann did not posses any notable talents when he was alive.

## Trivia

## References

1. Volume 2 Chapter 4: This Situation Calls for a “Who Is That Guy?!?
2. Master of Garden | Seven Shadows Chronicles. Strum of Velgalta: Chapter 22
3. Web Novel: Chapter 63

## Site Navigation
