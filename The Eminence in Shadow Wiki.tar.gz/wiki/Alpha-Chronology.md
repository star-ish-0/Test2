# Alpha/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Alpha/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Alpha/Chronology)

[Main](Alpha.md "Alpha")

[Relationships](Alpha-Relationships.md "Alpha/Relationships")

Image Gallery

### Rise of Shadow Garden

Fortunately, the young elf was discovered by Cid Kagenou, who defeated her captors before healing her [Possession](Possession.md "Possession") and restoring her body to normal. Swearing her loyalty as repayment, the girl, designated as Alpha, was recruited by Cid, who revealed the true nature of [Possession](Possession.md "Possession"), as well as the existence of the masterminds behind the conspiracy, the Cult of Diablos. Upon learning the truth, Alpha agreed to join his cause, formally creating the initial formation of Shadow Garden.[[1]](#cite_note-V1P-1)

Afterward, Alpha, being sheltered and guided by Cid, trained to improve her swordsmanship and magic, while also learning different various skills from her master. Eventually, she was reunited with [Beta](Beta.md "Beta"), before being later joined by [Gamma](Gamma.md "Gamma") and [Delta](Delta.md "Delta"). Together with [Beta](Beta.md "Beta") and [Gamma](Gamma.md "Gamma"), the three discussed and planned the structure of the organization, using their leader's Shadow Wisdom. In the meantime, both Shadow and Alpha continued recruiting members, lastly enlisting [Epsilon](Epsilon.md "Epsilon"), [Zeta](Zeta.md "Zeta"), and [Eta](Eta.md "Eta").

### Assault on the Order

After Cid's elder sister, Claire, was kidnapped by the Cult of Diablos, Alpha led the investigation to track down their location, although her master quickly ascertained their enemies' position himself. Later, as Shadow Garden assaulted the Cult's hideout, Alpha led the other members in slaughtering the guards before confronting the culprit behind the abduction, Viscount [Grease](Grease.md "Grease"). Although she was easily able to overwhelm him, Grease barely escaped capture after consuming drugs to enhance his strength. Despite the Viscount's getaway, Alpha nevertheless was confident that Shadow would handle him, believing that he had already foreseen their enemies' movement. Subsequently, her faith was soon rewarded, as Cid successfully defeated Grease and liberated his sister from captivity.

Following their success, Alpha and the other girls later requested a meeting with their master, showcasing the results of their research into the [Curse](Possession.md "Possession") and the Cult. In conclusion, the seven determined that they would need to disperse in order to rescue other victims as well as continue investigating their sole enemy. After receiving Shadow's permission, Alpha tearfully departed along with her allies to begin bolstering their resistance.[[2]](#cite_note-V1C1-2)

### The Kidnapping of Alexia Midgar

Alpha later reunited with Cid after learning of his suspected involvement with the abduction Princess Alexia Midgar, particularly her master's relationship with the royal member. After both suspected the Cult's involvement in the kidnapping and conspiracy against him, the young elf then departed to gather their forces to counterattack the Cult and rescue the princess.

Later, observing Shadow Garden's operation's progress, Alpha intervened during Princess Iris' battle against the mutated [Millia](Millia.md "Millia"), the experimented daughter of [Grease](Grease.md "Grease"), opting to dispatch the child as mercy before disappearing.[[3]](#cite_note-V1C3-3)

### Midgar Academy Terrorism

Absent during the terrorist assault on Midgar Academy for Dark Knights, Alpha mets with Gamma after the incident. Gamma informed her of the situation. Despite Shadow Garden being framed as the perpetrators by the Cult of Diablos, she nevertheless resolved to continue following her master's will, ordering [Gamma](Gamma.md "Gamma") to gather the Seven Shadows before departing.[[4]](#cite_note-V1FC-4)

### Holy Ground Infiltration

After sending a letter to Cid to come to [Lindwurm](Lindwurm.md "Lindwurm"), Alpha meanwhile examined the murder of Archbishop [Drake](Drake.md "Drake"), however, her focus remained on the truth regarding the Hero [Olivier](Olivier.md "Olivier") and the [Sanctuary](Sanctuary.md "Sanctuary").[[5]](#cite_note-V2P-5)

As such, after Shadow defeated the Witch of Calamity [Aurora](Aurora.md "Aurora") during the Goddess' Trial, Alpha and Shadow Garden seized the opportunity to investigate the Sanctuary, forcibly bringing acting Archbishop Jack Nelson, as well as Princess Alexia and Rose Oriana unexpectedly.[[6]](#cite_note-V2C1-6)

Within the Sanctuary, Alpha revealed her lineage with [Olivier](Olivier.md "Olivier"), as well as her ancestor's history and goal of the Cult of Diablos until Nelson attempted to retaliate. Along with [Delta](Delta.md "Delta"), the two repelled the Knight of Rounds' onslaught before retreating upon the completion of their investigation.[[7]](#cite_note-V2C2-7)

Later, after the destruction of the Sanctuary by their master, [Alpha](Alpha.md "Alpha") was briefed on the situation by [Epsilon](Epsilon.md "Epsilon") who then announced the results of their research, revealing Aurora as the true identity of Diablos.[[8]](#cite_note-V2C3-8)

### God of War Tournament

After Rose escaped from the Bushin Festival, Alpha approached the fugitive princess to offer her the opportunity to join them to rescue the Oriana Kingdom against the Cult of Diablos. Upon Rose's acceptance, Alpha then guided the former student council president to their hidden base, [Alexandria](Alexandria.md "Alexandria"), where she entrusted their latest recruit to the instructor [Lambda](Lambda.md "Lambda") for training before departing.[[9]](#cite_note-V2FC-9)

### Great Trade Alliance Conflict

As the conflict with Mitsugoshi Company's rival, the Major Corporate Alliance, escalated, Alpha and Shadow Garden noticed the increasing circulation of counterfeit banknotes into the economy, which consequently could ruin both companies if left unrestricted. However, their attempts to locate the source of the forgeries had failed due to the interference of a mysterious guard named John Smith. After dispatching [Delta](Delta.md "Delta") resulted in her presumed death, Alpha then confronted the new adversary, only to discover that Shadow was the true culprit. Demanding an explanation, she attempted to subjugate him to force an answer. However, the Seven Shadow was ultimately defeated and left by her master.[[10]](#cite_note-V3C6-10)

Following the confrontation, Alpha became heavily depressed while the counterfeit situation continued to worsen, believing that her master had abandoned Shadow Garden. Fortunately, upon receiving a decrypted message previously given by Shadow earlier detailing his motives, she was exuberant that he had not betrayed them and even supplied them the funds to resolve Mitsugoshi's financial crisis. With her faith reaffirmed, Alpha then departed with Shadow Garden to retrieve their master's capital after reuniting with [Delta](Delta.md "Delta").

Subsequently, Shadow Garden was able to locate and collect the stash before infiltrating the Great Trade Alliance leader, [Gettan](Gettan.md "Gettan")'s residence, discovering a letter addressed to his former fiancé, [Yukime](Yukime.md "Yukime"), the White Monarch of Outlaw City. Later, Alpha approached the fox lady, giving her Gettan's letter before revealing Shadow's connection with the Mitsugoshi Company and his plan to establish their strength. Despite the revelation, the two agreed to form an alliance against the Order of Diabolos and departed together to discuss their plans.[[11]](#cite_note-V3E-11)

### Return to Earth

Alpha confronted Beta after she and the Shadow returned from their adventure in another world. Beta had taken some of the otherworld's technologies back with her as well as one of its inhabitants, from whom they could hopefully learn how to use these items. However, while the girl intended to just pawn her captive off to someone else, Alpha placed the otherworlder under Beta's own custody, arguing that she needed to take responsibility and fearing what [Eta](Eta.md "Eta") would do if she got her hands on an alien.[[12]](#cite_note-V4E-12)

## References

1. Volume 1 Prologue: Preparing the Perfect Stage!
2. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
3. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
4. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
5. Volume 2 Prologue: To Lindwurm, the Scared Land!
6. Volume 2 Chapter 1: Fun Times at the Goddess's Trial!
7. Volume 2 Chapter 2: Investigating the Sanctuary!
8. Volume 2 Chapter 3: When Things Get Boring, It's Time for Explosives!
9. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
10. Volume 3 Chapter 6: Circulating Counterfeit Cash!
11. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fakes Bills!
12. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
