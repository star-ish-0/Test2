# Millia/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Millia/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Millia/Relationships)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Millia/Relationships?action=edit).

[Main](Millia.md "Millia")

[Chronology](Millia-Chronology.md "Millia/Chronology")

Image Gallery

## Family

### [Grease](Grease.md "Grease")

Millia loved her father and held onto the locket of the two of them for her dear life. So much so that her arm merged into her torso just from holding tightly onto her precious treasure.

## Others

### Alexia Midgar

Although mutated and in immense pain from the possession, Millia was self-aware enough to prioritize freeing Alexia before making her own escape.

## Shadow Garden

### Shadow

Although Shadow killed her father three years before her defection, Millia most likely holds her savior in high regard similar to all Shadow Garden.

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

#### [Beta](Beta.md "Beta")

### Numbers

#### [Lambda](Lambda.md "Lambda")

#### Akane Nishino

Millia and Akane joined about the same time, becoming contemporaries once recruited, but had a language barrier due to Akane's [alien origin](Earth.md "Earth"). Like Millia, Akane was healed directly by Shadow.

However, she does seem to hold some fear for Akane for an unexplained reason, as she immediately ran out of her room when it was revealed that the 2 would be cohabitating during their stay at Alexandria.

## Cult of Diablos
