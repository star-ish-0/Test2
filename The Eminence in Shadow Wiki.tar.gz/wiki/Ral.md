# Ral

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Ral](https://the-eminence-in-shadow.fandom.com/wiki/Ral)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Ral?action=edit).

## Ral

### Japanese

ラル

### Romaji

Raru

## Characteristics

### Race

[Therianthrope](Therianthrope.md "Therianthrope") (Wolf Therianthrope)

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

- Unnamed Father
- Unnamed Biological Mother †
- [Sara](Delta.md "Delta") (Younger Sister) (Killer)
- [Ren](Ren.md "Ren") † (Older Brother)

## Debut

### Light Novel

Volume 6

Ral (ラル, Raru[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), was [Delta](Delta.md "Delta")'s older brother.

## Appearance

## Personality

## Chronology

## Relationships

## Powers & Abilities

## Trivia

## References

## Site Navigation
