# Leaf One

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Leaf%20One](https://the-eminence-in-shadow.fandom.com/wiki/Leaf%20One)

## Leaf One

### Japanese

一葉（かずは）

### Romaji

Kazuha

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Brown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Assassin

### Affiliation

Major Corporate Alliance
[Clovers](Clovers.md "Clovers")

## Debut

### Web Novel

Chapter 121

### Light Novel

Volume 3

### Manga

Chapter 35

### Anime

Episode 25

## Portrayal

### Japanese

[Taku Yashiro](https://en.wikipedia.org/wiki/Taku_Yashiro "wp:Taku Yashiro")

Leaf One (一葉（かずは）, Kazuha[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the leader of the [Clovers](Clovers.md "Clovers"), a small personal group under the Garter Corporation.

## Appearance

In the manga, Leaf One is a tall adult man presumably in his late 20s with medium-length hair tied up in a short ponytail. He adorned a black-hooded assassin outfit and has a dagger-like tattoo underneath his left eye, marking him as the leader of the Clovers.

In the anime, his hair is now a brown, choppy flat-top and wears dark-olive full-body tactical combat armor with fingerless gloves. Most of his face is obscure due to his headgear covering everything but the eyes although it's presumed, he doesn't have his facial tattoo anymore like the rest of the Clovers.

## Personality

## Chronology

### Great Trading Company Conflict

## Powers & Abilities

## Relationships

## Trivia

## References
