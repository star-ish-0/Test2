# Skel Etal

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Skel%20Etal](https://the-eminence-in-shadow.fandom.com/wiki/Skel%20Etal)

## Skel Etal

### Japanese

ヒョロ・ガリ

### Romaji

Hyoro Gari

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

15

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Brown

### Birthday

March 5

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Student

### Affiliation

Midgar Academy for Dark Knights

## Debut

### Web Novel

Chapter 10

### Light Novel

Volume 1

### Manga

Chapter 3

### Anime

Episode 3

## Portrayal

### Japanese

[Yoshitsugu Matsuoka](https://en.wikipedia.org/wiki/Yoshitsugu_Matsuoka "wp:Yoshitsugu Matsuoka")

### English

Nathan Wilson

### French

Aurélien Raynal

### Italian

Giuseppe Palasciano

### German

Julian Manuel

Skel Etal (ヒョロ・ガリ, Hyoro Gari[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a student of Midgar Academy for Dark Knights and a friend of Cid Kagenou. He is the second son of the Baron Etal family.[[1]](#cite_note-V1C2-1)

## Appearance

Skel is a plain-looking student, wearing the Midgar Academy for Dark Knights uniform. His physique is tall and thin.

In the anime, due to having to work to pay for his gambling debts, his skin became darker due to sun burns. But his skin tone would be restored after Shadow's "Recovery Atomic" technique.[[2]](#cite_note-AS1E20-2)[[3]](#cite_note-AS2E03-3)[ANIME ONLY]

## Personality

Skel has shown to drag his friends into his various schemes, whether to gain money or getting a girlfriend. This made him a target of his friend, Cid's wrath. He usually ropes Cid into his and Po's schemes of trying to get an attractive girlfriend. This always ends in failure for Skel and Po.

## Chronology

### The kidnapping of Alexia Midgar

At school, Skel, along with Cid and Po made a bet that the loser should confess to Princess Alexia. However, while Cid lost the bet, Alexia accepted the boy's offer and the two started a relationship much to Skel's jealousy.

Alexia later reveals to Cid that she spoke to Skel and Po who told her about the bet.

### Midgar Academy Terrorist Attack

During the day, Skel selfishly enters Cid's name to have him participate in the Senbatsu tournament earning a punch in the gut by the latter. The three then went to buy new chocolate from Mitsugoshi Co. While there, he tries and fails to impress a [beautiful attendant](Nu.md "Nu") who was only interested in Cid. Skel and Po would despair as the attendant took Cid to answer a questionnaire.

He nervously tries to offer chocolate to an upper-class girl, but his attempts cause her boyfriend to angrily take him away for a talk, though the girl announced she was keeping the chocolate, to his dismay. Both Cid and Po walk away while he was being "talked to".

When the terrorists attack the academy and Cid was presumably killed, Skel cries in anguish over his friend. Later, he and Po are seen sleeping by Cid's bedside while his wounds were tended to.

### Bushin Festival Tournament

Light Novel/Manga

Anime/Game

Skel would later start gambling in hopes of amassing money but this backfires, leaving him broke and asking Cid for money for his gambling addiction. In the anime, Skel attempted to use Cid as leverage when debt collectors carried him away from the venue when Mundane Mann declined Annerose's offer to train her home country of Velgalta.[[4]](#cite_note-4)

Skel was later seen working to pay off his gambling debt. But due to working long hours his skin tone became darker.[[2]](#cite_note-AS1E20-2)

### Red Moon Incident

Anime/Game

After the forced labor he had to do as a fisherman abroad, Skel in the end, as he could not earn enough to pay his debt, was reduced to being a slave, and was transported to the Lawless City, to be sold, as buyers pet, but during the nights shortly before the arrival of the Red Moon, Skel managed to escape, (partly with the help of his friend Po), then they went to the area governed by the White Tower, to enjoy a night of strong love. with the prostitutes, to say goodbye to her virginity, but before trying, as night fell, both Skel and his friend became victims of the attacks of Ghouls, due to the red moon that began to show, throughout the Night.[[5]](#cite_note-5)

### Great Trading Company Conflict

### The Academy Disappearances

### Bloody Midgar Serial Murder Terror

## Image Gallery

## Trivia

- Skel's Japanese name is Hyoro Gari. Hyoro (ヒョロ) translates to weak and slim, while Gari (ガリ) means very thin.
- Skel's English name is play on the word "skeleton" .
  - It may also be related to the American slang word "skell", which "refers to a person who is homeless, vagrant or derelict." Although to be fair, that could just be coincidental.
- Skel has a gambling addiction, to amass large amounts of money by using Cid, Po, and the bets during The Bushin Festival, but is horrible at betting, choosing to places bets on ten matches at once (thinking that his battle scouter is perfect for future bets), instead of one at a time (causing him to be broke) and suffer from a gambling debt.

## References

1. Volume 1 Chapter 2: Assuming the Role of a Side Character at School!
2. Episode 20
3. Episode 23
4. Episode 18
5. Episode 21

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • **Skel Etal** • Po Tato • Alexia Midgar • Christina Hope • [Isaac](Isaac.md "Isaac") • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |
