# Elf

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Elf](https://the-eminence-in-shadow.fandom.com/wiki/Elf)

Elves (エルフ, Erufu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are one of the races in the world of The Eminence in Shadow.

Elves are better at magical power and have a much longer lifespan than [Humans](Human.md "Human") and [Therianthropes](Therianthrope.md "Therianthrope").[CITATION NEEDED]

Because their longer lifespan elves grow differently than humans do, some can be as tall as teenagers or smaller. This applies to family as well, where the older sibling may be shorter than the younger sibling(s).[CITATION NEEDED]

Elves have a society akin to that of humans, meaning that their countries are managed by an aristocracy and royal family.[CITATION NEEDED]

Dark Elf are a close relative of the Elves.

## Abilities

Out of the Three Races, Elves have high magic potential making them powerful magic users. Unfortunately, this trait is what makes them susceptible to magical overload, especially those that possessed the blood of the Three Heroes.[CITATION NEEDED]

Cid noted them to mature faster at a young age, making them vastly intelligent compared to their neighbors.[CITATION NEEDED]

## Known Individuals

- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Gamma](Gamma.md "Gamma")
- [Epsilon](Epsilon.md "Epsilon")
- [Eta](Eta.md "Eta")
- [Olivier](Olivier.md "Olivier")
- [Beatrix](Beatrix.md "Beatrix")
- [Lambda](Lambda.md "Lambda")
- [Mu](Mu.md "Mu")
- [Sigma](Sigma.md "Sigma")
- [Chi](Chi.md "Chi")
- [Omega](Omega.md "Omega")
- [89](89.md "89")
- [Victoria](Victoria.md "Victoria")
- [664](664.md "664")
- [665](665.md "665")
- Lalanoa Hinoizumino
- Tokiseiryuno Sakura
- [Shinji](Shinji.md "Shinji")
- [Gendou](Gendou.md "Gendou")
- [Otoutrion](Otoutrion.md "Otoutrion")
- Sword God
- [Ashgrey](Ashgrey.md "Ashgrey")
- [Secondary](Secondary.md "Secondary")
- [Ryuu](Ryuu.md "Ryuu")
- [Sakisa](Sakisa.md "Sakisa")
- [Salaman](Salaman.md "Salaman")
- [Koban](Koban.md "Koban")
- King Anorion (deceased)
- Ainoa Hinoizumino (deceased)

## Trivia

- According to Beatrix there are few elven towns left around the world.[GAME ONLY][CITATION NEEDED]
