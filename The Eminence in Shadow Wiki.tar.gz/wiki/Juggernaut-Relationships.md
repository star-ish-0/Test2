# Juggernaut/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Juggernaut/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Juggernaut/Relationships)

[Main](Juggernaut.md "Juggernaut")

[Chronology](Juggernaut-Chronology.md "Juggernaut/Chronology")

Image Gallery

## Lawless City

### [Yukime](Yukime.md "Yukime")

Leader of the White Tower. The two leaders held no respect for each other as they often fought whenever they saw each other. However, they knew better when they collaborated with Shadow in defeating Elisabeth out of safety for the denizens of the Lawless City.[[1]](#cite_note-:2-1) Her collaboration with Shadow as John Smith inadvertently lead to his death when John whimsically ordered Juggernaut's assassination through Delta.[[2]](#cite_note-:0-2)

### [Elisabeth](Elisabeth.md "Elisabeth")

Leader of the Crimson Tower. Juggernaut alongside Shadow and Yukime agreed to collaborate in dethroning her after the activation of the Red Moon caused chaos and panic within the city. Although the two heads of the city stood their ground, they ultimately struggled against her until Shadow confronted her. Unbeknownst to either of them, the mysterious figure was handicapped during their fight.[[3]](#cite_note-:1-3)

### [Crimson](Crimson.md "Crimson")

Personal advisor of Elisabeth and temporary head of the Crimson Tower. The two had a brief instance where the vampiric supremacist tasted utter defeat by him. Juggernaut wanted face Crimson again to the point where he interrogated every captured vampire to ask for his whereabouts.

## Others

### Shadow

Leader of Shadow Garden. The leader of the Black Tower was aware of his existence prior to meeting him through gossip. Throughout their interactions, he was terrified of the mysterious figure's prowess after witnessing it firsthand expect for an instance where he had cursed him for knocking him off the floors of the Crimson Tower.[[3]](#cite_note-:1-3) Although he held nothing personal towards the foul mouthed leader, Shadow whimsically ordered his death through Delta after she nearly blew his cover as "John Smith".[[2]](#cite_note-:0-2) His head was later presented to him when she wanted a reward.

## References

1. Volume 3 Chapter 2: Storming the Crimson Tower!
2. Volume 3 Chapter 6: Circulating Counterfeit Cash!
3. Volume 3 Chapter 3: Pursuing the Blood Queen!
