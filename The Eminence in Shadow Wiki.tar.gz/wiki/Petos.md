# Petos

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Petos](https://the-eminence-in-shadow.fandom.com/wiki/Petos)

CLEANUP: ONLY YOU CAN IMPROVE THE WIKI!

You do not need to have peregrinated around Midgard or experienced dimensional travel help here. Shadow Garden encyclopedists have marked this page to be cleaned up by the community. You can assist the wiki by proofreading or checking if this article follows our standards and layout guide. Your contributions will make the wiki better for everyone in this community.

[Chronology](Petos-Chronology.md "Petos/Chronology")

[Relationships](Petos-Relationships.md "Petos/Relationships")

Image Gallery

## Petos

### Japanese

ペトス

### Romaji

Petosu

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Black

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

- 10th seat of the Knights of Rounds
- High Priest (undercover)

### Affiliation

Cult of Diablos

## Debut

### Light Novel

Volume 5

### Manga

Chapter 61

Petos (ペトス, Petosu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a high priest who's also the 10th Seat Knights of Rounds of the Cult of Diablos, and the one who wiped out [Zeta](Zeta.md "Zeta")'s race.

## Appearance

Petos is a man with cropped black hair and wearing round sunglasses.

## Personality

Like his comrades, Petos is a wicked man, as he turned an entire village against the daughter of their leader and had the family persecuted. He also killed a young baby boy in front of his sister while showing no remorse for actions. Petos when speaking has an unclear tone which is sometimes polite and rude, whether it's natural or intentional.

According to [Fenrir](Fenrir.md "Fenrir"), Petos is a rather unpleasant person.

## Powers & Abilities

Being the 10th Seat Round Knight, Petos is considered the strongest Cultist and also one of the Cult of Diablos executive leader.

### Weapons and Equipment

Petos using a chain as his weapon.

## Trivia

- He is the first Cult's Knights of Rounds member to live past his introduction due to not fighting Shadow or Shadow Garden head-on.

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | [Loki](Loki.md "Loki") • [Hel](Hel.md "Hel") • [Jormungandr](Jormungandr.md "Jormungandr") • [Fenrir](Fenrir.md "Fenrir") • [Mordred](Mordred.md "Mordred") • **Petos** • Jack Nelson • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • Sir Gaunt | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • [Jean](Jean.md "Jean") • Dark Spider • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • [Gray](Gray.md "Gray") • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • Reina Oriana • [Isaac](Isaac.md "Isaac") | |
