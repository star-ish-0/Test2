# Goldy Gilded/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Goldy%20Gilded/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Goldy%20Gilded/Chronology)

Main

Relationships

Image Gallery

### Background

### Bushin Festival

Goldy travelled to Midgar and participated in the country's Bushin Festival. While watching the fights from the seatings, he encountered two students, one of them being his biggest fan. After boasting about his abilities, Goldy witnessed the qualifying thirds round match between Mundane Mann and Gonzales and was surprised how incredibly weak the former was causing him to laugh. However, he stopped when Mundane somehow took down Gonzales easily.[[1]](#cite_note-1)

When he entered the arena and faced off against Mundane on the qualifying fourth round match, Goldy immediately tried to strike him down only to be shocked once again that his opponent somehow able to dodge his attack. He immediately jumped back before he could retaliate but only found that Mundane barely noticed what he was doing. Angered that he was being disrespected, Goldy tried to kill Mundane using his most powerful attack. Unfortunately, he was knocked down by Mundane before he could deliver the attack.[[2]](#cite_note-V2C5-2)

In the anime, after the Bushin Festival, Goldy packs his things and decide to ride a train to escape until [Quinton](Quinton.md "Quinton") follow him.[[3]](#cite_note-3)

### From Dark Knight to Slave

Goldy teamed up with [Quinton](Quinton.md "Quinton") and the two traveled to the Lawless City to face the [Blood Queen](Elisabeth.md "Elisabeth") of the Red Tower. When they arrived at the building, they encountered the tower's watchdog. The two arrogantly fought the man but weren't able to defeat him, with Quinton being cut down by the watchdog's blade. Goldy realized in horror that the watchdog was the White Demon. The Victorious Golden Dragon immediately fled, abandoning Quinton. Alas, he didn't get far as when residents of the Lawless City started attacking him.[[4]](#cite_note-:0-4)

Captured, a brutalized Goldy was enslaved alongside Quinton. The two encountered Cid Kagenou and Claire Kagenou passing by when they tried begging for their help. Unfortunately, they failed after the siblings left with someone else purchasing them to their horror.[[5]](#cite_note-:1-5)

## References

1. Episode 15
2. Volume 2 Chapter 5: A Battle to Attract Only MVPs!
3. Episode 20
4. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
5. Volume 3 Chapter 1: Lawless City Bandit Hunting!
