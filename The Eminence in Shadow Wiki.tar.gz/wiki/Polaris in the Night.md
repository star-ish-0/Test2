# Polaris in the Night

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Polaris%20in%20the%20Night](https://the-eminence-in-shadow.fandom.com/wiki/Polaris%20in%20the%20Night)

## Polaris in the Night

## Information

### Artist(s)

Numbers

### Composer(s)

Tsubasa Ito

### Arranger(s)

Tsubasa Ito

### Lyrics

Kotomi Fukagawa

### Release date

October 12, 2023

Polaris in the Night is the ending theme song for the second season of the anime adaptation The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). The song was performed by the voice actresses of the Numbers: Ikumi Hasegawa, Maaya Uchida, Mayu Minami and Ryōko Maekawa.

## Lyrics

- [Kanji](#)
- [Romaji](#)
- [English](#)

どこまでも深い　闇夜と

思って 目を瞑ってた

呼びかける星の声に 気づけないまま

眩しくはない淡い灯

心地いい　そんなあなたを

知らぬうちに　目で追いかけた

息を切らして

ああ　もつれそうになっても

この気持ちははじめて

見たことのない自分に逢える

予感が止まらない…

目の前の道を走る

遠く、迷っても

見上げれば　あなたは変わらないで

そこに居ることを

不思議　でも　信じられる

風が強い日も

Over You 届けようとしなくたっていい

ねえ (知ってる？)

すべての星が回りながら

あなたを目指してる

Polaris in the Night

(Shala Shala-la)

出口などは無い　深淵

下を向いて決めつけた

藍に慣れた目に

届いたのは、光

それは　導いているようで

(聴こえてる)

気にもしていないような

(響いてる)

「君の意思でついておいで」と

笑うの

果てのない道を走る

それが嬉しくて

大丈夫　わたしは変わらないで

ここに居ることを

素敵だと感じられる

雨が降っても

Over You 立ち込める雲の先

うつろう世界　あなたは真ん中にいるの

自由自在に

わたしも行きたい

派手な流星じゃなくても

闇から闇　走る

一瞬いっしゅんの光ひかりになれる

Over You

目の前の道を走る

遠く、迷っても

見上げれば　あなたは変わらないで

そこに居ることを

不思議　でも　信じられる

風が強い日も

Over You 届けようとしなくたっていい

ねえ (知ってる？)

すべての星が回りながら

あなたを目指してる

Polaris in the Night


(Shala Shala-la)

Doko made mo fukai yamiyo to

Omotte me o tsubutteta

Yobikakeru hoshi no koe ni kizuke nai mama

Mabushiku wa nai awai tomoshibi

Kokochī sonna anata o

Shiranu uchi ni me de oikaketa

Iki o kirashite

Aa motsuresō ni natte mo

Kono kimochi wa hajimete

Mita koto no nai jibun ni aeru

Yokan ga tomaranai...

Me no mae no michi o hashiru

Tōku, mayo tte mo

Miagereba anata wa kawara nai de

Soko ni iru koto o

Fushigi demo shinjirareru

Kaze ga tsuyoi hi mo

Over You todokeyō to shinaku tatte ī

Nē (shitteru?)

Subete no hoshi ga mawari nagara

Anata o mezashiteru

Polaris in the Night

(Shala Shala-la)

Deguchi nado wa nai shinen

Shita o muite kimetsuketa

Ai ni nareta me ni

Todoita no wa, hikari

Sore wa michibīteiru yō de

(Kikoeteru)

Ki ni mo shite inai yō na

(Hibīteru)

"Kimi no ishi de tsuite oide" to

Warau no

Hate no nai michi o hashiru

Sore ga ureshikute

Daijōbu watashi wa kawara nai de

Koko ni iru koto o

Suteki da to kanjirareru

Ame ga futtemo

Over You tachikomeru kumo no saki

Utsurō sekai anata wa mannaka ni iru no

Jiyū jizai ni

Watashi mo ikitai

Hade na ryūsei janakutemo

Yami kara yami hashiru

Isshun no hikari ni nareru

Over You

Me no mae no michi o hashiru

Tōku, mayo tte mo

Miagereba anata wa kawara nai de

Soko ni iru koto o

Fushigi demo shinjirareru

Kaze ga tsuyoi hi mo

Over You todokeyō to shinaku tatte ī

Nē (shitteru?)

Subete no hoshi ga mawari nagara

Anata o mezashiteru

Polaris in the Night


(Shala Shala-la)

An endlessly deep dark night

I thought as I closed my eyes

Still unaware of the voice of the star calling out to me

A faint light not too bright

But comforting, that's how you were

Before I knew it, I was following you with my eyes

Even if I run out of breath and start to stumble

I've never felt this before

I can't stop the feeling

That I can meet a me I've never seen before

I run down the path in front of me

I run far, even when I'm lost

If I look up, you won't have changed

You'll be there

It may be strange, but I can believe it

Even on windy days

I don't have to try to reach over you

Hey (Did you know?)

As all the stars revolve

I keep my sights on you

Polaris in the Night

(Shala Shala-la)

There's no way out in this abyss

I had already decided as I looked down

To my eyes accustomed to indigo

Light has finally reached

It's as if it's guiding me

(I can hear it)

As if I'm not concerned

(It's echoing)

"Follow your own will and come with me,"

It laughs

I run on the endless road

I'm happy about it

It's okay, I won't change

I can feel that I'm here

Even on rainy days

Beyond the clouds that envelop you

In a changing world, you're at the center

I want to go freely

Just like you

Even if I'm not a dazzling meteor

I run from darkness to darkness

Becoming a momentary light

Over You

I run down the road before me

Even if I get lost in the distance

When I look up, you remain unchanged

I can't help but believe

It's strange but I can trust

Even on days when the wind is strong

It's okay not to try to reach you

Hey (Do you know?)

While all the stars revolve around

They're aiming for you

Polaris in the Night


(Shala Shala-la)

## Ending Versions

【ラムダ-CV-長谷川育美 Ver.】「陰の実力者になりたくて！ 2nd season」 ノンクレジットエンディング：「Polaris in the Night」

Lambda (Ikumi Hasegawa) Ver.

【ニュー-CV-内田真礼 Ver.】「陰の実力者になりたくて！ 2nd season」 ノンクレジットエンディング：「Polaris in the Night」

Nu (Maaya Uchida) Ver.

【カイ-CV-南真由 Ver.】「陰の実力者になりたくて！ 2nd season」 ノンクレジットエンディング：「Polaris in the Night」

Chi (Mayu Minami) Ver.

【オメガ-CV-前川涼子 Ver.】「陰の実力者になりたくて！ 2nd season」 ノンクレジットエンディング：「Polaris in the Night」

Omega (Ryōko Maekawa) Ver.

## Characters

In order of appearance:

- [Lambda](Lambda.md "Lambda") - Episode 22, Episode 30
- [Nu](Nu.md "Nu") - Episode 23, Episode 26
- [Chi](Chi.md "Chi") - Episode 24, Episode 29
- [Omega](Omega.md "Omega") - Episode 25, Episode 31
