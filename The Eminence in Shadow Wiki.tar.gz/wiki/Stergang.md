# Stergang

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Stergang](https://the-eminence-in-shadow.fandom.com/wiki/Stergang)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Stergang?action=edit).

## Stergang

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Baron

## Debut

### Light Novel

Volume 6

### Manga

Chapter 68

Stergang (グレハン, Gurehan[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a member of the Thirteen Nightblades.

## Appearance

## Personality

## Synopsis

## Powers & Abilities

## Relationships

## Trivia

## References
