# Epsilon/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Epsilon/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Epsilon/Chronology)

[Main](Epsilon.md "Epsilon")

[Relationships](Epsilon-Relationships.md "Epsilon/Relationships")

Image Gallery

## Background

Epsilon was the daughter of an elven noble family. She was praised by many for her beauty, intellect, and her martial arts skills. Then, her life took a dramatic turn when she was discovered to have [Possession](Possession.md "Possession") Epsilon's family and her closest friends disowned her and she was forced to run away from being hunted by the people she once trusted.

She crawled her way up a mountain trail but the [Possession](Possession.md "Possession") started to take effect on her body. Suddenly, she was rescued from death by Cid. Since then, she swore loyalty to him.

When she met the other members of Shadow Garden, Epsilon was dismayed at how lacking she was compared to her more skilled superiors such as [Delta](Delta.md "Delta"), [Gamma](Gamma.md "Gamma"), and [Beta](Beta.md "Beta"). Despite this, she moves forward out of love for her master and later decided to improve her appearance which would be appealing to him. During that time, she learned about the slime bodysuit and realized the potential that would allow her to reach her goal. By experimenting with it, she can significantly develop her magic skills, earning [Alpha's](Alpha.md "Alpha") praise. She is called the "Precision" for her magic control.[[1]](#cite_note-V2C2-1)

## Volume 1

### First Assault on the Cult

Epsilon along with the "Seven Shadows" assaulted the hidden secret base, where Claire Kagenou was being held captive. After they've dealt with the guards and Shadow defeating Viscount [Grease](Grease.md "Grease"), they rescued Claire and return home. Epsilon would leave Cid Kagenou along with the other members to hunt down the Cult of Diablos.[[2]](#cite_note-V1C1-2)

### Becoming Shiron

After learning that all members of Seven Shadows had their respective roles, especially [Beta](Beta.md "Beta") had become a well-known writer, Epsilon decided to become a pianist in the Oriana Kingdom by presenting his debut plans to [Alpha](Alpha.md "Alpha") and [Gamma](Gamma.md "Gamma") for evaluation. With Lambda's honest opinion, Epsilon's plans were approved by Alpha and later Gamma would full-time investment in Epsilon in her debut along with publicizing Luna, Ltd.'s (former name of Mitsugoshi Company before changing the name) fashion business and promoting [Alexandria](Alexandria.md "Alexandria") tea to aristocrats at the garden party, which was hosted by the MNA branch of the Midgar Kingdom.

Before Epsilon made his debut as a pianist, he was trained by [Lambda](Lambda.md "Lambda") to be able to know the proper nobility etiquette so that later there would be no failures when performing. After the training was over, Gamma told Epsilon that Beta had arranged everything she needed during the event.

When the garden party started, Epsilon with the name "Shiron" as a wandering pianist made her debut by playing all the music that Shadow had taught her in front of the nobles, especially the Oriana Kingdom who wants her to become their patrons. After his debut, Shiron's name was known throughout the world as a professional pianist and composer and received many awards.

## Volume 2

### Sanctuary Infiltration

Epsilon under orders by Alpha investigated [Lindwurm](Lindwurm.md "Lindwurm") regarding rumors of Drake's corruption and child abductions. On the night of his murder, she reunited with her lord Shadow after killing an assailant and briefed him regarding the murder and that there will be a change in plans. She then left to rejoin with [Alpha](Alpha.md "Alpha") to start their plan to infiltrate the [Sanctuary](Sanctuary.md "Sanctuary").[[3]](#cite_note-3)

When [Beta](Beta.md "Beta") signaled her and her team to come out of hiding, Epsilon apprehended the Acting Archbishop Nelson. Epsilon was then nearly ambushed by [Venom](Venom.md "Venom") the Executioner when her slime bodysuit was cut and exposed. Seeing her life flash before her eyes, the enraged elf decapitated her assailant and threatened the witnesses about her slime suit. After apprehending the Archbishop, Epsilon left him to Alpha to investigate the Sanctuary on her own.

She and her team investigated the Sanctuary to learn that Diablos and [Aurora](Aurora.md "Aurora") are the same entity. While investigating, the effects of the Sanctuary had inadvertently exposed her fake slime suit once more with her asking her squad if they saw anything which they denied. Epsilon later reported to Alpha their findings during Delta's onslaught on Nelson and left the Sanctuary after concluding their investigation was a success.[[4]](#cite_note-4)

In the Anime, Epsilon was seen with Alpha summarizing what had happened after the Sanctuary was annihilated by Shadow.[[5]](#cite_note-5)

### The God of War Tournament

Epsilon meets up with Cid when she was posing as Shiron. She informed him of Rose Oriana's whereabouts and later explained her mission to infiltrate the Oriana Kingdom to uncover both the Chancellor and the Cult of Diablos's involvement.[[6]](#cite_note-V2C6-6)

## Volume 4

### Oriana Kingdom Civil War

Epsilon traveled to the Oriana Kingdom and used her Shiron persona to infiltrate Perv Asshat's faction during their civil war against the Royalist faction for control of the country. When Cid traveled to Oriana castle upon learning that Rose was being held prisoner there, Epsilon saved him from detainment after he was caught loitering around by claiming he was her apprentice. She excitedly applauded Cid's performance to prove his innocence to Doem Ketsuhat and the nobles all the while he pocketed the Chancellor's engagement ring on his way out. She would then form a rivalry with [one](Margaret.md "Margaret") of the kingdom's maids who attempted to poach her master into working for her family.

After reprimanding her protégé and subordinate [Victoria](Victoria.md "Victoria") regarding Rose, Cid came by after showering for them to affectionately welcome him and offer him condiments. Cid briefed them to confirm Epsilon's suspicions of Rose's mother being held hostage and used as leverage over the princess.[[7]](#cite_note-7)

The following day had a predatory Margaret attempt to poach Cid for the last with Epsilon being forced to intervene and help her master. Cid revealed to the elf that he has figured out what to do and was curious to see the Black Rose shocking her after telling them what has happen to the kingdom. Later when they were at the hot springs, Cid revealed the truth regarding the Queen and that the operation would take place on the day of the wedding.[[8]](#cite_note-8)

In the manga, she like Alexia was fixated on his "Excalibur" during his report and briefing at the hot springs.

When the battle for the Oriana Kingdom commenced, Epsilon joined with Beta in defeating [Mordred](Mordred.md "Mordred"). The Round Knight nearly beheaded Epsilon when she narrowly dodged him. Being scarred on her cheek enraged the elf with the former princess joining and the two sides fought to a standstill until Shadow defeated [Ragnarok](Ragnarok.md "Ragnarok"). Left with no option, Mordred mutated himself by consuming a piece of the beast's flesh and fought Shadow, resulting in his defeat and severed head activating the Black Rose.[[9]](#cite_note-9)

### Return to Earth

Epsilon was ecstatic to hear both her master's and Beta's return from Earth during a meeting with the elf alongside Alpha discovering what her rival came back with. After Alpha reprimanded the silver-haired elf, they and other Shadow Garden members resumed their meeting.[[10]](#cite_note-10)

### The Academy Disappearances

Epsilon was briefly mentioned when Alpha was deciding who to send to the Academy to infiltrate. [Eta](Eta.md "Eta") interrupted that Zeta has already infiltrated the Academy after she was dragged and woken up by Gamma.[[11]](#cite_note-11)

## Volume 6

## References

1. Volume 2 Chapter 2: Investigating the Sanctuary!
2. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
3. Volume 2 Prologue: To Lindwurm, the Scared Land!\*
4. Volume 2 Chapter 2: Investigating the Sanctuary!
5. Episode 14
6. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
7. Volume 4 Chapter 1: Putting the Kibosh on Rose Oriana's Wedding!
8. Volume 4 Chapter 2: Begin Operation: Obstruction!
9. Volume 4 Chapter 3: Crashing the Ceremony!
10. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
11. Volume 5 Chapter 4 The World is at Peace Today
