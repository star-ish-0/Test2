# Iris Midgar/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Iris%20Midgar/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Iris%20Midgar/Relationships)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Main

Chronology

Image Gallery

## Family

### Klaus Midgar

Unfortunately, Iris does not seem to have a good relationship with her father, King Klaus. This stems from their fundamentally different ways to solve problems: whereas Iris prefers to tackle things head-on, Klaus' foremost concern is to keep the peace. As a result, he often reprimands his daughter for not thinking through the consequences of her actions. Unfortunately, despite Klaus' attempts to educate Iris on these matters, the latter stubbornly refuses to change her ways.

### Alexia Midgar

Alexia is her younger sister. When they were younger both Iris and Alexia used to spend entire afternoons training together, although Iris always defeated Alexia. With the passage of the next years, their relationship became very distant and strained due to her job as the first princess and leader of the Royal Knights. Iris confesses that she doesn't even remember the last time she and Alexia talked to each other, nevertheless she still cares for her sister and looks up to her most of the time. When she learned that Alexia was kidnapped, Iris did everything in her power to rescue her sister and when she found out the location where Alexia was taken, Iris didn't hesitate and went to that place. After discovering that her sister is safe and alive, Iris hugs her and feels relieved.

After the incident, their relationship begins to improve and now are closer than they used to be. Iris also trusts Alexia enough to let her participate in the investigation about the Cult of Diablos and all their connections with royal knights and the academy. They even spend time off together, with Iris going out with Alexia shopping.

Their relationship would become strained once more as Iris became dead set against Shadow and his organization during the auto spy of the deceased head librarian. Alexia tried to give her testimony and even reach out to her sister when she was being manipulated by Adder. This failed as it showed how exasperated Iris's view on Shadow has become as she would even threaten Alexia if she were to obstruct her in the matter.

It is implied that Iris is jealous of Alexia, due to her younger sister growing up and being more mature than her, no longer being the young little girl that needed to be protected and is resolute to do things on her own way, stemmed with her own insecurities and having been humiliated by Shadow. During the Trading Company Conflict, in one opportunity Iris encounters Alexia and is shocked and surprised that she's been dedicating herself to study subjects outside of training swordsmanship and how wise she's become despite her young age, something Iris can't withstand and just quietly leaves her continuing on her way.

## Crimson Order

### [Glen](Glen.md "Glen")

Glen was a trusted knight Iris knew and was her first choice to join her Crimson Order as well as be her Vice-Commander. His death during the terrorist attack on the Midgar Academy was not only a personal loss, but a professional loss also as Glen's popularity amid the knightly ranks had future candidates doubt Princess Iris's capability to lead.

### Marco Granger

Marco was her junior from the Midgar Academy as well as a protege of Glen, thus he was also Iris's choice to join her Crimson Order concurrent to Glen. It is unclear how Marco feels about Iris after Glen's death, but he remained in their ranks most likely out of loyalty.

Their relationship appeared to have been strained as he watched Iris believe in Adder's fabrications over anything and even apologized to Alexia about it.

### [Adder](Adder.md "Adder")

The Crimson Order's new vice-commander following Glen's death who is secretly a member of the Cult of Diablos. Iris is ignorant that Adder is a spy, who successfully manipulated Iris into believing that the Cult was merely a fabrication by Shadow Garden to justify their crimes and falsifying that all of the Cult's past evils were Shadow Garden's.

## Cult of Diablos

### Zenon Griffey

Her sister's ex-fiancé. Iris had always greatly trusted Zenon, to the point of placing him in charge of investigating Alexia's disappearance. But because of this, she was greatly shocked upon learning that he was really the mastermind behind the whole abduction plot. She was also concerned to learn of his true allegiance to the Cult when Shadow Garden made themselves publicly known.

### Lutheran Barnett / "Sir Gaunt"

### Perv Asshat

Iris held an obvious dislike toward the chancellor of the Oriana Kingdom. However, she remained blind to the true depths of Perv's megalomania and his brainwashing of King Raphael Geerk Oriana, which were overlooked due to the festival and Shadow's appearance.

## Shadow Garden

### [Alpha](Alpha.md "Alpha")

## Others

### Cid Kagenou / Shadow

Being one of Alexia's few friends, Iris was kind towards Cid and even looked after him when he was at the special booths during the Bushin Festival. She admitted that she was envious of his and Claire's close relationship, stating that she wished to have a similar bond with herself and Alexia. Iris is not aware that Cid and Alexia were dating and not just friends.

Iris's opinion about Shadow contrasted that, as she initially viewed Shadow as an enemy that needed to be vanquished. Despite having been told about his vast power and seeing his "I Am Atomic" blow a hole across several city blocks, Iris merely believed that Shadow was using an artifact to enhance himself to cause the havoc he did. This hostility would later turn into pure hatred when Shadow who disguised as Mundane Mann, bested and humiliated her in the Bushin Festival. After revealing his identity, she fought alongside Beatrix to defeat him but was countered in every turn, as the Shadow Garden leader beats the two of them with brutal ease. It's only after seeing Shadow perform his "I Am Atomic!" at close range that she lost the will to fight and begrudgingly accepted that he was one of the strongest Dark Knights in existence. This humiliating defeat would cause her to become obsessed in getting stronger to defeat him.

### Claire Kagenou

After the Alexia kidnapping incident was resolved, Iris and Claire developed a level of friendship and empathy as they both cared deeply for their younger siblings and are willing to go to any lengths for their sake.

### Sherry Barnett

Despite her being just a student, Iris acknowledged Sherry's mechanical skills and trusted her with repairing the Artifact that the Crimson Order recovered from a Cult of Diablos base.

### Rose Oriana

Their interactions were little and brief; however, due to her status as Student Council President and royal background, Rose was the only known witness Iris spoke to when the Academy was terrorized by Diablo Cult members posing as Shadow Garden. Her testimony confirmed both organizations existence and forced Iris to investigate them and ponder whether Shadow is an enemy or not.

### [Luna](Gamma.md "Gamma")

### [Natsume Kafka](Beta.md "Beta")

### [Beatrix](Beatrix.md "Beatrix")

Iris had heard of the famed "War Goddess" and held great respect toward her as a fellow swordswoman. During the events of the Bushin Tournament, she teamed up with Beatrix against Shadow and worked quite well together, even knowing that Beatrix would not be sure of winning against Shadow, Iris offered herself as bait to sacrifice in order to have a chance at defeating him. But in the end, they were ultimately still defeated with ease by Shadow's superior fighting prowess and power.

## References
