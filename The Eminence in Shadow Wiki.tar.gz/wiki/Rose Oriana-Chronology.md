# Rose Oriana/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Rose%20Oriana/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Rose%20Oriana/Chronology)

Main

Relationships

Image Gallery

## Background

### Early Life

Born as the daughter of King Raphael Geerk Oriana and Queen Reina Oriana, Rose was expected to excel in an art and later marry in life. While growing up, she became friends with [Margaret](Margaret.md "Margaret") who later became her family's maid and accompanied her father to the Kingdom of Midgar but snuck out of her inn to play with other children. Due to her extravagant clothes, she attracted bandits who kidnapped her for ransom upon realizing her nobility. Before they intended to use her for ransom, Cid Kagenou under the alias "Fancy Bandit Slayer" suddenly appeared to slaughter all her abductors. Having been saved, Rose became enamored by the sight of the mysterious figure's swordsmanship after witnessing his onslaught and became spurred into developing her own built around basics without wasted movements.[[1]](#cite_note-V2CF-1)

Due to traditions within Oriana royalty, she was required to chose an art to excel in. Despite her country's stigma on swordplay, she made it as her specialty and strived to prove her country wrong in believing that swordplay is uncivilized.[[2]](#cite_note-V2C4-2) In her mid-adolescence, she attended Midgar Academy for Dark Knights as an exchange student, where she later became Student Council President.

## Volume 1

### Midgar Academy Terrorist Attack

Entering the Bushin Festival tournament, she first encountered Cid in the preliminaries and dominated the duel with her vastly superior skills. Seemingly overpowered, he refused to yield however and impressed her with his unyielding willpower. Intent on ending their bout, the two combatants prepared to launch a decisive blow before the referee stopped and the ended the fight in her favor. Despite triumphing, she later developed respect for the unassuming freshman.[[3]](#cite_note-V1C5-3)

Approximately a week later, Rose along with the student council candidates gave a speech in his class to discuss their upcoming election. While speaking, several black hooded men posing as Shadow Garden raided the academy. In an attempt to defend the students, Rose confronted the terrorists and failed to notice that her magic was disabled when she attacked. Upon realizing, Cid was forced to intervene and shield her when one of the terrorists tried killing her. Seemingly sacrificing his life to save her, Rose was astonished by his actions and interpreted them as his unwavering 'love' towards her.

With no time to mourn over his apparent death, Rose vowed to avenge Cid while she and other students were forced into the auditorium. During their captivity, She and the other students hoped that the Knight Order would come to their rescue. Due to the Order being barred from entering the academy and magic being sealed, Rose began to think for a way out of confinement.[[4]](#cite_note-V1C6-4)

Later in the day, Rose saw that some of the terrorists began to maliciously attack the students. She told the students not to do anything because without magic, they won't stand a chance until she saw a shining light that made her magic return. At that moment, she lunged at one of the terrorists and declared to the students that their magic had returned as she tried rallying them into fighting back. With their battle commenced, Rose fought off the terrorists while weakened from her magic not fully recovering and was too weak to continue.

When she was nearly killed, Rose was saved by a black hooded swordsman who suddenly plummeted through the roof with several other black-hooded figures who announced themselves as Shadow Garden. Upon their arrival, they collaborated with the students to fight off the rest of the terrorist until a fire appeared in the auditorium. Rose took the opportunity to lead all the students out of the auditorium while the two groups continued fighting each other.[[5]](#cite_note-V1FC-5)

In the anime, Rose alongside other students came out of the burning auditorium and treated several injured students while waiting for the Knight Order. When Iris Midgar asked what had happened, she reported to her that a mysterious organization called Shadow Garden appeared to fight off the terrorist group who bared the same name.[[6]](#cite_note-6)

She later discovered that Cid had survived and found him unconscious in a bed at the school infirmary with his friends nearby. Overjoyed by his miraculous survival, she thanked him for saving her and said that he had earned her love.[[7]](#cite_note-7)

## Volume 2

### Sanctuary Infiltration

Due to the Academy's damaged infrastructure, students had their summer vacation started early. Rose had received an invitation to attend the "Goddess' Trial" in [Lindwurm](Lindwurm.md "Lindwurm") as a special guest. Before she went to depart from Midgar, she bumped into Cid and discovered he was also going there as well. Using this coincidence as an opportunity, she eagerly suggested him that they should go together.

On the way, she held onto his hand while voicing her affections to him that they'll overcome any adversity their "relationship" would bring. Though dismayed by this, Cid was aware of her affection and tried shaking her off to no avail. She informed him about the incident at the Academy and thought that something was going on behind the scenes. She suspected the two groups who called themselves Shadow Garden were involved but distinguished them that they differed drastically in swordsmanship, prowess, and members as actual members of the organization except their leader were females.

In the anime, Rose tried sneaking into Cid's room at night to sleep with him but was disappointed that he was absent. In actuality however, he was hiding on the ceiling asleep.

Upon arriving to Lindwurm, Rose gave Cid a tour when he bought a souvenir resembling the hero [Olivier](Olivier.md "Olivier")'s sword encircled by [Diablos](Aurora.md "Aurora")' left arm and told him a fairy tale regarding the souvenir. She told him that the arm was cut off and sealed in the ruins known as the [Sanctuary](Sanctuary.md "Sanctuary") before bringing him to a book signing by her favorite author, [Natsume Kafka](Beta.md "Beta"). After getting a copy signed, she was puzzled his that was written uniquely, but wrote it off as interest to him.[[8]](#cite_note-V2P-8)

In the game, Rose attended a pre-trial party and left Cid in their hotel room. Upon returning, she began to panic and was worried when she noticed that he wasn't in the room. When he came back, she was furious at him for wandering off and asked where did he go. Miraculously, she brought his fictitious excuse of going to the washroom.

At the Goddess' Trial, Rose was in the VIP seating with Alexia and Natsume next to the Acting Archbishop Jack Nelson. Prior to the event, she deliberately enrolled Cid to take the trial without his consent in order to show her his love struggle. Later at night when Cid's name was called as expected, she was aghast that Shadow appeared instead and summoned Aurora, the Witch of Calamity who was known as the strongest witch long ago.

In his trial, Jack almost withheld information about the witch from the two princesses when Natsume seduced him into doing otherwise. They were able to learn that she was called the most wicked woman in history. Despite firmly believing that she'll win, he grew impatient and demanded her to win to her losing in response. Rose and Jack were shocked to see her lose until Natsume pointed that a magical door appeared. When Jack tried to leave through the door, he was confronted by Shadow Garden.[[9]](#cite_note-V2C1-9)

The two princess saw Shadow Garden entering the Sanctuary, taking Jack with them. Rose tried reacting when [Epsilon](Epsilon.md "Epsilon") took Natsume as "hostage" to ensure they don't impede. Despite the Archbishop summoning [Venom](Venom.md "Venom") to finish the elven off, Epsilon executed him on spot and forced him into the facility. After they entered through the door, Alexia refused to stand idly and followed suit while Rose was forced to join her out of concern.

Inside, the second in command of the organization, [Alpha](Alpha.md "Alpha") guided the two princess and explained the dark history the Cult of Diablos covered up while revealing her lineage with Olivier after she revealed her face. After the revelation, she showed the two the truth through her ancestor's memories. They came to learn the connection recent events had with the two organizations and the truth about the Three Heroes, [Possession](Possession.md "Possession"), as well as the Cult's origins and true objective. It was then the elven revealed Jack's true affiliation as the 11th Seat of the Round Knights as he confirmed them by revealing himself as the Avaricious as he tried separating the group through an ambush.

When Nelson tried fighting back with his cloning ability, Alpha ordered [Delta](Delta.md "Delta") to fight him. Rose was shocked to see how the therianthrope fought and noted that the way she fought was nothing like her peers as she fought with pure violence. She and Alexia pitied him as they saw a berserker with no technique slaughter dozens of his clones. By the time the defense system broke, Nelson was surprised that over hundred of his copies were defeated without breaking a sweat. Alpha retorted that despite being able to create a hundred copies, they share one brain and that he couldn't control them all that well. The Archbishop saw a statue of Olivier and called her to come out to his side. By the time Olivier was called to his side however, Epsilon regrouped with Alpha to report that they finished investigating. Despite the Archbishop's taunts, the group left the sanctuary as Alpha got what she wanted. [[10]](#cite_note-V2C2-10)

Upon returning outside, the three saw Shadow's magic annihilated the Sanctuary and Lindwurm being flooded. Concluding they were ignorant to the true battle even after learning the truth, Alexia proposed to form an alliance with Rose and the author in hopes of protecting what's most dear to them and swore friendship through networking. Unbeknownst to the three, they all had Cid in mind when they thought of what was most dear to them.[[11]](#cite_note-V2C3-11)

In the anime, Rose was seen practicing her sword in the rain. While contemplating on her life, her body began to feel strange when she noticed symptoms of Possession started appearing on her body.[[12]](#cite_note-12)

### Bushin Festival Tournament

After training, she received word that her father will be visiting her with the presumed intention of taking her home for an arranged engagement. At an unknown point she received information from Natsume of her father's condition and rumors of her assumed fiancé, Duke Perv Asshat's connection with the Cult.

Sometime after the Bushin Festival had started, She ran into Cid who bought several Tuna King sandwiches and told him that she made friends with Alexia and Natsume. She confided to him that she'll be meeting her father and fiancé later and explained that her selfish behavior had disappointed and betrayed many when she picked up a sword. She implored him that if anything happens to her, she hopes he'll continue to believe in her. Before they parted ways, Cid gave her one of his sandwiches to cheer up.

Following her conversation, Rose went to her father in an attempt to convince him to approve her engagement with Cid. Instead, she saw her father's extremely pale face with a hollow stare and knew something was wrong when she saw Perv and his civil servant's grim smiles. Realizing the information Natsume gave was true, she found out firsthand that Perv was brainwashing her father in an attempt to take over her kingdom.

Horrified by the revelation, Rose was unable to think straight and tried lunging at Perv. Perv easily dodged her and he along with his servant's declared that she had gone mad while they called for guards. Unable to stop the machination, Rose was forced to escape and go into hiding while Perv threaten her to turn herself in before the end of the Bushin Festival or else he'll have her father kill Klaus Midgar, causing war between the two kingdoms. Because of her actions, she became a fugitive after nearly causing an international incident.[[2]](#cite_note-V2C4-2)

To avoid apprehension, Rose fled into the underground tunnels of the capital while being pursued by the Cult. After escaping them, she began to doubt whether her choice was right and whether it could've been dealt with without involving other countries. She knew that even after killing Perv, the Cult's presence within her kingdom will remain.

Remembering his words, Rose pondered whether surrendering is the best course of action, but recalled her memories of Cid. As her symptoms were deteriorating, Rose had heard someone playing the "Moonlight Sonata". Following the tune, she reached an abandon cathedral and found Shadow playing the piece. As he finished playing, Shadow asked her what she'll do to which she was shocked that he seemingly saw everything she's done to this point. She answered that she wanted to protect her kingdom and bring a better but was too weak. In response, he asked if it meant that her fight was over and offered her his power when her pursuers found her.

With no choice, Rose took up his offer and began to understand him when he gave her a piece of his power. Slaughtering off her pursuers, Alexia and Natsume found her surrounded by their corpses. Alexia, who wanted to know her side of the situation, confronted her on what had happened as the two princess fought. Despite their skill differences in the past, Rose overwhelmed her with her newly obtained magic and power. Before leaving, Natsume wished good luck on her future endeavors and left her confused. [[13]](#cite_note-V2C6-13)

After sneaking into the Bushin Festival's VIP area, Rose killed her father to stop their kingdom from becoming the Cult's puppet with his last words forgiving her. After killing her father, Rose was prepared to take her own life when Shadow intervened to save her once more. His intervention allowed her to escape to a forest where she was found by Alpha who gave her with two choices: fight alone or join them. Reminiscing Shadow's determination to thwart evil, she entrusted herself and her kingdom's into the organization and joined.[[1]](#cite_note-V2CF-1)

In the anime, she was taken to [Alexandria](Alexandria.md "Alexandria") to be introduced to it's headquarters. It was there she was renamed to No.666 and trained. In the manga, she joined at the end of the Bushin Festival and was already a Number before the Red Moon Incident.

## Volume 3

### Red Moon Incident

Under the codename No. 666, Rose alongside her squad leader [No. 664](664.md "664") and teammate [No. 665](665.md "665") were assigned her first field mission to research Possession and Progenitor's blood through utilizing the vast library beneath the Crimson Tower under Beta's command. While at the underground library, she met Cid's sister Claire and the ancient vampire Hunter, [Mary](Mary.md "Mary"). Upon hearing from Claire that her brother was "kidnapped", she panicked and asked her confirmation. Despite worrying for his safety, she was ordered by Beta to step down. After they departed with the duo, she was immediately reprimanded by Beta and her squad for stepping out of line.[[14]](#cite_note-V3C2-14)

Sometime later, she alongside her squad and Beta stepped into battle against the Blood Queen, [Elisabeth](Elisabeth.md "Elisabeth"). Despite putting a valiant effort with the [two](Yukime.md "Yukime") [other](Juggernaut.md "Juggernaut") monarchs' collaboration, Rose and her squad were overpowered by the revived vampire and was knocked unconscious. Later awoken by Beta, Rose noticed that all her wounds were healed and that the Crimson Tower was annihilated to mere rubble. Following the elves's orders, she returned to headquarters with her squad.[[15]](#cite_note-V3C3-15)

### Major Corporate Alliance Conflict

Under Alpha and [Gamma](Gamma.md "Gamma")'s orders, Rose and her squad investigated the origin of counterfeit bills. While investigating, she was chided by 664 for being distracted. Upon arriving at the warehouse where the counterfeits originated, Rose quickly noticed magic steel threads around them and warned her teammates to stop.

It was then they encountered a mysterious figure named John Smith and fought. Rose and her squad were immediately subdued by his steel threads and were immobilized at his mercy. With a long pause, John sparred them and ordered that they pass a message to Alpha not get involved. With no further recourse, 664 ordered the group to withdraw and report to Alpha. Despite warning the elven leader of the mysterious figure and imploring her for another chance, 664 argued with Rose for acting out while 665 mediated the two. Alpha thanked the squad for the report and clarified she did not plan to punish them for the failure before dismissing them.[[16]](#cite_note-V3C6-16)

## Volume 4

### Oriana's "Black Rose" Wedding

Rose and her team's next assignment was to travel to her own kingdom, Oriana and aid [No. 559](Victoria.md "Victoria") to the recover the "Ring" that was key to the Black Rose hidden within Fort First. Upon arriving at the fort, Rose was shocked to see her mother amongst the Cult members. Before she could comprehend, Victoria leapt in and started slaughtering them mercilessly until she started targeting Reina. It was then that Rose intervened to protect her mother from her superior and asked for clarity as she wasn't properly debriefed on the mission. Seeing it as a form of insubordination, Victoria branded her a traitor as one of the Cult members, [Kouadoi](Kouadoi.md "Kouadoi") took the opportunity to take both her and her mother hostage back to the capital.

With her mother hostage, Rose was forced to marry Perv. In her room, she believed that Shadow Garden was furious for disobeying her superior and wondered where she went wrong. When she recalled her memories with Cid, she began lamenting on her situation until he snuck in through the balcony. Surprised by his sudden appearance, she assumed that he came to denounce the marriage and take her elsewhere together. When he asked her about the marriage, she tried dissuading him tearfully that she's doing it out her own will so he could live peacefully. Cid saw through however and retorted that she needed to honest as he was like her with a dream nobody supported. Their conversation was abruptly stopped when Perv barged in after learning that she was talking to someone to only find her. Irked by her antics, he slapped and threatened her that her mother's life was dependent on her cooperation. Unbeknownst to them however, Cid was hiding in the balcony and overheard the conversation to confirm that she was coerced into the marriage.

Later in the evening after Margaret served her tea, Rose opened her windows believing it to be Cid but was instead greeted by Shadow. He brought her to where her mother was at and learned that she was never hostage and that she was conspiring with Perv in taking over her kingdom. Shocked by this revelation, she lost consciousness and found herself in her room. Upon waking up, she heard and saw Cid playing the Moonlight of Sonata. Despite having to push him away, she believed that he was an illusion until he gave her a heartfelt speech.

Cid told her that he gave everything up for the one thing he cherished most, and that the world had become too bright to the point she'll lose sight of things she cared for before telling her that she's going through this. He told her that these lights lead people astray so instead of desperately trying not to lose sight of everything she sees, she should sit under a quiet moonlight and gaze at the one thing she cherishes most before asking her what the thing was, she cherished most. Deeply touched by his speech, Rose tearfully answered that he was the thing she cherished most before noticing that he disappeared. After disappearing, she noticed a "ring" he left and believed it to be a proposal. Realizing it wasn't a dream and that she loved him most, her determination and resolve to save her kingdom was reignited.

At the wedding ceremony, Rose denounced the marriage in front of Perv and attendees that she refused to marry him and that she'll believe in true love before presenting the "ring" in front of the audience. Upon presenting, a projection of her father appeared to play his memo to everyone in attendance. In his memo, Raphael anticipated his loss of sanity and knew that Perv was responsible along with his crimes. He revealed the Cult's existence and implicated both his own wife and chancellor's involvement before lamenting that he was unable to fight for his country. He lastly entrusted it's future to his daughter and implored its citizens to believe in her no what before disappearing. With the truth revealed, Rose confronted her now ex-fiancé with capital punishment as the fight for her kingdom commenced.

Initially believed to be evenly matched, the former princess belittled the second child's sword prowess that it won't defeat anyone after she overwhelmed him. She further degraded him that she intentionally avoided fatal blows for him to confess his sins. Before he could finish his sentence, his superior, [Mordred](Mordred.md "Mordred") beheaded him before anyone noticed. Believing that she murdered him, Reina tried cursing her before being struck down by the Round Knight before announcing himself. Declaring that the banquet of slaughter had begun, Mordred announced the activation of the Black Rose and summoned dozens of magical beasts.

After saving Margaret from an oncoming beast, Rose was reunited by her team and was told to join Beta and Epsilon in taking down the Round Knight. Initially overwhelmed by his summoning of [Ragnarok](Ragnarok.md "Ragnarok"), Shadow intervened to drive away its attention and even the level field. It was after that she joined the elves to confront the Round Knight. As they fought, she learned the origins of those beasts as well as the phenomenon. After further learning that she was supposed to be a test subject for the Cult at birth, she became enraged after Beta told her that they were defanging the kingdom through infiltrating their culture and that her father sought to end it by sending her to Midgar for asylum.

After Shadow returned with the interdimensional demon's corpse, the Round Knight refused to accept defeat and consumed his flesh, thus mutating him into a monster. Despite receiving tremendous power from the demon, Mordred was ultimately defeated by Shadow when he inadvertently activated the Black Rose. As soon it was activated, Rose saw that her ring broke and watched Shadow and Beta be taken into [another world](Earth.md "Earth").[[17]](#cite_note-17)

## Volume 5

### Midgar Academy Mist Terrorist Attack

As sole heir to the throne and under Alpha's order's, Rose inherited both her late mother and father's position's respectively, becoming Queen and Ruler of Oriana. Due to her responsibility as the Ruler of her nation however, she was forced to leave Shadow Garden and continue working with them as an associate. After leaving, her former teammates, 664 and 665 continued working with her as undercover maids.

After the Black Rose incident, Alpha and her organization stayed in Oriana to help restructure the war-torn state. As the elven was talking to the now Queen Rose, the former princess was unsure on what to do as she believed that she'll cause more chaos. Alpha assured her that there was no other choice as the alliance treaty between her country and Midgar was broken and that the Holy Church declared them as a heretic state. Due to its status and trade restriction, Alpha anticipated that several neighboring countries will eventually invade the country.

Alpha further assured Rose that this was done out fear from the Cult after she declared her country's independence from them. She explained that eternal life is the symbol of human desire, and they sought after it, fearing that it'll be taken by someone else. Since they rule the world, someone will try to take it from, and it was because of it they hide in the dark. They chose to hide that eternal life so no one else can take it away from them before telling her why they fear the sunlight.

Since Oriana became independent and aware of the Cult's existence, they feared that they'll be forced onto the main stage and be exposed. Alpha explained to Rose that she'll have Shadow Garden use Oriana to annihilate the Cult by differentiating them from the Holy Church and defeat invading countries, declaring that the Cult are the world's enemy. By exposing the Cult, their beliefs will be killed off, thus annihilating them.

Despite this, Rose was uncertain that she'll be a great ruler as the elven continued to assure her that they need a ruler than can bring pain, sacrifice, hatred, and achievement and that she must be that ruler. As she shallowed words and thoughts of uncertainty, Rose cut her hair short and became determined to protect her country. Happy with her answer, Alpha assured the Queen that as long as she's determined, Shadow Garden would never betray her before [Gamma](Gamma.md "Gamma") dragged [Eta](Eta.md "Eta") to report her research to the second in command.[[18]](#cite_note-18)

## References

1. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
2. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
3. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
4. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
5. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
6. Episode 9
7. Episode 10
8. Volume 2 Prologue: To Lindwurm, the Scared Land!
9. Volume 2 Chapter 1: Fun Times at the Goddess's Trial!
10. Volume 2 Chapter 2: Investigating the Sanctuary!
11. Volume 2 Chapter 3: When Things Get Boring, It's Time for Explosives!
12. Episode 14
13. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
14. Volume 3 Chapter 2: Storming the Crimson Tower!
15. Volume 3 Chapter 3: Pursuing the Blood Queen!
16. Volume 3 Chapter 6: Circulating Counterfeit Cash!
17. Volume 4 Chapter 3: Crashing the Ceremony!
18. Volume 5 Chapter 4: The World is at Peace Today
