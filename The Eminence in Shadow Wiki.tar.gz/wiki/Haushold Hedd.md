# Haushold Hedd

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Haushold%20Hedd](https://the-eminence-in-shadow.fandom.com/wiki/Haushold%20Hedd)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Haushold_Hedd?action=edit).

## Haushold Hedd

### Japanese

オヤノ・ボウ

### Romaji

Oyano Bō

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- Earl

### Affiliation

Thirteen Nightblades

## Debut

### Light Novel

Volume 6

### Manga

Chapter 69

Haushold Hedd (オヤノ・ボウ, Oyano Bō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), also known as Earl Haushold Hedd, was a nobleman of the Midgar Kingdom and was a member of the Thirteen Nightblades.

## Appearance

## Personality

## Chronology

### Bloody Midgar Serial Murder Terror

## Relationships

### Dunder Hedd

## Powers & Abilities

## Trivia

## References

## Site Navigation
