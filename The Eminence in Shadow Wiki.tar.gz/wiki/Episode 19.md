# Episode 19

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2019](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2019)

## Dancing Puppet

### Kana

踊る人形

### Romaji

Odoru Ningyō

## Special Title

### English

The Eminence in Shadow Wants People to Gossip About His Powers!

### Kana

陰の実力者はその実力をヒソヒソ噂されたい！

### Romaji

Kage no Jitsuryokusha wa Sono Jitsuryoku wo Hisohiso Uwasa Saretai!

## Episode Information

### Season

1

### Episode

19

### Air Date

February 8, 2023 JP
May 1, 2023 EN

### Adapted From

Volume 2 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Mio Inoue

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Delta ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Betting on a Moment | Advent of the Demon |

Dancing Puppet (踊る人形, Odoru Ningyō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the nineteenth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Doem tries to make war with Midgar. Meanwhile, the match between Mundane and Iris begins.[[1]](#cite_note-1)

ドエムは、オリアナ国王を操ることで、ミドガルと戦争を起こさせようとしていた。そんな中、ジミナとアイリスの試合がスタート。さらに、姿を消していたローズが会場に現れ…!?[[2]](#cite_note-2)

## Summary

In the cloudy morning, Iris Midgar is practicing for her upcoming match and recalls her path from child to now. Even at a young age, she proved capable and bested her mentors, praised by the knight order, even winning the Bushin Festival not too long ago and earning acclaim from her academy days. However, Iris started to feel limited as she couldn't go where she felt she was needed, especially with scathing remarks by [Alpha](Alpha.md "Alpha") and her powerlessness during the Academy terror attack. Adding more force to her practice swings, iris recalls her father denying her an audit of the Divine Teachings as the Bushin Festival was nearing and she had no evidence, as well as those unaware of her reasoning would not understand why she is right. As her father claimed she was willing to endanger the kingdom and the citizens to prove herself right, Iris grits her teeth to swear to herself she will get results. Although she claims she has the will to triumph, a slight hesitancy lingers in her voice.

As the Bushin Festival Finals prepare under a stormy afternoon, Cid starts to like the VIP seating as the maids get him anything he wants free of charge. Iris sits next to him, guessing he came to cheer for his sister and explains that she is free of her official duties today to attend her duel later. She notes Cid drinking coffee, but while liking the smell, Iris doesn't like bitter flavors. Cid explains how she can add milk and sugar to the coffee, so Iris decides to try it and finds it the milk coffee delicious. While Cid thinks how having breakfast with Iris would go viral on the internet, he and Iris hears the guards stopping a woman with a sword, ordering she to give it to them but she refuses. As onlookers start with judgement on her, Iris then see its [Beatrix](Beatrix.md "Beatrix"), explaining who she is and that Iris invited her. Although Cid wonders at people awing at him being "the legendary" in a situation, he grows uncomfortable as Iris and Beatrix sit beside him. Realizing who Beatrix is, everyone get excited and gather around her. Beatrix uses the chance and asks them if they have seen her niece, but no one has seen her, while Cid realizes this is the most he's ever played a background character. As the onlookers ask if anyone has caught her eye, Beatrix answers that Cid has. The people are surprised as Cid is basically average compared to his prodigious sister, and some start to question if Beatrix is really that good while a few others support her assertion; much to Cid's annoyance. However, Cid thinks to himself how Beatrix seems to have the worth to be called Goddess of War, as all facets of her are natural and unembellished. Thus, nobody besides Cid can see how powerful she really is, as Beatrix gleefully munches on another burger.

In private, Perv Asshat drugs King Raphael Geerk Oriana once more, annoyed at drug's sweet odor and tells his subordinates to mask the smell with a perfume. Leading his puppet to his seat, Perv is sure that Rose will come to save her father, and noting she showed signs of possession, she will also become prime material for the Cult's experimentation. but should Rose not appear, Perv intends to use King Oriana to kill King Midgar, instigating a war between the kingdoms and the destruction of Oriana Kingdom. But while Perv will lose his status, he doesn't really care as he plans to make the new king of Midgar his puppet, plotting the best time to act will be during Iris's match. However, he is worried about Mundane Mann, having investigated him and found nothing, and worries that he could be affiliated with the underworld. Mundane Mann may likely prove quite dangerous if not addressed, so Perv deployed a number of Third Children around the arena, but Perv is now worried what Shadow Garden may do and that they may be working with Rose. Entering the VIP seating, he passes by Beatrix, who states that he and the king stink. An offended Perv orders the guards to take her, but Iris stops him and explains she is her guest, Beatrix the War Goddess. Now panicked, Perv realizes who she is and that she may have awakened the heroes' blood. As Beatrix apologizes, Perv does the same, and he takes his seat. While he starts to worry about Beatrix, guessing he needs to eliminate her as well, he also wonders if he is even able to assassinate the King of Midgar. Regardless, Perv assures himself it will all go normally if Rose shows up. Below, Perv sees Cid sneak off to the bathroom, and calms himself to not worry about the ignorant masses.

Once the next match commences, Claire wins her fight, as Iris heads out for her match against Mundane Mann. Walking past cheers from the knights on her way down, Iris motivates herself that these cheers are her strength, needing people to know that her strength will ensue the kingdom's strength. To continue that, Iris plans to defeat Mundane Mann, but she still cannot sense an iota of strength from him despite standing in front of him, certain that he is undoubtedly a powerful opponent. While Iris is uncertain what it is about him that she cannot resolve, she considers herself confident that she can defeat him. Whatever he may be hiding, Iris refuses to allow him a second to reveal it and end the match in one blow. As Claire finds Cid's seat empty, the other attendees are startled by her reaction, and Claire hunts for Cid among the food stands for the crowd.

As their fight starts, Iris senses she loses her head from a sword strike and retreats backwards in fear. Finding herself unharmed, Iris is surprised of what she did, seeing him at a further distance asking her if she isn't going to attack. Iris gathers herself and stands up, realizing she backed away after instinctively sensing her death. Iris draws her sword, but in that moment, she feels she her leg dismembered, only to see it unharmed as well. Iris realizes that the entire arena is in Mundane's striking range. Meanwhile, Rose makes her way unimpeded to the VIP seating, soon seeing dead cult members, before [Beta](Beta.md "Beta") and other Shadow Garden members appear behind her. Beta tells Rose that she can proceed and fulfill her mission, to which Rose removes her disguise and dons her sword. In the arena, Iris keeps feeling that she is losing limbs from Mundane's attacks, realizing this is due to his gaze and each time he slightly shifts his center of gravity. Iris conclude this from pure skill, this is his true strength, and being capable of these effects would make him the world's most powerful warrior. When crowd start to voice doubt at Iris's ability from her retreats and stumbles, she hears how they feel that she is scared. Enraged, Iris throttles her magical output for an attack, but in that moment, she is baffled to realize that Mundane isn't even holding his sword. Everything he did was to make her see things, to think he was holding his sword. but this comes too late, as Mundane manually deflects her sword before getting around her to grab Iris by the throat and pin her down. Placing his sword at her neck, he asks her what is wrong as they are just starting, as Iris can only stare at him in fright.

As rain begins to pour, King Klaus Midgar sighs in disappointment before taking his unnoticed leave, as the crowd whisper in disbelief. Perv stares in dumbfounded as he can't believe that Iris lost without being even able to make a single move, amazed Mundane could lead with illusory attacks as even the strongest Dark Knight Perv knows isn't capable of such a feat. While Beatrix sees Mundane and states how she wants to fight him, Rose surprises everyone with her arrival. She apologizes to her father, stating she made mistakes and will likely make one more, but she decided to follow the path she believe in. Of his free will, King Oriana then forgives all of her sins, surprising Perv as he didn't instruct him to say that. Beatrix notices Mundane Mann approaching the VIP seating, as Rose cries before her attack at Perv, who uses the king as a shield. However, Rose proceeds and stabs her father, telling Rose he loves her in his last moments. Perv is shocked at how easily she killed her father, but sees Rose ready her blade against her neck and orders his men to stop her. Mundane then comes from the window, asking if that's the choice Rose made, while cutting down Perv's men.

Once Mundane reveals himself as Shadow, Rose finally recognizes him as the Stylish Bandit Slayer. The onlookers are bemused, as Rose explains how seeing him fight reminded her of the past. When a masked boy (Cid) had saved her from some bandits and killed them all, she was in awe by his fencing and dedicated to becoming fencer herself. When Cid happened upon the kidnapped Rose who asked his name, the masked Cid was still training back then, so he just said he was a Stylish Bandit Slayer. Rose is surprised to learn that Shadow was the Stylish Bandit Slayer, that he wasn't afraid to fight against evil even as a boy. However, Shadow recalls the instance to himself, but thought she was a [Therianthrope](Therianthrope.md "Therianthrope") girl at the time. As Rose voices not mustering the strength, Shadow tells her that her fight isn't over, prompting Rose to stand and escape. While Perv wants to stop her, all of his men are already slain by other Shadow Garden members. So Beatrix states she will do it and jumps at Shadow, smiling at the chance to fight her. As they clash swords, the force of their clash shatters the VIP seating area, and Perv uses the chance to escape while they take their battle to the stadium roof.

## Characters

- Iris Midgar
- Alexia Midgar (Flashback)
- Zenon Griffey (Flashback)
- [Glen](Glen.md "Glen") (Flashback)
- Lutheran Barnett (Flashback)
- [Alpha](Alpha.md "Alpha") (Flashback)
- Cid Kagenou
- [Beatrix](Beatrix.md "Beatrix")
- Perv Asshat
- Raphael Geerk Oriana
- Klaus Midgar
- Claire Kagenou
- Rose Oriana
- [Beta](Beta.md "Beta")

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第19話予告≪ノーマルVer.≫「踊る人形」

TVアニメ『陰の実力者になりたくて！』第19話予告≪スペシャルVer.≫「陰の実力者はその実力をヒソヒソ噂されたい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e019>
2. <https://shadow-garden.jp/1st/story/#story19>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • **Episode 19** • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
