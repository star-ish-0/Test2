# Magical Beast

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Magical%20Beast](https://the-eminence-in-shadow.fandom.com/wiki/Magical%20Beast)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Magical Beasts (魔獣（まじゅう）, Majū[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are a race and species of magical carnivorous creatures that live and inhabit other worlds, called "Infernal or Demonic worlds", which is why these creatures are classified as demons.

## Appearance

Magical Beasts are monstrous creatures characterized by their predominantly black bodies, intense red eyes, and large, razor-sharp teeth. However, as time went on, it became evident that their appearances, abilities, and magical powers varied significantly from one individual to another. This variation further reinforced their classification, progressing from mere demons to higher-ranking beings known as demon kings. These demon kings possess their own consciousness and wield tremendous magical power, enabling them to rule over entire worlds.[CITATION NEEDED]

The Earth variants of Magical Beasts bear some resemblance to their counterparts from other realms. Cid Kagenou, a renowned expert on these creatures, described them as having features reminiscent of a lion and a bear, combining elements of both animals.[CITATION NEEDED]

## History

According to Mordred's explanations, approximately 10 million years ago, there was a first contact between two worlds: one inhabited by infernal beings and the other ruled by dragons. It is speculated that during this contact, the first magical or demonic beasts crossed over into the dragon world but perished in the process due to the struggle and adaptation required.[CITATION NEEDED]

Several millennia later, the remains of these magical beasts were discovered by the first investigators, scientists, and archaeologists from the dragon world. They embarked on a quest to uncover the origins and nature of these beings but found no definitive clues or key information about them. In their pursuit of knowledge, some of these researchers resorted to unethical experiments, incorporating the magical genes of these creatures into kidnapped boys and girls. Over time, these initial researchers and other members involved in such practices would eventually become the founders of the Cult of Diablos.[CITATION NEEDED]

Several centuries later, after the defeat of the [Demon Diablos](Aurora.md "Aurora"), and the distribution of the descendants of the 3 Heroines of the world, the breach between both worlds known by the cult as the "Black Rose", It reopened again during a conflict of the Oriana Kingdom , with the fight of 100,000 soldier of the Velgalta Empire, which caused the Velgalta armies to be completely eliminated. Unfortunately, the magical beasts proceeded to slaughter everyone that were in their way, in Oriana's kingdom, until the Cult of Diablos stepped in and closed the Black Rose.

When the Black Rose was activated once more by the cult member, [Mordred](Mordred.md "Mordred") The 9th Seat Knight of Rounds, manipulated it to summon the Magical Beasts, along with [Ragnarok](Ragnarok.md "Ragnarok"). The Oriana Kingdom would have been annihilated, but the timely intervention of Shadow Garden changed that. Shadow Garden worked alongside the Oriana Kingdom to take out the Magical Beasts while Shadow confronted Ragnarok. The battle ended when Shadow destroyed both Ragnarok and the Black Rose.

Cid Kagenou and [Beta](Beta.md "Beta") would travel through a portal created by the Black Rose and arrived on [Earth](Earth.md "Earth"), Japan. To their surprise, they found the nation completely ravaged apart and populated by Magical Beasts.

## Biology

Magical Beasts possess incredible magical powers that grant them strength and durability, allowing them to overpower most opponents. Their sharp teeth enable them to tear flesh from their prey, making them formidable hunters.[CITATION NEEDED]

Often labeled as demons, or possibly already considered as such, Magical Beasts possess a magical and biologically unique body that grants them eternal life. They do not age, succumb to deadly diseases, or suffer from causes of death that affect humans. However, they are not truly immortal, as they can be killed by powerful magical weapons, particularly those of sacred or national significance. Extreme cases, such as weapons capable of destroying capitals or entire countries, are necessary to defeat them.

Over time, the creatures continue to exist, feed, and engage in conflicts with their own kind. Their mutative blood allows them to evolve into more powerful and intelligent beings. This continuous evolution ultimately leads them to the pinnacle of their species, known as the Demon King (the highest known stage of development thus far).[CITATION NEEDED]

Earth variants of Magical Beasts are notably weaker than their counterparts, as evidenced by the ease with which Shadow was able to kill hundreds of them. They typically live in packs and construct nests. Once a nest reaches a certain threshold, the beasts go on a rampage, presumably to split the pack. They hunt for food and gather resources to build a new nest. This phenomenon is referred to as a Stampede (スタンピード, Sutanpīdo[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). Apex Beast (上位種, Jōi-shu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are a sub-species that are even more powerful than the standard beasts.

The only effective means of killing these creatures is by using a sword imbued with magic. It takes at least ten ordinary soldiers to even subdue a Magical Beast, unless they possess the Shadow Garden prowess (a special skill or ability). The level of power and destructive capability possessed by a demon determines its danger and difficulty to kill. For normal Earth soldiers, facing one of these creatures would be suicidal, even with special combat armor. It would require a team of twenty soldiers to stand a chance against a single Magical Beast. Their magical abilities make them almost invulnerable to ordinary bullets, machine guns, and in some cases, shotguns and rifles loaded with standard ammunition. Thus, reliance on magic knights is crucial for successfully killing these creatures. Earth's magic knights are more advanced compared to those from other worlds, such as the magic knights of Midgar, but they still pale in comparison to the power of the Magical Beasts.[CITATION NEEDED]

## Trivia

- Until now, magical creatures are classified as the oldest and most powerful creatures of all, then below these are Dragons.[CITATION NEEDED]
  - According to the Cult of Diablos, it is said that in the central parallel world, they inhabit the plane or kingdom of a god, or several.
- The demon [Diablos](Aurora.md "Aurora"), shares certain characteristics with the demonic Beasts, since the means that were used to create Diablos, come from these demons (even if it was an accidental result).

## References

## Site Navigation
