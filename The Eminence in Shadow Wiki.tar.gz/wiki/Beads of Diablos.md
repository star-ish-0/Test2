# Beads of Diablos

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Beads%20of%20Diablos](https://the-eminence-in-shadow.fandom.com/wiki/Beads%20of%20Diablos)

Beads of Diablos (ディアボロスの雫（しずく）, Diaborosu no Shizuku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are magical pills containing extraordinary power from the demon [Diablos](Aurora.md "Aurora")' blood. Developed by the Cult of Diablos through research on the demon's remains, these pills are designed to enhance the strength and vitality of the cult members and their allies.

## Source

These pills were created from the remains of the demon Diablos, severed by the Three Heroes. The cultists, coveting the demon's power, conducted experiments on its remains. They discovered that the demon's remains possessed incredible vitality, capable of instinctive movement and regeneration.

From then on, they created what would now be known as the "Beads of Diablos" and their various types, harnessing the incredible life energy contained within Diablos Cells. Though the pills had side effects, they were now effective for men as well. Nelson played a key role in organizing and collaborating on the creation of these pills and their derivatives.[[1]](#cite_note-:0-1)

## Overview

Over time, the Cult has used these drugs to support their endeavors, but the source of their true strength lies elsewhere. They engineered these Beads from Diablos' life force, flesh, and blood to enhance mana power. However, using them carries the risk of destroying one's body and mind if the user isn't already strong.

After years of research and experimentation on Diablos' remains, the Cult developed these pills to enhance the magical power of its members and organization.

The "Beads of Diablos" are Red pills (赤（あか）い錠剤（じょうざい）, Akai Jōzai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), which are unfinished products created using Diablos Cells. Despite their strong side effects, these pills were produced in large quantities and are primarily distributed to powerful members of the Cult of Diablos, particularly the First and Second Children.

However, these pills have significant flaws. The side effects are too potent for a normal body to handle, even for those within the Cult who possess the necessary attributes to control such magical power. As a result, the Red Pills are considered semi-failed experiments by the Cult, although they are still used to support their cause.[[1]](#cite_note-:0-1)

The pills serve as temporary enhancements, boosting the abilities of high-ranking servants by increasing their magic power, body size, muscle mass, speed, instant healing, and resistance to heavy damage. However, they do not provide the desired result of immortality that the Cult sought. Individuals such as [Grease](Grease.md "Grease"), Zenon Griffey, [Gettan](Gettan.md "Gettan"), and [Maximilian](Maximilian.md "Maximilian") use them to achieve their goals and survive in battles to the death.[[3]](#cite_note-3)

## Potential Power and Side Effect

These pills cannot be consumed by normal individuals with limited magical power, whether they are Human, Elf, or Therianthrope, as they contain tremendous demonic energy. Ingesting them would deform the individual until they succumb to the overwhelming strength and die from the supercharged magical power, leading to self-destruction. However, members of the "Knights of Rounds" are an exception, as only those who can control and manipulate this devastating power have the privilege of joining their ranks.

These pills grant significant raw demonic magical power, enhancing the strength and speed of Diablos cult members who consume them, with potential side effects including metamorphosis mutations based on race. They surpass all limitations, offering rapid regeneration and high resistance to pain, known as "Third Awakening" (覚醒者サード, Kakusei-sha Sādo[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). Their effects on spell use and enchantment capabilities remain unknown until now.[[1]](#cite_note-:0-1) When Therianthropes consume multiple pills, they not only gain all the abilities and magical powers offered but also transform into large animal versions, representing their corresponding race.[GETTAN MANGA ONLY][[4]](#cite_note-:1-4)

Generally, a single pill can greatly increase magical power. However, consuming multiple pills can lead to a metamorphic transformation of the entire body, sometimes resulting in fusion with the weapons they carry.[GREASE ANIME ONLY][[5]](#cite_note-5)

Other defects of the pills include their inability to fully restore wounds inflicted long ago and the short duration of their enhanced effects. Whether a few or many are taken, they only function for a limited time. Once the effects wear off, the individual returns to their normal state and is often left exhausted due to the immense power exerted by the pill, leaving them with little strength to continue fighting. This was evident in the case of Gettan after being defeated by John Smith, despite having consumed many of these pills and altering his body condition.[[6]](#cite_note-6)

## Trivia

- It appears that the "Beads of Diablos" lack the ability to cure terminal illnesses, highlighting their imperfections. A notable example is Lutheran Barnett, a former Knight of Rounds, who consumed the Beads but discovered they were ineffective in curing his illness.
- In the novel, the "Beads of Diablos" do not induce animal transformation in the Therianthropes. Also, the transformation is not seen in the [Anime](Anime.md "Anime"). This aspect is only depicted in the manga, specifically in the case of Gettan.[[4]](#cite_note-:1-4)

## References

1. Light Novel - Volume 2: Chapter 2: Investigating the Sanctuary!
2. Anime: episode 2
3. Light Novel - Volume 1: Chapter 3:
4. Manga: Chapter 39
5. Anime: Episode 2
6. Light Novel - Volume 3: Epilogue

## Side Navigation
