# Yuudai Saejima/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Yuudai%20Saejima/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Yuudai%20Saejima/Relationships)

Main

Chronology

Image Gallery

## [Messiah](Messiah.md "Messiah")/[Arcadia](Arcadia.md "Arcadia")

### Akane Nishino

Akane's former classmate, she saw no appeal and despised him for how he looked at her sexually since their time as students. However, this does not stop Yuudai as he often tried to force her into a relationship to no avail. Whenever the two have argued or enraged, he often abused his position and blackmailed her under the threat of having her recall memories as the Original Knight much to her anguish.[[1]](#cite_note-V4C5-1)

Due to their poor relationship, Akane was the first person to be accused when Yuudai was discovered dead after fending off a magical beast stampede.[[2]](#cite_note-V4C6-2)

### [Yuuka](Yuuka.md "Yuuka")

Fellow double-agent for the Alliance, Yuudai was bribed into their side as their mole in the Messiah until Yuuka murdered him after fending off a magical beast stampede and after she got what she needed. She would also exploit Yuudai's death in attempt to frame Akane as a murderer.[[2]](#cite_note-V4C6-2)

### [Haitani](Haitani.md "Haitani")

Much of their interactions are unknown during Shadow and Beta's time on Earth. However, since Haitani was the Commander of the Knights of Messiah, Yuudai would be outranked and would follow orders under him.

### Akira Nishino

Scientist for the Messiah and Akane's brother, Akira was unaware of either Yuuka or Yuudai's antics until his death.

## Others

### Minoru Kageno / The Black Knight

Former classmate of his late incarnation, Minoru was able to recall Yuudai in his past life as he was affectionally referred to as a gorilla and expertise on Judo. When Akane took Minoru in under her care, Yuudai tried to leave him in a monster nest to be eaten by monsters until Akane protected him. Yuudai also tried to use Minoru as a scapegoat when he accused him of being a spy before Akane to stepped in to protect him once more.

As the Black Knight, Yuudai's view of him would contrast much like Iris'. He was initially shocked to learn of his existence during the meeting but was enraged and suspicious the Knight when he effortlessly saved Akane and kill off the remaining stampede.[[1]](#cite_note-V4C5-1)

### [Natsume](Beta.md "Beta")

Although the two has never interacted, Yuudai has acknowledged her potential as a possible knight within their ranks and suggested that Akane should've simply taken her instead of the both of them in much to her ire.[[1]](#cite_note-V4C5-1)

## References

1. Volume 4 Chapter 5: Sneaking Around in Japan, Just like the Old Days!!
2. Volume 4 Chapter 6: Something Smells Fishy... But an Eminence in Shadow Always Cracks the Case!
