# Marco Granger/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Marco%20Granger/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Marco%20Granger/Relationships)

Main

Chronology

Image Gallery

## Crimson Order

### Iris Midgar

Princess Iris is the founder and leader of the Crimson Order, and thus is Marco's highest superior. It is unclear if Marco holds any concerns about the princess after Glen's death and Shadow's humiliating her at the God of War festival. Regardless, Marco is a loyal knight and will continue to follow her orders.

Their relationship appeared to become strained as he helplessly watch Iris being manipulated by Hubb into even believing him over her sister.[[1]](#cite_note-:0-1)

### Alexia Midgar

Princess Alexia is Marco's superior in peerage and will prioritize Alexia's safety is she is in his reach, being the younger sister of his commander.

Their relationship alongside Iris seemed to deteriorate when he was unable to stop her from Hubb's manipulation, even having the younger sister question his stance regarding the matter.[[1]](#cite_note-:0-1)

### [Glen](Glen.md "Glen")

Glen was Marco's mentor and senior from their time in the Dark Knights, as well as a good friend. After Glen's death during the Attack on the Academy, Marco visited his grave and still feels some guilt for his mentor's death.

### [Adder](Adder.md "Adder")

Adder is the Crimson Order's new vice-commander, [Glen](Glen.md "Glen")'s successor, and Marco's superior officer. Marco and the others are unaware that Adder is a spy for the Cult of Diablos gaslighting Iris Midgar to hunt Shadow Garden.[[1]](#cite_note-:0-1)

## Others

### Nicoletta Marquez

Nicoletta was Marco's fiancée. The two exchanged letters often and occasionally attended parties and danced together. Knowing the news that his fiancé had been declared dead suddenly due to an illness, Marco didn't know what feelings he had after losing her.

Marco did not know that his fiancé had been discarded by her family by faking her own death, due to suffering from [Possession](Possession.md "Possession") and now her symptoms have been cured which made her join Shadow Garden organization as the highest-ranking member with the name Nu.

## References

1. Light Novel Volume 5 Chapter 2: Shocking Morning, School Skewer Murder Case!!
