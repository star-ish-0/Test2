# Garter Kikuchi/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Garter%20Kikuchi/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Garter%20Kikuchi/Relationships)

Main

Chronology

Image Gallery

## [Gettan](Gettan.md "Gettan")

Gettan was a hired therianthrope that Garter tried to employ, but subordination was not the warrior's intent. The hierarchy reversed and Garter retired himself to a submissive role.
