# Gettan

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Gettan](https://the-eminence-in-shadow.fandom.com/wiki/Gettan)

[Chronology](Gettan-Chronology.md "Gettan/Chronology")

[Relationships](Gettan-Relationships.md "Gettan/Relationships")

Image Gallery

## Gettan

### Japanese

月丹（げったん）

### Romaji

Gettan

### Aliases

Sword Devil
Great Wolf

## Characteristics

### Race

[Wolf Therianthrope](Therianthrope.md "Therianthrope")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Black

### Eye Color

Gold
Red

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

[Yukime](Yukime.md "Yukime") (Ex-fiancée)

## Professional Information

### Affiliation

Cult of Diablos
Major Corporate Alliance

## Debut

### Web Novel

Chapter 120

### Light Novel

Volume 3

### Manga

Chapter 34

### Anime

Episode 24

## Portrayal

### Japanese

[Daisuke Namikawa](https://en.wikipedia.org/wiki/Daisuke_Namikawa "wp:Daisuke Namikawa")

### English

[Ian Sinclair](https://en.wikipedia.org/wiki/Ian_Sinclair_(voice_actor) "wp:Ian Sinclair (voice actor)")

### French

Jochen Haegele

### Italian

Alessandro Fattori

Gettan (月丹（げったん）, Gettan[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), renowned as the Great Wolf, was a collaborator with the Cult of Diablos and the leader of the mercenary trope, the [Clovers](Clovers.md "Clovers"). Desiring the 12th seat in the Knights of Rounds, he quickly assumed control of the Major Corporate Alliance.[[1]](#cite_note-V3C4-1)[[2]](#cite_note-V3C5-2) His intent was to force Mitsugoshi Company into an insolvent position by inciting a bank run. Ultimately, the plan did not come to fruition, and a subsequent duel against John Smith cost Gettan his life.[[3]](#cite_note-V3C6-3)[[4]](#cite_note-V3CE-4)

## Appearance

A member of the therianthrope wolf race, Gettan possessed glossy jet-black fur and stoic features with a fearless face. Due to a past injury that blinded him, he keeps his inoperable eyes closed.

## Personality

Gettan was convinced by the philosophy "If you don't want anything robbed from you, you have to rob from others", even he treats his subordinates with utter contempt and will kill them should they fail him.

When he was young, Gettan was a brave man wanting only to protect those he held dear. However, what held him down was his immense pride which became nothing short of a curse for him because his inability to accept his own weakness causes him to make reckless and stupid decisions, including lashing out and trying to kill Yukime.

## Powers & Abilities

Praised by other for his strength, Gettan was considered the Great Wolves’ strongest warrior. His strength only grew as he amassed wealth and power from the Cult of Diablos. By borrowing the power of an incomplete Bead of Diablos, he forced John Smith into close combat, although the attempt to overwhelm Smith still proved unsuccessful.[[1]](#cite_note-V3C4-1)[[4]](#cite_note-V3CE-4)

### Weapons and Equipment

Gettan used a Katana Sword as his weapon, while in the Web Novel, he uses a Naginata, a Japanese pole weapon.

## Trivia

- In the Web Novel, Gettan suspected that the Mitsugoshi Company might be acting as a front for something else.[[5]](#cite_note-WN122-5)

## References

1. Volume 3 Chapter 4: I’ll Destroy It All and Start from Scratch!
2. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
3. Volume 3 Chapter 6: Circulating Counterfeit Cash!
4. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
5. Chapter 122: The Malaise of Mitsugoshi

## Site Navigation
