# Mu

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mu](https://the-eminence-in-shadow.fandom.com/wiki/Mu)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Mu?action=edit).

## Mu

### Japanese

ミュー

### Romaji

Myū

### Aliases

No. 12

Dr. Medi

## Characteristics

### Race

Dark Elf

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Silver

### Eye Color

Silver

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

- Numbers
- School Doctor (Undercover)

### Affiliation

Shadow Garden
Midgar Academy (Undercover)

## Debut

### Light Novel

Volume 6

### Manga

Chapter 69

### Game

Seven Shadows Chronicles: Edge of Realm: Chapter 1 - The World Will Find Out

Mu (ミュー, Myū[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Μυ) is a member of Shadow Garden, being one of the Numbers. She is currently taking care of Claire Kagenou as Midgar Academy for Dark Knights's school doctor.

## Appearance

Mu is a silver haired dark elf that Cid Kagenou mentions to have a sexy appearance. She has plump and sensual lips. In the past her hair was pink/purple, likely due to symptoms of possession.

Mu, from the limited appearances we have seen of her, all of which have not been in her shadow garden uniform, appears to like wearing shirts or dresses with a keyhole near the lower part of the chest area. She has appeared in a purple sleeveless collared dress in the game and a vertically striped shirt and form fitting pants in the manga.

## Personality

Mu is a courteous individual who is knowledgeable in medicine, having a role as Claire Kagenou's caretaker and works as the school doctor.

## Chronology

### Princess Alexia's Kidnapping

Around the time of Princess Alexia's kidnapping, Mu was known as Dr. Medi, and she was working with [Sinmara](Sinmara.md "Sinmara"), the elven chieftan of the Emirate of Muspel.[[1]](#cite_note-:0-1) She appears (as of the currently available information from the gatcha game) to have been researching suppressing the symptoms of possession, using herself, [664](664.md "664") and [665](665.md "665") as experimental subjects.[[2]](#cite_note-:1-2)

### Jack The Ripper arc

Oversees Claire Kagenou's treatment while she is unconscious.

## Powers & Abilities

Mu has been trained to use and control her magic, as well as fighting practices, based on lessons passed down from Shadow.[CITATION NEEDED] Mu quickly rose through the ranks, making her one of the double-digit Numbers as a testament to her prowess and ability, to which she was given a Greek name number. She is good at magic manipulation and erasing her own presence, a notable detail considering Shadow Garden's powers of stealth and espionage.

Among her training was also the forte in medicine, granting her the knowledge needed for her undercover mission as head doctor within the Midgar Academy for Dark Knights.[CITATION NEEDED]

She is the master of the Western Liechtenroi style and is also skilled in combat using a glaive.[[3]](#cite_note-3)

## Relationship

### Shadow Garden

#### Cid Kagenou / Shadow

Just as with the other members of Shadow Garden, Mu holds their leader in the highest of regards. As one of the Number, Mu has the privilege to know his civilian identity and operates as the academy's doctor to protect his sister while she is comatose after being bound to Diablos' right arm and be an informant for Shadow Garden some time after the Bushin Festival.[CITATION NEEDED] She respects whatever choice he makes but takes his words too seriously. Mu keeps Cid appraised of Claire's comatose condition.

#### [Nami (664)](664.md "664") and [Maggie (665)](665.md "665")

Dr. Medi has a caring side and looked after [Nami](664.md "664") and [Maggie](665.md "665") while using them, and herself as experimental subjects to research suppressing the symptoms of possession. She even offers to order them any clothing they like from the Mitsugoshi catalog.[[2]](#cite_note-:1-2)

### Midgar Academy for Dark Knights

#### Claire Kagenou

After the being bound to Diablos' right arm, Mu acts as Claire's caretaker while she was comatose providing steadfast medical care.

#### [Nina](Nina.md "Nina")

They are acquainted with each other.

## Trivia

## References

1. Edge of Realm Ch. 1: The World Will Find Out | Kagemasu: Seven Shadows Chronicles Story
2. Edge of Realm Ch. 2: For Riches, Fame and Glory | Kagemasu: Seven Shadows Chronicles Story
3. Edge of Realm Ch. 4: Activate! Slime Nightmare !| Kagemasu: Seven Shadows Chronicles Story

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • **Mu** • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
