# The Alliance

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/The%20Alliance](https://the-eminence-in-shadow.fandom.com/wiki/The%20Alliance)

The Alliance are a group of Japanese who seek to claim Messiah's base for their own.

## Background

Following the destruction of Japan's last safe haven, [Arcadia](Arcadia.md "Arcadia"), multiple factions emerged and battled each other to claim resources (food, manpower, technology, etc..). The Alliance was one of those factions and desired to claim the base belonging to [Messiah](Messiah.md "Messiah"). The Alliance had their spy, [Yuuka](Yuuka.md "Yuuka") infiltrate Messiah's ranks. At some point, they managed to bribe Yuudai Saejima to their side and made him their mole.

## History
