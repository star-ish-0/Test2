# Magic Sealing Chains

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Magic%20Sealing%20Chains](https://the-eminence-in-shadow.fandom.com/wiki/Magic%20Sealing%20Chains)

The Magic Sealing Chains (魔封の鎖, Ma Fū no Kusari[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are magic items that are used to restraints magic.

## Overview

These chains are no ordinary chains because when it's on the magic user, the user cannot use their magic as the magic is sealed. There are different types, some are like handcuffs or collars.

## Types of sealing chains

Over time, the cult created various types of magical sealing chains, to use against their respective enemies, or creatures they captured and studied:

### Magic Sealing Chains Normal:

### Magic Sealing Chains (artifact):

## History

As understood, the creation of the sealing chains dates back more than a thousand years, shortly after the escape and chaos of Aurora, now turned into the first Demon King of the world, Diablos. The Cult of Diablos, created powerful anti-magic chains, capable of sealing, in a contained way, the supreme power of Diablos.[[1]](#cite_note-1)

## Functions

- Magic sealing:
- Physical Weakness: When sealing, the individual's magic, so that he cannot use it, the source of his magic, along with his connections, the subject, begin to feel tired deliberately, I form the chains, continue to be attached to it, to the point that partially, it cannot move, because the people of the other world, use the magic combined with their life force, for the complete support of the body and its functions. The more one uses, one's magic, the chains can affect the individual more, depending on how much they have, and mainly, how it is used (according to words taught, from Cid to his older sister Claire). this works well against magic warriors and magic knights, just like any other magic.[[2]](#cite_note-:0-2)[[3]](#cite_note-:1-3)
- Physical immobility:

## Weakness

- Although the sealing chains, of the normal type, can seal the magic of the person who wears them, the innate and vital force of the subject cannot, so under certain circumstances, if the subject's force is very strong, it can break the chains. chains that immobilize him, or free himself from their bonds. As it was in the case of Claire Kagenou freed herself from these chains, by sheer brute force, for having been angry, despite having hurt her hands, although she did not mind the pain, when the [Duke](Grease.md "Grease") mentioned that he would investigate Cid Kagenou, while she was still in prison, because of the Cult of Diablos.[[2]](#cite_note-:0-2)
- Sealing chains, as such, regardless of type, are not indestructible per se, they can be destroyed by external forces, either by magical or physical means. This is seen when [Millia](Millia.md "Millia") mutation destroyed Alexia Midgar Sealing chains, while they were prisoners of the Cult,[[3]](#cite_note-:1-3) and when Cid, with an "I Am Atomic", destroyed the sanctuary, destroying with it, the chains (artifact type), along with the left arm of the [Demon king Diablos](Aurora.md "Aurora").[[4]](#cite_note-4)

## References

1. Episode 13
2. Episode 2
3. Episode 4
4. Episode 14
