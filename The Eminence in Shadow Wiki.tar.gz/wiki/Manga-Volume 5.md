# Manga/Volume 5

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%205](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%205)

## Manga Volume 5

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041110027

### ISBN EN

ISBN 978-1975338787

### Release Date

February 26, 2021 JP
October 4, 2022 EN

## Volume Information

### Pages

152 JP
162 EN

### Chapters

5

Publication Order

| Previous | Next |
| --- | --- |
| Volume 4 | Volume 6 |

This is the fifth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

In the depths of the Sanctuary, where ancient memories of mighty warriors slumber, Shadow Garden lays bare the long-hidden truth behind the demon Diablos and the hero Olivier—all very critical plot information that Cid pays zero attention to because it’s time for the semiannual Bushin Festival! Playing the part of a weak-looking guy who’s actually super-strong is Cid’s raison d’être, and where better to strut his stuff than a tournament arc?[[1]](#cite_note-1)

ここに四肢を拘束された美女がいます。とりあえず助けてみませんか？
異世界に転生し「陰の実力者」設定を楽しむシド。目の前に現れたドアの向こうは聖域という名の「記憶の牢獄」。闇に葬られた数々の真実が明らかになるが――？強大な力と重度の勘違いで切り抜ける最強奇譚、第５弾！[[2]](#cite_note-2)

## Summary

### Holy Ground Infiltration

After sending a letter to Cid to come to Lindwurm, Alpha meanwhile examines the murder of Archbishop Drake, however, her focus remains on the truth regarding the Hero [Olivier](Olivier.md "Olivier") and the Holy Ground.

As such, after Shadow defeats the Witch of Calamity [Aurora](Aurora.md "Aurora") during the Trial of the Goddess, Alpha and Shadow Garden seizes the opportunity to investigate the Holy Ground, forcibly bringing acting Archbishop Nelson, as well as Princess Alexia and Rose Oriana unexpectedly.

Within the Holy Ground, Alpha reveals her lineage with [Olivier](Olivier.md "Olivier"), as well as her ancestor's history and goal of the Order of Diabolos until Nelson attempts to retaliate. Along with [Delta](Delta.md "Delta"), the two repels the Knight of Rounds' onslaught before retreating upon the completion of their investigation.

Later, after the destruction of the Holy Ground by their master, [Alpha](Alpha.md "Alpha") is briefed of the situation by [Epsilon](Epsilon.md "Epsilon") who then announces the results of their research, revealing Aurora as the true identity of Diabolos.

## Chapters

- Episode 17
- Episode 18
- Episode 19
- Episode 20
- Episode 21

## Characters

:   In order of appearance:

- Cid Kagenou
- [Aurora](Aurora.md "Aurora")
- Alexia Midgar
- [Epsilon](Epsilon.md "Epsilon")
- [Alpha](Alpha.md "Alpha")
- Alexia Midgar
- Rose Oriana
- Nelson
- [Olivier](Olivier.md "Olivier")
- [Delta](Delta.md "Delta")
- [Nu](Nu.md "Nu")
- Annerose
- [Quinton](Quinton.md "Quinton") (Debut)
- Skel Etal
- Goldoh Kinmeki (Debut)

## References

1. [The Eminence in Shadow, Vol. 5 (manga). YenPress](https://yenpress.com/9781975338787/the-eminence-in-shadow-vol-5-manga/)
2. [The Eminence in Shadow (5). Kadokawa](https://www.kadokawa.co.jp/product/322009000417/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • **Volume 5** • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
