# Lutheran Barnett/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lutheran%20Barnett/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Lutheran%20Barnett/Relationships)

Main

Chronology

Image Gallery

## Family

### Sherry Barnett

Lukreia's daughter. Lutheran never held any genuine affection towards her as he used the late-researcher's daughter as a means to cure his illness. He proudly admits alongside the murder of her mother to Cid who became disgusted when he confronted the former Round Knight. This admission would ultimately be his undoing when Shadow gave retribution to the former Round Knight.[[1]](#cite_note-:2-1) Still, he died laughing knowing that Sherry who saw his death at the hands of Shadow will have a vendetta against the latter while successfully fooling her till the end that he was a good adoptive father.

## Cult of Diablos

### Zenon Griffey

Fellow Cult member and infiltrator. Despite having seniority over the former instructor, Zenon had more authority over him most in due to being a candidate to replace his former seat within the Round Knights.[[2]](#cite_note-:3-2) However neither higher up members would earn the position of the 12th seat as both were killed by Shadow.[[1]](#cite_note-:2-1)

### [Rex](Rex.md "Rex")

Subordinate. The relationship between the two was tense due to how little to no respect the two had for each other. Lutheran was patient with the Child's attitude until he reported what happen with the Eye of Avarice to which he was enraged and had threaten him to retrieve it from Sherry. When Rex didn't come back, the former Round Knight called him useless unaware that he was killed by Shadow.[[3]](#cite_note-:1-3)

## Shadow Garden

### Cid Kagenou / Shadow

Initially, Lutheran did not have much thought on the student as he encouraged his stepdaughter to form a friendship with him.[[4]](#cite_note-:0-4) Much of it has changed when he was confronted by him and impressed by his foresight. In combat, much of his perception was in likeness of the former statement.

As Shadow however, the former Round Knight acknowledged his strength and knew he was at a disadvantage against him. Even with the Eye of Avarice, he was no match against him and was ultimately killed.[[1]](#cite_note-:2-1)

## Others

### Lukreia Crowley

Sherry's mother. Lukreia believed Lutheran to be a genuine friend when she was shunned by her colleges. Lutheran however saw otherwise as he only used her as a means to cure his illness until she went against working on the Eye of Avarice. Enraged, Lutheran brutally murdered the researcher in front of her daughter and used her to work on the artifact in her stead. This would ultimately be his undoing when Shadow killed him upon admitting to the murder and exploitation.[[1]](#cite_note-:2-1)

## References

1. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
2. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
3. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
4. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
