# Iota

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Iota](https://the-eminence-in-shadow.fandom.com/wiki/Iota)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Iota?action=edit).

## Iota

### Japanese

イオタ

### Romaji

Iota

### Aliases

No. 9
Novem Silva (Public Identity)

## Characteristics

### Race

[Therianthrope](Therianthrope.md "Therianthrope") (Rabbit Therianthrope)

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Green

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

- Numbers
- Influencer

### Affiliation

Shadow Garden
Mitsugoshi Company

## Debut

### Game

Secret of Sacra Ch. 4: Influencers Ahoy! | Kagemasu: Seven Shadows Chronicles Story

## Portrayal

### Japanese

Aki Toyosaki

Iota (イオタ, Iota[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Ιώτα) is a member of Shadow Garden, being one of the Numbers. She is [Gamma](Gamma.md "Gamma")'s subordinate.

## Appearance

She is revealed to be a blonde bunny girl with green eyes and shoulder length hair and 2 pig tails.

In her normal outfit, when she works at the beach hotels of the Mitsugoshi Company, Iota wears a set of seductive beach clothes, with a white shirt, with a heart-shaped neckline in the center, showing her bra and breasts, with feminine shorts, unbuttoned, that combined with the rest of her clothes, which resembles those of a Gyaru girl.[[1]](#cite_note-:0-1)

Her Shadow Garden outfit resembles that of a crop top along with a frilled miniskirt, opera gloves, strips of golden coins along with a see-through overlay that covers the rest of her body, giving an appearance similar to an Arabian belly dancer.

## Personality

Iota shows to have a cheerful, friendly, playful, and joking, during her first real mission, she was shown to be very happy to be able to participate, committing herself to it.[[1]](#cite_note-:0-1)

She is also shown to have a professional side, being able to complete her missions and follow orders without complaints. However, for undisclosed reasons, she only shows this side to [Alpha](Alpha.md "Alpha").

Iota has shown to have a seductive and charismatic side to influence people, which allows her to carry out her task as a speaker and presenter, which people like very much, and allows her to be able to do her jobs without problems.[[1]](#cite_note-:0-1)

## Chronology

## Powers & Abilities

She serves as the public relations representative of Mitsugoshi.

## Relationships

### Shadow Garden

#### Cid Kagenou / Shadow

When Cid first met Iota, he considered her to be a polite "forest girl". Upon meeting again, he is surprised with the drastic change from before and thinks her "party girl" vibe was actually her true persona. [[2]](#cite_note-:1-2)

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

#### [Gamma](Gamma.md "Gamma")

### Numbers

#### [Sigma](Sigma.md "Sigma")

#### [Lambda](Lambda.md "Lambda")

#### [Nu](Nu.md "Nu")

## Trivia

- Iota is the first member of Shadow Garden along with [Sigma](Sigma.md "Sigma") to be introduced in the game.
- Iota would be the first Therianthrope character, rabbit-type, to be seen in the story of The Eminence in Shadow, in the game canon.

## References

1. Secret of Sacra Ch. 4: Influencers Ahoy! | Kagemasu: Seven Shadows Chronicles Story
2. Boughs of Shadow Ch. 9: Hide-And-Seek Battle! | Kagemasu: Seven Shadows Chronicles Story

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | **Iota** • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
