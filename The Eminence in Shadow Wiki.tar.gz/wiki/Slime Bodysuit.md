# Slime Bodysuit

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Slime%20Bodysuit](https://the-eminence-in-shadow.fandom.com/wiki/Slime%20Bodysuit)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Slime_Bodysuit?action=edit).

The Slime Bodysuit (スライムボディスーツ, Suraimu Bodisūtsu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is an attire used by Shadow Garden to enhance their already powerful natural abilities.

## Overview

The Slime Bodysuits originally invented by Cid Kagenou were made from the slimes in his domain. While slimes are normally very fragile, they are also excellent mana conductors, allowing a user with excellent control over their mana to channel their magic through the slime suit and create just about anything conceivable, from swords to armor to fake breasts to wings, and so forth.

Due to how flexible and versatile the Slime Bodysuit is, it can become an instant armor as long as the mana channel by which to inject into it is still functional. It does take a lot of control, since the mana pathways of slimes and humans are radically different.

### Origin Of Creation

This equipment was developed by Cid Kagenou before he founded Shadow Garden and rescuing the [Elf](Elf.md "Elf") girl who would become [Alpha](Alpha.md "Alpha"), which is now become a standard equipment used by all Shadow Garden members. Each design is based on their own image and there are differences, such as the parts where the skin is exposed and the presence or absence of accessories such as mufflers.

It is made using slime jelly, an item from the corpses of slimes, that has a 99% conductivity efficiency for magic. Slimes in this world are liquid monsters that transform using magic. A large amount of them were collected and solidified into a jelly-like bodysuit and equipment that was formed into a sword.

By using slime jelly and Equipment Enhancement magic, the Slime Bodysuit has a ridiculous amount of utility and allowing users to manipulate it how they see fit, changing shape and even mass according to the user's instruction, making it an extremely easy-to-use equipment that combines offense and defense. Parts of the suit can be separated and made into weapons called Slime Weapons, which have the same basic capabilities as the suit and can be reabsorbed into it at any time. Even without shaping it into an actual weapon, by separating a part and firing it, it is possible to perform a long-range attack like a bow and arrow. It can also change the color, and by adjusting the amount of slime, a Shadow Garden members can change their appearance and become a completely different person, so it can use as a disguise tool.

At the beginning of development, Cid capturing many Slimes and extracting their magic cores without affecting their magic structure, and perfecting his control binding magic with them. It was just a black slime covering the whole body, but it was later improved to look like a bodysuit. In the Manga version, at the beginning of development, it is in a state like a coat without decoration.

## Functions

- Quick Equip & Remove: Due to the Slime Bodysuit's ability to change shape and mass according to the manipulation of magic by the wearer, it can be quickly donned and removed with but a thought. When removed, it can become extremely small, allowing the holder to always have it on their person.
- Slime Weapons: With the ability to soften, harden, and freely shape itself, the person wearing a slime bodysuit can freely create weapons out of the suit. Shadow often has blades protrude from his elbows, knees, and feet in order to increase the lethality of his hand-to-hand combat. Even converting the edges of his jacket into blades for proximity slashes. Cid's one favorite tactic is to unsuspectingly attack his opponent's leg using his own combined with the slime bodysuit to throw them off-balance.
- Slime's Defense and Intangibility: Depending on the control, magical power, and use of magic in the slime suit, the suit can provide a nearly impenetrable defense, or practically impenetrable for its user, as seen in the case of Shadow, who didn't even flinch from seriousness, instead took it easy, receiving a strong attack from Iris Midgar at full magical power, stopping her magical sword attack with only his right hand, during his fight with Beatrix in the kingdom of Midgar.
- Healing and Slime Regeneration: Even if the suit sustains intermittent level damage to its wearer, or they manage to break through its almost impenetrable defense, as long as the damage is not at the cellular level, be it a physical or magical attack, it can rebuild itself again. very quickly depending on the level and magic control of its user, and at the same time, provide an internal healing to it, in the event that they did not damage the suit, but the user did.
- Change Costume:
- Damage Disguise:

## Weakness

1. As a weak point, its entire performance depends on the control of its wielder's magical power. If its wearer's magic power is sealed, it will become a mere liquid and can't even hold its shape as equipment or clothing, rendering it useless. So far only Shadow, the Seven Shadows and their subordinates can keep control of this, preventing their suits from disappearing, Shadow being the one who overcomes them.
2. It has been shown that the slime suit can be damaged, sometimes seriously, when a magic order is not being exercised in the specific area where it receives damage to protect itself, this is seen, when they came to cut the fake slime breasts of [Epsilon](Epsilon.md "Epsilon"), during the infiltration of the Sanctuary. But while it can be damaged, as long as the damage is not on a cellular level, it can be repaired within a few seconds, if not a second, when Epsilon for fear that her secret would be exposed to everyone, in less than 1 second, she managed to gather her severed breasts to instantly kill the [Venom](Venom.md "Venom") enforcer.

## Trivia

- Cid recalls how harvesting the number of slimes to refine the bodysuit technology effectively made the slime population in his family's domain go extinct.[[1]](#cite_note-V1P-1)
- Rose Oriana had commented that the Slime Bodysuit itself was a groundbreaking invention that would revolutionize the entire world, especially the knights and military.[[2]](#cite_note-2)
- In the Web Novel, it is stated that Cid Kagenou fused the slime with human flesh.

## References

1. Volume 1 Prologue: Preparing the Perfect Stage!
2. Volume 4 Prologue: It's Time for a War in the Oriana Kingdom

## Side Navigation
