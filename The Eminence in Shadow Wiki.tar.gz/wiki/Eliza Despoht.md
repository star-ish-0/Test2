# Eliza Despoht

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Eliza%20Despoht](https://the-eminence-in-shadow.fandom.com/wiki/Eliza%20Despoht)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Chronology

Relationships

Image Gallery

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Eliza_Despoht?action=edit).

## Eliza Despoht

### Japanese

エライザ・ダクアイカン

### Romaji

Eraiza Dakuaikan

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Brad Despoht † (Father)

## Professional Information

### Occupation

Midgar Academy Student Council Vice President

### Affiliation

Midgar Academy for Dark Knights
Thirteen Nightblades

## Debut

### Light Novel

Volume 5

### Manga

Chapter 63

Eliza Despoht (エライザ・ダクアイカン, Eraiza Dakuaikan[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the student council vice president of the Midgar Academy for Dark Knights.

## Appearance

## Personality

Eliza is a haughty, overbearing, selfish, and rude individual due to her lack of etiquette. Her arrogance is particularly awful, even by the standard of noble. Not only does Eliza loves to intimidate everyone below her station, but she also constantly antagonizes people with equal or higher status.

It seems that she's so used to getting her way by making the threat to the point that she's never cared about her target. Eliza even dared to make a one-sided deal with Alexia Midgar, who was a royal family with far more political power than her household.

Eliza was also shown to be psychotic and heartless as during the attack by the cult of diabolos, she had her classmates intentionally kill each other as they were all forced to wear mana collars that killed them when the amount of mana they had left reached zero. During this she learned about one of the features of the collar which allowed one person to transfer mana from one person to another by touching the other person’s collar or vice versa. She then decided to forcibly steal the mana from her classmates and left them with little mana, which ultimately caused their deaths. She even had those with low mana be thrown out of their classroom as bait for the ghosts in the hallway.

## Powers & Abilities

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • Alexia Midgar • Christina Hope • [Isaac](Isaac.md "Isaac") • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | **Eliza Despoht** | |
