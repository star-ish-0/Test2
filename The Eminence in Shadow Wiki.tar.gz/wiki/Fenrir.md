# Fenrir

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Fenrir](https://the-eminence-in-shadow.fandom.com/wiki/Fenrir)

CLEANUP: ONLY YOU CAN IMPROVE THE WIKI!

You do not need to have peregrinated around Midgard or experienced dimensional travel help here. Shadow Garden encyclopedists have marked this page to be cleaned up by the community. You can assist the wiki by proofreading or checking if this article follows our standards and layout guide. Your contributions will make the wiki better for everyone in this community.

[Chronology](Fenrir-Chronology.md "Fenrir/Chronology")

[Relationships](Fenrir-Relationships.md "Fenrir/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | I am Fenrir. I have long held the fifth seat of the Rounds, and I am proud to uphold my pride. | ” |
| — Fenrir, Light Novel Volume 05 | | |

## Fenrir

### Japanese

フェンリル

### Romaji

Fenriru

### Aliases

Devil of Midgar

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Silvery White

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- 5th seat of the Knights of Rounds
- 6th seat (Formerly)

### Affiliation

Cult of Diablos

## Debut

### Web Novel

Chapter 16 (Mentioned)

### Light Novel

Volume 1 (Mentioned)
Volume 5

### Manga

Chapter 58

### Anime

Episode 4 (Mentioned)

Fenrir (フェンリル, Fenriru[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the 5th Seat of the Knights of Rounds and the leader of the Cult of Diablos' Midgar main faction.[[1]](#cite_note-V1C3-1)[[2]](#cite_note-V5C1-2) Before his rise to power, he was known as the Devil of Midgar (ミドガルの悪鬼（あっき）, Midogaru no Akki[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), an infamous assassin whom the Kingdom citizens feared.[[3]](#cite_note-V5E-3) His final mission for the Cult was to recover the right arm of [Diablos](Aurora.md "Aurora") under the Midgar Academy for Dark Knights.[[4]](#cite_note-V5C4-4) Shadow thwarted Fenrir's objective by liberating students who were held as sacrifices and killing the old assassin.[[3]](#cite_note-V5E-3)

## Appearance

Fenrir maintains the appearance of a young boy with silver hair. Others describe his beauty as something that can only exist in fairy tales. However, Fenrir possessed the ability to alter his face and body. His true form is that of a frail elderly man covered in deep wrinkles and white hair.[[3]](#cite_note-V5E-3)

## Personality

|  |  |  |
| --- | --- | --- |
| “ | I’ve been waiting so, so long for this day. There is no more exciting moment that compares to putting one’s practice to the test. A man cannot fight with a sword alone. | ” |
| — Fenrir, Light Novel Volume 05 | | |

Fenrir was a former assassin who took pride in being a murderer, claiming to have killed countless people to reach the "pinnacle of martial prowess". A combat fanatic at heart, he loves the thrill of battle and facing strong opponents.[[3]](#cite_note-V5E-3) He refused to acknowledge those he deemed weak, including fellow members of the Rounds. Like many of the Cult's higher-ranking members, Fenrir presented himself with absolute confidence and importance.[[4]](#cite_note-V5C4-4)

## Powers & Abilities

Once hailed as the "greatest knight ever," Fenrir strength soon became a legendary with a large body count behind it.[[5]](#cite_note-V5C2-5) He later climbed to his executive position in the Cult and maintained control over Midgar's underworld for hundreds of years. In combat, he has demonstrated the ability to overwhelm and suppress many opponents deemed powerful or who have previously triumphed over strong foes.[[3]](#cite_note-V5E-3)[[4]](#cite_note-V5C4-4)[[5]](#cite_note-V5C2-5)

### Swordsmanship

Fenrir utilizes a sword style that relies on concealment and agility. The Locust Shell technique is the pinnacle of this approach and centuries of attempting to achieve marital supremacy. Hiding his presence and creating magically induced after image, Fenrir delivers nine simultaneous strikes to an enemy.[[3]](#cite_note-V5E-3)

### Magic

### Physical Capabilities

### Intelligence

One of Fenrir's favorite tactic is to distract and rile up his opponents in order to lower their focus and guard.[[3]](#cite_note-V5E-3)

### Weapons and Equipment

Fenrir's primary weapon, [Bloodfang](Bloodfang.md "Bloodfang"), is a long sword that exceeds his height. The fiery blood-red blade was once used by the "greatest knight ever."[[3]](#cite_note-V5E-3)

## Trivia

- His name is derived from the giant wolf [Fenrir](https://en.wikipedia.org/wiki/Fenrir "wp:Fenrir") from Norse Mythology.[CITATION NEEDED]
- Fenrir's name was mentioned in the first volume of the light novel, before being officially debuted in the fifth volume.[[1]](#cite_note-V1C3-1)

## References

1. Volume 1. Chapter 3: My Official Beginning as a Mastermind in Action!
2. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
3. Volume 5 Epilogue: I’d Let the Whole World Burn, If That’s What It Took!
4. Volume 5 Chapter 4: Peace in Our Time!
5. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | [Loki](Loki.md "Loki") • [Hel](Hel.md "Hel") • [Jormungandr](Jormungandr.md "Jormungandr") • **Fenrir** • [Mordred](Mordred.md "Mordred") • [Petos](Petos.md "Petos") • Jack Nelson • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • Sir Gaunt | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • [Jean](Jean.md "Jean") • Dark Spider • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • [Gray](Gray.md "Gray") • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • Reina Oriana • [Isaac](Isaac.md "Isaac") | |
