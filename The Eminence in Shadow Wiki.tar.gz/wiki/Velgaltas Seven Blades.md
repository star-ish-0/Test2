# Velgalta's Seven Blades

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Velgalta%27s%20Seven%20Blades](https://the-eminence-in-shadow.fandom.com/wiki/Velgalta%27s%20Seven%20Blades)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Velgalta%27s_Seven_Blades?action=edit).

## Velgalta's Seven Blades

### Japanese

ベガルタ七武剣（しちぶけん）

### Romaji

Begaruta Shichibuken

## General Information

### Leader(s)

Unknown

### Status

Active

### Affiliates

Velgalta Military

### Base of Operation

Velgalta Empire

## Debut

### Web Novel

Chapter 68

### Light Novel

Volume 2

### Manga

Chapter 21

### Anime

Episode 15

Velgalta's Seven Blades (ベガルタ七武剣（しちぶけん）, Begaruta Shichibuken[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are a selection of seven most powerful and finest warriors who have earned the special knight title position that are highly regarded in Velgalta Empire.

## Overview

The Velgalta's Seven Blades is the title given to a group of knights, consisting of only the greatest weapon-wielding warriors of their generation that Velgalta Empire can produce. Said title would only be bestowed to the seven best warriors who are considered the strongest in the Empire, and have reached the physical heights of humanity, possessing heroic levels of strength.

## History

Velgalta's Seven Blades is a privileged honorary knight title that has been presumably made since the founding era of the Velgalta Empire, which is only given to the seven extremely powerful members at one time. The title can also be represented as a great symbol of power usually given to the most exemplary warriors, who have each possessed different phenomenal strength, fighting prowess with highly trained experience on mastered various form of weapons specialized as they entered into the service of the Empire.

## Organization Strength and Influence

The Seven Blades are a group of specially trained elite knights of the Velgalta Empire that cultivate their skills by practicing their performative swordsmanship, which is a most significant and crucial part of the empire's national power, serving as Velgalta's strongest force. Their renowned reputation and strength they had acquired before or during their tenure earned them considerable respect and fear both within and outside the Empire.

All members of the Velgalta’s Seven Blades are exceptionally powerful combatants, known for their pure martial prowess and ability to utilize such in both physical strength and possessed magic power to overwhelm any of their opponent they faced, which is estimated to be capable of bringing down an entire nation. Along with their impressive combat abilities, most members have shown to be highly intelligent, knowledgeable and crafty.

## Membership

Velgalta's Seven Blades is considered an esteemed position within the highest ranking of the empire's magic swordsmen, comprising only 7 strongest members are specifically selected based on their extraordinary capabilities that were worthy of the title. To become a member of the Seven Blades, a person must successfully prove their strength in order to be recognized or have accomplish a great feat from their major contribution to the Velgalta Empire. An example of the former is challenging one of the Seven Blades’ members to a duel in order to obtain the prestigious title by defeating the warrior who holds that position.

## Chronology

## Known Members

- Leader of the Seven Blades
- Annerose Nichtsehen (Formerly; Resigned)
- Sergey Gorman (Deceased)
- [Karen von Herzog](Chi.md "Chi") (Formerly; Revoked)
- Stan Bach (Deceased)

## Trivia

- It's unknown if Annerose was aware or not about her fellow Blades being part of the Cult of Diablos.

## References

## Site Navigation
