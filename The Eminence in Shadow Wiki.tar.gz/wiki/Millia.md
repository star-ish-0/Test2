# Millia

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Millia](https://the-eminence-in-shadow.fandom.com/wiki/Millia)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Millia?action=edit).

[Chronology](Millia-Chronology.md "Millia/Chronology")

[Relationships](Millia-Relationships.md "Millia/Relationships")

Image Gallery

## Millia

- Mutated
- Normal

### Japanese

ミリア

### Romaji

Miria

### Aliases

No. 711

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

Not specified

### Height

Unknown

### Hair Color

Gray

### Eye Color

Silver

### Birthday

Unknown

## Personal Information

### Status

Alive

### Relatives

[Grease](Grease.md "Grease") † (Father)

## Professional Information

### Occupation

- Midgar Academy for Dark Knights Student (Formerly)
- Numbers Member

### Affiliation

Shadow Garden
Midgar Academy for Dark Knights (Formerly)

## Debut

### Web Novel

Chapter 8 (Mentioned)
Chapter 15 (Full Appearance)

### Light Novel

Volume 1

### Manga

Chapter 2 (Mentioned)
Chapter 5 (Full Appearance)

### Anime

Episode 2 (Mentioned)
Episode 4 (Full Appearance)

## Portrayal

### Japanese

[Yuka Nukui](https://en.wikipedia.org/wiki/Yuka_Nukui "wp:Yuka Nukui")

### English

Cyrus Rodas (Mutated form)

Millia (ミリア, Miria[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the daughter of the late Viscount [Grease](Grease.md "Grease"). Ever since contracting the [Possession](Possession.md "Possession"), she became an experimental research subject for the Cult of Diablos while her father served them in the hopes that he might find and try to cure her.[CITATION NEEDED] After her encounter with Alpha, she is retrieved and revived by the Cult of Diablos to be turned into a more potent weapon.[CITATION NEEDED] She was then cured and was rescued by Shadow Garden who gave her the number 711.[CITATION NEEDED]

## Appearance

Millia is a beautiful young girl with grayish-white hair similar to her father's. In flashbacks, she wears a dress and two bows, one on her head while the other tied behind her back. As a little girl, she also carried a teddy bear. She has a petite build in resemblance to her thirteen-year-old self.

## Personality

She is noted to have a high aversion against losing/being defeated (for an unexplained reason).[CITATION NEEDED] This has resulted in her losing her composure on multiple occasions after being forced to interact with Akane Nishino following their duel.

## Powers & Abilities

During her rampage across Midgar Kingdom's capital, the mutated Millia exhibits superhuman strength and razor-sharp claws for offensive purposes. Her most unique on Millia's demonized state is a high regenerative ability, allowing her to survive even from multiple fatal slashes. But her overwhelming power is no match for Iris Midgar until she eventually returned to her normal state by [Alpha](Alpha.md "Alpha").[CITATION NEEDED]

After the Cult retrieves her body, they performed numerous experiments transforming Millia into the "Cult's strongest human weapon," a huge monster with numerous amounts of tentacles that possess great strength and magic. After Shadow defeats and heals her, she reverts back into her human body, losing her monstrous appendages. After training in Shadow Garden for a brief period, she is noted by [Lambda](Lambda.md "Lambda") to be a prodigy in swordsmanship but struggles to remain calm initially. She is also capable enough to fight on par with Akane in her Original Knight state.[CITATION NEEDED]

## Trivia

- In the Web Novel, Millia is revealed to be alive, having been resurrected by Perv Asshat to attack [Epsilon](Epsilon.md "Epsilon") and [her](Chi.md "Chi") [subordinates](Omega.md "Omega"). Following that encounter, Epsilon cured Millia and was taken into [Alexandria](Alexandria.md "Alexandria").
  - This would get adapted into the Light Novel, as in Volume 6 Millia was revealed to have been revived by the Loki faction and later be healed by Shadow.
- Millia is the third person to be healed by Cid prior to joining Shadow Garden after its debut.[[1]](#cite_note-1)

## References

1. Volume 6 Chapter 4: And the Monster Becomes a Legend!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • **No.711** • No. 712 | |
