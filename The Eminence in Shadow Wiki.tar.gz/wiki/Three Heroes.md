# Three Heroes

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Three%20Heroes](https://the-eminence-in-shadow.fandom.com/wiki/Three%20Heroes)

Three Heroes (三人（さんにん）の英雄（えいゆう）, San-nin no Eiyū[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are the three legendary warriors who once saved the world from the [Demon King Diablos](Aurora.md "Aurora").

## History

Long ago, the Cult of Diablos kidnapped orphans without relatives to implant and collect Diablos Cells, in an attempt to create powerful soldiers to fight the Demon King [Diablos](Aurora.md "Aurora"). The experiments almost resulted in failure, since most of the children ended up dying, but luckily for the Cult, three girls survived. They are [Olivier](Olivier.md "Olivier") the Elf, [Lily](Lily.md "Lily") the [Therianthrope](Therianthrope.md "Therianthrope"), and [Freya](Freya.md "Freya") the [Human](Human.md "Human"). The cult carried out more experiments to make them stronger and more powerful, creating weapons and equipment for them so that when they were adults and ready, they would go fight the Demon King Diablos.

It was historically recorded that years later, the Three Heroes went to exterminate the demon [Diablos](Aurora.md "Aurora") by order of the Cult, which resulted in the demon's defeat. During the battle, Olivier managed to cut off the demon's left arm with her sword, which was then sealed in the [Sanctuary](Sanctuary.md "Sanctuary"). But in the end, she and the other two heroes were cursed by Diablos so that their descendants would be possessed with rotten bodies.[[1]](#cite_note-1)

Sometime later, the members of the Cult of Diablos, began to hunt the descendants of the heroines, to collect more Diablos Cells in order to produce more Beads of Diablos.

## Chronology

### Sanctuary Infiltration

### The Academy Disappearances

### Apocrypha "Requiem for the Falling Shadows"

## Equipment and Artifacts

TBA

## Known Members

- [Olivier](Olivier.md "Olivier"), the Elf Hero
- [Lily](Lily.md "Lily"), the Therianthrope Hero
- [Freya](Freya.md "Freya"), the Human Hero

## Gallery

[Olivier](Olivier.md "Olivier")

[Freya](Freya.md "Freya")

[Lily](Lily.md "Lily")

## Trivia

- The names of the Three Heroes that have been revealed so far are the names that can be used in unisex, as their names is generally sound masculine and rarely feminine. Therefore, this is the Cult of Diablos' way of manipulating the world into thinking that all Three Heroes are considered male rather than female, except for Shadow Garden.
- The descendants of Olivier lineage would be the most numerous and affected by "[Possession](Possession.md "Possession")", compared to the other lineages of the other heroines, such as Lily and Freya.
- Both the dialogues, participations and interaction of the Three Heroines are constructions of the Game itself, since in the [Anime](Anime.md "Anime"), [manga](Manga.md "Manga"), Light novel and web novel, they are barely mentioned, and debuted, (without having much participation as such in the main story).[[2]](#cite_note-2)

## References

1. Volume 1 Prologue: Preparing the Perfect Stage!
2. In the digital manga, chapter 16, the 3 girl heroines are briefly seen, [Olivier](Olivier.md "Olivier") debuted in the 2nd volume of the Light Novel, [Lily](Lily.md "Lily") was partially seen in volume 5, and [Freya](Freya.md "Freya") is mentioned only in the Web Novel - chapter 182.

## Site Navigation
