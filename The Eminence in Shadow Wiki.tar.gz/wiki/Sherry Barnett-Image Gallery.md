# Sherry Barnett/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sherry%20Barnett/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Sherry%20Barnett/Image%20Gallery)

Main

Chronology

Relationships

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Profile Pictures

Sherry Barnett's Profile in English

Sherry Barnett's Profile in Japanese

Volume Illurstations

Season 1Design

Subtle Romance: Sherry Barnett

Young Researcher: Sherry Barnett

Happy Holiday: Sherry Barnett

Endless Curiosity: Sherry Barnett
