# Zeta

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Zeta](https://the-eminence-in-shadow.fandom.com/wiki/Zeta)

[Chronology](Zeta-Chronology.md "Zeta/Chronology")

[Relationships](Zeta-Relationships.md "Zeta/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | I'll shoulder all the sin. | ” |
| — Zeta, Light Novel Volume 05 | | |

## Zeta

- Light Novel
- Manga
- Anime
- Game

### Japanese

ゼータ

### Romaji

Zēta

### Aliases

Zeta the Prodigy
Lilim (Birth Name)
Zetan[[1]](#cite_note-:0-1)[ANIME-ONLY]

## Characteristics

### Race

[Therianthrope](Therianthrope.md "Therianthrope") (Cat Therianthrope)

### Gender

Female

### Age

15 Volume 1
17 (Currently)

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Purple

### Birthday

February 22

## Personal Information

### Status

Alive

### Relatives

- [Lily](Lily.md "Lily") (Ancestor)
- Unnamed Father (Deceased)
- Unnamed Mother (Deceased)
- Unnamed Younger Brother (Deceased)

## Professional Information

### Occupation

- 6th Seat of the Seven Shadows
- Head of Reconnaissance and Espionage Division

### Affiliation

Shadow Garden

## Debut

### Light Novel

Volume 4 (Mentioned)
Volume 5 (Full Appearance)

### Manga

Chapter 55

### Anime

Episode 1

### Game

Chapter 1 - Episode 1

## Portrayal

### Japanese

[Ayaka Asai](https://en.wikipedia.org/wiki/Ayaka_Asai "wp:Ayaka Asai")

### English

Dominique Meyer

### French

Sybille de Montigny

### Italian

[Deborah Morese](https://en.wikipedia.org/wiki/it:Deborah_Morese "wp:it:Deborah Morese")

### German

Cindy Kepke

Zeta (ゼータ, Zēta[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Ζήτα), formerly known as Lilim (リリム, Ririmu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), is the seventh initial member of Shadow Garden and the sixth seat of the Seven Shadows, serving as head of exploration and espionage. Out of dissent for Shadow Garden's direction under [Alpha](Alpha.md "Alpha"), she secretly founded her own faction with the intention of making Shadow an immortal god.[[2]](#cite_note-V5C3-2)[[3]](#cite_note-V5CE-3)

## Appearance

Zeta is a female [Therianthrope](Therianthrope.md "Therianthrope") from the Golden Leopard Clan, having blonde hair, large cat ears, purple eyes, and a long tail. Many describe her as "beautiful", with special attention to her golden tail and ears.[[4]](#cite_note-V5C1-4) Like [Alpha](Alpha.md "Alpha") and her ancestor, [Olivier](Olivier.md "Olivier"), Zeta bears a striking resemblance to her ancestor, [Lily](Lily.md "Lily").

She wears a customary Slime Bodysuit with a large cape settled over her left shoulder in the light novel. A stylized jacket embraces her arms and upper torso and opens under the sternum, where a generous decolletage exposes significant skin. Her jacket has a short frontal length that ends around her ribs section while the back continues to the length of her calves, with puffy fur accents at the collar and waistline and a section of exposed skin along the hips stretching into the back region. She also has an asymmetrical legging, with two solid gold rings circling her right femur while having three parallel belts circling her left femur. In the light novel, her suit has frilled pant cuffs just before her heels. In the anime and game, her leggings don't have frills, but rather boots with a V collar and cuffed endings above the short-heeled shoes with a simple gold lining over the metatarsal.

While exploring the world, Zeta dresses appropriately for the location she finds herself in, especially in the anime. For a jungle when investigating a pyramid, she wore standard khaki shorts and a jacket with exploratory boots. Another few examples include heavy winter attire in a snowy tundra and a sailor girl outfit out at sea.[ANIME ONLY][[5]](#cite_note-5)

## Personality

|  |  |  |
| --- | --- | --- |
| “ | If the time comes, cast me aside. | ” |
| — Zeta, Light Novel Volume 05 | | |

Despite being a Therianthrope, who are mostly known for being wild brutes, Zeta is smart and level-headed.[[6]](#cite_note-V3C4-6) She has also shown to be a loner, usually doing her missions on her own and only cooperating on a team if the situation demands it.[[7]](#cite_note-V5CP-7)[[4]](#cite_note-V5C1-4) Self-sacrificing to a fault, she attempts to shoulder all responsibility or consequences from those she admires.[[2]](#cite_note-V5C3-2)

Zeta can also be seen having a confrontational side when speaking to Delta. She purposefully seeks conflict and antagonizes the dog therianthrope, regularly implying that Delta possesses stupid and barbaric tendencies due to her heritage.[[7]](#cite_note-V5CP-7)

## Powers & Abilities

Cid describes Zeta as "talented in whatever she does," but she is held back by her own fickle tendencies, which prevent her from developing true mastery.[[7]](#cite_note-V5CP-7) As the head of Shadow Garden's reconnaissance division, she naturally specializes in stealth and can operate on her own for extended periods.

### Swordsmanship

Having an innate talent to learn quickly, Zeta presents proficiency in using swords. If she didn't have the habit of discarding them shortly after using them, her Swordsmanship level would be at the same level of Alpha at least,

### Magic

Zeta possesses the ability to turn her body into mist, allowing her to hide, move, and dodge deadly attacks thrown at her.[[7]](#cite_note-V5CP-7) The attack can likewise be used offensively. Its gaseous state allows Zeta to invade users' bodies and cause internal damage or death through rapid expansion.[[4]](#cite_note-V5C1-4) Zeta further demonstrates the capacity to alter the mist's state. By coagulating the gaseous power, she can generate numerous floating blades.

Her mastery over the defensive properties remains imperfect, causing preemptive materialization of body parts.[[7]](#cite_note-V5CP-7)

### Physical Abilities

### Intelligence

Zeta has been shown to be quite calculating, always looking for the most optimal way to achieve her goals.

### Standard Equipment

- Slime Bodysuit: Like all members of Shadow Garden, Zeta wears, as standard, a suit made of slime with 99% magical conductivity.
- Slime Weapons: Her weapons in the game are two moon blades.

### Named Techniques

#### A Thousand Blades: Certain Death

## Trivia

- In the Manga, Zeta, like [Delta](Delta.md "Delta"), tends to mark her Master's belongings.[[8]](#cite_note-MC56-8)
- In the Kage-Jitsu episodes, it was revealed that Zeta does not wear some undergarments because it's uncomfortable for her.[[9]](#cite_note-KJ6-9)
- In the Seven Shadows Chronicles, it's revealed that Zeta was the one who encouraged [Beta](Beta.md "Beta") to pursue a career as an author of novels.[CITATION NEEDED]

## References

1. Episode 28
2. Volume 5 Chapter 3: The Case Is Closed, So, It’s Time for a Flashback!
3. Volume 5 Epilogue: I’d Let the Whole World Burn, If That’s What It Took!
4. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
5. Episode 20
6. Volume 3. Chapter 4: I’ll Destroy It All and Start from Scratch!
7. Volume 5 Prologue: The Case of the Missing Students and the Not-So-Peaceful Academy!
8. Manga: chapter 56
9. Kage-Jitsu: Episode 6

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • **Zeta** • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
