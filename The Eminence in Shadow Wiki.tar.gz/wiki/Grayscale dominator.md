# Grayscale dominator

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Grayscale%20dominator](https://the-eminence-in-shadow.fandom.com/wiki/Grayscale%20dominator)

## Grayscale dominator

## Information

### Artist(s)

[OxT](http://www.oxt-music.com/)

### Composer(s)

Tom-H@ck

### Arranger(s)

Tom-H@ck

### Lyrics

hotaru

### Release date

October 5th, 2023

Grayscale dominator is the opening theme performed by OxT for the second season of the anime adaptation The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Lyrics

### TV Size

- [Kanji](#)
- [Romaji](#)
- [English](#)

That is too late

そんな手じゃもう追いつけない

That is to say…

最初の一手で選ぶ未知なるFuture

その有り様 This way

最後の一手で決める世界のAnswer

一人のWinner　It's me

この目は見据えた

誰も未だ見通せぬ最適解を

全ては盤上支配するGame

思考の闘争

Mistakeさえも偽装して

Checkmateまで布石として

Kingを奪い合うGame思想と欲望

One chance見逃さぬ悪手

Last chance必ず仕留める

That is too late

そんな手じゃもう追いつけない

That is to say

完全勝利はこの手の中に


誰にももう追いつけない

That is too late

Sonna te ja mō oitsukanai

That is to say...

Saisho no itte de erabu michi naru Future

Sono arisama This way

Saigo no itte de kimeru sekai no Answer

Hitori no Winner It's me

Kono me wa misueta

Dare mo imada mitōsenu saitekikai o

Subete wa banjō shihai suru Game

Shikō no tōsō

Mistake sae mo gisō shite

Checkmate made fuseki toshite

King o ubai-au Game shisō to yokubō

One chance minogasanu akushu

Last chance kanarazu shitomeru

That is too late

Sonna te ja mō oitsukanai

That is to say

Kanzen shōri wa kono te no naka ni


Dare ni mo mō oitsukanai

That is too late

I can’t catch up with that hand anymore

That is to say…

Choose an unknown Future with your first move

This way

The world’s Answer is decided with the last move

One Winner It's me

These eyes fixed on

The optimal solution that no one has yet foreseen

A Game where everything is controlled on the board

Struggle of thoughts

Even Mistake is disguised

As a stepping stone to Checkmate

Game of competing for the King Thoughts and Desires

One chance, don’t miss this bad move

Last chance, I’ll definitely finish it off

That is too late

I can’t catch up with that hand anymore

That is to say

Complete victory is in my hands


I can’t catch up with anyone anymore

### Full Version

- [Kanji](#)
- [Romaji](#)
- [English](#)

That is too late

そんな手じゃもう追いつけない

That is to say…

最初の一手で選ぶ未知なるFuture

その有り様 This way

最後の一手で決める世界のAnswer

一人のWinner　It's me

この目は見据えた

誰も未だ見通せぬ最適解を

全ては盤上支配するGame

思考の闘争

Mistakeさえも偽装して

Checkmateまで布石として

Kingを奪い合うGame思想と欲望

One chance見逃さぬ悪手

Last chance必ず仕留める

That is too late

そんな手じゃもう追いつけない

That is to say

完全勝利はこの手の中に

誰にももう追いつけない

狡猾に誘い込むあらゆる罠

無数のKiller　Warning！

嗅覚でかわしつつ昇ってくHigher

極めたPlayer　It's me

この手は望んだ

全てをかっさらうそのためのRace

至高の競争

Start it不平等なルール

Take it覆し掴む

敗者には無慈悲なRace

希望か絶望か

Showdown結果こそ運命(さだめ)

Get outチャンスは二度とない

誰にも見えない陰の中

誰よりまっすぐにその手順(みち)を

全ては盤上支配するGame

思考の闘争

Mistakeさえも偽装して

Checkmateまで布石として

Kingを奪い合うGame思想と欲望

One chance見逃さぬ悪手

Last chance必ず仕留める

That is too late

そんな手じゃもう追いつけない

That is to say

完全勝利はこの手の中に

全ては盤上支配するGame

全てをかっさらうそのためのRace


誰にももう追いつけない

That is too late

Sonna te ja mō oitsukanai

That is to say...

Saisho no itte de erabu michi naru Future

Sono arisama This way

Saigo no itte de kimeru sekai no Answer

Hitori no Winner It's me

Kono me wa misueta

Dare mo imada mitōsenu saitekikai o

Subete wa banjō shihai suru Game

Shikō no tōsō

Mistake sae mo gisō shite

Checkmate made fuseki toshite

King o ubai-au Game shisō to yokubō

One chance minogasanu akushu

Last chance kanarazu shitomeru

That is too late

Sonna te ja mō oitsukanai

That is to say

Kanzen shōri wa kono te no naka ni

Dare ni mo mō oitsukanai

Kōkatsu ni sasoi komu arayuru wana

Musū no Killer Warning!

Kyūkaku de kawashitsu nobotteku Higher

Kiwameta Player It's me

Kono te wa nozonda

Subete o kassarau sono tame no Race

Shikō no kyōsō

Start it fubyōna rūru

Take it kutsushi tsukamu

Haisha ni wa mujihina Race

Kibō ka zetsubō ka

Showdown kekka koso sadame

Get out Chansu wa nidoto nai

Dare ni mo mienai kage no naka

Dare yori massugu ni sono michi o

Subete wa banjō shihai suru Game

Shikō no tōsō

Mistake sae mo gisō shite

Checkmate made fuseki toshite

King o ubai-au Game shisō to yokubō

One chance minogasanu akushu

Last chance kanarazu shitomeru

That is too late

Sonna te ja mō oitsukanai

That is to say

Kanzen shōri wa kono te no naka ni

Subete wa banjō shihai suru Game

Subete o kassarau sono tame no Race


Dare ni mo mō oitsukanai

That is too late

I can’t catch up with that hand anymore

That is to say…

Choose an unknown Future with your first move

This way

The world’s Answer is decided with the last move

One Winner It's me

These eyes fixed on

The optimal solution that no one has yet foreseen

A Game where everything is controlled on the board

Struggle of thoughts

Even Mistake is disguised

As a stepping stone to Checkmate

Game of competing for the King Thoughts and Desires

One chance, don’t miss this bad move

Last chance, I’ll definitely finish it off

That is too late

I can’t catch up with that hand anymore

That is to say

Complete victory is in my hands

I can’t catch up with anyone anymore

All kinds of traps that cunningly lure you in

Countless Killer　Warning！

I’m climbing Higher, avoiding it with my sense of smell

Mastered Player　It's me

I wanted this hand

A Race to steal everything away

Supreme competition

Start it unequal rules

Take it, overturn it and grab it

A merciless Race for losers

Hope or despair?

Showdown, the result is destiny

Get out, there’s no second chance

In the shadows that no one can see

Follow the steps straighter than anyone else

A Game where everything is controlled on the board

Struggle of thoughts

Even Mistake is disguised

As a stepping stone to Checkmate

Game of competing for the King Thoughts and Desires

One chance, don’t miss this bad move

Last chance, I’ll definitely finish it off

That is too late

I can’t catch up with that hand anymore

That is to say

Complete victory is in my hands

A Game where everything is controlled on the board

A Race to steal everything away


I can’t catch up with anyone anymore

## Characters

:   In order of appearance:

- Minoru Kageno/Cid Kagenou/Shadow
- Akane Nishino
- Mr. Kagenou
- Mrs. Kagenou
- [Grease](Grease.md "Grease")
- Claire Kagenou
- Iris Midgar
- Alexia Midgar
- [Glen](Glen.md "Glen")
- Skel Etal
- Zenon Griffey
- Lutheran Barnett
- Po Tato
- [Rex](Rex.md "Rex")
- [Venom](Venom.md "Venom")
- [Olivier](Olivier.md "Olivier")
- Goldy Gilded
- Annerose Nichtsehen
- [Quinton](Quinton.md "Quinton")
- Klaus Midgar
- [Beatrix](Beatrix.md "Beatrix")
- Raphael Geerk Oriana
- [Aurora](Aurora.md "Aurora")
- [Elisabeth](Elisabeth.md "Elisabeth") (Silhouette)
- [Mary](Mary.md "Mary") (Silhouette)
- [Gettan](Gettan.md "Gettan") (Silhouette)
- [Yukime](Yukime.md "Yukime") (Silhouette)
- Rose Oriana (Silhouette)
- [Eta](Eta.md "Eta")
- [Beta](Beta.md "Beta")
- [Zeta](Zeta.md "Zeta")
- [Alpha](Alpha.md "Alpha")
- [Delta](Delta.md "Delta")
- [Gamma](Gamma.md "Gamma")
- [Epsilon](Epsilon.md "Epsilon")

## Videos

OxT「grayscale dominator」Music Video Full Size

Full Music Video

TVアニメ「陰の実力者になりたくて！ 2nd season」 ノンクレジットオープニング：OxT「grayscale dominator」

Opening Visual

## Trivia

- For each arc, the title card transitions into one of Cid's three personas this season before resuming the lyrics.
  - Shadow for Episodes 21-23.
  - John Smith for Episodes 24-27
  - Cid Kagenou starting at Episode 29.
    - The Cid Kagenou transition has blue eyes, in contrast to Shadow and John Smith with red eyes each.
- Episode 28 had a brief audio transition but no opening, as there was no Cid/Shadow except in a flashback.
