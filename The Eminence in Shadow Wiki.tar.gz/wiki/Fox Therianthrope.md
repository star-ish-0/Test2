# Fox Therianthrope

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Fox%20Therianthrope](https://the-eminence-in-shadow.fandom.com/wiki/Fox%20Therianthrope)

Fox Therianthrope is one of the races of [Therianthrope](Therianthrope.md "Therianthrope").

Fox Therianthropes have fox ears and tail powerful fox Therianthrope can have more tails for two to nine tails.

## Known Individuals

- [Yukime](Yukime.md "Yukime")
