# Episode 29

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2029](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2029)

## The Key

### Kana

鍵

### Romaji

Kagi

## Special Title

### English

The Eminence in Shadow wants to go on a journey of self-discovery!

### Kana

陰の実力者は自分探しの旅がしたい！

### Romaji

Kage no Jitsuryokusha wa Jibun Sagashi no Tabi ga Shitai!

## Episode Information

### Season

2

### Episode

9 (29)

### Air Date

November 29, 2023 JP & EN

### Adapted From

Volume 4 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

Grayscale dominator

### Ending

Polaris in the Night (Chi ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| The Dragon's Tears | Caged Bird |

The Key (鍵, Kagi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the ninth episode of the second season, and the twenty-ninth episode of [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

On the way to the Kingdom of Oriana, Cid is also on a journey of self-discovery and reflection. He feels like something's missing. Is he imagining it?[[1]](#cite_note-1)

559の下でオリアナ王国の遺跡調査にあたる666たちは、教団幹部に連行される666の母レイナ王妃を発見。
遺跡に隠された“鍵”を巡る、王妃をも巻き込んだ戦闘が始まる。[[2]](#cite_note-2)

## Summary

Cid’s introspective journey has brought him to a small tavern the Oriana Kingdom. The taverner, [Marie](Marie.md "Marie"), apologizes for the meager selection of drinks, explaining that soldiers seized expensive items to finance the war effort. Urban warfare has ruined the surrounding town, occasioning an unfortunate arrival time for her and Cid. Paying no mind to her concerns, Cid reminisces about his past actions. His journey started without direction, and the time allowed for a profound meditation of his Eminence in Shadow dream. His efforts have been largely reactionary, performing in whatever seemed "eminence-in-shadowy" in any situation. Cid wonders if he should continue that path, orally commenting, "Can things really go on like this?" Marie, engaged in food preparation, misinterprets the rhetorical question as a reply to the previous conversation. Agreeing, she declares they must not give in to the situation. Marie sets her resolve aside to focus on a patron, handing her the completed sandwich. Before the customer puts the plate down, a nearby hand seizes half of her meal. [665](665.md "665") takes a large bite, ignoring [664](664.md "664")'s reprimands. Marie quickly promises to make another sandwich.

Rose is not with her teammates and has remained in her lodgings. As she whimpers an apology to the empty room, vivid hallucinations of patricide run through her mind. King Oriana grips Rose's rapier with a bloodied hand, using his last breath to call her choice unforgivable. The cold eyes of her father roused Rose from the nightmare. Lying in bed, Rose returns to her senses. The princess glances through the window, commenting on the destruction of First Castle Town. Joining Shadow Garden was to gain strength and rescue her kingdom. A knock on the door interrupts her thoughts—664 announces their departure, followed by 665's ebullient encouragement.

Departing from the tavern, 664 explains she will not be in charge of the mission. The operation commander is [559](Victoria.md "Victoria"), a distinguished Shadow Garden member whose previous victory over [89](89.md "89") has granted her the right to challenge the Numbers. 664 notices 666's preoccupied musings and offers to discuss her thoughts. 666 politely declines, explaining there is nothing. The gluttonous 665 forces 664 to begrudgingly accept the unsatisfactory answer to stop her massive appetite.

The three arrive at the rendezvous after nightfall. 559, already present, skips the pleasantries and asks if the trio were briefed about the mission. She sighs after hearing a negative and begins to explain the specifics. Perv's faction besieged the small caste town two days ago. Such an insignificant location should have no strategic value; however, the Cult of Diablos dispatched Name Children, their strongest troops, to conquer the area. Their objective is to discover the Cult's intentions. 559 pulls 666's attention away from the dead royalist soldiers and asks if she knows the reason for her inclusion. 666 speculates it is her intimate knowledge of the area. The assumption is correct, but 559 clarifies that was the only reason. 559 confesses that Rose's presence—using 666's birth name—was a special request made by her. Rose's power was given to her by Shadow. Her teammates explain that the Seven Shadows empowered everyone, the only exception being the Seven Shadows themselves. 559 corrects their explanation, saying she "...too was grated power by Lord Shadow", calling Rose weak despite receiving such a blessing. The devout 559 will eliminate anyone undeserving of Shadow's power. Movement on the ground halts her fanaticism, and everyone focuses on the road. Dozens of carriages head in the direction of repurposed ruins. What was once a war memorial to soldiers' sacrifice against Diablos became an amphitheater.

The four-women squad quickly follows behind and begin observing their activities. They discover the cult leader [Kouadoi the Gale](Kouadoi.md "Kouadoi") and a large assembly of First Children. Kouadoi inserts a card into a pedestal, reminiscent of the key cards used in [Sanctuary](Sanctuary.md "Sanctuary")'s laboratories. The subsequent illumination of the pedestal and surrounding area signifies a connection. 666 is shocked by the sudden appearance of her mother, Reina Oriana. The Queen places her hand on a runic circle at Kouadoi's behest, unlocking the sealed contents—a ring affiliated with [Hero Freya](Freya.md "Freya"). 559 recognizes the relic and tells the other to prepare for combat. She gives cursory answers to her teammates' questions, calling it "the key".

Reclamation is the new priority, shifting the mission from reconnaissance to assault. 666 begs 559 to reconsider the decision due to her mother's presence. The commander ignores her pleading and chooses the Queen as her first target. Rose parries the strike, asking for an explanation. Elaboration is not the attacker's objective, and she receives no answer. The Queen recognizes her daughter and hurriedly falls on her for support. 559, unimpressed with the spectacle, pivots to break the sword lock and transfers the momentum into a right hook. The attack hits Rose's face, sending her and Queen Oriana tumbling, but the enclosing Cult Members inhibit further assault. Rose's treachery confirms for 559 her unworthiness of servitude. Undeterred by the Cult's Children, she delves into the throng to assassinate the traitor.

In Midgar's capital, [Nu](Nu.md "Nu") reports to [Gamma](Gamma.md "Gamma") that the First Castle surveillance team has engaged the enemy. The lounging Gamma acknowledges the report; 559 overzealous behavior is nothing new. Hearing that Rose encountered her mother and Perv Asshat was absent, Gamma wonders if it was all a trap. Shadow's Garden's interface has not uncovered [Mordred](Mordred.md "Mordred"), the Ninth Seat of the Round. He is the puppet master behind the Oriana Kingdom's circumstances. Gamma accepts the situation and continues to glance at a newspaper. Princess Rose's Return is the leading article. Mordred patience is not shared amongst his subordinates. Perv Asshat's anxiety is apparent. The civil unrest and Shadow Garden's continuous harassment have thinned his troops. Oriana Kingdom's security has significantly reduced, making it a perfect time to strike. Gamma orders Nu to deploy numerous troops and leave Rose to the Cult. Shadow has set up present circumstances, but Gamma still questions how it will end.

Back at the tavern, Cid is pondering the present situation. There is a succession battle between the royalists and the Perv faction. He is confident that an eminence in shadow opportunity will present. Cid's idea is that an unknown figure emerges, ending the dispute by guiding one faction to victory. Rose seems like an ideal candidate. His uncertainty about her recent regicide gave him pause. His first thought was a betrothal dispute; however, her resolve was one of conviction: to do whatever it took to be queen. Cid will help Rose's tyrannical ambitions and make her the next Monarch. After becoming a despot, she will inevitably be a roadblock for the heroes. The Eminence in Shadow will stop the evil queen, putting aside past emotional attachments.

Marie's waitressing is interrupted by the sound of the door slamming open. Three menacing men announce it is the war effort collection time. Marie protests their demands, reminding them she gave everything not too long ago. Watching their argument, Cid views it as a perfect opportunity to return to "his roots." One of the intruders suggests that her body could be an alternative form of payment. Mob Cid screams, stuttering at them to stop. The three men beat Cid and take their spoils, paying no heed to the crumpled boy. Marie begs Cid not to be so reckless. She kindly smiles at his apology. An ex-prostitute from the Lawless City is familiar with the feeling of despair. Ultimately, she received help from "him," and now she received help from Cid.

Cid says his final goodbyes to Marie, declining to stay longer. She refuses his attempt to pay, stating that he saved her, and they part ways. The plot contriving mind of Cid's is already in motion. He is impressed with the three soldiers' performance but refuses to be outdone by them. Over the next few days, Cid tried to realize the "Birth of Tryrant Rose" without success. He purposefully got locked up in a corrections facility to try out the life of a prisoner. The convicts found themselves making an explosive jailbreak. Freeman Cid immediately joined a volunteer army and went on a near-suicidal expedition. Cid helped from the shadows by mimicking an Oriana legend. Some older men got all the credit, invalidating all his efforts. To be a proper fixer, one must "stand out by not standing out when standing out."

A glow from a nearby ruined house offers shelter for three men—the exploitative soldiers from Marie's tavern. Surrounded by loot, they comment on the wise selection of locations. The lost ground on the Western Front and the reappearance of legends make other postings less profitable. There was a rumor about recently discovered treasure on the other side of the mountain. A voice asks for details, but the soldier warns that asking questions is a poor decision. Blood slowly trickles out of his comrades' bodies as he obliviously explains that departing is to their advantage. He suggests adding a few women to their possessions and proposes Marie as a start. The only response is the sound of rummaging from a black-haired boy. Noticing his dead allies, the man jumps up and demands an explanation. The intruder jovially explains that if one covets something, taking it is acceptable, even through murder. Dropping a bag of gold into a duffle bag, he says Lawless City rules are delightful. "Might makes right" would make his actions acceptable. The last thing the soldier sees is a black tendril whipping toward his face. A bloody Cid begins to leave, but he stops and looks back, his red eyes glowing in the dark.

Marie's account balance is woefully inadequate for demand. If she disregards rent, there are insufficient funds to replenish stock for the next day. It would have been better to ask Cid to pay, dignity notwithstanding. She supposes that in the end, she must fall back on selling her body. Marie abruptly stands from a muffled sound outside her door. Cautiously, she opens the door and discovers a bag of gold coins. A gust of wind gives her a glimpse of a man in an ebony. The wind's intensity forces Marie to close her eyes; he is gone the next time she opens them. Gazing down at the gold, she tearfully thanks Shadow for watching over her all this time.

Under the full moon, 559 dismembers a Named Child. Kouadoi the Gale articulates his amazement at the death of Heat Blast, Windstorm, Dry Wind, and Cool Breeze under her sword. She fought continuously for three days and nights, her strength decimating all his First Named Children forces. Kouadoi recognizes she has reached her limit and knocks 559 to the ground. A simple death cannot quell his anger. He will make sure she and her teammates die from torture. His losses will be worth it; with the acquisition of the key and Rose Oriana, he can surpass Perv Asshat and become the next Knight of the Rounds. A black figure against the moon brings a crazed smile to the moribund female warrior's face. She euphorically shouts that her savior has arrived. Purple magic enshrouds 559's body, and she moans in ecstasy. Kouadoi is incredulous as her severed left arm regenerates. With newfound strength, 559 turns the last man standing into red slime. Blood rains down as 559 voices her profound admiration and desire for Shadow.

664 and 665 thankfully gaze over their healed wounds, questioning the appearance of their lord. 559 cheerfully greets the slowly deciding Shadow. He starts to ask about the treasure's whereabouts but quickly switches to ruins mid-sentence. 559 falls to one knee to report 666's betrayal. Not catching his slight confusion, 559 declares her unworthy and requests the right to assassinate her. 664 and 665 come to their teammate's defense, clarifying that it was to protect her mother. Interpreting it as corporate espionage, Shadow ignores their squabble, having had enough commercial and traitorous shenanigans. A newspaper article with the headline "Princess Rose Announces Marriage to Chancellor Asshat" lands in his hands. Shadow mana explodes around him, inducing an ecstatic look from 559 and an anxious look from Rose's teammates. Before 664 can protest, Shadow blasts off into the air. Soaring through the air, he fears the Eminence in Shadow performance will be compromised. If Rose marries, her purpose of becoming a tyranness will be lost. He disappears into a purple glint, shouting to the absent Rose that he will pursue her.

## Characters

- [Marie](Marie.md "Marie")
- Cid Kagenou/Minoru Kageno (Flashback)/Shadow
- [664](664.md "664")
- Akane Nishino (Flashback)
- [665](665.md "665")
- Rose Oriana/No. 666
- Raphael Geerk Oriana (Dream)
- [Victoria](Victoria.md "Victoria")/No. 559
- [89](89.md "89") (Mentioned)
- [Kouadoi](Kouadoi.md "Kouadoi") (Debut)
- Reina Oriana (Debut)
- [Freya](Freya.md "Freya") (Mentioned)
- [Nu](Nu.md "Nu")
- [Gamma](Gamma.md "Gamma")
- Perv Asshat (Mentioned/picture)
- [Mordred](Mordred.md "Mordred") (Cameo)
- [Lambda](Lambda.md "Lambda")
- [Zack](Zack.md "Zack") (Flashback)
- Goldy Gilded (Flashback)
- [Quinton](Quinton.md "Quinton") (Flashback)

## Promotional Videos

「陰の実力者になりたくて！ 2nd season」 第9話予告≪ノーマルVer.≫「鍵」

『陰の実力者になりたくて！ 2nd season』 第9話予告≪スペシャルVer.≫「陰の実力者は自分探しの旅がしたい！」

## Trivia

- In the Light Novel, Rose was staying at a Shadow Garden safe house, instead of Marie's inn. She learned it was constructed by Mitsugoshi with mostly unknown decorations-- such as reinforced concrete walls, electricity, and light-bulb chandeliers costing approximately 10 million Zeni.
- [559](Victoria.md "Victoria")’s first anime debut was a cameo in Episode 20 of the first season. Her battle against [89](89.md "89") was featured in the same episode, a background moderated by [Lambda](Lambda.md "Lambda").
- Until the Oriana Kingdom Civil War arc, the light novel closely followed the web novel with only minor tweaks. Thereafter, Daisuke deviated from the original plotline. Cid's recap of his penitentiary and paramilitary exploits was adapted from some of the lost web novel content.
  - The director wanted to make episode 8 as the Prison Break arc. He was figuring out how to solve the differences between the light and web novels but ran out of time.[[3]](#cite_note-3)
- Cid's duffle bag contains his ski mask, sweater, and crowbars—a callback to his past life as the Fancy Hoodlum Slayer in Japan.
- Cid's interaction with 559 is much more detailed in the Light Novel and Manga, as he reflected on how she behaved after he initially rescued her. The only indicator to this shared past in the episode is her expression of him saving her once again.
  - Cid also gave a time frame of her membership by recalling how he had rescued her a year earlier, just around the beginning of his student life.

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e029>
2. <https://shadow-garden.jp/story/#story9>
3. [Director's Notes: 2-9](https://twitter.com/Shadowgarden_PR/status/1727522366631141837)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • **Episode 9** • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
