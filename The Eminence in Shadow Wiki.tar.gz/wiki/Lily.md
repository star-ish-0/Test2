# Lily

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lily](https://the-eminence-in-shadow.fandom.com/wiki/Lily)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Lily?action=edit).

## Lily

### Japanese

リリ

### Romaji

Riri

### Aliases

Therianthrope Hero
Holy Mother (by Nonna)

## Characteristics

### Race

[Therianthrope](Therianthrope.md "Therianthrope")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

[Zeta](Zeta.md "Zeta") (Descendant)

## Professional Information

### Affiliation

Cult of Diablos (Puppet)

## Debut

### Light Novel

Volume 5

### Manga

Chapter 60.2 (Silhouette)

### Game

Apocrypha: Chapter 1

Lily (リリ, Riri[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was [Delta](Delta.md "Delta") and [Zeta](Zeta.md "Zeta")'s ancestor and one of the Three Heroes who defeated the demon [Diablos](Aurora.md "Aurora"), known as the "Therianthrope Hero". In reality, however, she was a pawn of the Cult of Diablos, being a survivor of their experiments, tasked with defeating the demon of their own ends.[CITATION NEEDED]

## Appearance

She shares a resemblance with [Zeta](Zeta.md "Zeta") in terms of appearance.[[1]](#cite_note-1)

## Personality

Unlike her descendant, she shows a much more caring and is also more considerate of her teammates. She is also a lot more vocal about her feelings and opinions and is much more proactive in the interactions with her teammates and Shadow Garden.

She also has a softer demeanor and is much less likely to let her feelings take control of her, only truly speaking up when others are in danger

However, after being sealed inside the [Sanctuary](Sanctuary.md "Sanctuary") for centuries, she had been reduced to an emotionless state, possibly forced to serve the Cult of Diablos.[CITATION NEEDED]

## Synopsis

Centuries ago, originally Lily was a normal Therianthrope until she was kidnapped by the Cult of Diablos, to perform an experiment with her and all the other children, boys and girls alike they had kidnapped and collected to implant Diablos Cells, in an attempt to create powerful soldiers to fight the Demon King Diablos. The experiments resulted in almost failure, since most of the children ended up dying, and a small group of girls survived because they could not tolerate the blood of the demon in their veins.[CITATION NEEDED]

Luckily for the Cult, 3 girls survived the experiments, who turned out to be an [Therianthrope](Therianthrope.md "Therianthrope"), an Elf and a [Human](Human.md "Human"), Lily was one of the other 2 surviving individuals. The cult carried out more experiments to make them stronger and powerful, creating weapons and equipment for them so that when they are adults and ready, they would go to fight the Demon King Diablos.

It was historically recorded that years later, Lily already prepared along with the other two heroes, which is the Elf hero [Olivier](Olivier.md "Olivier") and Human Hero ([Freya](Freya.md "Freya"); WN Only) went to exterminate the demon [Diablos](Aurora.md "Aurora") by order of the Cult, which resulted in the demon's defeat. But then, she and the other two heroes were cursed by Diablos so that their descendants would be [possessed](Possession.md "Possession") with rotten bodies.

However, the truth was, Lily was one of few people who are compatible with Diablos Cells. Hence, she was tasked by the Cult to gather more cells in order to produce more Beads of Diablos. Moreover, the Cult has already manipulated historical records globally and misgendered Lily as a man, so that no one would be able to find out the real facts and try to investigate the truth.

From this point on, the records regarding Lily are starting to contradict one another. The Church's teachings say that Lily had spent the rest of her life traveling the world as a bishop of the church while Zeta's family records state that Lily went on to create the golden panther clan and disseminate the method to cure [Possession](Possession.md "Possession").[[2]](#cite_note-2)

### The Academy Disappearances

## Powers & Abilities

Being one of the three survivors of the Cult of Diablos' experiments with the implanted cells of the [Demon Diablos](Aurora.md "Aurora").

She is also shown to be quite proficient in healing magic, being able to re-create Claire's arm instantly after it had been chopped of by Demonic Gamma.

## Relationship

### Cult of Diablos

Initially, she looked upon the cult quite favorably as she believed that they had created her and her comrades to stop Diabolos from destroying the world.[CITATION NEEDED]

### [Olivier](Olivier.md "Olivier")

Lily has shown significant care towards Olivier, mainly because of her tendency to charge ahead without thinking.[CITATION NEEDED]

### [Freya](Freya.md "Freya")

Lily has shown to have significant amount of respect towards Freya, always addressing her as 'Freya-san'.[CITATION NEEDED]

### [Zeta](Zeta.md "Zeta")

## Trivia

## References

1. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
2. Shadow Garden/The Seven Shadow Chronicles Episode 30 The Hero Revealed!

## Site Navigation
