# Manga/Volume 13

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2013](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2013)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_13?action=edit).

## Manga Volume 13

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041149683

### ISBN EN

ISBN 979-8855416756

### Release Date

May 24, 2024 JP
September 23, 2025 EN

## Volume Information

### Pages

144JP
162 EN

### Chapters

4

Publication Order

| Previous | Next |
| --- | --- |
| Volume 12 | Volume 14 |

This is the thirteenth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

Cid and Beta have arrived at one of the last places the aspiring shadowbroker wanted to go—his home world, Earth! (Or at least what’s left of it.) After running into his former classmate Akane, Cid tries to figure out how the heck he’s gonna get back to his cool isekai fantasy life, but little does he know that his dinky old planet’s got some brand-new thrills…![[1]](#cite_note-1)

「風が――泣いている」…って陰の実力者の深みと孤高さを凝縮した一言！

異世界に転生し、あらゆる物事に陰から介入し実力を示す「陰の実力者」設定をエンジョイしているシド。
「黒キ薔薇」により、ベータとともに前世で過ごした「地球」の日本に飛ばされてしまう！
元クラスメイトの西野アカネ達に保護されるが、新たな脅威が迫り…！！

極度の勘違いと圧倒的な力で無双する異世界ファンタジー、残響の第１３巻！！[[2]](#cite_note-2)

## Summary

## Chapters

- Episode 50
- Episode 51
- Episode 52
- Episode 53

## Characters

:   In order of appearance:

## References

1. [The Eminence in Shadow, Vol. 13 (manga) YenPress](https://yenpress.com/titles/9798855416756-the-eminence-in-shadow-vol-13-manga/)
2. [The Eminence in Shadow (13). Kadokawa](https://www.kadokawa.co.jp/product/322401001369/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • **Volume 13** • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
