# Imatry Nottaloos

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Imatry%20Nottaloos](https://the-eminence-in-shadow.fandom.com/wiki/Imatry%20Nottaloos)

## Imatry Nottaloos

### Japanese

ツギーデ・マッケンジー

### Romaji

Tsugīde Makkenjī

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Brown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Swordsman

## Debut

### Anime

Episode 15

## Portrayal

### Japanese

Ryūnosuke Watanuki

### English

Cyrus Rodas

### Italian

Loris Bondesan

Imatry Nottaloos (ツギーデ・マッケンジー, Tsugīde Makkenjī[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the strapping young swordsman who entered the Bushin Festival tournament.

## Appearance

Imatry Nottaloos is a handsome young man with short spiky hair. As well as a well-built muscular body.

He opts to have an open chest and short, curtailed, leather armor, with a longsword - which he wields one-handed - sheathed on his left hip.

## Personality

Imatry Nottaloos is a young individual, who is depicted celebrating his hard-fought victory.

## Powers & Abilities

He has shown to be a capable fighter, participating in the Bushin Festival competition obtaining a few victories.

## Trivia

- Like many unimportant side characters, Imatry's name is a gag by the author.
