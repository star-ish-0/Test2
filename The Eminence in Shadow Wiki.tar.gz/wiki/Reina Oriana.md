# Reina Oriana

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Reina%20Oriana](https://the-eminence-in-shadow.fandom.com/wiki/Reina%20Oriana)

Chronology

Relationships

Image Gallery

## Reina Oriana

### Japanese

レイナ・オリアナ

### Romaji

Reina Oriana

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Blonde

### Eye Color

Honey

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Raphael Geerk Oriana † (Husband)
Rose Oriana (Daughter)
Clara Oriana  (Youngest Daughter; WN)
Perv Asshat † (Lover)

## Professional Information

### Occupation

Queen of Oriana Kingdom (Formerly)

### Affiliation

Oriana Kingdom

## Debut

### Light Novel

Volume 4

### Manga

Chapter 41

### Anime

Episode 29

## Portrayal

### Japanese

[Yūko Minaguchi](https://en.wikipedia.org/wiki/Y%C5%ABko_Minaguchi "wp:Yūko Minaguchi")

### English

Kara Greenberg

Reina Oriana (レイナ・オリアナ, Reina Oriana[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the Queen of the Oriana Kingdom and Rose's mother. It is revealed that she was a traitor to her country and family, having been in a secret affair with Perv Asshat and unknowingly aiding the Cult of Diablos.[[1]](#cite_note-1)[[2]](#cite_note-2) She was cut down by [Mordred](Mordred.md "Mordred") after Perv's crimes were exposed.[[3]](#cite_note-3)

## Appearance

Reina looked like an older version of Rose Oriana.

## Personality

From the outside, Reina appeared to be a loving mother and regal queen; in reality, this was a façade. The mask of the gracious queen hid an extremely cold and jealous person, accepting any price to receive her desires of lust and power—even the death or manipulation of family.

## Powers & Abilities

As the queen of the Oriana Kingdom, she held some political influence and power.

## Trivia

- The name "Reina" in Spanish means "Queen".

## References

1. Volume 4 Prologue: It's Time for a War in the Oriana Kingdom!
2. Volume 4 Chapter 2: Begin Operation: Obstruction!
3. Volume 4 Chapter 3: Crashing the Ceremony!

## Side Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | [Loki](Loki.md "Loki") • [Hel](Hel.md "Hel") • [Jormungandr](Jormungandr.md "Jormungandr") • [Fenrir](Fenrir.md "Fenrir") • [Mordred](Mordred.md "Mordred") • [Petos](Petos.md "Petos") • Jack Nelson • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • Sir Gaunt | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • [Jean](Jean.md "Jean") • Dark Spider • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • [Gray](Gray.md "Gray") • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • **Reina Oriana** • [Isaac](Isaac.md "Isaac") | |
