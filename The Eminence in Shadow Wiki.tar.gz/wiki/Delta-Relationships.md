# Delta/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Delta/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Delta/Relationships)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Main](Delta.md "Delta")

[Chronology](Delta-Chronology.md "Delta/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

Meeting Cid for the first time, Sara became overwhelmed by his power and immediately submitted to him.[[1]](#cite_note-V2C3-1) Since then, Delta has become a loyal subordinate, calling him Boss Man and following Cid's orders without question. Delta repeatedly voices genuine joy and elation whenever they meet or spend time together. Outside of articulating these feelings, she expresses affection through physical contact, frequently hugging and rubbing against Cid.[[2]](#cite_note-2)[[3]](#cite_note-V3C4-3)[[4]](#cite_note-V5CP-4)

She always enjoyed hunting but finds it even more enjoyable when Cid joins her; although, her definition of "hunting" can vary from seeking animals for food, to exterminating bandits - with the hunt itself being more the point to her, than acquiring the prey.

Due to her therianthrope culture of propagating the strong, Delta wishes to provide Cid with "100 strong," while also having him copulate with other mighty women - presumably the Seven Shadows and others in Shadow Garden - to produce even more powerful offspring. While she seems happy to share him, she is still strongly infatuated with him in her own Delta way, thus despite sharing, desires to receive the most attention out of his mates.

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

Delta loyally serves Alpha and easily gets frightened by her apparent anger; even if Delta falls into a feral mode, if Alpha reiterates her sternness, Delta obediently falls back in line. She often worries about upsetting Alpha whenever a report becomes delayed through forgetfulness or procrastination.[[5]](#cite_note-V3C6-5) This loyalty stems from when Delta tried challenging Alpha for the role of Shadow Garden's second-in-command.[[1]](#cite_note-V2C3-1) The physical confrontation did not switch their positions in the organization. Despite her submissive obedience, the two maintain a sororal relationship—reflective of the other Seven Shadows.[[5]](#cite_note-V3C6-5)[[6]](#cite_note-6)

#### [Beta](Beta.md "Beta")

While Delta's views on Beta are mostly unknown, Beta admits that Delta is like a "little sister" to her, implying that they have a good relationship. Delta see's Beta as the devious one of the Seven Shadows, stemming from their childhood when Beta would trick her into rigged games of chance to get more of Delta's food.[CITATION NEEDED]

#### [Gamma](Gamma.md "Gamma")

In their youth, Delta always quarreled with Gamma due to the latter's lack of combat abilities, something that frustrated her. However, the two seemed to get along fine now that they are older. However, they tend to get into comedic arguments on why brawn or brains is better for Shadow Garden.[CITATION NEEDED] When Gamma showed Alpha a piece of tail fur from Delta, she is seen trying to hold back tears and is more than relieved to know Delta is alive and well, with Delta confused why Gamma has suddenly become clingier towards her.

#### [Epsilon](Epsilon.md "Epsilon")

Delta is on good terms with Epsilon. However, she has, on multiple occasions, come close to uncovering the latter's secret, that she uses her slime bodysuit as breast padding, since she always smells of slime. In response, Epsilon often gives Delta snacks to distract her.[CITATION NEEDED]

#### [Zeta](Zeta.md "Zeta")

Delta and Zeta constantly bicker and antagonize each other. They use insulting nicknames such as "Stupid Bitch" and "Bitch Cat". If the argument goes beyond words, it digresses into physical altercations. Alpha typically stops these fights, but they quickly become bloody in her absence. A winner to these brawls remains elusive, as Zeta disengages before a victor can be named.[[4]](#cite_note-V5CP-4)[[7]](#cite_note-7)

#### [Eta](Eta.md "Eta")

In the anime, Delta and Eta have a rather troubling relationship, with the former being visibly afraid of the latter whenever she accidentally breaks one of her inventions. Eta also has no qualms about using Delta as a guinea pig in her experiments.

### Numbers

#### [Lambda](Lambda.md "Lambda")

#### [Nu](Nu.md "Nu")

Delta has a working relationship with Nu. Despite becoming a number, Delta does not fully accept and respect her. According to Nu, Delta occasionally bites her, even if it is not out of undue hostility.[CITATION NEEDED]

#### [Pi](Pi.md "Pi")

Pi is one of her subordinates and a fellow Dog Therianthrope. She respects her abilities greatly because she sometimes takes her along with her on hunts when she is ordered to track down a target and bring them in alive, mainly because, by her own admittance, Pi possesses a better nose than even she does.

They also seem to have a strong, friendly almost sibling like relationship. They spend much time playing together.

## Family

### Father

Delta's father is the chief of their therianthrope tribe. She previously respected him as the most powerful individual in her life, but that changed after meeting Cid.[[1]](#cite_note-V2C3-1) Delta has no desire to return unless it is with Cid to conquer the tribe.[[3]](#cite_note-V3C4-3)

### Mother

Delta, formerly named Sara, had a lot of affection and love for her beloved mother, unlike her other siblings who only treated her mother as a means to keep their lineage alive, strong and prosperous until they could join a family with Strong leaders, Delta respected, loved and helped her mother a lot even though Delta was the least intelligent in her family.

When her mother fell ill, in her few moments of life, Delta tried with all her efforts to save at the same time that her mother instilled her teachings so that her daughter tried or appeared not to be a fool, among those teachings, Delta learned to say "desu" at the end of every sentence mostly. When Sara realized that her mother's condition was worsening and that her brothers no longer had respect or love for her, nor they were going to help her, Sara became angry with her family and thought that if she became the strongest hunter in her tribe, she could save her mother but in the end she couldn't save her when she smelled that she had died in her bed while Sara was practicing hunting secretly.

Since her mother's death, Sara no longer had love for anyone and only looked at them as rivals and paid respect to those above her, until she later met and joined Shadow Garden.

### Siblings

#### Zabra

As one brother out of hundreds, Delta hardly knew Zabra. She became deeply enraged at his helplessness in battle, stating, "A weakling is no brother of mine," and killed him without hesitation.[[3]](#cite_note-V3C4-3)

#### [Ren](Ren.md "Ren")

#### [Ral](Ral.md "Ral")

## Others

### Claire Kagenou

### Mist Dragon

### Skel & Po

### Alexia Midgar

## References

1. Volume 2 Chapter 3: When Things Get Boring, It’s Time for Explosives!
2. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
3. Volume 3 Chapter 4: I'll Destroy It All and Start from Scratch!
4. Volume 5 Prologue: The Case of the Missing Students and the Not-So-Peaceful Academy!
5. Volume 3 Chapter 6: Circulating Counterfeit Cash!
6. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
7. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
