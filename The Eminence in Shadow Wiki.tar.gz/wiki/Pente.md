# Pente

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Pente](https://the-eminence-in-shadow.fandom.com/wiki/Pente)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Pente

## Characteristics

### Race

Elf

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Silver-Green

### Eye Color

Indigo

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

[Epsilon](Epsilon.md "Epsilon") (Descendant)

## Professional Information

### Occupation

Hero

### Affiliation

The heroes
Cult of Diablos

## Debut

### Game

Apocrypha: Chapter 1

Pente is one of the Heroes that defeated the [Demon Diablos](Aurora.md "Aurora"). She is the ancestor of [Epsilon](Epsilon.md "Epsilon").

## Appearance

Unlike the rest of the Heroes, there is a significant difference between her apperance and that of her Descendant.

Pente has a more silverly shade of green as her hair color compared to her descendant. Her hair is also unkempt, almost resembling dreadlocks. She also has a significant bust, unlike her descendant. She wears a battle armor similar to that of [Olivier](Olivier.md "Olivier") but in a red and silver color scheme.

## Personality

Unlike her descendant, she seems to be a lot more concerned of those around her.

## Powers & Abilities

## Relationships

### [Duet](Duet.md "Duet")

Unlike their Descendants, she and Duet are quite close to one another, to the point that she was feeling sorry for Duet seeing her blame herself for Cid's death, promising her to mourn alongside her.

## Trivia

- Her name, Pente, is derived from Greek meaning five. Likely a reference to her descendant being the Fifth member of Shadow Garden.
