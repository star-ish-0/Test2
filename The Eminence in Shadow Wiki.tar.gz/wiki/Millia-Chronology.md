# Millia/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Millia/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Millia/Chronology)

[Main](Millia.md "Millia")

[Relationships](Millia-Relationships.md "Millia/Relationships")

Image Gallery

### The Beginning of a Cursed Life

Millia is the daughter of Viscount [Grease](Grease.md "Grease") and had a wonderful life with her loving father. At some point, Millia also enrolled in the Midgar Academy for Dark Knights and commemorated the auspicious occasion with matching lockets, each holding a picture of her with her father.

At some point in time, Millia was afflicted with [Possession](Possession.md "Possession") much to her father's horror. This caught the attention of the Cult of Diablos, who abducted Millia and coerced her father's servitude to them, in exchange for not only her safe return to him but also the means to purge the curse from her body.

Eventually, Grease reluctantly joined the Cult and was forced to go along with their wishes in the hope that her disease could be cured. Tragically, Grease was killed by Shadow Garden and Millia remained under the mercy of the Cult.

### Princess Alexia's Kidnapping

About two years later, Millia was still a test subject for the Cult and was treated as a failed experiment. Her body was intentionally mutated until it had become heavily mutated due to possession symptoms, so much so that she barely looked human. Millia was kept in a laboratory hidden in the Midgar Kingdom under the royal capital, where she was subjected to horrendous experiments and constantly abused by a scientist that worked for the Cult. After some time, Millia was imprisoned next to the Second Princess, Alexia Midgar, who had been kidnapped by Zenon Griffey.

When Millia heard the commotion made by Shadow Garden, the scientist who had tormented her for so long tried injecting her with a prototype serum intended to increase her powers. ironically, she used the power to kill the scientist instead of serving the Cult. Before escaping, Millia freed her Alexia by destroying the Magic Sealing Chains on her limbs.

Later, the monstrous Millia rampaged across the royal capital before eventually being confronted by First Princess Iris Midgar and her knights. Despite receiving several attacks, she was able to survive, regenerating at incredible speeds, and continued fighting. However, [Alpha](Alpha.md "Alpha") arrived and cured Millia, freeing her from her Possession and allowing her to rest.

### Bloody Midgar Serial Murder Terror

Millia was reclaimed by the Cult she would later be revived by them and experimented on until she became a tentacled monstrosity to be weaponized against the Cult's enemies. Thankfully, Shadow defeated and healed her of her possession, reverting her back to human. She was rescued by Shadow Garden from the Cult's control to seek revenge upon the monsters for their inhumanity and to avenge her father.
