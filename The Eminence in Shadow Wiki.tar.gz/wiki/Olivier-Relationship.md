# Olivier/Relationship

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Olivier/Relationship](https://the-eminence-in-shadow.fandom.com/wiki/Olivier/Relationship)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Olivier/Relationship?action=edit).

[Main](Olivier.md "Olivier")

[Chronology](Olivier-Chronology.md "Olivier/Chronology")

Image Gallery

## Cult of Diablos

## [Lily](Lily.md "Lily")

## [Freya](Freya.md "Freya"); (WN Only)

## [Duet](Duet.md "Duet")

## [Pente](Pente.md "Pente")

## [Rouge](Rouge.md "Rouge")

## [Nonna](Nonna.md "Nonna")

## [Sarasa](Sarasa.md "Sarasa")

## Descendant

## [Alpha](Alpha.md "Alpha")
