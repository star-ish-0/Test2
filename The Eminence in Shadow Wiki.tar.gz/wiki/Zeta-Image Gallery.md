# Zeta/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Zeta/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Zeta/Image%20Gallery)

[Main](Zeta.md "Zeta")

[Chronology](Zeta-Chronology.md "Zeta/Chronology")

[Relationships](Zeta-Relationships.md "Zeta/Relationships")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Volume 5

Delta and Zeta Fighting

The First Meeting

Profile

Zeta and other girls in the past

Teen Zeta in her slime suit

White Slime Suit Zeta

Remember Your Duty: Zeta

Moonlight Shadow: Zeta

School Rocks!: Zeta

Sixth Member: Zeta

The Spy Life: Zeta

Snowy Rendezvous: Zeta

Ocean Commotion: Zeta

Special illustration: Situation Contest

Loving Maid: Zeta

Ancient Whirlwind: Zeta

Demonic Sixth: Zeta

Secret Technique: Zeta and Delta

Game Event: Apocrypha "Requiem for the Falling Shadows": Symptoms of Zeta corruption

Game Event: Apocrypha "Requiem for the Falling Shadows" Zeta in demonic form kills Eta

Apocrypha: Requiem for the Falling Shadows - Heroine Olivier vs Demon Zeta

Sixth White Shadow: Zeta
