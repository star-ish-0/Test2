# Nidhogg

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Nidhogg](https://the-eminence-in-shadow.fandom.com/wiki/Nidhogg)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Nidhogg

### Japanese

ニーズヘッグ

### Romaji

Nīzuheggu

### Aliases

Black Dragon

## Characteristics

### Race

[Dragon](Dragon.md "Dragon")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Yellows and Red

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Ruler of the Twelfth Realm

## Debut

### Game

Truth Seekers

Nidhogg (ニーズヘッグ, Nīzuheggu) was the ruler of the 12th realm. He was considered a Realm Dragon due to not being original to the main realm that the series is focused in.

## Appearance

1/2

Nidhogg was, by Cid’s words, a picture-perfect black dragon, with its giant size, stocky build and many huge eyes around its body.

Nidhogg’s body was also covered in many spikes and horns in its head and tail, which can be used for battle.

It had a big pair of red wings. However, during the events of Truth Seekers, Nidhogg’s wings were damaged.

## Personality

Nidhogg had a very destructive nature, destroying the abandoned sanctuary and attacking [Zeta](Zeta.md "Zeta") and [Eta](Eta.md "Eta") right after waking up. His intelligence seems to be that of a beast. Unlike the Mist Dragon, Nidhogg was not capable of talking.

## History

### Lord Laugus' Research

Nidhogg was brought from another realm by Lord Laugus, who was able to successfully open a portal to another realm.

After an unknown amount of time, Nidhogg was eventually injured and captured inside a sanctuary, where he would be used to research more about the other realms. This is where Lord Laugus officially gives Nidhogg the title of “Ruler of the 12th realm”

Due to unknown circumstances, the sanctuary that contained Nidhogg was eventually sealed and abandoned, leaving Nidhogg inside for many years.

### Truth Seekers

During an exploration to an abandoned sanctuary, Zeta and Eta were able to find the sealed dragon.

By “accident”, Eta ends up releasing Nidhogg, who instantly starts attacking and destroying the place.

Even while still being injured and stunned from being waken up, he was able to defeat Zeta and Eta without much effort. However when Shadow appeared the black dragon was defeated. Shadow here noticed that this Dragon had a magic totally different and ends up calling Nidhogg a Realm Dragon.

## Powers & Abilities

### Overwhelming Strength

Due to Nidhogg’s size and magic, he is capable of destroying anything that is in his way, even if its breaking through a sanctuary or fighting members from Shadow Garden.

### Regeneration

Due to being from another realm, Nidhogg did not adapt to magic like True Dragons, meaning he doesn't have immortality. However, he is equipped with fast regeneration.

### Draconic Breath

Nidhogg is capable of sucking air to then launch a breath attack from its mouth.

## Trivia

- The name [Nidhogg](https://en.wikipedia.org/wiki/N%C3%AD%C3%B0h%C3%B6ggr "wp:Níðhöggr") is the anglicized name of a serpent—sometimes translated as a dragon—who gnaws the root of the world tree in Norse mythology.[[1]](#cite_note-1)

## References

1. Poetic Edda: Völuspá "Prophecy of the Seeress"

## Side Navigation
