# Cid Kagenou/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Cid%20Kagenou/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Cid%20Kagenou/Relationships)

Main

Chronology

Image Gallery

## Family

#### Claire Kagenou

While describing his sister with positive words such as cool, he continues to distance himself from Claire—not wanting any undue attention.[[1]](#cite_note-V1C1-1) Shadow broker activity frequently causes Cid to renege on promises or past agreements, leading to threats of physical violence and strong words. A proponent of the idiom time heals all wounds, he applies it to Claire and continues to avoid contact, hoping that her smoldering anger will subside.[[2]](#cite_note-V2C7-2) The recent development of Claire claiming to have a special power, notebooks of magic circles, and a bandaged hand disquiets him; however, he wants to support his sister's development. Misinterpreting it as struggles of adolescent identity, he empathizes with her and articulates unilateral support—the “cringe edgelord” phase notwithstanding.[[3]](#cite_note-V3C3-3)[[4]](#cite_note-V5CP-4)

#### Mr. Kagenou

Baron of the Kagenou Estate and Cid's new biological father, Cid reacts indifferently towards his father. He accepts his role as the second-in-line rather than the inheritor of the estate.[[1]](#cite_note-V1C1-1)

#### Mrs. Kagenou

Cid, like his father, accepts Mrs. Kagenou's focus is on the Baron or Claire more than Cid. The one point of contention was Cid's frequent absences at supper.[[1]](#cite_note-V1C1-1)[[5]](#cite_note-SSC-P1C1E5-5)

## Shadow Garden

### Seven Shadows

Although Cid remains oblivious to the validity and consequences of his behavior, the Seven Shadows are among the few whom he has expressed genuine care and concern. He sees them as fellow thespians and friends but complains that they profit from his wisdom. Cid sometimes feels that their sorority excludes the only male in Shadow Garden, him.[[6]](#cite_note-V1C4-6)[[7]](#cite_note-V2C4-7)[[2]](#cite_note-V2C7-2) Despite the belief that they grew tired of imaginative play and perceived artifice, he remains thankful for their continual support for his shadow broker antics.[[1]](#cite_note-V1C1-1)[[8]](#cite_note-V3CP-8)[[9]](#cite_note-V5C5-9) Even if his actions come across as callous or thoughtless, Cid invariably moves to protect them from real or perceived threats.[[10]](#cite_note-V3C4-10)[[11]](#cite_note-V4C3-11)

#### [Alpha](Alpha.md "Alpha")

Alpha holds the honor of being the first member Cid inducted into Shadow Garden and his oldest friend.[[12]](#cite_note-V1CP-12)[[13]](#cite_note-V2CP-13) His familial relationship differs from the majority of the Seven Shadows; he rarely exhibits the Shadow persona if they are alone or in mild circumstances. Frequently talking to her as an equal, he adopts a more natural tone, being more comfortable and open as himself.[[14]](#cite_note-V1C3-14)[[15]](#cite_note-V6CP-15) Outside of their intimate conversations, Cid privately and publicly comments on Alpha's strength and compliments her growth.[[1]](#cite_note-V1C1-1)[[16]](#cite_note-V3C6-16) The restoration of her mutated body may have been accidental, but his expression of admiration is purposeful.

#### [Beta](Beta.md "Beta")

Cid quickly recognized Beta's passion for literature and talent in performing arts. To cultivate her literary ability, Cid would tell the shy and withdrawn Beta fairy tales from his original world. Although Cid acknowledges Beta's ability, her later appropriated literary success induced disappointment. He told her [Earth](Earth.md "Earth") stories for inspiration, not duplication. On account of Beta's “Academy Award-winning performances” and continual information on shadow broker opportunities, he tempers his displeasure at her profiteering from plagiarism.[[1]](#cite_note-V1C1-1)[[13]](#cite_note-V2CP-13)

#### [Gamma](Gamma.md "Gamma")

Cid personally trained Gamma, similar to all the Seven Shadows, but soon found her physically inept. Desperate to calm her tearful pleadings, he explained Earth's advancement into the modern age. They discussed various fields such as engineering, culinary advancements, and economics—the beginnings of Shadow Wisdom. Two years later, Cid would grow quietly envious of Gamma, who used the knowledge to establish the Mitsugoshi Company while keeping him out of the profits. These coveted feelings do not diminish his recognition of Gamma's intelligence or their friendship. He was even willing to temporarily abandon his core principles of technique over brute force to appease Gamma's physical ineptitude—something he has only done for her and Delta.[[6]](#cite_note-V1C4-6)[[7]](#cite_note-V2C4-7)

#### [Delta](Delta.md "Delta")

Delta's high energy and brawn before brain philosophy frequently exasperates Cid. The aforementioned irritation is compounded by Delta's overwhelming physical affection towards him. Regardless of her headache-inducing characteristics, Cid communicates his fondness for Delta, often drawing comparisons to his dog back on Earth. He is not always candid with his intentions, but they share a unique dynamic of direct communication. Cid understands the limitations of Delta's mental capacity and skips the role-playing. Instead, he adopts an informal tone and mannerism—reflective of his true personality—and avoids convoluted plot contrivances.[[10]](#cite_note-V3C4-10)[[17]](#cite_note-V3CE-17)

#### [Epsilon](Epsilon.md "Epsilon")

Cid enjoyed having Epsilon around when they were children. It allowed him to laze around while Epsilon served him tea and massaged his shoulders. Her usual prideful demeanor gets tempered around Cid—a point Cid acknowledges. He values her consideration of his needs and compliance with the chain of command. Epsilon's over-the-top reactions can get irksome, but it has allowed for some good shadow broker role-playing opportunities.[[18]](#cite_note-V4C2-18) What draws his ire, despite the aforementioned qualities, is Epsilon's musical recognition and monetary success as a charlatan. However, the aforementioned qualities and her mutual love for the first movement of Beethoven's "Moonlight" Piano Sonata No. 14 lessens his vexation.[[19]](#cite_note-V2C6-19)

#### [Zeta](Zeta.md "Zeta")

Suspecting Zeta loves spy games, the aspiring shadow broker encourages her role-playing preference. The two frequently exchange enigmatic remarks and ominous comments. He misunderstands her intentions, but it has worked thus far. Outside of the espionage play, Cid admires Zeta's talent. Her quick learning capabilities and genius impress him, but Zeta's boredom and disregard for mastery disappoints Cid. Zeta's constant territory rubbing—bunting—also annoys him.[[4]](#cite_note-V5CP-4)[[20]](#cite_note-V5C1-20)

#### [Eta](Eta.md "Eta")

Out of all the Seven Shadows, Cid admitted that he feels an “odd kingship” with her, seeing much of himself inside the young elf girl. They both have a singular pursuit and the willingness to sacrifice everything to reach it. He aspires to become the ultimate shadow broker, and she desires to explore the depths of science. Cid does not express this sentiment publicly; instead, his actions contradict his feelings. He distances himself purposefully, wanting to avoid her perverse obsession to pick his brains—not always metaphorically.[[21]](#cite_note-V5C4-21)[[22]](#cite_note-V5CA-22)

### Numbers

#### [Lambda](Lambda.md "Lambda")

#### [Mu](Mu.md "Mu")

#### [Nu](Nu.md "Nu")

#### [Pi](Pi.md "Pi")

#### [Chi](Chi.md "Chi")

### Members

#### [559](Victoria.md "Victoria")

#### [664](664.md "664") & [665](665.md "665")

## Midgar Academy for Dark Knights

### Sherry Barnett

Sherry was an upperclassman at Midgar Academy for Dark Knights when the two encountered one another. Cid randomly passed Sherry chocolate, and she misinterpreted the gesture as romantic. After that interaction, Cid retained a friendly acquaintanceship during Sherry's school year.[[23]](#cite_note-V1C5-23) Despite his self-reported aloofness, he admitted that Lutheran Barnett's murder of Sherry's mother and subsequent emotional manipulation disturbed him. After Lutherian's death, Cid allowed Lutherian to become a martyr while accepting Sherry's resentment for losing her supposed loving foster father.[[24]](#cite_note-V1CE-24)

### Eliza Dakuaikan

### Skel Etal & Po Tato

Skel and Po are Cid's classmates and his only friends at the Midgar Academy of Dark Knights. Second sons of minor Barons, the student body perceives the trio as insignificant and are dismissed from higher society—the “three stooges" of the school.[[25]](#cite_note-V1C2-25)[[26]](#cite_note-V3C5-26) Although he calls the two friends, his and their actions reflect the fickleness of the relationship. Cid uses the two's average standings to reinforce his background character persona, and the boys' constant gossiping leads to misconceptions or unscrupulous rumors. It irritates Cid, but he tolerates many of their actions.[[25]](#cite_note-V1C2-25)[[23]](#cite_note-V1C5-23) Tolerance does not equate to unilateral support. He expresses no qualms about abandoning them to their fate whenever they get into trouble due to their own stupid actions.[[27]](#cite_note-V2C5-27)[[4]](#cite_note-V5CP-4)[[15]](#cite_note-V6CP-15)

### Christina Hope

### Suzuki Hope

Suzuki has been Cid's classmate since the start of school. Cid respected his shadowy figure and has used him as a reference on several occasions for his mob persona.[[9]](#cite_note-V5C5-9)

### [Isaac](Isaac.md "Isaac")

### Alexia Midgar

Cid frequently expresses vexation towards Alexia. He continually rejects Alexia's invitations to join the Crimson Order and declines activities to spend more time together.[[13]](#cite_note-V2CP-13) The one exception to the rules is training. Cid raises fewer complaints about spending time with Alexia if swordsmanship is involved. He acknowledges her dedication to training and swordsmanship but still finds her personality twisted.[[25]](#cite_note-V1C2-25)[[26]](#cite_note-V3C5-26)

Initially, Cid confessed to Princess Alexia as part of a bet and to further his position as a normie. Alexia apathetically accepted, much to his surprise. Blackmailed to continue the farce, the relationship became quid pro quo. Alexia could drop the princess veil and delay her engagement, while Cid receives a salary for services rendered.[[25]](#cite_note-V1C2-25)[[2]](#cite_note-V2C7-2) Although the fake relationship concluded, and her violent reaction to rejection convinced Cid that her heart holds deep homicidal proclivities, the candid communication they developed during their fake romance remains.[[13]](#cite_note-V2CP-13)[[14]](#cite_note-V1C3-14)

### [Nina](Nina.md "Nina")

Cid maintains an amiable relationship with his sister Claire's best friend, Nina. This familiarity contains a material element, as Nina will deliver any item Cid requests—even prohibited books. He has. Despite her bad grades, Cid expresses genuine thankfulness that she became his sister's friend and recognizes that her true strength may surpass Claire's.[[20]](#cite_note-V5C1-20)

### Rose Oriana

Cid first interacted with Rose during the preliminaries to the Bushin Festival. He acknowledged the scion's "chic" aesthetic but did not offer additional comments. Between her status as royalty and her undefeated record, Cid viewed their fight as a chance to cement his background character persona and practice normie techniques accrued throughout the years.[[23]](#cite_note-V1C5-23) Another opportunity presented itself when terrorists attacked Midgar Academy. Cid took a sword slash intended for Rose to further his normie agenda, oblivious to Rose's interpretations.[[28]](#cite_note-V1C6-28)

At a later date, Cid was forced to concede his solitary transportation to [Lindwurm](Lindwurm.md "Lindwurm"), the Sacred Land, and traveled with the princess. The carriage ride and forced time together allowed Cid to get to know Rose. Her seemingly pious remarks about destiny, blessings, and deepening "our love" disconcerted Cid. He respects religion and her commitment, but Rose forcing the doctrine of Holy Teachings made him want to distance himself from her zealotry.[[13]](#cite_note-V2CP-13)

Cid succeeded in distancing himself, but he grew curious about Rose stabbing her fiancé.[[19]](#cite_note-V2C6-19) Through compounded information and subsequent conversation with her disguised Shadow, Cid assumed Rose rebelled against the marriage for independence. He thought she wanted the freedom to be a true monarch. Upon hearing that the marriage with Perv Asshat was back on, he was distraught. As queen, Rose would give him more shadow broker opportunities. He chose to personally visit Rose, hoping that restoring her rebellious spirit would annul the marriage.[[19]](#cite_note-V2C6-19)[[4]](#cite_note-V5CP-4)[[29]](#cite_note-V4C1-29)

## Midgar Kingdom

### [Aurora](Aurora.md "Aurora")

When Cid engaged Aurora's echo at the Goddess's Trial, he named her Violet due to her violet-colored eyes. He won but expressed a longing to fight her at full strength.[[30]](#cite_note-V2C1-30) Despite their short time together fighting and in various sanctuaries, Cid developed a friendly relationship with the witch's old and young memory reflection avatars. So far, Cid does not know Aurora's true identity.[[31]](#cite_note-V2C2-31)[[32]](#cite_note-V5C2-32)

### [Beatrix](Beatrix.md "Beatrix")

### Mist Dragon

### Goldy Gilded & [Quinton](Quinton.md "Quinton")

### Iris Midgar

At the time of Alexia's kidnapping, Iris signed off on Cid's arrest. Despite his brutal treatment and false imprisonment, Cid holds no grudges towards Iris. She was only doing her job.[[14]](#cite_note-V1C3-14) They would later share a tit-a-tat in the Bushin Festival Tournament VIP seats. Under the less intense circumstances, Cid acted respectfully toward the older princess, although he kept his opinions about her sister to himself.[[2]](#cite_note-V2C7-2) The two would soon face each other in combat—although Cid was in his Mundane Mann persona. After obtaining an overwhelming victory, he expressed disappointment in Iris's strength.[[33]](#cite_note-V2C8-33)

Once the Mundane Mann charade ceased, Cid, disguised as Shadow, mercilessly taunted and deconstructed Iris's skills, chuckling at the princess for using a weapon artifact as a clutch.[ANIME ONLY][[34]](#cite_note-S1E20-34)

### Annerose Nichtsehen

## Oriana Kingdom

### Perv Asshat

After news broke of Rose marrying Perv, Cid raced to Oriana and met the duke while posing as the apprentice of renowned pianist, Shiron. Cid held no significant malice towards the duke, but he chose to swipe a wedding ring from Perv's coat—ignorant that it was the key to the Black Rose.[[29]](#cite_note-V4C1-29) After the wedding failed and monsters started pouring out from the Black Rose anomaly, Cid arrived as Shadow and did not even comment on Perv's death.[[11]](#cite_note-V4C3-11)

### [Kevin](Kevin.md "Kevin")

### [Margaret](Margaret.md "Margaret")

## Lawless City

### [Crimson](Crimson.md "Crimson")

During Crimson's revival of Elisabeth, Shadow arrives and kills the pro-tempore Vampire Lord. However, when Elisabeth failed to appear, Cid helped himself to the tower's treasury, barely acknowledging Crimson's presence.[[3]](#cite_note-V3C3-3)

### [Elisabeth](Elisabeth.md "Elisabeth")

Cid first met Elisabeth while infiltrating the Lawless City's Crimson Tower. Having heard of the Blood Queen, he was excited to fight her. However, upon finding her coffin empty, he lost interest and left. Later, Cid returned to save the Shadow Garden members from the revived Elisabeth. Despite not fully comprehending the situation, the Shadow engaged the Blood Queen. After several exchanges, he used I... AM... ATOMIC Recovery. Afterward, while in their civilian personas, Elisabeth gave Cid a thankful nod, having deduced his identity, though Cid denied knowing her to Claire.[[3]](#cite_note-V3C3-3)

### [Juggernaut](Juggernaut.md "Juggernaut")

Besides kicking Juggernaut off the tower to protect Claire, Cid ignored the Tyrant's actions and comments.[[35]](#cite_note-V3C2-35) However, Cid did not have the best impression of him. Consequently, he frivolously ordered Delta to hunt him to distract the energetic [therianthrope](Therianthrope.md "Therianthrope") from his John Smith campaign.[[16]](#cite_note-V3C6-16)

### [Marie](Marie.md "Marie")

Cid rescued Marie during the Lawless City Red Moon incident. Their fortuitous encounter allowed Cid to practice muttering ominous lines as Shadow.[[36]](#cite_note-V3C1-36) After their meeting, he stumbles upon her as a tavern owner in the Oriana Kingdom. The second encounter allowed for another performance. Instead of his Shadow routine, Cid excitedly showed off normie Cid's pathetic ability.[[37]](#cite_note-V4CP-37)

### [Mary](Mary.md "Mary")

Infatuated with Mary's enigmatic words, Cid plagiarized her lines regarding a rampage, red moon, and the lack of time for Shadow's Lawless City performance.[[36]](#cite_note-V3C1-36)

### [Yukime](Yukime.md "Yukime")

## Cult of Diablos

Cid declared that he and the members of Shadow Garden are the sworn enemies of the Cult of Diablos; their sole mission is their destruction. In truth, Cid believes that the Cult of Diablos is fictitious, merely an invention from his youth.[[12]](#cite_note-V1CP-12) Instead of a massive conspiratorial organization, Cid assumes their enemies are bandits, petty criminals, or political saboteurs, and the others are humoring his live-action role-playing campaign.[[1]](#cite_note-V1C1-1)[[10]](#cite_note-V3C4-10)

### Lutheran Barnett

Cid was initially wary of interacting with Lutheran due to his high status and probable importance to the story.[[23]](#cite_note-V1C5-23) Upon learning that Lutheran murdered Lukreia and exploited her daughter, Sherry, Cid admitted that even in his wordy detachment, Lutheran's actions disturbed him.[[24]](#cite_note-V1CE-24)

### [Gettan](Gettan.md "Gettan")

### [Viscount Grease](Grease.md "Grease")

Viscount Grease abducted Cid's sister, Claire, right before her departure to the Midgar Academy for Dark Knights. While the Seven Shadows rightfully deduced that he was a member of the Cult, Cid believed Grease was just a bandit. The viscount's strength and unnatural augmentation proved inadequate for killing Cid. After Grease's death, Cid remained ignorant of the circumstances and somewhat disgusted at his reliance on overwhelming strength.[[1]](#cite_note-V1C1-1)

### Zenon Griffey

Cid was once a student in Zenon's class. They exchanged a few words regarding Alexia, but Zenon seemed capable of separating his work and personal life. He thought any woman would be lucky to have Zenon as a husband. The attractive swordsman not only held prestige and wealth but also had quite an affable personality. He wondered why Alexia spurned the accomplished swordsman's advances.[[25]](#cite_note-V1C2-25) Randomly encountering him during Alexia's kidnapping, Cid realized that Alexia's skepticism was warranted.[[14]](#cite_note-V1C3-14)

It only took a few sword exchanges for Cid to diminish Zenon's threat level, taking the chance to mock his definitive statements of power. He decided to teach Zenon a lesson by unleashing his I.. Am.. Atomic attack, killing him.[[14]](#cite_note-V1C3-14)

### [Mordred](Mordred.md "Mordred")

### Jack Nelson

### [Rex](Rex.md "Rex")

Cid encountered Rex during the terrorist attack on Midgar Academy for Dark Knights. Despite easily overwhelming the man, Cid complimented Rex's ability while eviscerating him to pieces.[[28]](#cite_note-V1C6-28)

## [Earth](Earth.md "Earth")

### Parents

Before being reincarnated, both parents moved and resided in America. Cid still holds some familial bounds towards his previous parents from his past life, as he still refers to them as Mom and Dad. After being transported back to Earth, he expressed concern after seeing the ruins of his old home.[[38]](#cite_note-V4C4-38)

### [John](John.md "John")

John was Cid's pet golden retriever in his previous life. Similar to his parents, Cid expressed concern about his well-being.[[38]](#cite_note-V4C4-38)

### Akane Nishino

Akane was the classmate of Minoru Kagenō in Cid's previous life. The two had a tense relationship due to his nonchalance and Akane's contempt. His eyes glazed over her despite their proximity, and Cid frequently forgot her name. However, after rescuing her from being kidnapped, Cid remembered her name. Their relationship dynamic started to shift positively, but his death stopped any further progression.[[39]](#cite_note-V4CA-39)

During Cid and Beta's infiltration on Earth, the old classmates would meet again. Cid was able to remember Akane and even notice the changes that Akane had after he reincarnated but was perplexed by her overfamiliarity.[[40]](#cite_note-V4C5-40)[[38]](#cite_note-V4C4-38) Currently, Cid is unaware that Beta brought Akane back to the new world or her new Shadow Garden status.[[41]](#cite_note-V4CE-41)[[42]](#cite_note-V6C5-42)

### Akira Nishino

### Yuudai Saejima

Minoru's ex-classmate and judo star, Cid remembered him as a gorilla and a possible background character. Reencountering him provided some excellent opportunities for background character acts—much to Cid's pleasure.[[40]](#cite_note-V4C5-40)

## References

1. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
2. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
3. Volume 3 Chapter 3: Pursuing the Blood Queen!
4. Volume 5 Prologue: The Case of the Missing Students and the Not-So-Peaceful Academy!
5. Master of Garden. The Seven Shadow Chronicles: 1-1, Episode 5
6. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
7. Volume 2 Chapter 4: This Situation Calls for a “Who Is That Guy?!”
8. Volume 3 Prologue Heading to the Lawless City over Fall Break!
9. Volume 5 Chapter 5: Terrorists Attack the School… Again!!
10. Volume 3 Chapter 4: I’ll Destroy It All and Start from Scratch!
11. Volume 4 Chapter 3: Crashing the Ceremony
12. Volume 1 Prologue: Preparing the Perfect Stage!
13. Volume 2 Prologue: To Lindwurn, The Sacred Land!
14. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
15. Volume 6 Prologue: The Clandestine Rulers of the Midgar Kingdom... I'm so Jealous!
16. Volume 3 Chapter 6: Circulating Counterfeit Cash!
17. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
18. Volume 4 Chapter 2: Begin Operation: Obstruction!
19. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
20. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
21. Volume 5 Chapter 4: Peace in Our Time!
22. Volume 5 Appendix Illustrations
23. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
24. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
25. Volume 1 Chapter 2: Assuming the Role of a Side Character at School!
26. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
27. Volume 2 Chapter 5: A Battle to Attract Only MVPs!
28. Volume 1 Chapter 6: That Scene Where Terrorists Take Over the School
29. Volume 4 Chapter 1: Putting the Kibosh on Rose Oriana’s Wedding!
30. Volume 2 Chapter 1: Fun Times at the Goddess’s Trial!
31. Volume 2 Chapter 2: Investigating the Sanctuary!
32. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
33. Volume 2 Chapter 8: Lay Your Eyes on My True Powers!
34. Episode 20
35. Volume 3 Chapter 2: Storming the Crimson Tower!
36. Volume 3 Chapter 1: Lawless City Bandit Hunting!
37. Volume 4 Prologue: It’s Time for a War in the Oriana Kingdom!
38. Volume 4 Chapter 4: Lurking in the Darkness in Fantastical Japan!
39. Volume 4 Auxiliary Chapter: Rise of the Fancy Hoodlum Slayer
40. Volume 4 Chapter 5: Sneaking Around in Japan, Just Like the Old Days!!
41. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
42. Volume 6 Chapter 5: Welcome to Shadow Garden!
