# Anti-Magic Nullifier

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Anti-Magic%20Nullifier](https://the-eminence-in-shadow.fandom.com/wiki/Anti-Magic%20Nullifier)

The Anti-Magic Nullifier (対（たい） 魔法（まほう） 無効化者（むこうかしゃ）, Tai mahō mukō-ka-sha[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), is an artifact of Shadow Garden, which can remove the effects of Magical Absorption and weakening, from artifacts or places that specialize in it.

## Overview

## History

## Functions

Anti-Magic Power Nullifier:

Wide Radius:

## Weakness

- Fragile as Crystal:
- Limited Field:
  - Area Reduction:

## Trivia

- Since Delta accidentally destroyed it, it is not known (as of today) if Eta has been able to repair it.
- To date, the useful capacity of the Eta Artifact has not been seen, but as it is understood, it has already been tested and works.
  - So far, the capabilities of the Eta Artifact have not fully come to light, so there is still more to know about it. Because of that, (for the audience), it's only partly speculation about what he can do.
  - According to what is understood, on the part of Alpha and Eta, it is speculated that they had planned to make more than one, but until today, it has not been possible to confirm it.
- Curiously, the design of the Eta Artifact has a combined design, between a [sea urchin](https://en.wikipedia.org/wiki/Sea_urchin "wp:Sea urchin") and a [human eye](https://en.wikipedia.org/wiki/Human_eye "wp:Human eye").

## Reference
