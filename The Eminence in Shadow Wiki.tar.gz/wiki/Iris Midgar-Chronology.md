# Iris Midgar/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Iris%20Midgar/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Iris%20Midgar/Chronology)

Main

Relationships

Image Gallery

## Background

### Early Childhood

From an early age, Iris has shown a tremendous talent for the sword, even being able to defeat her instructors on the first try, which surprised her and her little sister, Alexia. Upon reaching adolescence, she achieved a strong reputation among the Dark Knights of the Midgar Kingdom Knight Order, being acclaimed and recognized among the Midgar citizens. But soon after, when she tried to help the people of her kingdom in her own way, her superiors told her to stop as the situations were something a person in her position should not be involved in. Being told that a situation wasn't important for her involvement has since caused her to start feeling powerless and fueled an Inferiority Complex within her.

### Acclaim to Fame

Supposedly when she was just a student of Midgar Academy, Iris entered the God of War tournament and single-handedly defeated Viscount [Grease](Grease.md "Grease"), and soon gained fame and popularity among the masses for her strength. Iris later watched Alexia practicing her swordsmanship and complimented her sister when saying she liked it. However, Alexia wrongly interpreted the meaning causing a rift between them.

## Volume 1

### Kidnapping of the Princess

After learning her sister's disappearance, Iris desperately ordered the knights to find her. She later got into a fierce confrontation from Claire Kagenou whose brother, Cid Kagenou, was suspected of kidnapping Alexia. Iris looked at the window, crying for her sister's return, but ordered the knights resume their interrogation. Late one night, the kingdom is under massive panic and Iris and her men head into the city to stop the chaos, eventually encountering [a giant monster](Millia.md "Millia"). Despite easily slashing it many times over, the monster regenerates, and before Iris could resume attacking, [Alpha](Alpha.md "Alpha") stopped her and ended the monster's rampage. Iris witnessed a huge explosion and headed to the source, where at the location, she happily and finally found Alexia.

### Midgar Academy Terrorist Attack

Iris and Alexia along with her two personal subordinate, [Glen](Glen.md "Glen") and Marco Granger went to the Midgar Academy to meet Sherry Barnett and showing an artifact they found in the Cult's hideout, which they can't decipher it and asks for Sherry, who is the most brilliant mind in the kingdom, if she can decipher it. Her father, Lutheran Barnett encourages Sherry to do the job, which she accepts, and Iris decides to assign the Crimson Order to keep watch on them. Lutheran hears that's the new knight order that Iris formed, and Iris confirms, and that it's a small order, but it made by people she trusts. Alexia also wishes to help her for investigate Shadow and Iris accepts.

After Alexia escape from her attacker due to Shadow saved her, she tells Iris that the killer was impersonating Shadow Garden. Alexia adds that Shadow is fighting the Cult, and Iris hopes that they will learn something more when the artifact gets deciphered. Alexia then asks her who she thinks is the real enemy, Shadow Garden or the Cult. Iris states it's both and that she won't allow anyone to wreak havoc in the kingdom.

When Iris had Alexia dropped off at the academy to resume her studies, she was alerted by her little sister about the terrorist attack taking the school hostage.

As the Knight Order were kept at bay due to their sealed magic and snipers at vantage points, Iris attempted to intercede and meet with her Crimson Order subordinates inside. However, she was rebuffed by the senior authorities attempting to keep the situation stable for the time being, with one of the knights exclaiming that Iris would be of no use without her magic if she entered. Offended by the thought, Iris still had to respect the chain of command and withheld her frustration, waiting until the magic-sealing bubble lifted, and the knights could swarm in.

Once on academy grounds, Iris met with Princess Rose Oriana to learn that there were two groups calling themselves Shadow Garden, with one responsible for the attack and the other for freeing the students. However, all Alexia called about was that Shadow Garden was involved and thus deemed them responsible, listing their crimes in the Wanted posters and seeking to apprehend Shadow.

## Volume 2

### Bushin Festival Tournament

Fearing for her kingdom's future, Iris participated in the Bushin Festival with hopes that her victory would raise her people's confidence, in both her strength and their security. She also contacted a previous Bushin Festival champion, [Beatrix](Beatrix.md "Beatrix"), possibly to have her as an ally. When the festival began, Iris looked after Cid Kagenou. As the festival progressed, Iris started noticing the apparent strength of a particular contestant, Mundane Mann, but she was confident that she could defeat him.

When the two finally met in the arena, Iris charged in first and attempted to take him down before he could strike but stopped herself out of an instinctive warning Mundane posed. Iris began to hallucinate herself suffering gruesome deaths and eventually came to realize that Mundane was responsible, having thrown feints at her that told her exactly what each possible motion could result in. Iris came to the horrific discovery that Mundane might possibly be the strongest Dark Knight in the world, but her pride and stubbornness refused to let her back down and she tried to once more attack Mundane. One strike later, Iris fell and was defeated.

#### Light Novel/Manga

Finally, once victorious, and due to the murder of Oriana's king Raphael Geerk Oriana, Mundane revealed his identity as Shadow, which dumbfounded Iris and all the spectators, before he easily defeated Perv's guards. An enticed Beatrix decided to fight Shadow and was evenly matched at first, only to be easily outmatched after Shadow decided to get a little serious, and Iris joined their battle soon after with the intention of stopping Shadow by working with Beatrix to finish him off.

However, the plan didn't work out, as Iris was not even a hinderance and Beatrix was bested by Shadow's counterattack. The wounded Iris asked why he didn't just kill them, and Shadow replied that he only kills his enemies, departing while reminding her that she shouldn't lose sight of her true enemies. Immediately afterwards, Shadow disappears in a halo of light, leaving a clear sky in his wake.

#### Anime

After Mundane revealed himself to be Shadow, an enraged Iris stood and allied with Beatrix in the fight to suppress Shadow, even going so far as to take hold of the legendary mithril sword. Shadow chided Iris for the "crutch" while he outmatched and outpaced Iris and Beatrix, including using Crowbars as temporary fighting weapons. As their battle wandered the city, Iris and Beatrix eventually clashed with Shadow at the central clocktower, where Iris planned to distract Shadow with a grapple long enough for Beatrix to deliver a decisive strike, but Shadow defeated the two of them with instant counters and melee might.

Despite her injuries, Iris still stood up readied to continue fighting alongside Beatrix, even calling Shadow out for "fleeing" before her opponent cackled like mad at the thought. The offended Shadow unleashed a massive whirlpool of enraged magic out of his body, encompassing the whole capital with the size of its range, and the witnessing Iris stopped cold in her tracks with fear. When the enormous magic attack turned out to be a bluff that Shadow used to escape after the blinding flash of light, Iris was in shock and disbelief as Shadow had vanished, breaking down in tears as she was forced to face the reality that she lost to Shadow, and to feel truly powerless for the first time.

## Volume 5

### The Academy Disappearances

Iris alongside the Crimson Order investigated the student disappearances and the autopsy of the deceased head librarian. Alexia tried give her testimony and evidence but was too late as Iris believed in Adder's over hers. Alexia tried to reach out to her sister only for her to be written off and threatened by her if she got in the way before leaving.[[1]](#cite_note-:0-1)

## References

1. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
