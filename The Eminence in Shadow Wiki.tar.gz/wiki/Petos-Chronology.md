# Petos/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Petos/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Petos/Chronology)

[Main](Petos.md "Petos")

[Relationships](Petos-Relationships.md "Petos/Relationships")

Image Gallery

## Synopsis

### Background

Petos is send to the Golden Panther tribe village and obtained a [possessed "Matches" sample](Possession.md "Possession"). he reaches the village and informs the branch family tribe that their village has traces of possessed, where he heads to the tribal chief's house. He persuaded the tribal chief to give up [his daughter](Zeta.md "Zeta"), but he replied to him that he lied and say that possession is the scrutiny of the Holy Church.

He says to the chief that he has proof for that statement, which he replied that their tribe have a long-standing bloodline of a Therianthrope hero and tell the real truth about the three heroes and the possession. Petos lied about his true statement by saying it's a blasphemy against the Holy Church.

The chief continues that he has been curious about the story of heroes and demon, which he confirms that the fairy tale story that was passed down in the golden panther group is the truth, while The Holy Church distorts it, making Petos expression seems irritated about his confirmation.

Then, the leader of branch family threatened the chief to say where his daughter, but he refused. When the chief's daughter revealed herself, her father says to her that she must fulfilled her mission by heading to the east at the Midgar Kingdom, to find someone who will cure possession and tell his wife to with their children while he stay behind to protect them from his tribe and Petos, to which he activated the power from the Therianthrope hero, [Lily](Lily.md "Lily").

Petos surprised by the chief's attractive power, which he never thought would be her descendants in this village. He decides to attack him because he feels that the gathering possessed will be an unexpected advantage. Petos kill the chief by cutting his head and carrying it, also ordering his men to taken care of all the members of the golden panther group by killing all of them, so there will be no information leakage of the real truth of the Three Heroes and demon Diablos' story.

Then, Petos searched for the possessed chief's daughter. By chance, he found the chief's wife and beheaded her, while carrying her head. Petos found the girl, carrying her baby younger brother at the beach and showing the severed head of her parents. He walks toward her and demanded to know which one of them is a possessed, which the girl replied honestly.

Petos introduced himself to her and his rank, also says to her that she will become a valuable test subject. Knowing that her brother is not a possessed because the cases of possession in men are very few, but they are slim. Petos decided to kill him painlessly, by stroked her brother's neck with his chain.

The girl screaming at her brother's death, but Petos let out a mocking laugh as he looked down at her because thanks to her, his path to become Rounds will open. When the girl screams at him that she will kill him, while holding her family severed head, Petos ignored and turned his back on her, which he called his subordinates from the forest to confirm that the tasked is completed by showing all severed heads of the golden panther tribe to her, including the branch family leader.

The girl then charged towards Petos, but his chains sent her flying. Petos order his men to arrest the girl and send her to Valliora's laboratory, while he makes preparations to form his faction. Soon, Petos received word that the girl from the golden panther tribe had escape by unknown group, to which he then became obsessed with finding her whereabouts.

Sometime later, his achievement became the foothold for his promotion to the Rounds because he wiped out all the Golden Panther tribe and obtained a sample.

Around two and a half years ago, Petos' dreams are fulfilled when he becomes the 10th seat Knight of Rounds, to replace Sergey Gorman who was the previous seat holder who had been murdered by someone. He is grateful for the promotion and owe a lot for making him the Rounds.

It was then Petos learned the name of an unknown group that have been Cult's obstacle which make him Rounds are Shadow Garden after they show themselves at Midgar Kingdom.

### United on the Verge of Cult's Total Annihilation

Petos attended the "Round Table Committee" council meeting along with the Knights of Rounds members present this year (except [Fenrir](Fenrir.md "Fenrir")) after the failed operation in the Oriana Kingdom to discuss the topic of the Cult's recent losses and decided that Shadow Garden must be eliminated by stating that they become a formidable threat after considering their blunder with the result of their failure operation mission and the destruction of their base of operation facilities, including the [Sanctuary](Sanctuary.md "Sanctuary") at [Lindwurm](Lindwurm.md "Lindwurm") that used to be the sealing place of the [Diablos](Aurora.md "Aurora")' left arm, even many of their member have been killed, including two [Rounds](Mordred.md "Mordred") member, leaving 3 vacant seats position in the Rounds.

With the release of the demon's left arm, the Cult was beginning to run out of Beads of Diablos that would grant immortality to the "Knights of Rounds", which made this intolerable and the Cult "Rounds" members desperation grow increased thus they were in a great hurry to revive Diablos' other body parts. Hence, they sent out aid to assist [Fenrir](Fenrir.md "Fenrir"), who was not present at the meeting with the mission to revive Diablos' right arm that was kept in the [Sanctuary](Sanctuary.md "Sanctuary") at the Midgar Academy, to resupply the Tears and needed to decide on whether or not the 3 vacant seats would be occupied, considering how many drops to be expectedly produced this year.

As a result, the number of drops has decreased even further with the amount produced not as much as in previous years, which is estimated to be around maybe nine to eight drops. [Loki](Loki.md "Loki"), another Rounds seat member and hostile to Fenrir ignite their fellow Rounds by reminding them about the repeated failure of Fenrir and his faction which already become the problem for the Cult and make a decision that Fenrir will not take any of the Tears until his mission for reviving the right arm is success, which make an approval decision on Loki suggestion.

In the end, the Cult decided to stop factional strife and are now united for the first time in centuries in order to eliminate the threat from Shadow Garden until the remaining Knights of Rounds began to step in as they start to mobilize all of the organization's power into full force in response to Shadow Garden's harmful exploits against the Cult of Diablos whose actions will force the existence of their organization which had been hidden during its founding to rise to the surface and become known to the eyes of the world, even the Cult tried to set up an "operation" to eliminate Shadow with Loki as its leader as Shadow is considered their greatest threat due to his unreasonable strength.

As a result of the council's decision, Petos is appointed as the Cult's representative envoy to meet with Fenrir at Midgar Academy and inform him of all decision that had been made by the Rounds in the meeting at the Round Table, while bringing the latest artifacts developed in the Cult's laboratory that would be useful to help Fenrir's mission in speeding up the releasing process of Diablos' right arm in the [Sanctuary](Sanctuary.md "Sanctuary") and secretly wanted to confirm to [Fenrir](Fenrir.md "Fenrir") whether [a certain Therianthrope girl](Zeta.md "Zeta") was there.

## Volume 5

### The Academy Disappearances
