# Delta/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Delta/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Delta/Chronology)

[Main](Delta.md "Delta")

[Relationships](Delta-Relationships.md "Delta/Relationships")

Image Gallery

### Early Childhood

Delta was once a Wolf therianthrope girl named Sarah who was recognized to be the strongest daughter of the chieftain of her tribe. Because her father had about twenty concubines, she had over a hundred half siblings. If she wasn't born a girl, her father would have given her the position of the next chieftain. Upon learning that she had Possession, Sara's father attempted to kill her, but she successfully hid and escaped. When her body reached its limit, feeling powerless by the [Possession](Possession.md "Possession"), Sara was found by [Alpha](Alpha.md "Alpha") and Shadow, she immediately attacked Alpha, even in her weakened state, without even hearing her. But when Sara saw Shadow, she instinctively submitted when she realized how powerful and dangerous he was. Shadow offered to heal her and give her a home, to which Sara readily accepted seeing Shadow and Alpha as her new pack leaders, and Shadow named her Delta soon after.

### Assault on Viscount Grease

Delta and the Seven Shadows assaulted the hideout of [Viscount Grease](Grease.md "Grease") in order to rescue Claire Kagenou, and Delta joined her sisters as they killed all the guards under the Viscount's command. After Shadow eliminated Grease, they rescued Claire and return home, but had her escape on her own to hide their involvement at the time. Delta would leave with the Seven Shadows to hunt down the Order of Diabolos, spending a couple of ensuing years building Shadow Garden's network.

### Kidnapping of Princess Alexia

After Princess Alexia Midgard was kidnapped by the Order of Diabolos, [Alpha](Alpha.md "Alpha") orders Shadow Garden members stationed in the kingdom, including Delta to attack all known hideouts of their enemies. At one of these locations, Delta savagely slew all the cult members.

### Holy Ground Infiltration

Delta was part of Alpha's group in infiltrating the Holy Ground. She then battle Nelson who uses his powers to send an army of clones of himself to finish off Shadow Garden but the therianthrope easily slaughtered many of them. Delta later escapes with her team before Cid destroys the Holy Ground.

### Mitsugoshi Co vs Major Cooperate Alliance

Ordered by Shadow Garden, Delta had out to eliminate targets from the Major Cooperate Alliance who had tried to sabotage Mitsugoshi Co. During one of these missions, Delta reunites with Cid and excitedly hugs him to his dismay. Cid, who is in undercover as John Smith, orders Delta to withheld information of this meeting which she complies. The two work together in eliminating assassins with one of them being her older brother, Ole.

In her second meeting with her master, Cid orders her to help eliminate Juggernaut of the Black Tower. She succeeds, presumably cutting off his head and returns to Shadow Garden who were ecstatic to see her, believing that she had been killed. After the Great Commerce Alliance fell and Mitsugoshi Co., Delta was last seen helping Cid dig through the snow. Delta discovers something but Cid left before she could tell him.

## Volume 5

### The Academy Disappearances

## Volume 6

## References
