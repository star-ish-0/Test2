# Andy

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Andy](https://the-eminence-in-shadow.fandom.com/wiki/Andy)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Andy?action=edit).

## Andy

### Japanese

アンディ

### Romaji

Andi

## Characteristics

### Race

Siberian husky (Dog)

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Unknown

## Professional Information

### Occupation

Pet

## Debut

### Manga

Chapter 71.2

Andy (アンディ, Andi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a Siberian husky owned by the neighbors of Minoru Kageno, Cid Kagenou's previous life on [Earth](Earth.md "Earth").

## Appearance

Andy was a normal Siberian husky.

## Chronology

Before reincarnating, belonged to Minoru's neighbors.

## Relationships

## Trivia

## References
