# Anime

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Anime](https://the-eminence-in-shadow.fandom.com/wiki/Anime)

## Anime

- Season 1
- Season 2
- Movie

### English

The Eminence in Shadow

### Kana

陰の実力者になりたくて!

### Rōmaji

Kage no Jitsuryokusha ni Naritakute!

## Production

### Original Story

Daisuke Aizawa

### Original Design

Touzai

### Studio

[Nexus](https://en.wikipedia.org/wiki/Nexus_(animation_studio) "wp:Nexus (animation studio)")

### Direction

Kazuya Nakanishi

### Air Date

October 5, 2022 (Season 1)
October 4, 2023 (Season 2)

### Episodes

20 (Season 1)
12 (Season 2)

### Streaming

[Disney+](https://www.disneyplus.com/series/the-eminence-in-shadow/5I6JkWfEmf0M)
[HIDIVE](https://www.hidive.com/tv/the-eminence-in-shadow)
[Hulu](https://www.hulu.com/series/the-eminence-in-shadow)
[Prime Video](https://www.amazon.com/gp/video/detail/B0B6QPRY13/)
[Roku](https://therokuchannel.roku.com/details/6d10d8678faa5b89a306978abf5aa85e/the-eminence-in-shadow)

The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the anime adaptation of Daisuke Aizawa's light novel series illustrated by Touzai. The series is produced by [Nexus](https://en.wikipedia.org/wiki/Nexus_(animation_studio) "wp:Nexus (animation studio)") and directed by Kazuya Nakanishi. It premiered on AT-X and other Japanese networks, with international streaming available on HIDIVE in select territories, while also being distributed through Disney+, Hulu, Prime Video, and Roku in various regions.

The first season ran for 20 episodes, airing from October 5, 2022 to February 15, 2023. A second season was announced on February 22, 2023,[[1]](#cite_note-1) which aired for twelve episodes from October 4, 2023 to December 20, 2023.

In December 2023, an anime film titled The Eminence in Shadow: Lost Echoes (陰の実力者になりたくて！残響編, Kage no Jitsuryokusha ni Naritakute! Zankyōhen[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was announced to be in production.[[2]](#cite_note-2)

## Synopsis

- [Season 1](#)
- [Season 2](#)

- [English](#)
- [Japanese](#)

Great heroes and diabolical villains are the types of characters that people long to be—but not Cid Kagenou. He longs to become the true mastermind behind it all, pulling the strings, and having his machinations drive the entire story. In his previous life in modern-day Tokyo, Japan, he was not able to achieve his goals. But now, his ambitious and restless mind/spirit has been reborn into an era of magic, he will show the one true Eminence in Shadow!
As Cid pretends to be just another average mob character, he recruits members to his magical organization dubbed "Shadow Garden," aiming to take down the mysterious cult who lurks in the shadows. With plenty of ad-lib, Cid leads his organization against the foul, yet surprisingly very real, Cult of the Demon Diabolos.

「陰の実力者」

それは、主人公でも、ラスボスでもない。
普段は実力を隠してモブに徹し、物語に陰ながら介入して密かに実力を示す存在。
この「陰の実力者」に憧れ、日々モブとして目立たず生活しながら、
力を求めて修業していた少年は、事故で命を失い、異世界に転生した。

シド・カゲノーとして生まれ変わった少年は、
これを幸いと異世界で「陰の実力者」設定を楽しむことにする。
「妄想」で作り上げた「闇の教団」を倒すべく（おふざけで）暗躍していたところ、
どうやら本当に、その「闇の教団」が存在していて……？
ノリで配下にした少女たちは勘違いからシドをシャドウとして崇拝し、
シドは本人も知らぬところで本物の「陰の実力者」になっていき、

そしてシドが率いる陰の組織「シャドウガーデン」は、やがて世界の闇を滅ぼしていく――。[[3]](#cite_note-3)

- [English](#)
- [Japanese](#)

Everything has been going according to plan, but the hour of awakening draws near. Cid Kagenou and Shadow Garden investigate the Lawless City, a cesspool where the red moon hangs low in the sky and three powerful monarchs rule the streets. The true draw for Cid, however, is one who can draw blood–the Blood Queen, a vampire who has slumbered in her coffin for eons. Her awakening approaches, and Cid could finally face a day of reckoning.

「陰の実力者」に憧れた少年は、
道半ばで命を失い、シド・カゲノーとして
異世界に転生した。

新たな世界で「陰の実力者」設定を
楽しむことにしたシドは、
陰に潜み、陰を狩る者――シャドウを演じ、
付き合いのいい配下の少女たちと
闇の教団に対抗する
「シャドウガーデン」を組織する。

すべては妄想の産物……そのはずだった。
ところが世界の闇たる
「ディアボロス教団」は実在し、
シドの知らぬところで「シャドウガーデン」は
教団との抗争を繰り広げていた。

次なる舞台は「血の女王」「妖狐」「暴君」の
三勢力が統治する無法都市。
そこは、ならず者がはびこる弱肉強食の
世界だった。

吸血鬼たちの支配者「血の女王」の討伐のため、
姉のクレアに連行されてきたシドは、
またとない「陰の実力者」ムーブの機会に
心を躍らせるのだが……。

「血の女王」を巡る陰謀が動き出し、
無法都市は三つの勢力が入り乱れる。
さらに姉のクレアも騒乱に巻き込まれ、
シャドウガーデンも独自に行動。
混沌を極める中、シドは人知れずシャドウとして
暗躍しようとする。

赤き月は昇り、覚醒の刻は来た――！[[4]](#cite_note-4)

## Differences Between Media

The first season of the anime covers the first two novel volumes; however, many things are left out while others are added. In general, most of these changes were made for aesthetic and dramatic purposes, while they have tried to respect the narrative of the work.

### Examples

1. The light novel presents a traditional medieval fantasy world with swords and magic. The anime shifts this to a late-medieval setting with Industrial Revolution elements, where the Cult of Diablos maintains hidden advanced technology and Shadow Garden utilizes scientific knowledge from Cid Kagenou's modern Earth experiences.
2. The first season finale expands the battle between Cid, as the ever infinitely powerful and equally dangerous Lord Shadow, the levelheaded elfin warrior [Lady Beatrix the War Goddess](Beatrix.md "Beatrix") and Princess Iris Midgar, to span the entire city. The anime adaptation omits Lord Shadow's warnings about the unpredictable nature of the Cult of Diablos.

These facts do not alter the general narrative of the story since they only seek to increase the dramatic factor in the anime.

## Episodes

- [Season 1](#)
- [Season 2](#)

| Episode # | Image | Title | Air Date |
| --- | --- | --- | --- |
| 01 |  | The Hated Classmate (嫌いなクラスメイト, Kirai na Kurasumeito) | October 5, 2022  December 26, 2022 |
| 02 |  | Shadow Garden is Born (結成シャドウガーデン, Kessei Shadō Gāden) | October 12, 2022  January 2, 2023 |
| 03 |  | Fencing Ordinaire (凡人の剣, Bonjin no Ken) | October 19, 2022  January 9, 2023 |
| 04 |  | Sadism's Rewards (加虐への報酬, Kagyaku e no Hōshū) | October 26, 2022  January 16, 2023 |
| 05 |  | I Am... (アイ・アム......, Ai amu...) | November 2, 2022  January 23, 2023 |
| 06 |  | Pretenders (偽る者, Itsuwaru Mono) | November 9, 2022  January 30, 2023 |
| 07 |  | A Fencing Tournament of Intrigue & Bloodshed (謀略と流血の剣術大会, Bōryaku to Ryūketsu no Kenjutsu Taikai) | November 16, 2022  February 6, 2023 |
| 08 |  | Dark Knight Academy Under Attack (狙われた魔剣士学園, Nerawareta Makenshi Gakuen) | November 23, 2022  February 13, 2023 |
| 09 |  | The End of a Lie (偽りの果て, Itsuwari no Hate) | November 30, 2022  February 20, 2023 |
| 10 |  | The Sacred Land, City of Deception (聖地・欺瞞の都, Seichi: Giman no Miyako) | December 7, 2022  February 27, 2023 |
| 11 |  | The Goddess' Trial (女神の試練, Megami no Shiren) | December 14, 2022  March 6, 2023 |
| 12 |  | The Truth Within the Memories (記憶の中の真実, Kioku no Naka no Shinjitsu) | December 21, 2022  March 13, 2023 |
| 13 |  | A Bloody Showdown as an Offering to Annihilation (消滅に捧げる血闘, Shōmetsu ni Sasageru Kettō) | December 28, 2022  March 20, 2023 |
| 14 |  | Your Lie, Your Wish (君の嘘、 君の願い, Kimi no Uso, Kimi no Negai) | January 4, 2023  March 27, 2023 |
| 15 |  | The Strongest Weakest Man (最強最弱の男, Saikyō Saijaku no Otoko) | January 11, 2023  April 3, 2023 |
| 16 |  | Unseen Intentions (見えざる真意, Miezaru Shin'i) | January 18, 2023  April 10, 2023 |
| 17 |  | Moonlight That Pierces the Darkness (闇に射す月光, Yami ni Sasu Gekkō) | January 25, 2023  April 17, 2023 |
| 18 |  | Betting on a Moment (刹那に賭ける, Setsuna ni Kakeru) | February 1, 2023  April 24, 2023 |
| 19 |  | Dancing Puppet (踊る人形, Odoru Ningyō) | February 8, 2023  May 1, 2023 |
| 20 |  | Advent of the Demon (魔人降臨, Majin Kōrin) | February 15, 2023  May 8, 2023 |

| Episode # | Image | Title | Air Date |
| --- | --- | --- | --- |
| 21 |  | The Lawless City (無法都市, Muhō Toshi) | October 4, 2023  October 4, 2023 |
| 22 |  | The Haven (安息の地, Ansoku no Chi) | October 11, 2023  October 11, 2023 |
| 23 |  | The Hour of Awakening (覚醒の刻, Kakusei no Toki) | October 18, 2023  October 18, 2023 |
| 24 |  | Mask of Falsehood (偽りの仮面, Itsuwari no Kamen) | October 25, 2023  October 25, 2023 |
| 25 |  | He Who Pulls the Strings (糸を引く者, Ito o hiku mono) | November 1, 2023  November 1, 2023 |
| 26 |  | John Smith (ジョン・スミス, Jon Sumisu) | November 8, 2023  November 8, 2023 |
| 27 |  | Something Precious (大切なもの, Taisetsu na mono) | November 15, 2023  November 15, 2023 |
| 28 |  | The Dragon's Tears (龍の涙, Ryū no Namida) | November 22, 2023  November 22, 2023 |
| 29 |  | The Key (鍵, Kagi) | November 29, 2023  November 29, 2023 |
| 30 |  | Caged Bird (籠の鳥, Kago no Tori) | December 6, 2023  December 6, 2023 |
| 31 |  | Determination (決断, Ketsudan) | December 13, 2023  December 13, 2023 |
| 32 |  | HIGHEST | December 20, 2023  December 20, 2023 |

## Staff

- Original Creator: Daisuke Aizawa
- Original Character Design: Touzai
- Director: Kazuya Nakanishi
- Series Composition: Kanichi Katou
- Character Design: Makoto Iino
- Animation Production: Nexus
- Music Composition: Kenichiro Suehiro

## Cast

| Character | Japanese VA | English VA |
| --- | --- | --- |
| Cid Kagenou | [Seiichirō Yamashita](https://en.wikipedia.org/wiki/Seiichir%C5%8D_Yamashita "wp:Seiichirō Yamashita") | [Adam Gibbs](https://en.wikipedia.org/wiki/Adam_Gibbs "wp:Adam Gibbs") |
| Iris Midgar | [Yoko Hikasa](https://en.wikipedia.org/wiki/Yoko_Hikasa "wp:Yoko Hikasa") | Patricia Duran |
| Alexia Midgar | [Kana Hanazawa](https://en.wikipedia.org/wiki/Kana_Hanazawa "wp:Kana Hanazawa") | Olivia Swasey |
| [Alpha](Alpha.md "Alpha") | [Asami Seto](https://en.wikipedia.org/wiki/Asami_Seto "wp:Asami Seto") | [Christina Kelly](https://en.wikipedia.org/wiki/Christina_Kelly "wp:Christina Kelly") |
| [Beta](Beta.md "Beta") | [Inori Minase](https://en.wikipedia.org/wiki/Inori_Minase "wp:Inori Minase") | Annie Wild |
| [Gamma](Gamma.md "Gamma") | [Suzuko Mimori](https://en.wikipedia.org/wiki/Suzuko_Mimori "wp:Suzuko Mimori") | Elissa Cuellar |
| [Delta](Delta.md "Delta") | [Fairouz Ai](https://en.wikipedia.org/wiki/Fairouz_Ai "wp:Fairouz Ai") | Raven Troup |
| [Epsilon](Epsilon.md "Epsilon") | [Hisako Kanemoto](https://en.wikipedia.org/wiki/Hisako_Kanemoto "wp:Hisako Kanemoto") | Ellen Evans |
| [Zeta](Zeta.md "Zeta") | [Ayaka Asai](https://en.wikipedia.org/wiki/Ayaka_Asai "wp:Ayaka Asai") | Dominique Meyer |
| [Eta](Eta.md "Eta") | [Reina Kondō](https://en.wikipedia.org/wiki/Reina_Kond%C5%8D "wp:Reina Kondō") | Genevieve Simmons |
| Claire Kagenou | [Rina Hidaka](https://en.wikipedia.org/wiki/Rina_Hidaka "wp:Rina Hidaka") | [Luci Christian](https://en.wikipedia.org/wiki/Luci_Christian "wp:Luci Christian") |
| Rose Oriana | [Haruka Shiraishi](https://en.wikipedia.org/wiki/Haruka_Shiraishi "wp:Haruka Shiraishi") | Donna Bella Litton |
| Sherry Barnett | [Saya Aizawa](https://en.wikipedia.org/wiki/Saya_Aizawa "wp:Saya Aizawa") | [Brittney Karbowski](https://en.wikipedia.org/wiki/Brittney_Karbowski "wp:Brittney Karbowski") |
| Akane Nishino | [Yui Horie](https://en.wikipedia.org/wiki/Yui_Horie "wp:Yui Horie") | [Natalie Rial](https://en.wikipedia.org/wiki/Natalie_Rial "wp:Natalie Rial") |
| [Juggernaut](Juggernaut.md "Juggernaut") | [Tsuyoshi Koyama](https://en.wikipedia.org/wiki/Tsuyoshi_Koyama "wp:Tsuyoshi Koyama") | Luis Galindo |
| [Yukime](Yukime.md "Yukime") | [Shizuka Itō](https://en.wikipedia.org/wiki/Shizuka_It%C5%8D "wp:Shizuka Itō") | Courtney Lomelo |
| [Crimson](Crimson.md "Crimson") | [Tomokazu Sugita](https://en.wikipedia.org/wiki/Tomokazu_Sugita "wp:Tomokazu Sugita") | Dickie Sanders |
| [Mary](Mary.md "Mary") | [Ai Kakuma](https://en.wikipedia.org/wiki/Ai_Kakuma "wp:Ai Kakuma") | Katelyn Barr |

## Promotional Material

- [Promotional Images](#)
- [Character Designs](#)

Key Visual 1

Key Visual 1 (textless)

Key Visual 2 (JP)

Key Visual 2 (textless)

Key Visual 2 (EN)

Key Visual 3

Key Visual 4

Season 2 Key Visual 1 (JP)

Season 2 Key Visual 1 (EN)

Season 2 Key Visual 1 (textless)

Season 2 Key Visual 2

Season 2 Key Visual 2 (textless)

Season 2 Key Visual 3

Season 2 Key Visual 3 (textless)

Lost Echoes Movie Key Visual (JP)

Lost Echoes Movie Key Visual 2 (JP)

Cid Kagenou

Shadow

Iris Midgar

Alexia Midgar

[Alpha](Alpha.md "Alpha")

[Beta](Beta.md "Beta")

[Gamma](Gamma.md "Gamma")

[Delta](Delta.md "Delta")

[Epsilon](Epsilon.md "Epsilon")

[Zeta](Zeta.md "Zeta")

[Eta](Eta.md "Eta")

Claire Kagenou

Rose Oriana

Sherry Barnett

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』特報 2022年放送開始！

Season 1 PV #1

TVアニメ『陰の実力者になりたくて！』PV第2弾≪2022年10月放送開始！≫

Season 1 PV #2

TVアニメ『陰の実力者になりたくて！』第３弾PV≪2022年10月5日（水）放送開始！≫

Season 1 PV #3

TVアニメ『陰の実力者になりたくて！』キャラPV「アルファ編」≪2022年10月放送開始！≫

Character PV "Alpha Version"

TVアニメ『陰の実力者になりたくて！』キャラPV「ベータ／ガンマ編」≪2022年10月放送開始！≫

Character PV "Beta/Gamma Version"

TVアニメ『陰の実力者になりたくて！』キャラPV「デルタ／イプシロン／ゼータ／イータ編」≪2022年10月放送開始！≫

Character PV "Delta/Epsilon/Zeta/Eta Version"

TVアニメ『陰の実力者になりたくて！』番組CM≪2022年10月5日（水）放送開始！≫

Season 1 TV Commercial

TVアニメ「陰の実力者になりたくて！ 2nd season」特報 【第2期制作決定】

Season 2 PV #1

TVアニメ「陰の実力者になりたくて！ 2nd season」PV第2弾 【2023年10月放送開始】

Season 2 PV #2

TVアニメ「陰の実力者になりたくて！ 2nd season」PV第3弾 【10月4日(水)放送開始】

Season 2 PV #3

「劇場版 陰の実力者になりたくて！ 残響編」特報

Movie PV #1

『劇場版 陰の実力者になりたくて！ 残響編』特報第2弾｜2027 ROADSHOW

Movie PV #2

## External Links

- [Official Website](https://shadow-garden.jp)
- [Official Twitter account](https://twitter.com/Shadowgarden_PR)
- [Season 1](https://www.hidive.com/tv/the-eminence-in-shadow) and [Season 2](https://www.hidive.com/tv/the-eminence-in-shadow-2nd-season) on HIDIVE

## Trivia

## References

1. [Shadow Garden PR Announcement from February 22, 2023](https://twitter.com/Shadowgarden_PR/status/1628364145862254597)
2. [Shadow Garden PR Announcement from December 20, 2023](https://twitter.com/Shadowgarden_PR/status/1737488274640257499)
3. <https://shadow-garden.jp/1st/story/#intro>
4. <https://shadow-garden.jp/story/#intro>
