# Light Novel/Volume 7

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%207](https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%207)

## Light Novel Volume 7

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Touzai

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4047382909

### ISBN EN

ISBN 979-8855447224

### Release Date

April 1, 2026 JP
March 9, 2027 EN

## Volume Information

### Pages

344 JP
352 EN

## Adaptations

### Manga

Chapter 79.2 - Ongoing

Publication Order

| Previous |
| --- |
| Volume 6 |

This is the seventh volume of the light novel series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). The cover features Lalanoa Hinoizumino (left) and Tokiseiryuno Sakura (right).

## Synopsis

- [English](#)
- [Japanese](#)

A succession battle for the throne is underway in the elf country following the sudden and suspicious death of their king Anolion. Several competing factions nominate their greatest fighters to represent their candidates, and among them are some familiar faces: Beatrix the Sword Saint and even Shadow Garden’s own Alpha, who has assumed a masculine disguise. And she’s not the only one—Cid adopts a new shadowbroker role of the wise, mysterious teacher to a young elf girl who is desperate to stake her claim as the next elven monarch! [[1]](#cite_note-1)

「これより教える剣は血生臭い暗殺剣」　シリーズ累計650万部突破!!

『シャドウガーデン』を率いる七陰の第一席アルファ――
彼女の故郷・エルフの国の王が急死し、次代の王を決める王位継承戦の開催が決定する。

エルフの剣聖・ベアトリクスを筆頭に牙を研ぐ強者たち。
暗躍する『三大派閥』。

その裏に『ディアボロス教団』の影を察知したアルファは偽りの身分にて自らも王位継承戦の渦中に飛び込んでいく……。

なんてことは深く気にせず、エルフの少女に弟子入りを志願されたシドは“師匠ポジション”という『陰の実力者』の新たな境地に立って王位継承戦に殴り込み!!

※画像は表紙及び帯等、実際とは異なる場合があります。[[2]](#cite_note-2)

## Summary

## Chapters

- Prologue: Spring is the Season for Departures!
- Chapter 1: My Name is Nazono Seinen!
- Chapter 2: This Time, They Won't See Through My Disguise!
- Chapter 3: Preparing for the War of Succession!
- Chapter 4: Lurking in the Shadows at the Eve-of-Festival!
- Chapter 5: The War of Succession Begins!
- Chapter 6: If My Old Wounds Hadn't Ached, I'd Be Dead!?
- Epilogue: Witness the Perfect Plan, Refined and Matured Through Constant Improvement!
- Appendix
- Afterword
- Profile

## Characters

:   In order of appearance:

- Cid Kagenou
- Lalanoa Hinoizumino (Debut)
- [Ryuu](Ryuu.md "Ryuu") (Debut)
- King Anorion (Mentioned)
- [Salaman](Salaman.md "Salaman") (Debut)
- [Otoutrion](Otoutrion.md "Otoutrion") (Debut)
- [Beatrix](Beatrix.md "Beatrix")
- Tokiseiryuno Sakura (Debut)
- [Alpha](Alpha.md "Alpha")
- Ainoa Hinoizumino (Mentioned)
- [Beta](Beta.md "Beta")
- [Epsilon](Epsilon.md "Epsilon")
- [Eta](Eta.md "Eta")
- [89](89.md "89") (Debut)
- [Gendou](Gendou.md "Gendou") (Debut)
- [Ashgrey](Ashgrey.md "Ashgrey") (Debut)
- Sword God (Debut)
- [Secondary](Secondary.md "Secondary") (Debut)
- [Sakisa](Sakisa.md "Sakisa") (Debut)
- [Koban](Koban.md "Koban") (Debut)
- [Shinji](Shinji.md "Shinji") (Debut)

## Illustrations

- [English](#)
- [Japanese](#)

## References

1. [Yen Press. The Eminence in Shadow, Vol. 7 (light novel) (EN)](https://yenpress.com/titles/9798855447224-the-eminence-in-shadow-vol-7-light-novel/)
2. [Kadokawa. The Eminence in Shadow 07 (JP)](https://www.kadokawa.co.jp/product/322410001721/)

## Trivia

- This is the first volume cover not to feature Cid or any of his guises on the volume cover.

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • **Volume 7** | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
