# Lambda/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lambda/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Lambda/Chronology)

[Main](Lambda.md "Lambda")

[Relationships](Lambda-Relationships.md "Lambda/Relationships")

Image Gallery

## Background

### Recruitment

Lambda was once part of the military of Velgalta Empire, and served as a solider named Zinaida. She constantly faced death repeatedly alongside her comrades, many of whom were killed on the battlefield. Zinaida was lucky to escape with the only injury on her right eye.

After the symptoms of the [possessed](Possession.md "Possession"), she is captured by the Cult and taken to a hidden facility as their prisoner. Meanwhile, the Seven Shadows attacked the facility and found her as the only surviving captive. [Epsilon](Epsilon.md "Epsilon") then cured Zinaida by healing her until she was restored to her original, true form. Following this rescue and the revelation of the truth of the Cult of Diablos, she joined Shadow Garden and subsequently earned her the rank No. 11 and became one of the Numbers as she would identify herself as Lambda.

### Searching for a New Base

When Shadow Garden still had a small membership, Lambda trained the new recruits due to her background in the Velgaltan military. But as their small village grew in population, training space became an issue expressed by Lambda and the Seven Shadows.

When the Seven Shadows sought a new location for a secret headquarters, Lambda was among the chain of command to search and gather members who are at least adequately trained. As [Delta](Delta.md "Delta") and [Zeta](Zeta.md "Zeta") went ahead to find the source of the barrier from the Abyss Wood, [Alpha](Alpha.md "Alpha") ordered Lambda's company to retreat and relay the situation to Shadow if there was no news within three days, while the Seven Shadows would conduct an investigation.

When her master defeated the Mist Dragon that guarded the Midgar Kingdom's ancient capital of Alexandria, Lambda was ecstatic as the others in Shadow Garden to have more space and living quarters for the membership.

## Volume 2

### Bushin Festival Tournament

After the Bushin Festival, Alpha brought Rose Oriana to the secret city of [Alexandria](Alexandria.md "Alexandria"), the hidden headquarters of Shadow Garden. Ignorant to her true identity, Lambda carried out Alpha's orders to train Rose and renamed her to Number 666 and assigned her to partner with [664](664.md "664") and [665](665.md "665") as a new team. Lambda then carried out her instructing No. 666 as she did with all other members in Shadow Garden.[[1]](#cite_note-V2F-1)

## Volume 6

## References

1. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
