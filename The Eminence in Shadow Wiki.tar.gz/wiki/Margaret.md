# Margaret

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Margaret](https://the-eminence-in-shadow.fandom.com/wiki/Margaret)

[Chronology](Margaret-Chronology.md "Margaret/Chronology")

[Relationships](Margaret-Relationships.md "Margaret/Relationships")

Image Gallery

## Margaret

### Japanese

マーガレット

### Romaji

Māgaretto

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

June 21

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Maid

### Affiliation

Oriana Kingdom

## Debut

### Light Novel

Volume 4

### Manga

Chapter 42

### Anime

Episode 30

## Portrayal

### Japanese

[Reina Ueda](https://en.wikipedia.org/wiki/Reina_Ueda "wp:Reina Ueda")

### French

Isabelle Volpe

### Italian

[Jenny De Cesarei](https://en.wikipedia.org/wiki/it:Jenny_De_Cesarei "wp:it:Jenny De Cesarei")

Margaret (マーガレット, Māgaretto[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a servant of the royal family of Oriana Kingdom and acted as Rose Oriana's personal maid.

## Appearance

Margaret is a beautiful young woman with long rose-madder hair. Her coiffure is a ponytail, pulled back to keep waist-length hair controlled. The maid's curvaceous hips and voluptuous breasts challenge even [Epsilon](Epsilon.md "Epsilon")'s manufactured figure.

As a royal family servant, Margaret's attire is comparable to a Victorian-style maid uniform. These outfits were of a black-and-white color scheme, commonly with a corset underneath a shirt or corset cover. A bodice and apron were layered on top of the shirt, accompanied by a long pleated or circle skirt. At Princess Rose's wedding, she wore an elegant outfit with a long skirt and a flower-decorated headband.

## Personality

Margaret is a kindhearted and compassionate young woman who she enjoys her friendship with Rose. However, Margaret is an opportunist who would beguile anyone if it could assist in elevating her family's status. She was also incredibly gullible.

As a maid, Margaret is level-headed who carries out duties flawlessly on doing her job.

## Powers & Abilities

Margaret is an average civilian of society. She has no special power or ability. The only talent she has demonstrated is the knowledge of knots.

## Trivia

## References

## Site Navigation
