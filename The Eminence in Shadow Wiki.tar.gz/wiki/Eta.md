# Eta

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Eta](https://the-eminence-in-shadow.fandom.com/wiki/Eta)

[Chronology](Eta-Chronology.md "Eta/Chronology")

[Relationships](Eta-Relationships.md "Eta/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | “Time is money. I have an obligation to prevent opportunity costs caused by stupid decisions | ” |
| — Eta, Light Novel Volume 06 | | |

## Eta

- Light Novel
- Manga
- Anime
- Game

### Japanese

イータ

### Romaji

Īta

### Aliases

Eta Lloyd Wright (Public Identity)

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

15 Volume 1
17 (Currently)

### Height

Unknown

### Hair Color

Brown

### Eye Color

Purple

### Birthday

November 10

## Personal Information

### Status

Alive

## Professional Information

### Occupation

- 7th Seat of the Seven Shadows
- Shadow Garden's Head Research Division
- Head of Mitsugoshi Research and Development

### Affiliation

Shadow Garden

## Debut

### Web Novel

Chapter 111 (Mentioned)

### Light Novel

Volume 3 (Mentioned)
Volume 5 (Full Appearance)

### Manga

Chapter 62

### Anime

Episode 1

### Game

Chapter 1 - Episode 1

## Portrayal

### Japanese

[Reina Kondō](https://en.wikipedia.org/wiki/Reina_Kond%C5%8D "wp:Reina Kondō")

### English

[Genevieve Simmons](https://en.wikipedia.org/wiki/Genevieve_Simmons "wp:Genevieve Simmons")

### Italian

Giada Bonanomi

### German

Eileen Fuhrmann

Eta (イータ, Īta[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Ήτα) is the eighth initial member of Shadow Garden and the seventh seat of the Seven Shadows. As Shadow Garden's chief engineer, she accelerated the Other World's industrial revolution by reverse-engineering technologies from [Earth](Earth.md "Earth") through vague descriptions from Cid.[[1]](#cite_note-V5C3-1) Her public identity is Eta Lloyd Wright, a highly regarded innovator who won Architect of the Year.[WEB NOVEL ONLY][[2]](#cite_note-WN200-2)

## Appearance

Eta is a female elf with long puce hair and unkempt bangs above bleary, purple eyes. She frequently presents a bedraggled appearance, a consequence of her slothful activities. A faded, traditional white lab coat over slime clothes stylized in a pleated dress pattern with a black wispy represents Eta's usual outfit for work and sleep.

Outside her work clothes, Eta styles the customary slime bodysuit like a double-slitted keyhole dress, hemmed at the upper thighs and dressed over a lighter bodysuit. The oversized sleeves and long endings tapering to ragged edges make the accompanying loose-fitting jacket look like a cloak. Various frills and minor decorations adorn the jacket. A loose belt dangles off the back of her coat, offering a tail-like appearance.

Eta has a garter on each leg for dark stockings and two decorative belts around her thighs. The position changes based on the adaption—left in the light novel and right in the anime. Simplified black trousers, rather than stockings, cover her legs in the anime. They have riveted fins along the back, from the knee, down the back of her calf, ending at the ankle. Eta's footwear in the light novel are pumps while she wears wedges in the anime. A strip of gold trim around the vamp of the shoes are present in both adaptations.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Boo. Sacrifices have to be made in order to advance Shadow Wisdom. | ” |
| — Eta, Light Novel Volume 05 | | |

A quiet presence, Eta derives pleasure through indolent activities. She demonstrates lethargy and apathy, slowly conversing with others and moving sluggishly. Eta's raison d'être is the pursuit and development of Shadow Wisdom. Her manic devotion has helped the advancement of Shadow Garden, but it frequently manifests through petty defiance or unauthorized experimentation. Such antics can disrupt administrative efficiency or harm the physical well-being of others. Threats of reduced budgetary allocations modulate Eta's ethically dubious experiments and rebellious behavior; however, occasional quarrels still occur. The reasons for disobedience are presented as differences in ethics and methodology rather than administrative directives or malice towards her fellow sisters.[[1]](#cite_note-V5C3-1)[[3]](#cite_note-V6C5-3)

## Powers & Abilities

While constant lethargy causes Eta to generally abstain from direct combat, she is actually perfectly capable of standing her ground against her fellow Shadows through trickery, provided she has the energy and motivation. However, Eta's true strength lies in intellect, enabling her to reverse engineer modern Earth technologies from descriptions alone.

### Swordsmanship

Eta’s combat style revolves around overwhelming combatants with atypical attacks in standard fencing. By creating numerous slime spears and swords, she freely manipulates the weapons through magic. The numerical advantage and awkward angles help keep combatants occupied. Throwing the weapons likewise offers a decisive finisher move that showers the ground with swords.[GAME ONLY] Aggressive tactics can limit defense, as counterattacks are limited. Rather than parrying, her defense comes from slime shields that deflect and mitigate incoming damage.[[3]](#cite_note-V6C5-3)

### Magic

Slime Bodysuits require conscious magical control to be shaped upon the user. Eta magically induced telekinesis to control and create various weapons out of slime.

### Physical Capabilities

Limited by her fatigue, Eta's speed is typically sluggish. She regularly dozes off, not bothered by surrounding noise. A heavy sleeper, rousing her can take considerable physical stimulation. Sometimes, walking presents too much of an obstacle and members of Shadow Garden wheel her around for management on various projects.[ANIME ONLY] For moments of increased energy, her attacks may not be refined like a trained combatant, but they can present an obstacle to opposing parties.[[3]](#cite_note-V6C5-3)

### Intelligence

An engineer, architect, and scientist in one mind, Eta's ability is predominantly responsible for creating Shadow Garden's technology and Mitsugoshi Company's products. Her research into Shadow Wisdom has successfully reversed engineered many of modern Earth innovations and inventions merely through Cid's offhand remarks or pilfered items from Earth. She has demonstrated a practical understanding of mechanical engineering, chemistry, physics, and biology through such creations as steam engines, industrial textile production, pile foundations, and human anatomy.[[1]](#cite_note-V5C3-1)[[4]](#cite_note-V3P-4)[[5]](#cite_note-V1C2-5)[[6]](#cite_note-V1C4-6) Cryptanalysis is another area in which Eta has shown competency; translating kanji, hiragana, katakana, and romaji into the local language of the Midgar Kingdom in mere days.[[7]](#cite_note-V3E-7) In the area of Linguistics, Eta also stands out, being able to read, write, and translate both ancient and modern languages of the other world, with Eta being at a higher level than any of the Seven Shadows and members of the Shadow Garden.[GAME ONLY] Outside of typical physical science, Eta has shown a mechanical understanding of magic and artifacts. Utilizing that knowledge, she has successfully made artifacts that visualize magic circuitry and devices that interfere with the functionality of magic.[[3]](#cite_note-V6C5-3)[[8]](#cite_note-V5C2-8)

### Weapons and Equipment

- Slime Weapons
- Slime Bodysuit

## Trivia

- Eta's alias shares surnames with American architect [Frank Lloyd Wright](https://en.wikipedia.org/wiki/Frank_Lloyd_Wright "wp:Frank Lloyd Wright").
- While in the light novel, manga, and web novel, Eta did not initially appear, (until a long time later)[CITATION NEEDED][[9]](#cite_note-9), she debuted in the first episodes of the anime and in the game.[[10]](#cite_note-10)
  - Both the participations, as well as the dialogues and other themes, that Eta has done in the [Anime](Anime.md "Anime") and the Game are exclusive until now, differing in part with the events narrated in the Light Novel, Web Novel, and [Manga](Manga.md "Manga").
- In an episode of [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu"), Eta demonstrated supernatural strength, being able to lift a 100-tonne hammer without any problem.[[11]](#cite_note-11)
- In the [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu") episode, Eta seems to inquire into [Epsilon](Epsilon.md "Epsilon")'s behavior when reference is made to her breasts.[[12]](#cite_note-12)
- Within the anime, Eta has demonstrated knowledge and mastery of [Morse code](https://en.wikipedia.org/wiki/Morse_code "wp:Morse code"), which, to date, is not mentioned in the light novel or web novel.[[13]](#cite_note-S1E20-13)
  - The telegram that Eta sends out during the season 1 finale spells out "To be continued" in Morse code.[[13]](#cite_note-S1E20-13)

## References

1. Volume 5 Chapter 3: The Case Is Closed, So, It’s Time for a Flashback!
2. Web Novel Chapter 200
3. Volume 6 Chapter 5: Welcome to the Shadow Garden!
4. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
5. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
6. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
7. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
8. Volume 5 Chapter 2: On a Shocking Morning, the School Murder Case!
9. [Manga](Manga.md "Manga") Chapter 62
10. Anime Season 1 Episode 1: The Hated Classmate
11. KAGE-JITSU! Operation 5: The Seven Shades Want to Create an Artifact!
12. KAGE-JITSU! Operation 16: The Seven Shades Want to Put on Amazing Underwear!
13. Anime Season 1 Episode 20: Advent of the Demon

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • **Eta** | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
