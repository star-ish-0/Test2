# Willow

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Willow](https://the-eminence-in-shadow.fandom.com/wiki/Willow)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Willow

### Japanese

細（さい）柳（りゅう）

### Romaji

Sairyū

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Around 70s

### Height

Unknown

### Hair Color

Gray

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Unnamed Wife †

## Professional Information

### Occupation

- Head Librarian of Midgar Academy for Dark Knights (undercover)

### Affiliation

Midgar Kingdom
Cult of Diablos

## Debut

### Light Novel

Volume 5

### Manga

Chapter 58

Willow (細（さい）柳（りゅう）, Sairyū[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the Head Librarian at Midgar Academy for Dark Knights and a member of the in the Cult of Diablos [Fenrir](Fenrir.md "Fenrir") Sect. Mirroring the death his former pupil, Zenon Griffey, he perished under Shadow's blade.

## Appearance

## Personality

## Chronology

### Early Life Before Becoming "Willow"

Willow was once a young swordsman in the Midgar Kingdom with a very high sense of justice and have a wife he loved very much. Fifty years ago, Willow won the Bushin Festival and joined the Knight Order because of his remarkable swordsmanship. During his tenure, Willow exposed injustice and arrested bad people, even corrupt priests in the Church, until he was promised a future career and then formed a group that had the same thoughts and principles as him.

At one point, Willow finds evidence of the injustice of an infestation in the kingdom, some of which lead to the Church and think that the priests are committing wrongdoings. Because his sense of justice is so strong, Willow decides to go to the Church along with his subordinates to try to investigate and collect convincing evidence of misdeeds in order to solve the case he is investigating and bring justice to the corrupt Church, where only a small portion of the dishonest high ranking priests among all the ordinary priests who have nothing to do with injustice, along with the congregation of religious followers.

Later that night, Willow leads his group in carefully monitoring the priests and discovers a secret room in the church basement. After descending the long stairs, Willow and his group found a terrible scene where they saw a number of people suffering from [Possession](Possession.md "Possession") symptoms as their bodies had turned rotten and some of them had been implanted with something unknown.

In the midst of confusion about a very surprising revelation, the group led by Willow turns out to have fallen into a trap when the secret door they entered had already closed. While defending himself with great concern, Willow was then blown away by the tremendous impact and rolled on the ground. By the time he wakes up, Willow witnesses the corpses of his men with their hands cut off and sees a magic swordsman standing in the middle of them. Knowing that his left arm could not be used, Willow gripped his sword with his remaining right arm and in a fit of rage slashed at the swordsman but in the end, Willow also lost his right arm after the swordsman slashed him with incredible force.

With both of his arms cut off, the swordsman approached Willow until he was unexpectedly surprised to find out that the swordsman's identity was [Fenrir](Fenrir.md "Fenrir"), who was the strongest magic swordsman known by the Midgar Kingdom and had made a name for himself throughout the world that should have lived for hundreds of years ago. At the same time, Fenrir brought an unconscious woman in front of him when Willow fainted and it turned out that the woman being held hostage was his own wife, and that's when Fenrir offered Willow to join a dark organization called the Cult of Diablos because his abilities would definitely be useful for the organization with Willow who was the winner of the Bushin Festival and the star of the Knight Order on the condition that his wife would not be harmed. Having no other choice in exchange for his beloved wife's life, he willingly decided to become a member of the Cult for the sake of her safety and discarded his real name until he adopted the title "Willow".[[1]](#cite_note-V5C2-1)

### Serving the Cult

After becoming a member, Willow's both hands that was previously severed were reattached with the help of Cult's technology, but he no longer moves his arms in the same way and cannot use a sword as often as before. Later, Willow obtained a red pill from the organization but did not take a single pill because he thought it was a disgrace for a swordsman.

During his time spent in a secretive organization, Willow understands how the Cult of Diablos' enormous power and influence they possessed which has ruled the world behind the scenes without the public knowing for thousands of years through their artificial religion, the Holy Church of Divine Teachings from the shadows.

Even knowing the secrets of the organization that Possession is something possessed by women who have the blood of the Three Heroes, it turns out that all three of them are women, different from what is said in the story that the Three Heroes are men. Plus, something that was implanted by the possessed sufferer when he first saw it was Diablos Cells, which can only be adapted to women.

It was at that moment that Willow learned the truth about the 2 true goals of the Cult of Diablos that had been working on; the first is to gain more power which the Cult was able to obtain through imperfect drugs by conducting experiments on possessed people who were implanted with Diablos cells, which were believed to have great potential until Willow understood the reason why the Cult continued to study the blood of heroes for so many years, for the sake of being able to develop a perfect medicine that has no side effects and if their experiments are successfully completed, then the Cult will have extraordinary power that surpasses even the heroes.

And Willow realized that the main reason why the Cult wanted to revive the Devil Diablos was to perfect eternal life by harvesting 'Beads of Diablos' in large quantities which initially had the drawback that Tears could stop aging for just one year, until it required taking an annual dose to maintain its effect and can only collect twelve drops per year which are produced at a minimum, each of which is taken by twelve selected members that constitute the Cult's leadership and Fenrir is one of those top executives called the "Knights of Rounds" who have life immortal in their hands and has continued to rule this world from the shadows.[[1]](#cite_note-V5C2-1)

### Prior Beginning of the Age of Upheaval

At an unspecified time, Willow infiltrated the Midgar Academy for Dark Knights, where he managed to become Head Librarian and continued to live his life as a Cult subordinate while looking after his wife until his beloved died a normal death without knowing anything about the incident that happened to both of them, much to Willow relief.

Even though there was no longer anything that could restrain him any longer, Willow no longer had the will to rebel, as that will had been severed along with both arms that day and realized that any action to resist was futile since learning how terrifying the Cult really is until Willow finally accepts the reality of serving loyally to the Cult for the rest of his life.

In his middle age, Willow mentored Zenon Griffey as his student by honing his sword skills until his skills were recognized by the public which made him considered a prodigy, as well as spreading the Royal Bushin sword method throughout the country before First Princess Iris Midgar popularized it thanks to his contributions. Since becoming such a prominent person that there wasn't a swordsman who didn't know his name in Midgar, Zenon eventually joined the same Cult after receiving their invitation for the sake of strength, even Willow considered Zenon stupid and a disgrace to the point that he no longer wanted to think of him as his best student again after seeing Zenon consume the red pill.

A year after the kidnapping of Second Princess Alexia Midgar incident has passed, Willow heard the news that Zenon, who was becoming a candidate for the 12th seat in the Knights of Rounds, had been killed by Shadow, whose abilities apparently surpassed the skills of his former student whom he had taught personally and are the leader of an mysterious secret organization that dared to fight the Cult of Diablos called Shadow Garden where they have exposed the Cult's activities to the public for 6 months since their appearance, even though the Cult has labeled them as criminals and Shadow Garden is considered a terrorist organization in front of the world by utilizing their influence in kingdom's government and artificial religion.

That's when Willow knew that he would face Shadow sooner or later, making Shadow as his final opponent because Willow wanted to fight the killer of his stupid student in his last moments as a swordsman. Plus, Willow realized that the Cult's higher-ups were feeling uneasy after hearing that the number of Tears had decreased even though he didn't know the cause.

However, Willow thinks that perhaps it is not a coincidence that Shadow Garden has appeared in this current era, as he considers the organization to be the most powerful people in the world and their existence could end the Cult's long reign in the world to the point of wondering whether Shadow Garden was really on the side of justice to protect world peace or maybe they were trying to take everything from the Cult, which made Willow assume that Shadow Garden would take away eternal life and the world that the Cult of Diablos had owned all this time after their fall.

### The Academy Disappearance

## Powers & Abilities

## Relationship

### Cult of Diablos

#### [Fenrir](Fenrir.md "Fenrir")

#### Zenon Griffey

### Enemies

#### Shadow

#### Alexia Midgar

#### Claire Kagenou

## Trivia

## References

1. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • **Willow** • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • Alexia Midgar • Christina Hope • [Isaac](Isaac.md "Isaac") • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |
