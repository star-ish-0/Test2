# Millia/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Millia/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Millia/Image%20Gallery)

[Main](Millia.md "Millia")

[Chronology](Millia-Chronology.md "Millia/Chronology")

[Relationships](Millia-Relationships.md "Millia/Relationships")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)

Millia as No.711
