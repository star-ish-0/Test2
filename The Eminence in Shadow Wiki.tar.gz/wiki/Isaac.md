# Isaac

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Isaac](https://the-eminence-in-shadow.fandom.com/wiki/Isaac)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

Chronology

Relationships

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | That’s right. I was the mole. | ” |
| — Isaac when he openly reveals himself as Cult's minion, Light Novel Volume 05 | | |

## Isaac

### Japanese

アイザック

### Romaji

Aizakku

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Dark Green

### Eye Color

Yellow

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Student

### Affiliation

Midgar Academy for Dark Knights (undercover)
Cult of Diablos

## Debut

### Light Novel

Volume 5

### Manga

Chapter 59

Isaac (アイザック, Aizakku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a one of the top students at Midgar Academy for Dark Knights and Cid Kagenou's classmate he cheats off during tests.[[1]](#cite_note-V5C1-1) However, it is revealed that he was an insider working for the Cult of Diablos.[[2]](#cite_note-V5C5-2)

## Appearance

Isaac was a handsome man with dark green hair and yellow eyes.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Tch… Don’t go getting cocky, loser. | ” |
| — Isaac, Light Novel Volume 05 | | |

Isaac normally presents himself as a highly intelligent student with very calm personality at school. In reality, Isaac has shown to be a very treacherous cold-hearted individual with deceitful nature that he won’t hesitate to manipulate anyone, even his friends, if necessary, in order to make his task easier.[CITATION NEEDED]

Despite his perceived intelligence, however, Isaac was shown to be a wary hypocrite as he's being cautious of others when he keeps voicing his suspicion of Suzuki's secretive behavior and making his team to believe that he's leading the Special Attack Squad into a trap, even though he is the one luring them to their doom since he's actually a mole for the Cult.[CITATION NEEDED]

Like most people who work for the Cult, Isaac had confident in himself and his own abilities. However, due to his overconfidence, he seriously underestimated "Suzuki", and this eventually led to his death.[CITATION NEEDED]

## Chronology

### Background

Isaac was the son of a noble family with connections to the Cult of Diablos and entering the Midgar Academy for Dark Knights to operate as an insider by becoming a student for about a year, eventually ascending into a model student; all while keeping his true loyalties hidden from everyone outside of his affiliates.[CITATION NEEDED]

### The Academy Disappearances

## Powers & Abilities

Isaac was considered one of the five best students in Cid's class who becomes a model student due to his intelligence, even Cid Kagenou himself always cheats on all of his answers during tests, although he answered the test that could adjust his average scores.[CITATION NEEDED]

As a Cult's agent, Isaac is highly adept at manipulating people when he is deceptive enough to make people believe his baseless accusation, to which even the entire student was completely in the dark about him as an insider man until he revealed himself when trapping his own team.[CITATION NEEDED]

### Genius Manipulator

Isaac was intelligent and cunning as he tended to come up with twisted schemes of ingenious and imaginative plans. This includes spreading deliberate propaganda about Shadow Garden's infamy in order to make every student believe in him and being highly deceptive. He demonstrated his deceptive nature by managing to successfully manipulate his friends from discovering his true affiliation towards the Cult during his time at the academy which he won’t mind for luring his team into a Cult's trap.[CITATION NEEDED]

## Trivia

- Isaac's family may possibility be affiliated with a secret society which have ties to the Cult of Diablos.[CITATION NEEDED]

## References

1. Volume 5 Chapter 1: Claire's Back, and Her Symptoms Are Worse Than Ever!
2. Volume 5 Chapter 5: Terrorists Attack the Shool...Again!!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • Alexia Midgar • Christina Hope • **Isaac** • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | [Loki](Loki.md "Loki") • [Hel](Hel.md "Hel") • [Jormungandr](Jormungandr.md "Jormungandr") • [Fenrir](Fenrir.md "Fenrir") • [Mordred](Mordred.md "Mordred") • [Petos](Petos.md "Petos") • Jack Nelson • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • Sir Gaunt | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • [Jean](Jean.md "Jean") • Dark Spider • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • [Gray](Gray.md "Gray") • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • Reina Oriana • **Isaac** | |
