# Wakoku

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Wakoku](https://the-eminence-in-shadow.fandom.com/wiki/Wakoku)

## Wakoku

### Japanese

ワコク

### Romaji

Wakoku

## Location Information

### Leader

Unknown

### Status

Active

### Affiliates

Unknown

### Type

Country

### Government

Unknown

### Location

In a remote land far to the east beyond the Midgar Kingdom on the main continent.

### Inhabitants

Humans
Elf

## Debut

### Light Novel

Volume 6 (Mentioned)

Wakoku (ワコク, Wakoku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a country that resides far from Midgar Kingdom. Contrary to different Other World kingdoms, the top caste are those called martial artists, rather than Dark Knights. The country's isolation keeps the majority of information from reaching other countries, but a few martial artists leave the country for training.[[1]](#cite_note-:0-1)

Wakoku has four major schools of martial arts, though we have so far only seen one of them, that being the Byakko style. The one using the Byakko style was the master of the Byakko style called Sword Demon. Sword Demon had been expected to become the youngest Chief Instructor, though he killed nine of his fellow disciples leading to him getting expelled.[[1]](#cite_note-:0-1) He was killed by Cid Kagenou in his Jack the Ripper persona some time after.

The Sword Demon was one of the few we have seen from Wakoku, however, Alexia Midgar has mentioned that those martial artists who leave Wakoku for training are all called strong.[[2]](#cite_note-2) In addition to the Sword Demon, [Sigma](Sigma.md "Sigma") of Shadow Garden's Numbers, has been stated to be from a Ninja Organization from Wakoku.[[3]](#cite_note-3)

## History

## Governance and Economy

## Inhabitants

- [Sigma](Sigma.md "Sigma")
- Sword Demon (Deceased)

## Trivia

- Wakoku serves as this world's variation of Japanese culture.

## References

1. Volume 6. Chapter 2: Intruders at the Sleepover Party!
2. Volume 6. Chapter 3: Deciphering the Threatening Message!
3. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 3: Secret of Sacra, Chapter 3-8: Shadow Ninja Girl, Episode 2: Cool Ninja Girl

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • **Wakoku** | |
