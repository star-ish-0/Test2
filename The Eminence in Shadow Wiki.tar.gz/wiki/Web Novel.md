# Web Novel

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Web%20Novel](https://the-eminence-in-shadow.fandom.com/wiki/Web%20Novel)

|  |  |  |
| --- | --- | --- |
| “ | Just like how everyone adored heroes in their childhood, a certain young man adored those powers hidden in shadows. After hiding his strength and living the mediocre life of a mob character by day while undergoing frenzied training by night, he finally reincarnates into a different world and gains ultimate power. The young man who is only playing at being a power in the shadows, his misunderstanding subordinates, and a giant organization in the shadows that gets trampled…. This is the story of a young boy who had adored powers in shadows possibly eventually reigning over the world of shadows in another world. | ” |
| — Source: Novel Updates | | |

The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a web novel written by Aizawa Daisuke and published on the Japanese Web Novel publishing site [Syosetu](https://syosetu.com/). The web novel started in 2018, consisting of 8 volumes and 206 chapters (including character introductions). All plots and events parallel the Light Novel up to the Oriana Kingdom arc. From there, the stories significantly diverge. It has been on hiatus since November 26, 2022, and Daisuke has not announced anything for the unfinished story.

The original version of the web novel can be found on [Syosetu](https://ncode.syosetu.com/n0611em/).

## Chapters

Note: Does not include character introduction chapter.

- [Volume 1](#)
- [Volume 2](#)
- [Volume 3](#)
- [Volume 4](#)
- [Volume 5](#)
- [Volume 6](#)
- [Volume 7](#)
- [Volume 8](#)

- Chapter 1: Within the Limits of Being Human Means You Would Be Vaporized by a Nuke
- Chapter 2: Bandits Are Basically Just Walking Bonus Stages
- Chapter 3: Sudden Emergence of the Order of Diabolos?
- Chapter 4: If Only He Had Hair……
- Chapter 5: Real Member of the Order, and Real Person of the Curse
- Chapter 6: Your Drug Test Result Is ‘Positive’
- Chapter 7: A Simple Fighting Lesson, Power in Shadows Style (With Only This Much, \*You Are Also a Power in the Shadows?!)
- Chapter 8: Powers in the Shadows Are Lonely
- Chapter 9: The Frolicking of Those Who Know Nothing of the World of Shadows
- Chapter 10: Apparently He Discovered Her Secret and Is Blackmailing Her……
- Chapter 11: Conflict Is Entertaining When You Are Uninvolved
- Chapter 12: HI, My Name Is Pochi! Nice to Meet You, Everyone!
- Chapter 13: Incidentally, I’m in the Zenon Faction
- Chapter 14: It Would Take Serious Effort to Make Me Truly Flip Out
- Chapter 15: Oh Wow, What a Wonderful Idea (In a Monotone Voice)
- Chapter 16: Currently Writing the Complete Version of ‘the War Chronicles of Shadow-Sama’
- Chapter 17: Fragment of Diabolos! Squish!
- Chapter 18: Keep Watching From Below the Stage
- Chapter 19: Far off Memory
- Chapter 20: “I Am……”
- Chapter 21: [Urgent Question] the Way to Dispose of a Dead Body on Campus [Anon]

- Chapter 22: That Which Anyone Would Overlook
- Chapter 23: Otherworld General Trading Company Mitsugoshi Co.
- Chapter 24: 7 Girls and 1 Guy. Obviously Someone’s Going to Be Left Out
- Chapter 25: Respite in an Alleyway
- Chapter 26: Ugh, My Head……
- Chapter 27: High Heels & One Piece & White Legs
- Chapter 28: Otherworld-Style Valentine’s Day
- Chapter 29: A Mob Can Tell
- Chapter 30: \_\_\_ Bastard
- Chapter 31: Can You Keep Up With Me?
- Chapter 32: The Undying Magic Swordsman
- Chapter 33: What Every Boy in the Universe Dreams Of
- Chapter 34: There Are Times When a Mob Has to Act
- Chapter 35: The Romance of Looking Down From a Rooftop
- Chapter 36: Relieved That It’s More Decent Than Expected
- Chapter 37: The Course of an Advanced Psychological Battle
- Chapter 38: Lending Just a Tiny Bit of Help
- Chapter 39: Wanting to Live For Just One More Day
- Chapter 40: That Which Is Truly Important
- Chapter 41: Arrival of the Summer Rain

- Chapter 42: Proposing the Leech-Style Mob Life
- Chapter 43: That Thing That’s as Enigmatic as Wooden Swords at Tourist Spots
- Chapter 44: Holy Sword Excalibur
- Chapter 45: Plan a Has Failed, Shift to Plan B
- Chapter 46: A Woman Who Seems Shady and a Woman Who Seems Cheap and a Woman Who Seems Blissful
- Chapter 47: The Theory That When a Bomb Goes off It Can Erase Everything Else That Had Happened
- Chapter 48: Please Believe That There Really Are Times When Those Who Have No Intention of Looking Still End up Seeing
- Chapter 49: Those That Don’t Understand Are Boring
- Chapter 50: The Heroine Who Directed and Acted in Her Own Production
- Chapter 51: The Birth of ‘Precise’
- Chapter 52: The Truth Within Memories
- Chapter 53: The Escape Plan of a Fragile, Dainty Girl
- Chapter 54: Gratz for Taking First Place in the ‘Humans Who Can’t Use Magic’ Tournament
- Chapter 55: Just Look at What You Want to Look at Then
- Chapter 56: Genes, Age, or Stress?
- Chapter 57: Everything Is Within His Expectations
- Chapter 58: That Which Can Only Be Drawn by the Chosen
- Chapter 59: Inescapable Attack
- Chapter 60: Puzzle Piece

- Chapter 61: The Girl and the Sound of Rain
- Chapter 62: I Am a Man Who Rides the Waves
- Chapter 63: The Mysterious Young Swordsman Jimina
- Chapter 64: Spartan Hazing From a Festival Regular!
- Chapter 65: No Need to Rush, Youngster, for Life Is Long
- Chapter 66: The Harmless Poyoyon and Mole
- Chapter 67: Sure-Win Golden Dragon’s Sure-Win Formula
- Chapter 68: The Match Where the Stronger One Gets All the Attention
- Chapter 69: Evil \*\* Kill \*\* Dragon!!
- Chapter 70: In Expectation of This Happening
- Chapter 71: Beta’s Job
- Chapter 72: A Power in the Shadows Playing Under the Moonlight
- Chapter 73: The Girl Who Dreams a Dream and the Boy Who Walks a Dream
- Chapter 74: The Single Ray of Light Shining Into the Darkness
- Chapter 75: The Girls’ Paths, and His Decision
- Chapter 76: The Basics of Human Relationships Is Abandonment Play
- Chapter 77: And Who Are You
- Chapter 78: What Always Ends up Happening From Stopping at the Last Instant
- Chapter 79: I’ve Won! (Assured)
- Chapter 80: Exactly Who Are You?
- Chapter 81: Breakfast at the Special Seating Nao
- Chapter 82: The Smelly Man Is Part of the Plan
- Chapter 83: From a Far Away Height……
- Chapter 84: Final Duty
- Chapter 85: Mysterious Masked Swordsman Slayer, at Your Service!!
- Chapter 86: Summit of the Path of the Sword
- Chapter 87: Your Real Enemy
- Chapter 88: Ashes of a Dream

- Chapter 89: Being Gatekeeper a Is Great!
- Chapter 90: It’s Already Completely Healed
- Chapter 91: What Belongs to Bandits Also Belongs to Me
- Chapter 92: Two Loser (Dogs) And a Watchdog
- Chapter 93: Shockingly Huge Bargain Sale, Only in Outlaw City!!
- Chapter 94: Stop Throbbing……
- Chapter 95: From Mob Escape to Mob Revenge
- Chapter 96: For the Sake of This Day, I Have Prepared This… Hole!!
- Chapter 97: Rampage…… the Streets Are…… Blood…… Run……
- Chapter 98: Tough Lady
- Chapter 99: The Three Currents
- Chapter 100: War of Monsters
- Chapter 101: The Rumored Shadow Garden
- Chapter 102: Two Lasses
- Chapter 103: What Are You Doi-?!
- Chapter 104: Don’t You Dare Steal My Role, Girl
- Chapter 105: The Man Who Was Too Early
- Chapter 106: What Do You Understand About This Pain?! (Blood Pressure)
- Chapter 107: Her Duty
- Chapter 108: Overwhelmingly Terrible at Explanations
- Chapter 109: The Queen of Blood
- Chapter 110: Her Master
- Chapter 111: Mission Complete
- Chapter 112: There’s No Helping It When the Left Hand Begins to Ache

- Chapter 113: Kyaaa! Not So Rough!
- Chapter 114: Super Elite Agent, That Person Is…
- Chapter 115: The World Is Whispering to Me
- Chapter 116: Do You Really Think So?
- Chapter 117: Booking Making Special
- Chapter 118: Golden Retriever
- Chapter 119: Olé, It’s Olé!!
- Chapter 120: Blind Big Wolf
- Chapter 121: Swish, Swish, Swish, Swish, Swish!!
- Chapter 122: The Malaise of Mitsugoshi
- Chapter 123: Sample
- Chapter 124: The Power of a Super Elite Agent
- Chapter 125: The First to Notice the Change
- Chapter 126: Don’t Get In the Way
- Chapter 127: Black Jaguar
- Chapter 128: The Supreme Code
- Chapter 129: It’s All That Fool’s Fault
- Chapter 130: Goodbye, John Smith
- Chapter 131: His Back
- Chapter 132: Finally, This Day Has Come
- Chapter 133: Yukime and Gettan
- Chapter 134: Rumor of the Counterfeit Bills
- Chapter 135: All Met His Expectations
- Chapter 136: You Made Me Angry ...
- Chapter 137: Those Who Robbed Both Eyes
- Chapter 138: The Man Who Is Burning With Revenge
- Chapter 139: Even if We Talk, It Will Be a Waste of Time
- Chapter 140: Gettan……
- Chapter 141: Everything Is His
- Chapter 142: The Bloody Demon King Who Betrayed His Dream

- Chapter 143: That Ordinary Boy is Revealed to be!
- Chapter 144: Concentration Camp
- Chapter 145: His name is Kageno Minoru [Cid's Past Life]
- Chapter 146: Mystery Man
- Chapter 147: Not Enough Calories At All
- Chapter 148: When it's All Over
- Chapter 149: Code 0
- Chapter 150: Who Do You Think You're Dealing With?
- Chapter 151: The Princess's Mob Friend
- Chapter 152: Evil Encroaching
- Chapter 153: Looks like We're Done
- Chapter 154: Soul Searching
- Chapter 155: Sorry, Ya Lost Me.
- Chapter 156: Action Spy
- Chapter 157: Cut Down Anything!
- Chapter 158: Beacon of Revolt
- Chapter 159: I Can Hear Him But From Where…
- Chapter 160: My Time to Shine?
- Chapter 161: The Ringleader is Here!?
- Chapter 162: Sigh, really didn't want to make a scene, man~
- Chapter 163: The Power of Diabolos
- Chapter 164: Where is He?
- Chapter 165: Demon Lord Unleashed
- Chapter 166: Mordred

- Chapter 167: What Were Ideal Powers in Shadows in My Mind?
- Chapter 168: In This Troop You Will Earn A Lot of Money
- Chapter 169: The Dream Of Two Men
- Chapter 170: Mob Character’s Field Trip
- Chapter 171: Three Ojisans
- Chapter 172: Vow of Black Rose
- Chapter 173: Don’t Upstage Me
- Chapter 174: Do Not Kick the Platform
- Chapter 175: Evil God・Instant Kill・〇〇〇 Sword
- Chapter 176: Died On the Spot
- Chapter 177: So-called Master
- Chapter 178: The End of Mob Character
- Chapter 179: A Small Part of the Abyss-like Plan
- Chapter 180: She’s the Type of Person Who Always Exaggerates
- Chapter 181: The Other Side Connecting the Past, Present and Future
- Chapter 182: Infatuated with That Courage and Insight
- Chapter 183: We Are Friends After All!
- Chapter 184: If He Was Born Before A Thousand Years Ago
- Chapter 185: Terrible Interests
- Chapter 186: Two People with Social Phobia
- Chapter 187: Epsilon’s Secret Recipe
- Chapter 188: Epsilon in Gorgeous Disguise
- Chapter 189: Take A Walk in the Forest
- Chapter 190: Everything Is Connected, All of Which Meets His Expectations
- Chapter 191: Let Me Show You Perfect Magic Control
- Chapter 192: It’s Not My Fault The Shot Went Away
- Chapter 193: Great Sacrifice for World Peace and Science
- Chapter 194: The Secret One Wants to Hide the Most
- Chapter 195: A Natural Phenomenon of Unknown Cause or A Paranormal Phenomenon
- Chapter 196: Battle of Darkness
- Chapter 197: Forget to Close the Door
- Chapter 198: It’s All The Americans’ Fault
- Chapter 199: Mysterious Architect Eta Lloyd Wright
- Chapter 200: The Only Food Left Is DX
- Chapter 201: Fraudulent Company
- Chapter 202: Seems Like Never Coming Back
- Chapter 203: Kaya...Uma
- Chapter 204: House of Zombies
- Chapter 205: Interlude – Delta’s Past

## Trivia

- The initial translation by Tenshi Translations starts at chapter 2 on [Syosetu](https://ncode.syosetu.com/n0611em/), skipping the character introduction chapter.
- The absence of chapter 143 is because the chapters aren't numbered on Syosetu. The author added a character introduction chapter at the top of the contents, which pushed the rest of the chapters up by one and when the translators changed the new one used the number of chapters on Syosetu, which 'skipped' chapter 143.
- Web Novel characters such as [Mordred](Mordred.md "Mordred") and Akane Nishino have been made into Canon characters who have an important role in their own respective story arc by making the characters changes, as well as story content that is quite commensurate with making them as an important role figure.
  - It was revealed that after the release of Volume 5 and 2 anime episodes, namely Episode 13 and Episode 20, there are several Web Novel characters that have been made into Canon characters. Currently, the canonical characters which are revealed so far is [Chi](Chi.md "Chi"), [Omega](Omega.md "Omega"), Christina Hope, [Fenrir](Fenrir.md "Fenrir") and [Grant](Grant.md "Grant").

## References
