# Crimson Order

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Crimson%20Order](https://the-eminence-in-shadow.fandom.com/wiki/Crimson%20Order)

## Crimson Order

### Japanese

紅（くれない）の騎士団（きしだん）

### Romaji

Kurenai no Kishi-dan

## General Information

### Leader(s)

Iris Midgar (Founder; Commander)
[Glen of the "Lion Mane"](Glen.md "Glen") (First Vice-Commander; Deceased)
[Adder](Adder.md "Adder") (Second Vice-Commander/Cult infiltrator)

### Status

Active

### Affiliates

Midgar Military

### Base of Operation

Midgar Kingdom

## Debut

### Web Novel

Chapter 22

### Light Novel

Volume 1

### Manga

Chapter 7

### Anime

Episode 6

Crimson Order (紅（くれない）の騎士団（きしだん）, Kurenai no Kishi-dan[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a newly established military organization affiliated with the Midgar Kingdom's government. It is dedicated to protecting the nation by maintaining security and order against all threats. The organization is led by First Princess Iris Midgar, one of the most powerful swordsmen and magic users on the continent.

They are currently investigating the Cult of Diablos and Shadow Garden following the kidnapping of Second Princess Alexia Midgar. However, the Crimson Order has been unable to make satisfactory progress due to repeated failures in their assignments, leading to dire straits. As a result, the Order is now experiencing a significant shortage of personnel and support.

Eventually, the Cult managed to infiltrate the Crimson Order by planting a [spy](Adder.md "Adder") within their ranks. This spy fabricated evidence to falsely incriminate Shadow Garden for the Cult's past crimes, while dismissing the existence of the Cult as mere fantasy.

## Overview

The Crimson Order operates as a special investigation unit. Despite being a newly formed and relatively small knight order, it is composed of trusted individuals. As an official military organization dedicated to internal security, their primary goal is to combat all threats to maintain order and peace within the Midgar Kingdom.

During its early days, the Crimson Order launched a kingdom-wide investigation into two shadow organizations: the Cult of Diablos, responsible for the kidnapping of Second Princess Alexia Midgar, and Shadow Garden, which had rescued Alexia, destroyed the Cult's hidden facility, and eliminated those within, including Zenon Griffey, the main perpetrator of the kidnapping.

However, the Crimson Order struggled to operate smoothly due to limited funds from the sudden establishment of the new order. Additionally, the Order faced several setbacks, losing support after the death of their best knight, [Glen](Glen.md "Glen"), shortly after he joined. The situation worsened with Princess Iris Midgar's public defeat at the Bushin Festival, further diminishing their credibility.

## History

The Crimson Order was founded by Iris Midgar, the First Princess of Midgar Kingdom and the kingdom's strongest warrior. The Order consists of her trusted members, including [Glen](Glen.md "Glen") the "Lion Mane" and Marco Granger, who voluntarily joined the new Order.

Iris Midgar established the Crimson Order to combat forces threatening the Midgar Kingdom after the kidnapping of her younger sister, Alexia Midgar, by Zenon Griffey. Although Griffey was a respected figure, he was revealed to be the mastermind behind the kidnapping and a secret member of the Cult of Diablos. Iris founded the new Order due to her growing distrust of the existing Knight Order.

During that incident, Iris also encountered [Alpha](Alpha.md "Alpha") from the Shadow Garden organization. Unable to determine whether Shadow Garden was friend or foe, the Crimson Order pursued them with the same intensity as they did the Cult of Diablos.

## Organization Strength and Influence

The Crimson Order is a powerful military organization in the Midgar Kingdom and has become a major force to be reckoned with. It comprises knights carefully selected from the Knight Order, initially recruiting only eight members, including [Glen](Glen.md "Glen"), the strongest knight who serves as the Vice-Commander. However, the true strength of the Crimson Order lies in its commander, First Princess Iris Midgar. Renowned as the strongest person in the kingdom, Iris is celebrated by the populace for her extraordinary achievements.

Despite being a newly formed order tasked with investigation and law enforcement, the Crimson Order's current influence is relatively weak, and it may struggle to survive for more than ten years without Iris's significant contributions, especially given its limited budget. Shortly after its founding, the Crimson Order experienced several failures that resulted in losing substantial support and casting doubt on Iris's ability to lead the organization effectively.

## Membership

The Crimson Order was established as a special force comprising individuals personally chosen by Iris Midgar from the Knight Order. Its purpose was to combat and eliminate any malicious forces that posed a threat to the Midgar Kingdom. However, due to Iris's impulsive decision to create a new Order, the Crimson Order lacked sufficient resources needed to establish itself as a proper organization. Subsequently, efforts were made to collect funds and stockpile weapons to bolster its military strength.

During the failure of their first mission, Iris acknowledged that the Crimson Order had lost [their strongest member](Glen.md "Glen") shortly after his joining, leading to a significant loss of support from the Knight Order. With little hope of finding a replacement, rebuilding the Order seemed unlikely.

## Equipment and Artifacts

As a newly formed organization, the Crimson Order has already lacked in funds, weapons equipment, and only possessed one Artifact.

- Swords

## Known Members

Originally, there were only eight total members who had joined in the organization.[[1]](#cite_note-V1C4-1) In Volume 5, it is unveiled that although there are additional members in the Crimson Order, many of them appear to lack courage or resolve.[[2]](#cite_note-V5C1-2) Meanwhile, members of the Cult of Diablos infiltrate to manipulate Princess Iris. With [Adder](Adder.md "Adder") as a key player, they fabricate false evidence, attributing past world evils to Shadow Garden instead.

- Iris Midgar (Founding Commander)
- [Glen](Glen.md "Glen") of the "Lion Mane" (1st Vice-Commander; Deceased)
- [Adder](Adder.md "Adder") (2nd Vice-Commander/Cult infiltrator)
- Marco Granger (Senior Knight)
- Alexia Midgar (External Staff)

## Trivia

- Crimson Order members wearing red cloaks is likely due to Iris's notable crimson red hair.
- Claire Kagenou is one of the few students that Iris wants to recruit, after she graduates from the Midgar Academy for Dark Knights.[[3]](#cite_note-V2C7-3)
- Even though Iris had recently built this Order for almost half a year, the Crimson Order has been losing public support from mishaps and failings regarding to their pursuit of Shadow.
  - With Adder already taking over the Crimson Order by manipulating Princess Iris, the order is effectively becoming an asset to the Cult.

## References

1. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
2. Volume 1 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
3. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!

## Image Gallery

## Site Navigation
