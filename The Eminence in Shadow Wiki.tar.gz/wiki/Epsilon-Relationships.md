# Epsilon/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Epsilon/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Epsilon/Relationships)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Main](Epsilon.md "Epsilon")

[Chronology](Epsilon-Chronology.md "Epsilon/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

Having been rescued by the boy when she was a child, Epsilon became extremely devoted to him. Realizing that her skills were severely lacking compared to her fellow Seven Shades, Epsilon decided to become the perfect woman for Cid. Due to her insecurity with her body, she would utilize her slime magic taught by Cid and later alter the appearance of her body. As such, she would often present herself as a voluptuous figure to attract her oblivious master attention.[[1]](#cite_note-:2-1)

When the two reunited, he was already aware of her fake slime body and gave a side glance.[[2]](#cite_note-:4-2) Epsilon misunderstood and exaggerated that he said that "She had a nice figure" to other members such as [Delta](Delta.md "Delta") and [Nu](Nu.md "Nu"). She was delightfully laughing when Beta became enraged of the report given by Nu. This interaction occurred in the spinoff "Kage-Jitsu".

Epsilon believes her master's Shadow persona is the real personality and his actual one is a façade especially when he likes to play with the Shadow Garden members to relieve them of their worries. Having to constantly maintain her slime body resulted in her incorporating it into her body which impressed her master. However, she misunderstood that her body attracted him when in actuality he was fixated on the slime on her body.

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

Epsilon deeply respects Alpha, following her orders without question. When they were younger, Epsilon was surprised and touched that Alpha entrusted her with curing a possessed despite it being her first time. However, the prideful elf has admitted to being outmaneuvered by her in terms of leadership and was envious of it. This did not stop her as she used it as motivation in becoming the "perfect woman" for her master.[[1]](#cite_note-:2-1)

#### [Beta](Beta.md "Beta")

Fellow Seven Shade members, the two were able to utilize skills taught by Cid and make names for themselves through their true relationship has not come to public light. Personally, Epsilon sees Beta as her rival for their master's affection and especially resents her naturally voluptuous figure. Beta however is oblivious to Epsilon's resentment toward her. Regardless, the two are still able to put aside their rivalry for Shadow Garden's cause.[[3]](#cite_note-:5-3)

In her and Cid's flashbacks in the Anime to when they were younger, the two elves cameoed in each other when Beta's breasts came to mind when Cid taught her about slime magic and how to utilize it when he told her to change her fate and take hold of the truth.

In Cid's flashback, Epsilon humorously cameoed as she enviously watched the silvered-haired elven through the windows when he taught her about stories and literature from his past life.[[4]](#cite_note-4)

#### [Gamma](Gamma.md "Gamma")

Epsilon seems to have a working relationship with Gamma. In the spinoff "Kage-Jitsu", the entrepreneur inadvertently scared her when she was discussing about economics and how inflation works. The prideful elf couldn't keep up and heard the parts "Something that isn't worth much" and "Burst" causing her to panic, and pride be damaged.

#### [Delta](Delta.md "Delta")

Fellow Seven Shade member and one of the only two [Therianthrope](Therianthrope.md "Therianthrope"), Epsilon gets along well enough with Delta. However, the latter has on several occasions came close to discover that she pads her chest since she always reeks of slime. In response, Epsilon has taken to offer her snacks as a distraction.

#### [Zeta](Zeta.md "Zeta")

Fellow Seven Shade member and one of the two Therianthrope. The two alongside other members of the Seven Shades worked together in taking down Viscount [Grease](Grease.md "Grease") and save Claire from captivity.[[5]](#cite_note-:7-5) Epsilon is unaware of Zeta's own sub-faction within Shadow Garden that is loyal solely to her, effectively going behind her and the other Shades' backs.[[6]](#cite_note-:0-6)

#### [Eta](Eta.md "Eta")

Fellow Seven Shade member and the only inactive one, in the anime, Epsilon seems to have a working relationship with Eta. In the spinoff "Kage-Jitsu," the somewhat mad scientist came close to exposing her fake slime body when she tried to force her to reveal what she was hiding, using a robot.

### Numbers

#### [Lambda](Lambda.md "Lambda")

Instructor for new recruits. In the game, Lambda admires her magic capabilities and musical talent. She is also subconsciously aware of her rivalry with Beta.

#### [Nu](Nu.md "Nu")

#### [Sigma](Sigma.md "Sigma")

#### [Chi](Chi.md "Chi")

One of Epsilon's direct subordinates. Chi is one of many to be aware of her superior's fake slime body but denies out of concern for her pride.[[7]](#cite_note-:1-7)

#### [Omega](Omega.md "Omega")

Like [Chi](Chi.md "Chi"), Omega is also one of Epsilon's direct subordinates. Omega is also one of many people aware of her superior's fake slime body. However, the subordinate in question denies of seeing her fake slime body out of concern for her own safety.[[7]](#cite_note-:1-7)

### Members

#### [Victoria](Victoria.md "Victoria") (559)

Subordinate and protégé, the two share an intense attachment towards Shadow which helped them work well together. However, their affection towards their master does not stop the elf from reprimanding her regarding the instance with Rose and other failed missions.[[8]](#cite_note-:3-8) Epsilon is unaware of her subordinate's allegiance to Zeta and is working behind her and other members back with the intention of immortalizing their master.[[6]](#cite_note-:0-6)

#### [664](664.md "664") & [665](665.md "665")

#### Rose Oriana (666)

Former member and current affiliate. Epsilon took particle responsibility regarding the instance with Victoria as she understood why the former princess acted out and that she hides information from her about her mother.[[9]](#cite_note-:6-9) The two alongside Beta fought together against [Mordred](Mordred.md "Mordred") when he crashed the queen's wedding.[[3]](#cite_note-:5-3)

#### Akane Nishino / "Akane Nishimura" (712)

## Others

### Claire Kagenou

Ever since the abduction by the hands Viscount [Grease](Grease.md "Grease"), Claire's safety has become Epsilon and the Seven Shades' top priority.[[5]](#cite_note-:7-5) Since Claire is her master's sister, Epsilon alongside members of Shadow Garden respects and cares for her deeply.

### Alexia Midgar

Unaware of her master's coerced relationship with the princess, Epsilon was uncharacteristically concerned about Beta's emotional meltdown when she learned about the things the princess did with their master. This event occurred in the game around the time Cid enrolled into the academy. Beta's hatred towards Alexia is a parallel to Epsilon's disdain towards [Margaret](Margaret.md "Margaret") though neither the elves are aware of it.

### [Margaret](Margaret.md "Margaret")

As Shiron, Epsilon has expressed disdain and jealously when the maid tried to get close to her master which in response released an aura that signified a killing intent.[[10]](#cite_note-10) When the maid tried desperately to poach Cid into working for her family for the last time, Epsilon was forced into using her slime to unpick the locks in the room they were in and intervened.[[9]](#cite_note-:6-9) This relationship dynamic parallels to Beta's hatred and jealously towards Alexia though neither of them are aware.

### [Pente](Pente.md "Pente")

Unlike the rest of Shadow Garden, Epsilon holds a significant amount of disdain towards her ancestor, to a point of visible disgust. Mainly because, unlike her, Pente is naturally well endowed, in addition to the fact that she is very close with Beta's ancestor [Duet](Duet.md "Duet").

### Skel Etal & Po Tato

## Enemies

## Cult of Diablos

### [Viscount Grease](Grease.md "Grease")

One of her primary targets during the operation of rescuing Claire, Epsilon alongside the Seven Shades fought and struggled against the former knight turned mutated Cult member to a standstill until he escaped. She alongside other members of the Seven Shades believed that their master set the Cult member up for a confrontation when in actuality, he got lost and lucky when Grease escaped to the lower floor of the hideout Claire was in and ran into him. [[5]](#cite_note-:7-5)

### Nelson

Late acting Archbishop and person of interest, Epsilon under Alpha's orders investigated Lindwurm regarding Drake's alleged corruption and child trafficking.[[2]](#cite_note-:4-2) Upon her master's victory over [Aurora](Aurora.md "Aurora"), Epsilon was the member who apprehended Nelson. During the apprehension however, the archbishop is one of many people become aware of her fake slime suit when he tried resisting by ordering the [Executioner](Venom.md "Venom") to kill her. After leaving the Archbishop to Alpha's squad, Epsilon left with her squad to perform their own investigation and reported back to her during [Delta's](Delta.md "Delta") onslaught on multiple copies of Nelson. During her squad's own investigation, the Sanctuary activated its effects and inadvertently exposed her slime suit to her members.[[1]](#cite_note-:2-1)

### Perv Asshat

When Rose went into hiding after stabbing him, Epsilon was sent to infiltrate Oriana to gather intel reading the Chancellor. Upon Cid's arrival, she took the initiative to save him from detainment when he was loitering. Under the guise of apprenticeship, the Chancellor condescendingly tested her master's skill to determine whether he was an intruder or not.

This forced her into leaving her master and become overwhelmed alongside the audience especially Ketsu by his performance of the Moonlight of Sonata.[[9]](#cite_note-:6-9) In doing so allowed Cid to pocket the proposal ring carried by the Chancellor, an essential item in freeing the Kingdom from the Cult's influence.[[3]](#cite_note-:5-3)

### Reina Oriana

Former Queen of Oriana and affiliate of the Cult. Epsilon was initially concerned of her safety due to her relation to member 666 and that the Cult was using her as hostage in order to have her daughter return to her kingdom as the Chancellor's fiancé. This failed however when Shadow reported the elf the truth regarding her and that the operation of freeing the kingdom would take place during the wedding.[[8]](#cite_note-:3-8)

On the day of the wedding, Rose denounced both the wedding her fiancé when she presented the proposal ring Cid pocketed and activated a projected memoir left by her father. In the memoir, Reina would be outed as a co-conspirator and killed when she tried cursing her daughter when she thought she killed her lover. Mordred however revealed himself as the mastermind and activated the Black Rose with Epsilon and Beta to teaming up with the former princess in taking down the Round Knight in response. [[3]](#cite_note-:5-3)

### [Mordred](Mordred.md "Mordred")

The mastermind behind the Oriana Civil War and member of the Round Knights. Epsilon alongside Beta and Rose fought him when the Round Knight activated the Black Rose. Epsilon and [Beta](Beta.md "Beta") mocked Mordred when calling him a coward of using the elven weapon and armor. Enraged that she got a cut on her face, the two parties fought to a standstill until Shadow defeated [Ragnarok](Ragnarok.md "Ragnarok").[[3]](#cite_note-:5-3)

After his defeat, Oriana was freed of the Cult's control but not without consequences. With international support being cut off, Epsilon decided to stay in the kingdom when Rose became the Queen.

## References

1. Volume 2 Chapter 2: Investigating the Sanctuary!
2. Volume 2 Prologue: To Lindwurm, the Scared Land!
3. Volume 4 Chapter 3: Crashing the Ceremony!
4. Episode 10
5. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
6. Volume 5 Chapter 3 Case Closed, Yes, Let’s Talk About the Old Days
7. Episode 13
8. Volume 4 Chapter 2: Begin Operation: Obstruction!
9. Volume 4 Chapter 2: Begin Operation: Obstruction!
10. Volume 4 Chapter 1: Putting the Kibosh on Rose Oriana's Wedding!
