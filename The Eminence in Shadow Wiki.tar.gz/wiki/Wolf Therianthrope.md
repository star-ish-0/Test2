# Wolf Therianthrope

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Wolf%20Therianthrope](https://the-eminence-in-shadow.fandom.com/wiki/Wolf%20Therianthrope)

Wolf Therianthrope is one of the therianthrope species.

Wolf Therianthropes have been shown to live in packs structured around a dominance hierarchy. The strongest members leads the tribe and becomes the primary male for the purposes of reproduction.[[1]](#cite_note-)

## Known Individuals

- [Delta](Delta.md "Delta")
- Zabra
- [Gettan](Gettan.md "Gettan")

## Reference List

1. Volume 3. Chapter 4: I'll Destroy It All and Start from Scratch!
