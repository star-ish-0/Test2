# Lalanoa Hinoizumino

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lalanoa%20Hinoizumino](https://the-eminence-in-shadow.fandom.com/wiki/Lalanoa%20Hinoizumino)

Chronology

Relationships

Image Gallery

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Lalanoa_Hinoizumino?action=edit).

|  |  |  |
| --- | --- | --- |
| “ | Toward everyone who laughed at my mother's death. If I participate in the War of Succession, let alone become the Queen—it would be the ultimate spite. | ” |
| — Lalanoa to Nazono Seinen, Light Novel Volume 7 - Chapter 1 | | |

## Lalanoa

### Japanese

陽の泉のララノア

### Romaji

raranoa

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

12

### Height

Unknown

### Hair Color

Black

### Eye Color

Violet

### Birthday

Unknown

## Personal Information

### Status

Alive

### Relatives

- King Anorion † (Father)
- Ainoa Hinoizumino † (Mother)
- [Beatrix](Beatrix.md "Beatrix") (Aunt)
- [Alpha](Alpha.md "Alpha") (Cousin)
- Tokiseiryuno Sakura (Childhood Friend)

## Professional Information

### Occupation

Swordswoman

## Debut

### Light Novel

Volume 7

### Manga

Chapter 80

Lalanoa (陽の泉のララノア, raranoa[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the candidates in the war of succession. Due to her appearance of having darker coloured hair her legitimacy as the daughter of the late elf King Anorion has been put into question many times. Some time after her mother—Ainoa Hinoizumino—was killed, she returns to take part in the war of succession for the elven throne to spite the ones who caused her mothers death. She meets Nazono Senen (Cid Kagenou in disguise) who agreed to become her knight and swordsmanship master after saving her from kidnappers.[[1]](#cite_note-1)

## Appearance

## Personality

## Powers & Abilities

## Trivia

## References

1. Light Novel, Volume 7, Chapter 1

## Site Navigation
