# Light Novel

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel](https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel)

The Eminence in Shadow is a Japanese published [Light Novel](https://en.wikipedia.org/wiki/Light_Novel "wp:Light Novel") written by Daisuke Aizawa and illustrated by Touzai. This story is about a boy named Cid Kagenou, a person who has always looked up to the heroes that work in the shadows of society. In an unfortunate accident, he is reborn in a world of magic, so he uses his vast knowledge of martial arts and training discipline to become a power in the shadows. With the members of Shadow Garden, he unwittingly works to stop the Cult of Diablos and their diabolical plans.

The light novel is published in Japanese by [Kadokawa](https://www.kadokawa.co.jp/)[[1]](#cite_note-1) and in English by [Yen Press LLC](https://yenpress.com/).[[2]](#cite_note-:0-2)

## Synopsis

ONE BIG FAT LIE AND A FEW TWISTED TRUTHS
Even in his past life, Cid’s dream wasn’t to become a protagonist or a final boss. He’d rather lie low as a minor character until it’s prime time to reveal he’s a mastermind…or at least, do the next best thing—pretend to be one! And now that he’s been reborn into another world, he’s ready to set the perfect conditions to live out his dreams to the fullest. Armed with his overactive imagination, Cid jokingly recruits members to his organization and makes up a whole backstory about an evil cult that they need to take down. Well, as luck would have it, these imaginary adversaries turn out to be the real deal—and everyone knows the truth but him![[2]](#cite_note-:0-2)

## Volumes

- [Japanese](#)
- [English](#)

Volume 1

Volume 2

Volume 3

Volume 4

Volume 5

Volume 6

Volume 7

Volume 1

Volume 2

Volume 3

Volume 4

Volume 5

Volume 6

## Promotional Material

Alpha Poster

Beta Poster

Gamma Poster

Delta Poster

## Promotional Videos

KADOKAWA『陰の実力者になりたくて！ 01』CM

Volume 1

KADOKAWA『陰の実力者になりたくて！ 02』CM

Volume 2

## Trivia

- The light novel volumes 1 to 3 plots and actions mirror the corresponding web novel chapters, 1-142. From Volume 4 onwards, the story diverges to a completely different plot line.

## References

1. [Kadokawa 陰の実力者になりたくて！　０１](https://www.kadokawa.co.jp/product/321806000138/)
2. [Yen Press: The Eminence in Shadow, Vol. 1 (light novel)](https://yenpress.com/titles/9781975359058-the-eminence-in-shadow-vol-1-light-novel)
