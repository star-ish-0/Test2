# Zeta/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Zeta/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Zeta/Relationships)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Main](Zeta.md "Zeta")

[Chronology](Zeta-Chronology.md "Zeta/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

After Cid cured her from her demonic possession, Zeta saw him as the living proof that her father and she were right about there being someone who can cure demonic possession, and she swore absolute loyalty to him. Like the rest of Shadow Garden, Zeta cherishes Cid and always seizes the chance to spend as much time as possible with him. She enjoys marking Cid's belongings with her scent and snuggling beside him. Although Zeta speaks very little and tries to suppress all unnecessary emotions, like the deep-seated hatred within her heart, so it doesn't hinder her from achieving her objectives. Zeta's original true self often comes to the surface when she is with Cid, as she would be acting happy, wagging her tail, and humming afterwards from her good mood whenever she remembers the time she had spent with Cid. After losing her family and tribe, everything she had known overnight, she got attached to Cid upon his saving her. This trauma and rescue led Zeta to believe that her family and entire clan had sacrificed themselves so that she could fulfill her true purpose of meeting and serving her master.

Zeta's pious devotion to Cid has reached a level of extreme fanaticism. She believes that gaining immortality is Cid's true goal, but his kindness is what is stopping him. To satisfy this mission, Zeta is determined to make Cid immortal, even at the cost of her own life. Her aims to resurrect the demon Diablos to grant Cid's immortality. In doing so, Cid would become the god of the new world; ensuring that he would be the eternal ruler to prevent the rise of another wicked group like the Cult of Diablos into power-- ironically unaware that she would supplant them with Shadow in that position.

#### [Alpha](Alpha.md "Alpha")

Zeta disapproves of Alpha's lenient goal of wanting to separate the Cult from the existing religion, believing that Alpha's kindness would impede their goal of defeating the Cult of Diablos. Zeta also believes that it is due to Alpha's more mellow approach to handling things, as well as Cid's kindness and over-reliance on Alpha; like how she handles the things Cid stopped pursuing for his 'original goal' of immortality, seeing the result as potentially catastrophic. For this reason, she mostly does her own thing without regularly reporting to the latter, much to Alpha's annoyance. She is even willing to go behind her back by creating her splinter faction within Shadow Garden loyal solely to her.

Despite all of this, Zeta is aware of Alpha's immense power and thus does not even try to challenge her directly, like Delta once did. Zeta feigns obedience while secretly pursuing her own goals, yet will still has no problem with Alpha, and they usually get along well.

#### [Delta](Delta.md "Delta")

Delta and Zeta do not get along well and constantly bicker with each other, mostly stemming from their [Therianthrope](Therianthrope.md "Therianthrope") instincts, as Zeta is a cat while Delta is a Wolf. They refer to each other with names like "Back Ally Cat" and "Dumb Doggie" respectively, but will forego their animosities if commanded by Cid or Alpha.

#### [Eta](Eta.md "Eta")

### Numbers

#### [Lambda](Lambda.md "Lambda")

#### [Nu](Nu.md "Nu")

#### [Chi](Chi.md "Chi")

#### [Omega](Omega.md "Omega")

### Zeta's Branch Division

#### [Victoria](Victoria.md "Victoria") (559)

A member of Zeta's secret faction, operating within Shadow Garden's Numbers. Being the first number to be granted power by Shadow himself since the original Seven Shadows, Zeta recruited Victoria following her initiation as No. 559, as both share a desire to serve their lord and seek to immortalize him like the god they think him to be.

#### [Nina](Nina.md "Nina")

A member of Zeta's secret faction. Although Nina is Zeta's personal subordinate, she is not affiliated with Shadow Garden, thus allowing Nina to move freely on her own. After Claire began displaying symptoms of having become the host to [Diablos](Aurora.md "Aurora"), Zeta had Nina infiltrate Midgar Academy for Dark Knights as a student to become Claire's best friend and watch over her. However, while Nina complied with merging Claire to the right arm, she was conflicted given her friendship to her target.

## Enemies

### Cult of Diablos

Zeta willingly intends to do anything for her goal of bringing down the Cult because it was, they who made her lose everything in her life which make her feeling become far greater hatred than anything else. In fact, Zeta intends to take advantage of the Cult's work in resurrecting the Demon Diablos in order to obtain immortality for her master Shadow.

### [Petos](Petos.md "Petos")

Zeta's Archenemy, responsible for the genocide of the entire Golden Panther Tribe, due to Zeta's possession and his desire for promotion into the Rounds. He is also directly responsible for death of her entire family, including her baby brother when she begged him to at least spare him, only for Petos to behead the baby held in her hands without any hesitations.

## Others

### Claire Kagenou

After Claire was cured of possession by Shadow, Zeta sent Nina to infiltrate the Midgar Academy for Dark Knights to watch her when it was time for Claire's enrollment. When Claire began displaying symptoms of having become Aurora's host and upon confirming her suspicions, Zeta forcefully had Claire absorb Diablos severed right arm, intending to use her body to revive the demon to make Shadow immortal. Despite Zeta and Shadow Garden swearing to protect her as her lord's sister, Zeta misunderstood Cid's acknowledgment of her goals, and proceeds to use Claire for her plans in reviving Diablos to give her master immortality.

### Skel & Po

Despite the two boys being her beloved master's friends in his civilian identity, Zeta does not care for them. When she heads to the hot springs, believing she could go on a group date with Cid, she is upset to see he is not there and that Skel and Po are the only ones present which caused her to get angry much to their horror. Following that, she spent much of the day avoiding them.[[1]](#cite_note-1)

## References

1. Episode 28
