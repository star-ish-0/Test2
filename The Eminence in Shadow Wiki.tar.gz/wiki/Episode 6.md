# Episode 6

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%206](https://the-eminence-in-shadow.fandom.com/wiki/Episode%206)

## Pretenders

### Kana

偽る者

### Romaji

Itsuwaru Mono

## Special Title

### English

The Eminence in Shadow Wants to Properly Confess!

### Kana

陰の実力者は告白にもこだわりたい！

### Romaji

Kage no Jitsuryokusha wa Kokuhaku ni mo Kodawaritai!

## Episode Information

### Season

1

### Episode

6

### Air Date

November 9, 2022 JP
January 30, 2023 EN

### Adapted From

Volume 1 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Kanichi Katou

### Storyboard

Daisuke Takashima

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Epsilon ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| I Am... | A Fencing Tournament of Intrigue & Bloodshed |

Pretenders (偽る者, Itsuwaru Mono[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the sixth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

While Iris seeks a bright mind to study an artifact, Cid visits a popular store. Meanwhile, in the dark corners of the city, someone commits murders in Shadow Garden's name![[1]](#cite_note-1)

王都にシャドウガーデンを騙る人斬りが出没する中、アイリスは古代文字解読を、王国随一の頭脳と名高いシェリーに依頼する。その頃、シドは友人と百貨店ミツゴシ商会を訪れていた。[[2]](#cite_note-2)

## Summary

Under the cover of night, a random citizen is attacked and killed by assailants who repeat the same phrase "We are Shadow Garden" almost manically. Then after that, a bloodied flyer falls down near the murder scene, proclaiming "Shadow Garden's" sinister motives.

The next day at the Academy dining hall, Skel and Po if Cid at least a kiss when he was dating Princess Alexia. However, Cid tells them that they broke up and didn't do anything, prompting the disappointed Skel to recommend visiting a special place. While Po interjects thinking something else, Skel clarifies that he is referring to a recently talked about shop called Mitsugoshi Company, a high-end retailer that sells all kinds of innovative products which no one's ever seen before, including a novelty goods item calls "chocolate". According to Skel, if they can use to give some chocolates to some girls then they win them over. As Skel and Po are too excited, Cid accepts their invitational offer, as he is also quietly curious to see the chocolate of this world.

At the same time, Princess Iris Midgar presents a confiscated artifact to Sherry Barnett, a Midgar Academy of Science student. After Alexia's kidnapping, the Crimson Order discovered it from a facility belonging to an organization that calls itself the Cult of Diablos. Iris admits they do not know the details about the artifact because they cannot decipher it. She formally asks for help from Sherry. Those familiar with Sherry claim her brilliant and analytical mind has no equal in the kingdom. Even Alexia, a student majoring in swordsmanship, reported overhearing rumors about Sherry's intelligence from fellow dark knights at the academy.

Feeling confused and nervous about Iris's request, Sherry's father, Lutheran Barnett who is the Assistant Principal of the Midgar Academy of Science, encouraged her to accept the princess' assignment by stating that this is a rare opportunity she should received because Sherry would travel the world with her research one day with Lutheran trying to strengthen her self-confidence, believe that Sherry can definitely do it and she accepts the job after being encouraged.

Hearing Sherry's accepting answer, Iris then asked for permission to suggest protection by assigning the Crimson Order knights to stand guard over Sherry, Lutheran who heard the Order's name inquires if they were the new order of knights that the princess had recently established and Iris confirm that although the newly created Crimson Order is a small order and has few members, but contains of knights that she can trusts, with [Glen](Glen.md "Glen") saying to count over Sherry's safety to him along with his partner Marco Granger as Sherry's bodyguards. Alexia also wishes to help and, after seeing her determination, Iris accepts.

By evening twilight, Cid, Skel, and Po reach the Mitsugoshi store, but the crowded line is so long that they have to wait 80 minutes for their turns. Po is worried given their dorm's curfew, likely heading back at night and nervous given he heard rumors of a killer going around after dark. However, Skel tells Po not to be afraid because the three of them are Dark Knights with Cid who is curious about Po's words about killer. While waiting, a store employee asks Cid if he can come with her and answer some survey, rejecting Skel and Po's eagerness to join him.

Once inside, Cid feels the store of Mitsugoshi Company resembles a department store from his old world, as there are many things that remind him of his world that he hasn't seen anywhere else in this world. Eventually arriving at the house atop the store building, Cid sees [Gamma](Gamma.md "Gamma") next to a throne and concludes her store belongs to her. She confirms as much and states how she made it after recreating items and goods from the wisdom Cid shared with them. Cid recalls that he did used to tell the girls random things as he was mentoring them and calls the knowledge from his old life "Shadow Wisdom", noting how Gamma was the smartest among the Seven Shadows. But he also knows she lacks athleticism, just as Gamma ends up falling the stairs in that very moment.

Noting her nosebleed, Gamma invites Cid to sit on the throne, to which he feels like a king, and thanks her by giving Gamma along with her staff as he creates something like fireworks with his magic as their reward. As the other Shadow Garden girls are in awe, this excites Gamma especially as the light reminds her of the light he used to save her. Cid guesses she is making money using the company and Gamma confirms as much, stating she has several franchises around the major cities and beyond from inside and outside the kingdom, and that they even use mail orders system for more remote areas to expand their organization's influence. She also displays how Shadow Garden has a secret budget of approximately One Billion Zeni for immediate disposal. Shocked hearing the answer, Gamma apologizes if it isn't enough, but Cid reassures her it is fine; all while quietly panicking and jealous to her achievements that Gamma used his knowledge to get many profits as she generate more money than he could ever hope to get.

Gamma guessed Cid came due to recent incidents where the killers who has appeared in the royal capital wearing black hooded clothes and claim to be from 'Shadow Garden' had committed serial murders on civilians randomly, which Gamma and her subordinates were currently investigating the matter already. However, they have not apprehend the perpetrators who are still hiding somewhere around the capital and promise Cid that they will put an end to their misdeeds by finding traces of the assailants' whereabouts that are difficult to find.

Cid had no idea, but as he remembers what Skel and Po also said something about a killer and finally learns the culprit's identity after recalls his own bloody incident with Alexia, Cid decides to play along and states he has some idea who it may be as he intends to investigate on his own. Gamma is in awe of her master's genius and introduces [Nu](Nu.md "Nu"), the employee girl who brought him upstairs earlier, really one of their newest Numbers, explaining that [Alpha](Alpha.md "Alpha") acknowledged her skill and promoted her to the Numbers position by telling Cid to assign Nu as his supporter. Cid tells Gamma that he will call Nu if he needs her, but before taking his leave, he asks Gamma to purchase three of the cheapest chocolate packages. While Gamma states she will give him their finest chocolate for free, Cid gets happy and while laughing with Gamma, as he steals one gold coin-- roughly 10,000 Zeni.

Later at night, Cid and his friends are rushing home as they remark how he took too long when Cid thought about his unexpectedness towards Alexia who started killing people indiscriminately and guesses that the princess had finally went crazy, remembering yesterday's incident when he rejected Alexia's proposal to continuing their "fake initial relationship". But just as he starts to wonder why the princess would do these things, Cid heard something faint in the distance to which he immediately stopped and then smiled after realizing that the sound he heard was the sound of swords clashing so he decided to tells his friends that he needs to poop right away. Urging them to go before they see him fail, Skel and Po race off believing that is very manly and swear not to forget him and will never tell anyone about this.

Once they're gone, Cid then goes in the back alley to confirm his guess of Alexia being a homicidal maniac which he didn't mind on her decision, but would act if the princess really claimed to be from Shadow Garden and he didn't plan on letting it go unpunished. Arriving at the destination, Cid is surprised where he finds Alexia and see the princess fighting a black hooded man who claimed to be from Shadow Garden. Alexia managed to defeat her attacker who always said the words "We are Shadow Garden" which made the princess think whether this serial murders was what Shadow wanted, while she on night patrol and intended to finish him off until suddenly two friends of the assailants appeared behind Alexia, with them immediately attack the princess.

However, Alexia was taken a hit by an sudden attack from the assailants she had previously defeated and managed to injure her by attacking her left arm, until the princess immediately hit the attacker in the face and leaned against the wall because she was overwhelmed by three people. The assailants surround Alexia until the injured men decide to kill the princess knowing that she will die, but Cid shows up as Shadow and kills one of the pretenders, telling the other two that they will also pay for impersonating Shadow Garden. As both imposters immediately run, an exhausted Alexia asks Shadow why he is fighting, but he coldly tells her to stay out of it, flying away as Alexia faints from pain in the alley.

As the men in black assailants escape to a rooftop, Shadow follows and kills another imposter before Nu arrives and congratulates Shadow's expeditious discovery in finding the culprit. Nu personally requests Shadow to leaves the interrogation for information from the perpetrator who dared to use the name Shadow Garden to her, so Shadow permits her, then the last impersonator immediately attacked Nu, but Nu instantly disarms the fraudster's weapon and limb, stating that she isn't as forgiving as her master and proceeded to torture the pretenders. Elsewhere in the ruined building, a Cult underling informs that he lost contact with the puppet and the two other men, with [an officer](Rex.md "Rex") responding in insults to the assassin being killed and asking his superior what their next step will be, to which the leader addressed as "Gaunt Knight" states in reply that it's fine as they located the whereabouts of the item they need and their top priority is retrieving the item.

Back at the academy, Alexia has her injuries addressed and updates Iris that the killer is not from Shadow Garden but from a different organization that falsely assumed the name as Shadow said. Iris also explained how she met a member of Shadow Garden named [Alpha](Alpha.md "Alpha") as she recall during the simultaneous attacks on the city. When she woke up from her daydream, Iris learn from other reports that it was known that Shadow Garden had very high combat capabilities and the rest didn't know, with Alexia adding that Shadow is fighting against the Cult of Diablos. Feeling that the artifact is the only best lead they have, Iris hopes that they will learn something more once the artifact gets deciphered. Curious, Alexia asks her sister who she thinks is the real enemy between Shadow Garden and the Cult, only for Iris to state she believes both organization are a threat and that she won't allow anyone to wreck havoc in the kingdom.

Next morning on the train to school, rumors spread that Cid had soiled himself on his way back to the dorms. A nervous Skel and Po tried to change the topic with Cid replying back that today might feel even more torturous until the two of them who were already scared immediately asked Cid if he got chocolate from yesterday. Thankful he did, they are excited to commence with their plan called 'Operation Gift Giver'.

In the school hallway during the lunchbreak, Skel nervously gives chocolate to an upper-classwoman he likes, much to her disgust. However, her betrothed arrives and wants to have a chat with Skel, as the girl even keeps his chocolate; with nothing more to do, Cid and Po take their leave. Then moments later in the library, Po claims he won't follow Skel's footsteps, elaborating that he learned all about the girl he plans on giving chocolate, to an unhealthy detail. When an excited Po approaches her, the girl he targets recognizes him as her stalker and yells for help, with Po being attacked.

Unenthused, Cid decides to give his chocolate to the first girl he sees and be over with his background character moment. When he wanted to look for the girl he chose, Cid saw Sherry who had placed a stack of research books she was carrying at the table next to him previously, while Sherry was contemplating an artifact code which was similar to the code that her mother had researched. It was at that moment that Cid immediately gave her the chocolate before leaving Sherry, who is confused at the sudden acceptance. Looking back at his gift, Sherry recognizes Cid as the blood-soaked boy from the other day.

Taking the gift to her research room, atop her paused analyze work, Sherry wonders what exactly chocolate is. As her father arrives, Lutheran recognizes the chocolate and explains its been a recent popular confection. When Sherry tells him that a boy gave it to her, her father guesses that it's a present and it must have been love at first sight. Lutheran wondered what Sherry would say to the boy as he must be waiting for her answer, even telling Sherry that while study and research is important, she also needs to learn how to interact with others. After a slight coughing fit, Lutheran reassures her that he has been feeling better lately and is lucky to have such a good daughter, as Sherry states she is the lucky one as he adopted her. Lutheran remarks how Sherry's mother would be so proud of her, given her growth as a researcher as well, and voices confidence in Sherry's abilities.

## Characters

- Skel Etal
- Po Tato
- Cid Kagenou
- Iris Midgar
- [Glen](Glen.md "Glen")
- Marco Granger
- Alexia Midgar
- Sherry Barnett
- Lutheran Barnett
- [Nu](Nu.md "Nu")
- [Gamma](Gamma.md "Gamma")
- [Alpha](Alpha.md "Alpha") (Mentioned & Flashback)
- [664](664.md "664") (Cameo)
- [665](665.md "665") (Cameo)
- [Rex](Rex.md "Rex") (Shadowed)
- Lukreia Crowley (Mentioned)

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第６話予告≪ノーマルVer.≫「偽る者」

TVアニメ『陰の実力者になりたくて！』第６話予告≪スペシャルVer.≫「陰の実力者は告白にもこだわりたい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e006>
2. <https://shadow-garden.jp/1st/story/#story6>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • **Episode 6** • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
