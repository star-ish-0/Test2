# Human

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Human](https://the-eminence-in-shadow.fandom.com/wiki/Human)

Human (人間, Ningen[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the races in the world of The Eminence in Shadow.

Humans are much weaker than the [Therianthropes](Therianthrope.md "Therianthrope") and have much shorter lives than the [Elf](Elf.md "Elf") population.

## Known Individuals

### [Earth](Earth.md "Earth")

- Akane Nishino
- Akira Nishino (Deceased)
- [Haitani](Haitani.md "Haitani")
- Yuudai Saejima (Deceased)
- [Yuuka](Yuuka.md "Yuuka") (Deceased)
- Minoru Kageno (Deceased; Reincarnated)

### The Other World

- Alexia Midgar
- [Adder](Adder.md "Adder")
- [Aurora](Aurora.md "Aurora") (Deceased; Spirit)
- [Azukay](Azukay.md "Azukay") (Deceased)
- Annerose Nichtsehen
- [Battler](Battler.md "Battler") (Deceased)
- [Borg](Borg.md "Borg") (Deceased; Spirit)
- Brad Despoht (Deceased)
- [Butcher](Butcher.md "Butcher") (Deceased)
- [Claudia](Claudia.md "Claudia")
- Christina Hope / "Jack the Ripper"
- Cid Kagenou / Shadow / Mundane Mann / John Smith / Jack the Ripper
- Claire Kagenou
- Clara Oriana (WN)
- Mr. Kagenou
- Mrs. Kagenou
- Dark Spider (Deceased)
- [Drake](Drake.md "Drake") (Deceased)
- Dunder Hedd (Deceased)
- Eliza Despoht (Deceased)
- [Fenrir](Fenrir.md "Fenrir") (Deceased)
- [Freya](Freya.md "Freya") (Deceased)
- Garter Kikuchi
- [Glen](Glen.md "Glen") (Deceased)
- Gonzales Machom
- Goldy Gilded
- [Grease](Grease.md "Grease") (Deceased)
- Haushold Hedd (Deceased)
- Imatry Nottaloos
- Iris Midgar
- [Isaac](Isaac.md "Isaac") (Deceased)
- Jack Nelson (Deceased)
- [Jean](Jean.md "Jean") (Deceased)
- [Jet](Jet.md "Jet") (Deceased)
- [Juggernaut](Juggernaut.md "Juggernaut") (Deceased)
- [Kanade](Kanade.md "Kanade")
- [Kevin](Kevin.md "Kevin")
- Klaus Midgar
- Korrupt White (Deceased)
- [Kouadoi](Kouadoi.md "Kouadoi") (Deceased)
- Lukreia Crowley (Deceased)
- Lutheran Barnett (Deceased)
- [Millia](Millia.md "Millia") (Revived)
- [Margaret](Margaret.md "Margaret")
- Marco Granger
- [Marie](Marie.md "Marie")
- [Maximilian](Maximilian.md "Maximilian")
- [Mordred](Mordred.md "Mordred") (Deceased)
- Mundane Mann (Deceased)
- [Nina](Nina.md "Nina")
- [Nonna](Nonna.md "Nonna") (Deceased)
- [Nu](Nu.md "Nu")
- Parton
- Raphael Geerk Oriana (Deceased)
- Reina Oriana (Deceased)
- Rose Oriana
- [Rex](Rex.md "Rex") (Deceased)
- [Rude](Rude.md "Rude")
- Perv Asshat (Deceased)
- [Petos](Petos.md "Petos")
- Po Tato
- [Quinton](Quinton.md "Quinton")
- [Scarface](Scarface.md "Scarface") (Deceased)
- Sherry Barnett
- [Shinobi](Shinobi.md "Shinobi") (Deceased)
- Shoddi Goodz (Deceased)
- Skel Etal
- [Stergang](Stergang.md "Stergang") (Deceased)
- Suzuki Hope (Deceased)
- Sword Demon (Deceased)
- Toppe Batterius
- White Demon (Deceased)
- [Zack](Zack.md "Zack") (WN)
- Zenon Griffey (Deceased)

## Trivia

- In Volume 4, Mordred of the Knights of Rounds speculated that humanity may not have been native to this world, based on research into the planet's history, and likely merely entered here when the realms collided.
