# Suzuki Hope

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Suzuki%20Hope](https://the-eminence-in-shadow.fandom.com/wiki/Suzuki%20Hope)

## Suzuki Hope

### Japanese

スズーキ・ホープ

### Romaji

Suzūki Hōpu

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

15

### Height

Unknown

### Hair Color

Dark Brown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Christina Hope (Distant Relative)

## Professional Information

### Occupation

Student

### Affiliation

Midgar Academy for Dark Knights

## Debut

### Light Novel

Volume 5

### Manga

Chapter 10 (Cameo)
Chapter 63 (Official Apperance)

Suzuki Hope (スズーキ・ホープ, Suzūki Hōpu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a first-year student at Midgar Academy for Dark Knights and a distant relative of Christina Hope. After his death from a bomb collar, Cid Kagenou adopted his likeness to secretly work undercover during the Cult of Diablos’ second takeover of Midgar Academy.[[1]](#cite_note-V5C5-1)[[2]](#cite_note-V5CE-2)

## Appearance

Suzuki was a short ordinary boy with slicked-back dark brown hair and glasses.[[3]](#cite_note-3)

## Personality

According to Christina, Suzuki was quiet and did not stand out.[[1]](#cite_note-V5C5-1) Inwardly, Suzuki disliked his unremarkable qualities and how he easily blended into the background. He desperately wanted to be liked and accepted at Midgar Academy. The desire made him express elation at awakening with a mysterious collar. Its strange noises and the inability to remove it did not alarm him; instead, he delusionally believed the explosive collar would help him stand out more.[MANGA ONLY][[4]](#cite_note-MC63-4)

## Chronology

### Background

A member of the Hope branch family, Suzuki lived as a minor noble.[[1]](#cite_note-V5C5-1)

### The Academy Disappearance

Suzuki suddenly passed out while practicing magic. When he awoke, a collar was around his neck. Shortly afterward, Cid Kagenou entered the room and barely remembered his name. Suzuki pleaded with Cid for assistance in removing the collar. Before anyone could act, the collar exploded, instantly killing Suzuki.[[1]](#cite_note-V5C5-1)

## Powers & Abilities

Suzuki had low magic power and mana reserves compared to Cid’s other classmates. His already meager mana and depleted state from practicing magic made him one of the first deaths in Midgar Academy’s bomb collar incident.[[1]](#cite_note-V5C5-1)

## Relationship

### Christina Hope

Suzuki's life was forfeit if he did anything to endanger the main family. Consequently, Christina's higher family status made Suzuki deferential towards her. Outside of this extreme, their relationship was only that of any distant relatives and classmates.[[1]](#cite_note-V5C5-1)[[2]](#cite_note-V5CE-2)

### Cid Kagenou

Suzuki did not engage in any relationship outside of knowing Cid as a fellow student.

## Trivia

## References

1. Volume 5. Chapter 5: An Unexpected Terrorist Attack in the Academy Again!!!
2. Volume 5. Epilogue: If I Could Get It I Wouldn’t Hesitate to Destroy the World!
3. Volume 5 Color Inserts
4. [Manga](Manga.md "Manga"). Chapter 63

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • Alexia Midgar • Christina Hope • [Isaac](Isaac.md "Isaac") • **Suzuki Hope** • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |
