# Nonna

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Nonna](https://the-eminence-in-shadow.fandom.com/wiki/Nonna)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Nonna?action=edit).

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Nonna

### Japanese

ノンナ

### Romaji

Nonna

## Characteristics

### Race

Human

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Black

### Eye Color

Red

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Claire Kagenou (Descendant)
Cid Kagenou (Descendant)

## Professional Information

### Occupation

Hero

### Affiliation

The Heroes
Cult of Diablos

## Debut

### Game

Apocrypha: Chapter 2 Part 3

Nonna (ノンナ, Nonna[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the Heroes that took part of the fight against the [Demon Diablos](Aurora.md "Aurora"). She is the ancestor of Cid and Claire Kagenou.[CITATION NEEDED]

## Appearance

Her appearance is very similar to Claire Kagenou. Unlike her Descendant, she has short length hair that she has tied in a high-side ponytail.

She also wears a battle armor similar to Olivier. However, hers is in a black and gold color scheme.

## Personality

## Chronology

## Powers & Abilities

## Relationships

### [Olivier](Olivier.md "Olivier")

### [Lily](Lily.md "Lily")

### [Freya](Freya.md "Freya")

### [Duet](Duet.md "Duet")

### [Pente](Pente.md "Pente")

### [Rouge](Rouge.md "Rouge")

### [Sarasa](Sarasa.md "Sarasa")

## Image Gallery

## Trivia

- The name Nonna (nòn·na) means "grandmother" in Italian.

## References

## Site Navigation
