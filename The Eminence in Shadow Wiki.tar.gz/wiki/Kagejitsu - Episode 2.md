# Kagejitsu - Episode 2

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%202](https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%202)

## Operation 2

## Special Title

### English

The Seven Shades want to perfect an amazing war chronicle!

### Kana

七陰は素敵な戦記を仕上げたい！

### Romaji

Shichi kage wa suteki na senki o shiagetai!

## Episode Information

### Season

1

### Episode

2

### Air Date

November 2, 2022

### Adapted From

Light Novel

## Staff

### Director

Minoru Ashina

### Writer

Daisuke Aizawa

Episode Navigation

| Previous | Next |
| --- | --- |
| Operation 1 | Operation 3 |

Operation 2 is the second episode of the spin-off series [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu").

## Summary

[Beta](Beta.md "Beta") is suffering from significant writer's block and finds herself unable to continue the Chronicles of Master Shadow. She stops wailing to look up at [Alpha](Alpha.md "Alpha"), who has just entered the room. Alpha kindly smiles and asks about her progress. Beta begrudgingly admits that while Shadow's exploits and majestic countenance would make anyone's creativity run wild, she feels her words are inadequate to represent his greatness accurately. Alpha admits that Beta's writing talents cannot fully grasp all the necessary nuisances to perfectly portray Shadow. The silver-haired elf's eyes droop in resignation, but Alpha resumes her opinion. She still believes Beta needs to continue to pursue it. The girls of Shadow Garden still enjoy her work. The kind words ease Beta's anxiety and she thanks Alpha for her encouragement. Before Alpha leaves, Beta asks about Cid's torture session. Even Alpha, who has known him the longest, does not see the purpose of his life-begging act, but she thought it was pretty convincing. Intrigued by witness testimony, Beta asks for specifics and a reenactment. Sitting on the couch, Alpha screams out for her life, gesticulating for a few seconds to oblige the writer's curiosity. Furious scribbling, Beta begins to jot down a description of the performance. She tries her hand at torture theater, asking Alpha for pointers on how to improve.

## Characters

- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")

## Gallery

End Credits

Alpha Demonstrating Mob Torture Techniques

## Trivia

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • **Episode 2** • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
