# Drake

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Drake](https://the-eminence-in-shadow.fandom.com/wiki/Drake)

## Drake

### Japanese

ドレイク

### Romaji

Doreiku

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Brown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- Archbishop
- Bishop (formerly)

### Affiliation

Holy Church of Divine Teachings

## Debut

### Web Novel

Chapter 45

### Light Novel

Volume 2

### Manga

Chapter 15

### Anime

Episode 10

Drake (ドレイク, Doreiku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was an archbishop in the Holy Land, [Lindwurm](Lindwurm.md "Lindwurm").

## Appearance

## Personality

Much of his personality is yet to be elaborated. However, allegations of child trafficking and his relationship with Victoria would imply that he was cowardly and corrupted.

## Chronology

### Background

Long ago, Drake was a Bishop who secretly became an auditor for the [Templars](Templars.md "Templars"). However, he was under suspicion of corruption and orphan trafficking when rumors of such allegations reached the royal capital of Midgar Kingdom.

At the underground chamber of Orum cathedral within the Templars' main headquarters, Drake expressed his disappointment with their [leader](Victoria.md "Victoria") after hearing reports of her mission's failure to seize [a human possessed](Nu.md "Nu") from the Cult of Diablos that eventually fell into the hands of Shadow Garden. Due to her mistake, his position within the Church was undermined until the Cult gave reason in questioning their inquisition rights.

Therefore, Drake decided to refrained Victoria's action from exercising her inquisitorial powers unnecessarily by focusing on her role as a Saint for the time being. Through this, he ensured that his role as auditor would not be jeopardized.

Although Drake served as Victoria's auditor, he was afraid that her devotion is working against her because she gained wisdom through her contact with the outside world. Because of this, Drake forced Victoria into withdrawing from the battlefield so he could brainwash her by secretly increasing the dose of the secret drug on Victoria and letting her hear the mighty "voice of the Goddess".

A year and a half later, Drake was appointed to be Archbishop and entrusted with the sacred ministry of [Lindwurm](Lindwurm.md "Lindwurm") cathedral.

## Volume 2

### Sanctuary Infiltration

Prior to the Goddess's Trial, Drake was assigned to host the event. However, the royal family of Midgar began investigating the truth about his rumors and sent Alexia Midgar.

Before Alexia had reached to Lindwurm, Drake was killed by [Venom](Venom.md "Venom") on behalf of Nelson's order in order to erase the evidence before she could arrive. [Alpha](Alpha.md "Alpha") was next to his corpse and pondered to what he was hiding to where the Cult wanted to kill him.[[1]](#cite_note-1)

After Drake's death, Nelson was appointed as the acting Archbishop to replace him as a host for the Goddess's Trial event.[[2]](#cite_note-2)

## Powers & Abilities

## Relationships

### [Victoria](Victoria.md "Victoria")

## Trivia

## References

1. Volume 2 Prologue: To Lindwurm, the Scared Land!
2. Volume 2 Chapter 1: Fun Times at the Goddess's Trial!

## Site Navigation
