# Lukreia Crowley

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lukreia%20Crowley](https://the-eminence-in-shadow.fandom.com/wiki/Lukreia%20Crowley)

## Lukreia Crowley

### Japanese

ルクレイア・クロウリー

### Romaji

Rukureia Kurourī

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Pink

### Eye Color

Pink

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Sherry Barnett (Daughter)
Unnamed Husband †

## Professional Information

### Occupation

Artifact Researcher

## Debut

### Web Novel

Chapter 40 (Mentioned)

### Light Novel

Volume 1 (Mentioned)

### Manga

Chapter 12 (Flashback)

### Anime

Episode 9 (Flashback)

Lukreia Crowley (ルクレイア・クロウリー, Rukureia Kurourī[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was Sherry's biological mother and a great researcher in the academic world.

## Appearance

Lukreia is a tall woman like any adult, with long pink hair like her daughter Sherry's but darker, with pink eyes like Sherry's, and wearing a long white researcher's robe, with which she covers her head. normal clothes that she wore.

## Personality

She behaves in a loving and gentle way with everyone around her, and a very loving side with her daughter Sherry like any mother, but at the same time a mature side.

She has a sense of loyalty, justice and care with what she does, but at the same time she is naive and innocent with whom she associates, which led to her subsequent death, when she discovered that the artifact she analyzed, which was the "Eye of Avarice".

It was a very dangerous object to be used, who wanted to deliver it to the custodian of the kingdom for his imprisonment, but she did not know that with whom she believed to be her best friend, Lutheran Barnett would kill her, since he had malicious intentions with the artifact.

## Chronology

### Biography

Lukreia was a great researcher with the best knowledge, intellect and abilities in the world. But because she is too smart, Lukreia was hated by the entire academic world at large to the point of which generated envy, jealousy, and repudiation by those around her who are in her field, even though she has no intention of disturbing and doing anything bad with anyone.

Lukreia has a daughter named Sherry and is taking care of her alone because her husband died soon after she was born. Despite all the hate and other negative things from the world's research community, Lukreia continued striving to be happy with her current situation while continuing her research into magical artifacts and the deciphering of ancient languages, albeit with her financial trouble whilst raising Sherry until she was already nine years old.[[1]](#cite_note-V1C6-1)

During that time, Lukreia met Lutheran Barnett who introduced himself as a good friend as he told her that he would help her work and fund on her research so as to ease her family's financial situation. Lukreia feels very happy about it and in her innocence without suspecting anything, she forms a friendship with Lutheran where she analyzes many artifacts that gathered by him until Lukreia examines an ancient artifact called, "Eye of Avarice".

When she realizes the potential of the artifact after analyzing by studying it, Lukreia argues with Lutheran that the Eye of Avarice cannot be used by anyone because it is very dangerous and unsafe that she decided to hand it over to the kingdom for safekeeping. But in a brief moment, Lukreia is sadistically murdered by Lutheran whom she believes to be her best friend in front of her daughter who was hiding in the closet and saw through the crack between the closet door, unaware that he was using her to analyze the artifact so he could achieve his selfish goals.[[2]](#cite_note-V1FC-2)

### Legacy

## Powers & Abilities

Like her daughter Sherry, Lukreia had a great talent for the investigation of magical objects and artifacts and analysis, she also had a great understanding and insight for ancient and magical letters, which she deciphered in order to help in the teaching of stories ancient.

Although he had no use for being able to wield magic as such, like any researcher, he could understand and decipher it very well like his daughter Sherry.

## Relationships

### Sherry Barnett

She had a deep, loving, caring and gentle relationship with her daughter, which is where Sherry was inspired to follow in her mother's footsteps as a researcher.

### Lutheran Barnett

Believing that she finally had a friend with whom she could trust, she maintained a good relationship with Lutheran, fully trusting him even after he decided to help her with her investigations, financing and so on, that in the end she did not know that he was handling her like this. It was her pleasure that she could achieve her goals apart from finding a cure for her disease, that in the end, she died at the hands of the man she trusted the most.

## Trivia

## References

1. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
2. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!

## Site Navigation
