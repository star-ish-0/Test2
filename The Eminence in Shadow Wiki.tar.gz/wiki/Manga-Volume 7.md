# Manga/Volume 7

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%207](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%207)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_7?action=edit).

## Manga Volume 7

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041115657

### ISBN EN

ISBN 978-1975362966

### Release Date

March 26, 2022 JP
July 18, 2023 EN

## Volume Information

### Pages

144

### Chapters

4

Publication Order

| Previous | Next |
| --- | --- |
| Volume 6 | Volume 8 |

This is the seventh volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

Cid’s shadowbrokering fun is interrupted when his sister Claire drags him off to the Lawless City to hunt some vampire called the “Blood Queen” or something. To fit in with this hard-boiled town, he decides to give his background character persona a break to try out a new role—a man of mystery who laughs in the face of danger! However, the legendary Red Moon that rises over Cid's carefree head might be more than just an ill omen...[[1]](#cite_note-1)

何で月が赤いのか全然わかんないけど「伝説」ってつけるとカッコイイよね！

異世界に転生し、あらゆる物事に陰から介入し実力を示す「陰の実力者」設定をエンジョイしているシドは、始祖の吸血鬼「血の女王」討伐をするという姉のクレアに連れられて"無法都市″を訪れる。
いつもみたいなモブを演じると逆に目立つ治安の悪さを誇るこの地域で、「殺伐とした状況を前に怪しく笑う謎めいた少年ごっこ」に興じることに。
ノリノリで楽しむシドの頭上に輝く伝説の「赤き月」は、凶兆を告げているのだった――。

強大な力と重度の勘違いで突き進む最強奇譚、第７弾！[[2]](#cite_note-2)

## Summary

### Bushin Festival Tournament

### Great Trade Alliance Conflict

## Chapters

- Episode 26
- Episode 27
- Episode 28
- Episode 29

## Characters

:   In order of appearance:

- [Beatrix](Beatrix.md "Beatrix")
- Perv Asshat
- [Quinton](Quinton.md "Quinton")
- Goldy Gilded
- Cid Kagenou
- Alexia Midgar
- Iris Midgar
- Rose Oriana
- [Alpha](Alpha.md "Alpha")
- Mrs. Kagenou
- Claire Kagenou
- Mr. Kagenou
- Skel Etal
- Po Tato
- [Beta](Beta.md "Beta")
- White Demon
- [Mary](Mary.md "Mary") (Debut)
- [Elisabeth](Elisabeth.md "Elisabeth") (Mentioned)
- [Marie](Marie.md "Marie") (Debut)
- [Crimson](Crimson.md "Crimson") (Debut)
- [Yukime](Yukime.md "Yukime") (Debut)
- [Juggernaut](Juggernaut.md "Juggernaut") (Debut)
- Graine (Debut)
- [Claudia](Claudia.md "Claudia") (Debut)

## References

1. [The Eminence in Shadow, Vol. 7 (manga). YenPress](https://yenpress.com/titles/9781975362966-the-eminence-in-shadow-vol-7-manga)
2. [The Eminence in Shadow (7). Kadokawa](https://www.kadokawa.co.jp/product/322103001427/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • **Volume 7** • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
