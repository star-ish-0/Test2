# Alpha/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Alpha/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Alpha/Relationships)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Main](Alpha.md "Alpha")

[Chronology](Alpha-Chronology.md "Alpha/Chronology")

Image Gallery

## Shadow Garden

### Cid Kagenou / Shadow

A friend, a mentor, a leader, and an object of affection, Cid encompasses many roles in Alpha’s life.

The pair spent an abundance of time together as children, well before Shadow Garden grew into its present power. They ate, played, trained, and lackadaisically relaxed together. Although Alpha’s organizational responsibilities have overpowered childish daydreams, she still looks at those simpler days with nostalgia and Cid with the same reverent eyes.[[1]](#cite_note-V2CP-1)[[2]](#cite_note-V6CE-2) Now, Alpha fully inhabits the role of second-in-command, acting as Shadow Garden’s leader in every way except name. The position is more than just her greatest joy; she views it as the sole reason for her existence.[[3]](#cite_note-V3CE-3)

Although many of the Seven Shadows share the same sense of purpose, Alpha and Cid’s relationship and power dynamic differ from the others. In her own words, she hopes to one day stand beside Shadow as an equal and actively works to realize that objective. She partially acts as a peer already. Instead of using honorary honorifics or titles, such as Leader, Master, or Boss, she simply calls him Cid or Shadow. Furthermore, she uses informal language in the Japanese version.[[4]](#cite_note-:4-4)

For all of her endeavors to stand next to Cid as an equal, she constantly expresses frustration and continuously worries about abandonment.[[5]](#cite_note-5) Alpha works incredibly hard to create an adequate support structure for Shadow’s ultimate goal, but he never requests assistance, utilizes available resources, and constantly intervenes without informing her. Alpha views this as confirmation of her own inferiority, believing herself to be nothing but a burden. Her reverence and Cid’s emotional disregard for those close to him further perpetuates this toxic cycle of self-loathing.[[6]](#cite_note-:1-6)[[3]](#cite_note-V3CE-3) She places him in a tier beyond reason and, wanting to act as an equal, it forces Alpha to set unrealistic expectations.[[7]](#cite_note-7)

### Seven Shadows

#### [Beta](Beta.md "Beta")

Although Alpha and Beta were acquainted before either of them joined Shadow Garden, the two did not immediately form a rapport. Instead, they grew apart. Alpha loathed Beta’s cowardice and aversion to fighting. She made no secret of her contempt and demanded that Beta find a reason to fight. After Beta discovered a path forward through literature, the relationship was no longer contentious and the two grew closer.[[4]](#cite_note-:4-4)

Currently, Alpha retains a close bond with Beta and considers her family. She likewise acknowledges Beta's competency and frequently entrusts delicate missions or complex assignments to her.

#### [Gamma](Gamma.md "Gamma")

Like Beta, Gamma is Alpha's right hand when it comes to managing Shadow Garden as she is responsible for the financial and administrative affairs of the organization. While Alpha and Beta were learning combat, Gamma lacked any ability and instead learning commerce and trade to compensate and the two would join her. During the two years the Seven Shadows established Mitsugoshi, Gamma operates as the head of Shadow Garden's operations in foreign countries to ensure special resources are found before the rest of the world or the Cult of Diablos, such as when Gamma learned of petroleum in the Velgalta Empire and moved to purchase the swathes of land where it was best to harvest it. From Alpha learning commerce and financial understanding alongside Gamma from Shadow, this allowed them both to plan brilliant commercial maneuvers and adapt to market competitors to put Mitsugoshi as the most trusted and highest quality brand name in the Midgar Kingdom. When it comes to managing resources to all of Shadow Garden, Alpha can trust Gamma to handle everything from lodging for the Numbers in Alexandria to finding the budget for whatever spontaneous experiment Eta comes up with.

#### [Delta](Delta.md "Delta")

Alpha is often the one who has to keep the "loose cannon" Delta in check. In the past, Delta once challenged Alpha for the position of Shadow Garden's second-in-command, but was soundly defeated. Since then, Delta has shown to be rather scared of Alpha, who, in turn, treats her as somewhat of an unruly pet dog. Delta has since learned to comply with Alpha's commands as though she were tamed, but Alpha can still rely on Delta when needing an unrelenting force to devastate enemy forces, such as mowing down Nelson and his clones in the Sanctuary or hunting bandits around the capital during the commerce war with the MCA.

However, despite the initial lack of respect in their relationship, Alpha deeply cares for Delta as one of her sisters. When the [Therianthrope](Therianthrope.md "Therianthrope") was presumably killed by "John Smith", Alpha was devastated and took it upon herself to avenge her.[[6]](#cite_note-:1-6) Conversely, when Delta returned and revealed that her disappearance was seemingly all part of the Shadow's plan, Alpha was so overjoyed at seeing her alive that she did not even punish her and embraced her instead.[[3]](#cite_note-V3CE-3)

#### [Epsilon](Epsilon.md "Epsilon")

Despite her pride, Epsilon deeply respects Alpha, which is why she tends to carry out the tasks assigned to her in the most effective way possible. Both are also superior spymasters, able to infiltrate even the most well-guarded of sites or conduct an information chain of intelligence gathering for Shadow Garden, such as infiltrating [Lindwurm](Lindwurm.md "Lindwurm") during the Goddess Trials or the Oriana Kingdom amid a civil war. Should Alpha be indisposed of with another mission, she can trust Epsilon to carry out spy work or to aid Shadow in whatever situation he needs, such as finding Rose Oriana or stopping the Black Rose.

Due to Alpha's status as the head of the Seven Shadows and the closest to Shadow, as well as her ample figure like the others, Epsilon's daily practice with the Slime Bodysuit ironically made her as masterful with her magic manipulation as Alpha. Epsilon's skill made it so that both she and Alpha can cure [Possession](Possession.md "Possession") like their master.

#### [Zeta](Zeta.md "Zeta")

While respecting Zeta's skills, Alpha wishes that she could report in more often as the [Therianthrope](Therianthrope.md "Therianthrope") tends to go long stretches of time without communication to explore the world for Shadow Garden. She also remains unaware that Zeta is superseding her authority by having created her own splinter faction within Shadow Garden loyal solely to her. While Alpha was aware of Zeta aiding Shadow during the Academy disappearances, she was unaware of Zeta using Claire Kagenou in a plan to revive [Diablos](Aurora.md "Aurora").

#### [Eta](Eta.md "Eta")

Alpha seemed to be wary of Eta as she became worried when Beta wanted to hand the Earthling she captured to the researcher.[[8]](#cite_note-:3-8)

### Numbers

#### [Iota](Iota.md "Iota")

Iota's minimal consideration of respect frequently evokes a humorous response from Alpha rather than censure. [CITATION NEEDED]

#### [Lambda](Lambda.md "Lambda")

#### [Nu](Nu.md "Nu")

#### [Chi](Chi.md "Chi")

Alpha originally had mixed Feelings regarding Chi. Alpha was initially quite angry at her for turning a blind eye to everything the Cult was doing, in her own territory no less. However, she also believed that everyone who had suffered from [Possession](Possession.md "Possession"), even her, had the right to abandon their old life and turn over a new leaf.[CITATION NEEDED]

She would eventually come to respect Chi's determination to set things right.[CITATION NEEDED]

#### [Omega](Omega.md "Omega")

### Members

#### [Victoria](Victoria.md "Victoria") (559)

She initially held a significant amount of animosity towards her, mainly because of her and the [Templars](Templars.md "Templars")' intentions of killing The Possessed on sight, to the point of stating outright that the destruction of the Templars takes precedence even over the destruction of the cult. However, she also holds a certain amount of respect for her skills as a warrior, stating that they were almost on par with her own.

Her current opinion of her now that she has joined Shadow Garden is unknown.

#### [664](664.md "664")

As Rose's team leader, Alpha was pleased by her leadership for the time she had been active.[CITATION NEEDED] Following Oriana Kingdom becoming an allied territory, 664 resumed her original name of Nami during a mission from Alpha to be Rose's bodyguard while undercover as a royal maid.

#### [665](665.md "665")

Following Oriana Kingdom becoming an allied territory, 665 was assigned a mission from Alpha to be Rose's bodyguard while undercover as a royal maid.

#### Akane Nishino / "Akane Nishimura" (712)

Despite having never directly met the Otherworlder, Alpha was concerned enough for her safety that she placed Akane under Beta's custody, fearing what Eta would do to her if she got her hands on her.[[8]](#cite_note-:3-8)

### Associates

### Mist Dragon

#### [Yukime](Yukime.md "Yukime")

Having learned that she was her master's partner in the counterfeit bill enterprise, Alpha went to Yukime to recruit her so that Yukime could carry out Mitsugoshi Company's more unscrupulous activities while the reputable conduct was handled by Gamma. Alpha has since developed a respectful working relationship with Yukime.[[9]](#cite_note-:2-9)

#### Rose Oriana (666)

Upon learning that Shadow had personally cured and empowered the princess, Alpha recruited Rose herself and brought her to [Alexandria](Alexandria.md "Alexandria") for training under [Lambda](Lambda.md "Lambda"). While uncertain of why Shadow helped Rose, Alpha concluded that it regarded the Oriana Kingdom and was proven correct when Rose exposed Duke Perv Asshat's conspiracy and corruption to the public before drawing out [Mordred](Mordred.md "Mordred") into the open. As such, Alpha dedicated covert resources to Oriana while the kingdom was hindered by international trade sanctions from the Cult of Diablos promoting smear campaigns against Rose's rule. Alpha sees Rose as a potential recruit into a new Seven Shadows unit and endeavors to help in honoring Shadow's wishes.[CITATION NEEDED]

## Other

### Claire Kagenou

Both Alpha and the rest of the Shadow Garden's members usually refer to her with immense respect. After her kidnapping and on Alpha's orders, Shadow Garden members often watch over her in order to make sure she is safe.[[4]](#cite_note-:4-4) Part of the reason for this respect is because the Numbers wish to protect their lord's cherished sister and to monitor her safety, as she was Cid's earliest known patient to be cured of [Possession](Possession.md "Possession")-- a valuable resource should the Cult of Diablos learn such.

### Alexia Midgar

Despite Alexia having forced Cid into a relationship with her, Alpha seems unbothered by this fact contrary to Beta, as Alpha is still assuming that it was just a ruse on Cid's part to learn about the cult's plans-- such as intercepting Zenon Griffey.

### Iris Midgar

Alpha met Iris while fighting off the mutated [Millia](Millia.md "Millia"), during which she chastised the princess for unknowingly prolonging the girl's suffering. Afterward, Iris warned the elf to not interfere with her and her men's duties, but Alpha just scoffed and relegated her to an audience viewer.[[10]](#cite_note-10)

### Skel Etal & Po Tato

## References

1. Volume 1 Prologue: Preparing the Perfect Stage!
2. Volume 6 Epilogue: That Nostalgic Smell
3. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills!
4. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
5. Volume 6 Prologue: There Are People Ruling the Midgar Kingdom from the Shadows? I'm So Jealous!
6. Volume 3 Chapter 6: Circulating Counterfeit Cash!
7. Volume 5 Chapter 4: Peace in Our Time!
8. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
9. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fakes Bills!
10. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
