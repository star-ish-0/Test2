# Aurora/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Aurora/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Aurora/Image%20Gallery)

[Main](Aurora.md "Aurora")

[Chronology](Aurora-Chronology.md "Aurora/Chronology")

[Relationships](Aurora-Relationships.md "Aurora/Relationships")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

First meeting

Profile

Calamity Witch: Aurora

Fighting Words: Aurora

Swaying Moonlight: Aurora

Seven Shadows Part 3 Secret of Sacra 11: The 7 Young Shadows vs Aurora - Sanctuary

Summer Night Bloom: Aurora

Game Event: Elisabeth and Aurora wearing a Yukata

Game Event Apocrypha: Elisabeth and Aurora

Reign of Violet Light: Shadow & Aurora

Aurora possessing and controlling the demonic Claire - launching an I Am Atomic

The Mysterious and Beautiful school nurse: Aurora
