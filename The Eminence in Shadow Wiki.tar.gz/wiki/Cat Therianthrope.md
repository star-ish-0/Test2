# Cat Therianthrope

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Cat%20Therianthrope](https://the-eminence-in-shadow.fandom.com/wiki/Cat%20Therianthrope)

Cat Therianthrope is a species of therianthropes.

## Overview

The Cat Therianthropes have cat ears and cat tails.

## Tribes

Golden panther

## Known Individuals

- [Kana](Kana.md "Kana")
- [Natsu](Natsu.md "Natsu")
- [Zeta](Zeta.md "Zeta")
