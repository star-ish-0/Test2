# Bushin Festival

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Bushin%20Festival](https://the-eminence-in-shadow.fandom.com/wiki/Bushin%20Festival)

Bushin Festival (ブシン祭（さい）, Bushin-sai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a massive biennial swordplay tournament hosted in Midgar Kingdom, where skilled fighters and dark knights from all over the world come to make a name for themselves.[[1]](#cite_note-V1C4-1)

## Background

The Bushin Festival is an international tournament held at Midgar Kingdom that attracts fighters from other lands across the world that is held once every two years. Here the fighters display their skills and strength before the king and other powerful nobles attending as guests who watch how the fights will play out.

Besides the local fighters, there are also famed renowned knights from around the world come to participate. Not only that, Midgar Academy for Dark Knights also especially has an obligation to send their representatives to the Bushin Festival by holding a qualifying preliminary through a Selection Tournament (選抜大会, Senbatsu Taikai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) to determine a student that will represent the Academy.

Apparently, the Bushin Festival superficially was for sport for all have different races, nationalities, and occupations as they nonetheless share a strange sense of unity and the common goal of wanting to enjoy the event. The winner is awarded a trophy.

## Organization

For the tournament, the fighters use dulled blades. The preliminary rounds have a bracket elimination style tournament, where only the leader of each group proceeds. The primary rounds are head-to-head elimination.

Before the main festival, The Midgar Academy for Dark Knights has a special bracket to determine the students who will represent the school at the festival.

During the festival, the fighters register at the reception.

After registration the preliminaries begin. These matches take place in grassy fields outside the capital. They have very few spectators and the quality of the fights is low since they involve a large number of inexperienced fighters.

From the third round, the fights are held in the arena in Midgar.

## Past Participants

- [Beatrix](Beatrix.md "Beatrix") (First Champion)
- Lutheran Barnett
- [Willow](Willow.md "Willow")
- [Grease](Grease.md "Grease")
- Iris Midgar
- [Quinton](Quinton.md "Quinton")
- Goldy Gilded
- Gonzales Machom
- Annerose Nichtsehen
- Claire Kagenou
- Cid Kagenou / "Mundane Mann" / Shadow (Disqualified)
- Rose Oriana (Disqualified)
- [Kevin](Kevin.md "Kevin") [MANGA ONLY]
- Imatry Nottaloos [ANIME ONLY]

## Trivia

- The word "Bushin" in Japanese Kanji means Warrior God.

## References

1. Volume 2. Chapter 4: This Situation Calls for a “Who Is That Guy?!”
