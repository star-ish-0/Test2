# Alexia Midgar/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Alexia%20Midgar/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Alexia%20Midgar/Image%20Gallery)

Main

Chronology

Relationships

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

At the cafeteria

Biography

Alexia bathing.

Uneasy alliance with Claire.

Anime portrait

Alexia in her Midgar Academy Uniform

Cid confessing to Alexia.

Alexia grabbing lingere.

Cid and Alexia sparring.

Alexia confronting Zenon.

Confused.

Alexia, Rose, and Natsume forming an alliance.

Rose carrying Alexia.

Royal Escort: Alexia Midgar

Idolized Swordplay: Alexia Midgar

Santa's Little Tease: Alexia Midgar

Queen of Luck: Alexia Midgar

Elegant Curves: Alexia Midgar

Royal Fan Service: Alexia Midgar

In-game model; Royal Fan Service

Imperfect Swordplay: Alexia Midgar

Ageless Bloodline: Alexia Midgar

Clever & Lucky Bunny Girls!

Game Event: Apocrypha "Requiem for the Falling Shadows": Demonic Alexia Midgar

Game Event: Apocrypha "Requiem for the Falling Shadows": Demonic Alexia Midgar

Game Event: Apocrypha "Requiem for the Falling Shadows": Demonic Alexia & Beta

[Second Majin Transformation Princess] Alexia Midgar

In-game portait.

Princess's Hospitality: Alexia Midgar
