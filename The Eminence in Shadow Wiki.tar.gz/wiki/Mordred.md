# Mordred

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mordred](https://the-eminence-in-shadow.fandom.com/wiki/Mordred)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Chronology](Mordred-Chronology.md "Mordred/Chronology")

[Relationships](Mordred-Relationships.md "Mordred/Relationships")

Image Gallery

## Mordred

- Light Novel
- Manga
- Anime

### Japanese

モードレッド

### Romaji

Mōdoreddo

### Aliases

Knight Beyond Men
The Transcendent Spellsword

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Fiery-Red
Snow-Silvery White (WN)

### Eye Color

Light Grey

### Birthday

Unknown

## Personal Information

### Status

Deceased; Alive (WN)

## Professional Information

### Occupation

9th seat of the Knights of Rounds

### Affiliation

Cult of Diablos

## Debut

### Web Novel

Chapter 166

### Light Novel

Volume 4

### Manga

Chapter 45

### Anime

Episode 20

## Portrayal

### Japanese

[Takehito Koyasu](https://en.wikipedia.org/wiki/Takehito_Koyasu "wp:Takehito Koyasu")

### French

Arnaud Leonard

### Italian

[Patrizio Prata](https://en.wikipedia.org/wiki/it:Patrizio_Prata "wp:it:Patrizio Prata")

Mordred (モードレッド, Mōdoreddo[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the 9th seated Knight of Rounds and the leader of the Cult of Diablos faction operating in the Oriana Kingdom.[CITATION NEEDED] When his underling's blunder resulted in the Cult's activities being exposed, he attempted to destroy the Kingdom as a cover-up, only to be thwarted and killed by Shadow.[CITATION NEEDED]

## Appearance

Mordred was a tall, dashing handsome man with long red hair and light gray eyes as his muscular body wears body armor with a long cape up to the metal boots.

## Personality

Mordred is shown to be a charismatic individual who is highly arrogant and megalomaniac in possessing a superiority complex with violently domineering, regularly displaying a lack of conscience and empathy.[CITATION NEEDED]

Mordred also has no tolerance for his subordinates who failed him or the Cult as he is willing to kill his useless subordinates, when he had killed Perv Asshat for his failures of taking over the Oriana Kingdom. His cold nature is widely feared by those who are aware of him.[CITATION NEEDED]

## Powers & Abilities

Being the 9th Seat Round Knight, Mordred was considered the strongest Cultist and also one of the Cult of Diablos executive leader.[CITATION NEEDED]

In the Web Novel, he was able to heavily injure Epsilon in one-to-one combat, although he caught her off-guard by surprise and beat [664](664.md "664") and [665](665.md "665") to near death. Mordred's endurance is strong enough that he could survive Shadow's attack "I Am Atomic" even though his right arm was severed.[CITATION NEEDED]

### Swordsmanship

Mordred was a skilled swordsman as he could easily kill normal people with a single swing of his sword.

### Weapons and Equipment

Mordred's primary weapon is the eleven artifact, Invisible Blade. True to its name, this legendary weapon possesses a completely unseen edge, making its length, trajectory, and movements entirely impossible to track with the naked eye.[[1]](#cite_note-V4C3-1)

## Trivia

- His name is based on the real knight [Mordred](https://en.wikipedia.org/wiki/Mordred "wp:Mordred") from Arthurian legend.[CITATION NEEDED]
- In the novel, Mordred's fate was different.
  - In the Web Novel, Mordred is still alive, and his powers are much stronger than his Light Novel counterpart, where he has beaten [664](664.md "664"), [665](665.md "665") to near death, and even gave a surprise attack to [Epsilon](Epsilon.md "Epsilon") until she is barely injured.[CITATION NEEDED]

## References

1. Volume 4 Chapter 3: Crashing the Ceremony!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | [Loki](Loki.md "Loki") • [Hel](Hel.md "Hel") • [Jormungandr](Jormungandr.md "Jormungandr") • [Fenrir](Fenrir.md "Fenrir") • **Mordred** • [Petos](Petos.md "Petos") • Jack Nelson • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • Sir Gaunt | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • [Jean](Jean.md "Jean") • Dark Spider • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • [Gray](Gray.md "Gray") • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • Reina Oriana • [Isaac](Isaac.md "Isaac") | |
