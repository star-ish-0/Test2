# Dark Spider

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Dark%20Spider](https://the-eminence-in-shadow.fandom.com/wiki/Dark%20Spider)

|  |  |  |
| --- | --- | --- |
| “ | They must have interceded. But that just means I have some obstructions to remove… nothing more. | ” |
| — Dark Spider, Light Novel Volume 05 | | |

## Dark Spider

### Japanese

闇（やみ）蜘蛛（くも）

### Romaji

Yami Kumo

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Silver

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

First Children (Named Child)

### Affiliation

Cult of Diablos

## Debut

### Light Novel

Volume 5

### Manga

Chapter 58

The Dark Spider (闇（やみ）蜘蛛（くも）, Yami Kumo[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was an assassin and Named First Child of the Cult of Diablos. Often sent by the Cult of Diablos to assist in clandestine operations, his final mission was to continue the work of [Jean The Wicked Smile](Jean.md "Jean") by kindnapping students from the Midgar Academy For Dark Knights. However he never managed to fulfill the [Fenrir's](Fenrir.md "Fenrir") request as upon trying to kill Cid Kagenou he was unable to kill Cid and ended getting killed himself.[[1]](#cite_note-V5C1-1)

## Appearance

Others describe the Dark Spider as an old man with long silver hair, chiselled facial features, and penetrating eyes—reflective of an eagle. He wore a black robe made of dark spider silk.[[1]](#cite_note-V5C1-1)

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Today just wasn’t your lucky day, kid. | ” |
| — Dark Spider, Light Novel Volume 05 | | |

Like many members of the Cult, the Dark Spider demonstrated a ruthlessness to fulfil their purpose and complete confidence in his combat capabilities.[[1]](#cite_note-V5C1-1)

## Chronology

### The Silent Assault on Midgar Academy

On a moonlight night, the Dark Spider resided on the roof of Midgar Academy for Dark Knights, contemplating future actions. Turning around after deliberation, he is startled by the presence of an academy student. The student quickly tries to walk away, but any witnesses would jeopardize the mission. Although the student promises not to inform anyone, the Dark Spider mercilessly strikes the unfortunate kid.[[1]](#cite_note-V5C1-1)

Surprisingly, the student dodged his attack. Between the boy’s evasion skills and believable disguise, the Dark Spider suspected that the Academy student was a member of the Knight Order special forces. Doubtlessly, the mysterious student killed Jean; however, the Dark Spider believes that his strength surpasses his fellow Named Child and reengages the target. Instead of dodging, the attack is parried by a black talon on the student's hand. The Dark Spider immediately recognized the transforming weapon as belonging to Shadow Garden agents. His attempt to disengage failed as the Shadow Garden operative closed the distance in an instant, ripping out his heart.[[1]](#cite_note-V5C1-1)

In The Dark Spider's final moments, he quietly apologized to Master [Fenrir](Fenrir.md "Fenrir") as his body fell off the roof and impaled itself on a statue. His corpse was discovered by students and staff the next morning.[[2]](#cite_note-V5C2-2)

## Powers & Abilities

As a member of the First Children—an elite group of dark knights considered the Cult of Diablos’ strongest military force—The Dark Spider possessed physical strength and magical powers beyond the average knight. For his accomplishments, The Cult granted him a name, indicating his superiority to his fellow First Children.[[1]](#cite_note-V5C1-1)[[3]](#cite_note-V151-3)

## Relationships

### Cult of Diablos

#### Knights of Rounds

##### [Fenrir](Fenrir.md "Fenrir")

#### Named Children

##### [Jean](Jean.md "Jean")

### The Midgar Academy for Dark Knights

#### Shadow

## Trivia

## References

1. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
2. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
3. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | [Loki](Loki.md "Loki") • [Hel](Hel.md "Hel") • [Jormungandr](Jormungandr.md "Jormungandr") • [Fenrir](Fenrir.md "Fenrir") • [Mordred](Mordred.md "Mordred") • [Petos](Petos.md "Petos") • Jack Nelson • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • Sir Gaunt | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • [Jean](Jean.md "Jean") • **Dark Spider** • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • [Gray](Gray.md "Gray") • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • Reina Oriana • [Isaac](Isaac.md "Isaac") | |
