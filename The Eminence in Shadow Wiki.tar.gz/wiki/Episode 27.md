# Episode 27

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2027](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2027)

## Something Precious

### Kana

大切なもの

### Romaji

Taisetsu na mono

## Special Title

### English

The Eminence in Shadow wants to be entrusted with dying words!

### Kana

陰の実力者はダイイングメッセージを託されたい！

### Romaji

Kage no Jitsuryokusha wa Daiin Messēji o Takusaretai!

## Episode Information

### Season

2

### Episode

7 (27)

### Air Date

November 15, 2023 JP & EN

### Adapted From

Volume 3 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

Grayscale dominator

### Ending

Everything is Changing

Episode Navigation

| Previous | Next |
| --- | --- |
| John Smith | The Dragon's Tears |

Something Precious (大切なもの, Taisetsu na mono[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the seventh episode of the second season, and the twenty-seventh episode of [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

The Major Corporate Alliance has forced closure of all their storefronts, bringing the citizens' unrest to its peak. But can Shadow Garden weather the storm? [[1]](#cite_note-1)

大商会連合の崩壊が始まり、ミツゴシ銀行にも破綻の危機が迫る。
シャドウの裏切りと絶望的な状況にアルファたちが憔悴する中、彼の残した“暗号”がついに解読される。[[2]](#cite_note-2)

## Summary

The circulation of counterfeits has destroyed public confidence in the Major Corporate Alliance banknotes. Citizens in the royal capital find paying for commodities increasingly challenging as more businesses refuse MCA's paper money. Exchange for gold is likewise becoming difficult as liquid assets dwindle. Mitsugoshi Company's notaries have remained legal tender, but trust has diminished.

As thousands of citizens form lines outside Mitsugoshi's main bank, morale is low in the higher ranks of Shadow Garden. [Gamma](Gamma.md "Gamma") gazes at the forming crowd. After closing the curtain, she falls into silent contemplation. [Eta](Eta.md "Eta")'s solemn eyes decipher Shadow's coded message while [Beta](Beta.md "Beta") and [Nu](Nu.md "Nu") discuss the company's monetary projections. Their worry soon pauses the conversation, and they gaze dejectedly at a room. Alpha has isolated in the main office after learning John Smith was Shadow. Curled into a ball by the fireplace, she laments the perceived betrayal.

Outside an MCA bank branch, men in suits load suitcases of gold coins into a carriage. A bystander comments that they have been seen redeeming banknotes at other bank affiliates. The citizens gaze back at the bank, only to find a locked door and a closed sign, escalating the already elevated distrust of paper currency. [Yukime](Yukime.md "Yukime") savors the result from afar and walks away from the disgruntled mob.

As the situation continues to spiral, [Gettan](Gettan.md "Gettan") demands answers from Garter. He informs the lycanthrope warrior the source of the counterfeits remains an enigma, but Yukime is the mastermind. Garter elaborates that carriages transporting exchanged gold were identified as Snow Fox Corporation vehicles. The company acts as a front for the White Tower, and the wagon's conveyance of gold coins follows an identical route as the counterfeit bills. An incredulous Gettan tries to rationalize the revelation, knowing Yukime turned to prostitution to survive. The sound of the bells startles Gettan out of contemplation. Garter, lacking the therianthrope senses, questions his sudden reaction. Gettan senses her formidable presence amid the crowd. He clutches his pocket watch, adorned with a braided lanyard and bells, and orders the carriage to stop.

The situation has not changed at the Mitsugoshi Company's headquarters as Gamma watches over a despondent Alpha. Gamma updates her about the MCA closing storefronts due to insolvency. Citizens' unrest has reached a boiling point, and bank riots are breaking out. Customers are also racing to Mitsugoshi banks to exchange what they can for gold, overwhelming their company cashiers. Liquid reserves are proving inadequate for the exigency. Gamma reports they only have a few days left before their vaults are devoid of gold; adding their domestic and foreign assets would not stave off a credit collapse. A projected graph [Nu](Nu.md "Nu") receives confirms the situation—a steady upward trajectory turns into a steep decline. Gamma suggests plans to stop the escalating bank run, like showing enormous stacks of gold to placate public anxiety, but Alpha dismisses the idea. Shadow was John Smith; he instigated the credit crisis, which must have been what he wanted. Gamma denies Shadow abandoning them, but Alpha rationalizes the situation differently. Even with all the wisdom and resources he shared, they did not meet his expectations; thus, he discarded them. As Alpha recalls her pledge to Shadow, a crestfallen Gamma slumps to the floor. "If that is what you wish, I will give you my life."

Nu enters, finding the two leaders in a depression. She chooses to begin her report regardless of the room's atmosphere. Investigations revealed solid evidence that Gettan was a Cult of Diablos agent who conspired to circulate counterfeit bills in a plot to bankrupt Mitsugoshi. Gamma satirically expresses flattery as the Cult saw Mitsugoshi as a threat without knowing their secret affiliation with Shadow Garden. Shadow foresaw the plan and took advantage of the companys economic warfare. Gamma's comments prompt Alpha to have an epiphany. The Cult of Diablos' objective of circulating the counterfeits had not commenced; instead, Shadow took the initiative. Shadow created the whole scenario by distributing the counterfeits under an alias while cutting off contact, but Alpha is unsure of the purpose. Interrupting Alpha's cogitation, Beta enters with news that they successfully cracked Shadow's code and offers the translated message. Reading it, Alpha joyously sheds tears and sniffles that their master did not abandon them. In the note, Shadow clarifies that he has turned traitor. He has to forsake his name and begin printing counterfeit bills with an accomplice to bring his plan to fruition. All the gold exchanged for counterfeit MCA notes is stored where his sister was previously held captive. Shadow concluded they might resent him for it, but he maintains that his choice was for the best.

The trio expresses joy and marvels at Shadow's ingenious stratagem and remarkable foresight. To counter the Cult's plot against Mitsugoshi, he utilized their scheme against them. He collected a tremendous fortune for them to survive the economic crisis. The Cult will lose the MCA for a financial and trade partner. Beta attests that the Cult chose the wrong battle because Shadow's comprehension of credit creation is unrivaled. Gamma praises his bold effort to collect the funds, conscious of the precariousness of a credit collapse. Shadow concealed his identity to remove any traceable connections from the counterfeit banknotes. It hid the link between the Mitsugoshi Company and Shadow Garden. Beta concludes that Shadow chose a spot they were familiar with to mark where they would need to go to recover their gains. "In fooling your enemies, first deceive your allies." All that remains is the retrieval of the gold. Alpha recalls how he told her she would understand when his plan was finalized and that it was the best option. She concludes that he was correct. Gamma hesitatingly asks after [Delta](Delta.md "Delta"), but Alpha reassures them not to worry and calls to an open window. Delta's ears and then face slowly make an appearance. Beta and Gamma hug her as Delta tries to justify her absence. Delta begins to clarify that she was on a confidential mission for Shadow but stops the explanation; the information is a secret. Alpha tenderly reproves her grammar, as Cid would not use redundant compound adjectives. The trio continues to hug her, much to Delta's confusion.

That evening, John Smith rhapsodically slaughters more men looking into the counterfeit production. Lone overtime work without proper remuneration is of no consequence. [Yukime](Yukime.md "Yukime") expressed no interest in monetary gains, and Cid is welcome to keep all the profit. Returning to the cave, Cid contemplates shadow broker scenarios as he prepares to conclude the operation. The leading idea is standing on a clock tower and murmuring profound but meaningless words. Eminence daydreams cease as an empty room greets him. A heavy silence befalls the area. Yuikme's attendants, [Natsu](Natsu.md "Natsu") and [Kana](Kana.md "Kana"), break the silence with pattering feet. They rush into the room, announcing they have lost contact with Yukime. John Smith tunes out their words, pondering how such a heist could have occurred. At the mention of [Gettan](Gettan.md "Gettan"), he suddenly turns his head, silencing the pair. The masked gentleman maniacally laughs, perceiving Gettan as the perpetrator. The empty jail cell finally attracts the notice of therianthropes, but Kana thinks it is hasty to assume Gettan is the perpetrator. John Smith's mana blazes in a rage, frightening the girls and cutting off any more conversations. He proclaims that Gettan will return what is precious to him.

Citizens-led riots continue to escalate in the royal capital. MCA bank notes are now being used as kindling over large street bonfires. Uninterested in the turmoil, Gettan collapses, having been mortally wounded by Yukime's war fans (tessens). Her golden-haired, nine-tailed fox technique overwhelms the warrior. Gettan frustratingly croaks that things would be different if he had that power. Nothing would have been taken from him. Frustration turns to anger as Gettan voices Yukime's unjustified betrayal, turning against him. As he rants about how he could do more with money and power, Yukime confesses that something unknown has altered him. Regardless of evolution and the murder of Yukime's mother, Gettan once saved her and the village. There are vestiges of hope that the man she knew remains inside Gettan. She concludes their battle with those words, sparing Gettan's life. Perceiving Yukime's departure as ridicule, Gettan retrieves a vial of red pills from his pocket. Consuming one, he gains a power boost and uses his snapped blade to cut Yukime's back. As his eyes regrow, a bloodthirsty Gettan declares he should have killed her back then. Gazing at Yukime's lacerated back with regained sight reminds Gettan of that day he murdered her mother. A traumatic episode overtakes Gettan, but he pushes through to finish her. A timely attack from John Smith interrupts the coup de grâce.

A stunned Yukime sees John interposing himself between herself and her oppressor. Gettan mocks him for coming into the open, but John Smith does not replay the taunt. Clashing with Gettan's blade, the masked fighter states he is there to retrieve something precious to him. Gettan thinks the special item means Yukime, recalling how she was before his treachery. John Smith exclaims he knows Gettan is the one who stole from him and reiterates his reclaim of his precious thing. Gettan roars that his claims are hypocritical and he would not feign ignorance. As their fight rages around the snow embankment, Yukime retrieves Gettan's pocket watch, thinking how it would have been simpler for John Smith to abandon her. His ambiguous declaration of "something very precious" leads Yuikme to the same conclusion Gettan reached. Yukime's reflection on his compassion halts when Gettan is sent flying past her, bloodied by John Smith's wrathful assault. John Smith demands that Gettan voice the truth, but Gettan refutes his demand, claiming he has nothing to say. Gettan tries to swallow the rest of the pills in the bottle, but Gettan's actions are again interrupted by John Smith. A swift stomp in Gettan's mouth is followed by another demand for Gettan to talk. Every refusal to speak is punished with another beating. John Smith's obscene power makes Gettan recall the masked monster who took his eyesight years ago. He starts to weep, confessing that all he ever wanted was the power to protect. The moribund Gettan points to Yukime and entrusts his precious treasure to John Smith in his last breath. The masked fighter tells the now-dead Gettan his treasure will be "in good hands" as he hugs Yukime to heal her wound. Yukime weakly trundles over to her savior and collapses in his arms. Embracing the wounded woman, John Smith administers first aid, healing her wound. The magic coursing through her body is reminiscent of someone who healed her when her village was destroyed. Yukime suddenly realizes that the suit-wearing healer is the boy who saved her life and tearfully thanks him for all he has done. The only response is a question regarding whether Gettan said it was under the snow.

Inside the capital, the collapse of the Major Corporate Alliance has mandated official intervention. Iris Midgar and the Crimson Order raid the MCA vault only to find it empty. As Garter attempts to make excuses, Iris orders Marco Granger to arrest Garter. A few of his crimes are disrupting the market and offensive actions against the royal distribution network. Iris walks away, a severity to her gaze.

Yukime returns to a worried [Kana](Kana.md "Kana") and [Natsu](Natsu.md "Natsu"). They question the whereabouts of John Smith. Grasping Gettan's pocket watch and bell lanyard, Yukime explains that he has gone to give him a proper burial. Yukime is similarly confused at the empty storeroom as a dark figure emerges from the shadows. Alpha formally introduces herself as Kana and Natsu stand guard, but Yukime waves them down. Alpha sees Yukime's confusion and confesses to Shadow's compartmentalization. She hands the Spirit Fox a letter belonging to Gettan. Shadow Garden seized relevant documents before the royal investigation into the MCA dissolution. Yukime tells Alpha that the handwriting is sloppy but is not necessarily due to Gettan's eyesight. In their youth, she often acted as his scribe due to his penmanship and inability to sit at a desk. Alpha elaborates how the Cult of Diablos is responsible for Gettan's change, taking advantage of his weaknesses. Shadow is at war with them, and Shadow Garden is supporting his efforts. Alpha surprises Yukime by revealing how Mitsugoshi Company is the public front of Shadow Garden. Yukime successfully deduces that all her gold will be used to survive the credit crisis. Alpha understands if Yukime wishes to feel betrayed by this revelation, and Shadow is ready to bear responsibility. The Spirit Fox instead expresses only gratitude and accepts Alpha's proposition to join their ranks. The Mitsugoshi Company would continue to handle public associations, and the Snow Fox Corporation would act as a liaison for the underworld. Thanks to the new funds, towers of gold greet the anxious customers as Gamma and her staff exchange coins for bills. The mountain of gold and the irreproachable exchange process has restored public trust in the Mitsugoshi Company.

Cid continues digging for the gold he thought Gettan had buried in the snow. His "happy ending" seemed just in his grasp, but now the money is missing, Mitsugoshi is stable, and Yukime is quiet. [Delta](Delta.md "Delta") helps him dig and pesters him to honor his promise to do what she wants. Cid retorts that he promised to do anything within his abilities and wishes he had a voice recorder to prove she was lying. At Delta's confusion, Cid clarifies that a voice recorder is a "weapon of the shadows" and could destroy the world, shocking the therianthrope. Cid compromises but cannot guarantee anything as he is not Santa Claus. Cid describes Santa Clause as a fiendish demon lord in red who betrays people's dreams. Those crushed dreams and despair are used to paint his robe red. Delta expresses alarm at this revelation. Cid explains that he was not immune to the red demon lord's powers. Santa betrayed him because his dream never came true. Delta asks what his dream was, but Cid stops himself from revealing his Eminence in Shadow goal. Cid has decided never to tell people what matters to him. Circling back to the point, he is not Santa and cannot give her anything. Delta points out Santa does not give people what they want either. They come to a mutual agreement of not understanding each other and move on. Cid tells Delta he is departing on a journey. He wants her to think hard about what she would want from him and to tell him once he returns.

Cid's "personal discovery journey" is to give the women in his life some space. He believes they are furious with him. After they "cool off", he will casually return after a suitable length of time without apologizing. It is Cid's secret technique for interpersonal relationships. Exhaust the other party until they give up. As he leaves, Delta discovers something and calls for Cid, only for him to be out of earshot and gone.

## Characters

- [Gamma](Gamma.md "Gamma")
- [Eta](Eta.md "Eta")
- [Nu](Nu.md "Nu")
- [Beta](Beta.md "Beta")
- [Alpha](Alpha.md "Alpha")
- [Yukime](Yukime.md "Yukime")
- [Gettan](Gettan.md "Gettan")
- Garter Kikuchi
- Claire Kagenou (Mentioned)
- [Delta](Delta.md "Delta")
- [Juggernaut](Juggernaut.md "Juggernaut") (Mentioned)
- Cid Kagenou/John Smith
- [Kana](Kana.md "Kana")
- [Natsu](Natsu.md "Natsu")
- Iris Midgar
- Marco Granger

## Promotional Videos

「陰の実力者になりたくて！ 2nd season」 第7話予告≪ノーマルVer.≫「大切なもの」

『陰の実力者になりたくて！ 2nd season』 第7話予告≪スペシャルVer.≫「陰の実力者はダイイングメッセージを託されたい！」

## Trivia

- The passage of time suggests Eta's decryption took between six to twelve hours after Shadow handed the message to Beta.[CONJECTURE]
- After Eta relays the decoded note, the message "I'm Tired" (つかれあ, Tsukarea[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is visible. It is written in [Hiragana](https://en.wikipedia.org/wiki/Hiragana) with the native script underneath.
- While Delta used "hush-hush secret mission" and Alpha corrected her, this is because Cid is much more casual around Delta and Alpha hasn't heard him use informal vernacular.
- The reaction to the Midgar Kingdom's credit collapse is comparable to the bank runs that followed [Earth's 1929 market crash](https://en.wikipedia.org/wiki/Wall_Street_Crash_of_1929). The difference is confidence in the solvency of banks was lost through counterfeits rather than a stock market crash.

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e027>
2. <https://shadow-garden.jp/story/#story7>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • **Episode 7** • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
