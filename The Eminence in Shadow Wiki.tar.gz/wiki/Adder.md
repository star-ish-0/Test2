# Adder

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Adder](https://the-eminence-in-shadow.fandom.com/wiki/Adder)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Adder?action=edit).

## Adder

### Japanese

ハブ

### Romaji

Habu

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Crimson Order Vice-Commander

### Affiliation

Cult of Diablos
Crimson Order

## Debut

### Light Novel

Volume 5

Adder (ハブ, Habu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the new vice-commander of the Crimson Order and a spy working for The Cult of Diablos. Taking over after [Glen](Glen.md "Glen")'s death, he manipulates the organization by feeding the commander, Iris Midgar, misinformation regarding Shadow Garden.[[1]](#cite_note-V5C2"-1)

## Appearance

Adder is a tall man with serpentine eyes and pale skin, giving him a frightening impression. After joining the Crimson Order, he wears their dark knight uniform.[[1]](#cite_note-V5C2"-1)

## Personality

Adder presents as a calm, obedient subordinate whose industriousness soon lead to rapid promotions. This placid demeanor does not falter, even while conveying lies or manipulating royalty.[[1]](#cite_note-V5C2"-1)

## Chronology

### The Academy Disappearances

After Iris refutes the existence of The Cult of Diablos, Adder steps forward. He introduces himself to a suspicious Alexia as the vice commander. Acknowledging Iris's declaration of trust, Adder states that Shadow Garden invented The Cult. An incredulous Alexia can only stammer as Adder enumerates their crimes: Princess Alexia's kidnapping, the Midgar Academy for Dark Knights terrorist attack, the consecration of holy land, the Oriana Kingdom massacres, and other wicked acts throughout the world. Alexia interprets Adder, arguing that the responsibility lies with Cult. The Vice Commander calmly explains to the hysterical girl that The Cult of Diablos' crimes are false flag operations perpetrated by Shadow Garden.

Adder supports his strong accusation by presenting evidence. A document titled “Creation of the Cult of Diabolos by Shadow Garden" contains witness accounts of Shadow Garden's coercion. Adder gives a few examples, such as a 34-year-old man who admits Shadow Garden asked him to play a cultist. The explanation is soon interrupted by an agitated Alexia. She claims witness testimony can be fabricated, but Adder offers more evidence. Ignoring Adder, Alexia soon finds that nobody in the room, even Iris, will listen to her desperate pleas. Alexia leaves the room with only Marco’s apology for a goodbye.[[1]](#cite_note-V5C2"-1)

## Powers & Abilities

## Relationships

### Iris Midgar

Using the facade of a reliably loyal knight, Adder gained Iris's trust, and she made him the new vice-commander of the Crimson Order. He continues to manipulate the princess into believing that the Cult of Diablos is merely a fabrication by Shadow Garden.[[1]](#cite_note-V5C2"-1)

### Marco Granger

Adder is Marco's new superior as the new vice-commander. Unlike his predecessor, Glen, he has not articulated any positive feelings towards Marco.[[1]](#cite_note-V5C2"-1)

## Trivia

- Habu (ハブ) is the Japanese colloquial name of a venomous viper located around the Japan's Ryukyu Islands—binomial nomenclature is Protobothrops flavoviridis.
  - Adder's English name likewise is named after a viper, the Common European adder or Vipera berus.

## References

1. Volume 5. Chapter 2: On a Shocking Morning, the School Murder Case!
