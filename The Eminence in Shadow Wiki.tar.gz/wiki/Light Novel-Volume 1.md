# Light Novel/Volume 1

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%201](https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%201)

## Light Novel Volume 1

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Touzai

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4047353022

### ISBN EN

ISBN 978-1975359058

### Release Date

November 5, 2018 JP
August 11, 2020 EN

## Volume Information

### Pages

390 JP
224 EN

### Chapters

8

## Adaptations

### Manga

Volume 1, Chapter 1 - Volume 4, Chapter 14

### Anime

Episode 1 – Episode 10

Publication Order

| Next |
| --- |
| Volume 2 |

This is the first volume of the light novel series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

ONE BIG FAT LIE AND A FEW TWISTED TRUTHS

Even in his past life, Cid's dream wasn't to become a protagonist or a final boss. He'd rather lie low as a minor character until it's prime time to reveal he's a mastermind...or at least, do the next best thing— pretend to be one! And now that he's been reborn into another world, he's ready to set the perfect conditions to live out his dreams to the fullest. Armed with his overactive imagination, Cid jokingly recruits members to his organization and makes up a whole backstory about an evil cult that they need to take down. Well, as luck would have it, these imaginary adversaries turn out to be the real deal— and everyone knows the truth but him![[1]](#cite_note-1)

主人公最強×異世界転生×勘違いシリアスコメディ、爆誕!!

『我が名はシャドウ。陰に潜み、陰を狩る者……』
みたいな中二病設定を楽しんでいたら、まさかの現実に!?

主人公でも、ラスボスでもない。
普段は実力を隠してモブに徹し、物語に陰ながら介入して密かに実力を示す「陰の実力者」。
この「陰の実力者」に憧れ、日々モブとして目立たず生活しながら、
力を求めて修業していた少年は、事故で命を失い、異世界に転生した。

これ幸いと少年・シドは異世界で「陰の実力者」設定を楽しむために、
「妄想」で作り上げた「闇の教団」を倒すべく(おふざけで)暗躍していたところ、
どうやら本当に、その「闇の教団」が存在していて……?

ノリで配下にした少女たちは勘違いからシドを崇拝し、
シドは本人も知らぬところで本物の「陰の実力者」になっていき、
そしてシドが率いる陰の組織「シャドウガーデン」は、やがて世界の闇を滅ぼしていくーー。

『小説家になろう』の超人気作が、加筆修正の上、待望の単行本化![[2]](#cite_note-2)

## Summary

### Prologue

Cid Kagenou always revered shadow broker characters. The origin of such adoration has been lost, but time did not diminish his feelings. In an attempt to become a strong mastermind, he began studying numerous martial arts and weapon disciplines, all while playing the mediocre "mob character." Circumstances force to Cid admit that there was always someone stronger, even after his dedication. No amount of training could prevent his annihilation in the face of a nuclear weapon. Plunging into the depths of lunacy, Cid begins to seek magic to defeat that last obstacle. Striking his head repeatedly against a rock, he notices two lights beckoning him forward, finding magic at the moment of his death before being reincarnated in another world. As a baby boy, his new life was in a world not too dissimilar to medieval Europe. He is now able to see magic as light particles. Cid was again ready to become an Eminence in Shadow, focusing on exploring the limits of his capabilities.

At ten years old, Cid is stronger and more capable than his past self. He still places the weapons of Earth in his mind as limits to overcome. Cid was born into a lower dark knight noble family. Dark knights infuse magic into swordsmanship and the environment allows Cid to resume his role as a background character. Living as an average apprentice, Cid found Earth fighting and weapon styles substantially superior. They were universally accessible and refined to simplicity. In his current life, techniques are limited and restricted to their countries of origin. Isolation restricts potential refinement and magic that acts as compensation. Maai becomes irrelevant as magic is used to close the distance between fighters. Proper technique and close observation can compensate for a lack of defense on Earth. Cid secretly refined his magic control and skills. Cid feels confident that he could change a battle's outcome, even at a one-millimeter distance.

At the Kagenou family home, Cid's father directs him and his older sister, Claire Kagenou, on how to spar. As Claire has natural talent, it would not be uncommon for her to take over the family. Magic is an equalizing force between the sexes. Her position is further reinforced as Cid keeps losing to Claire to maintain his background character status. Between aristocratic lessons and duties as a noble, Cid only has time to train at night and periodically hunts bandits. Proper utilization of magic and meditation compensate for his reduced sleep, periodically hunting bandits for practice. Cid learns a band of rogues has camped at a nearby ghost town, glad to be vigilante and eager to test his new Slime Bodysuit. Cid's research found common weapon materials act as poor conductors with a 90% magical loss after initial infusion. Lightweight and silent, slimes carry 99% conductivity, and their liquid state provides fluid weapon shapes. His slime bodysuit is a simple coat but can be refined in the days to come.

A disguised Cid crashes the thieves’ banquet, slaughtering them wholesale with his versatile bodysuit. At the end of the massacre, one bandit remains, the boss. Cid’s desire to test his suit's functionality spared his life, but the mercy did not last long. Examining the loot, Cid happens upon a mutated mass of living rotted flesh, someone afflicted with [possession](Possession.md "Possession"). The Church buys the infected to execute while the public cheers them for "keeping the peace," it was similar to [Earth](Earth.md "Earth")'s Middle Ages. Interrupting his thoughts, Cid detects a magical overload in the blob, surpassing his magic. It recalls a memory of a previous magic overload that he resolved years earlier. Having not tested the effects of magical overload on himself, Cid is excited to have a test subject to safely experiment without risk to himself.

After a month of experimentation, Cid unintentionally returns the blob to its original state, a blonde [elven](Elf.md "Elf") girl. Cid grants her freedom, but the elf explains that she no longer has a home. He recruits the elf as his subordinate and renames her [Alpha](Alpha.md "Alpha"). Recalling a tale, Cid states his mission is to prevent the resurrection of the demon [Diablos](Aurora.md "Aurora"). It was defeated long ago by the Three Heroes, who cursed their bloodlines with the disease known as possession. Protection and treatment used to be the norm, but someone twisted history, warping facts to mold the descendants into objects of scorn. They carry immense magical and demonic power, making them a threat. Alpha lost her home to a false narrative. Cid then tells an angered Alpha that their enemy is the Cult of Diablos, who operate behind the scenes to revive the demon. His mission is to destroy the Cult and their influence in the world.

The Cult holds many positions of power and Cid believes Alpha will be invaluable for his mission. She accepts the offer, determined to avenge her injustice. Cid knows he made up the story but is excited to have Alpha and can slaughter criminals with the "Cult" accusation. Cid dubs their organization Shadow Garden and Alpha aims to recruit more hero descendants to their cause. Cid is secretly content with just him and Alpha. As he trains Alpha, Cid is astonished at her incredible aptitude despite only recently being a novice, and they continue training as Cid thinks about their improving skills.

### First Assault on the Cult

Three years have passed since [Alpha](Alpha.md "Alpha") agreed to follow in Cid's shadow. The ages of the Shadow Garden founders are thirteen and Claire, Cid’s older sister, is fifteen. Fifteen is a significant milestone for aristocrats; higher education in the royal capital begins at that age. A large party is a Midgardian tradition, but the kidnapping of Claire sabotages all hopes of gayety.  After carefully examining the crime scene, Cid’s father concludes that the kidnappers are highly organized and skilled. Leaving his mother’s physical and verbal abuse to the bald baron behind, Cid excuses himself to his room. There, he encounters [Beta](Beta.md "Beta"), the third member of Shadow Garden.

Beta expounds on the present situation, proposing Claire's suspected [hero ancestry](Olivier.md "Olivier") made her a target. Her abduction was, conceivably, authorized by a leading figure in the Cult of Diablos. The silver-haired elf concludes a foray into the Cult’s strongholds is inevitable for such a hostage crisis. The assembled information suggests that Claire is held captive at a particular hideout. Disregarding her conclusion, Shadow haphazardly throws a knife at a wall map, averring that his sister is at that site. Beta, reassessing the data, realizes Shadow’s analysis was correct, the initial throw being random notwithstanding.

At the knife mark location, a man approaches a holding cell. After receiving a warning about the prisoner's recalcitrant belligerence, the man enters the room. Claire greets the newcomer with a cold glare. Identifying the man as [Viscount Grease](Grease.md "Grease"), she sarcastically comments on his Bushin Festival performance. The biting remark is followed by a bite aimed at his carotid artery. Her teeth miss success by a hair's breadth. Grease punches the snapping teenager and begins to ask questions regarding her health when using magic. Humoring the Viscount, Claire concedes she did have [concerning symptoms](Possession.md "Possession"), but they have since disappeared after engaging in a few stretches with Cid. Grease makes a few incredulous comments and remarks that Kagenou’s son should be investigated. His sentence is cut short by a swift strike to his face, administered by a wounded Claire. By dislocating bones and shredding skin, she freed one arm to deliver the strike. The minatory Claire assures the broken-nosed man that if anything befalls her brother, the same will occur to him and his loved ones tenfold. Grease retaliates with a few punches to remind the girl of her place, but a subordinate’s warning of intruders interrupts further bludgeoning.

The scene that greets Grease’s eyes is beyond reasonable expectations. Bloody bodies are piled unceremoniously around the underground facility. Black bodysuit figures, stained red from the slaughter, glare down at the lone dark knight. One person radiates an intense bloodlust, but a delicate voice tells the girl, [Delta](Delta.md "Delta"), to stand down. The figure who spoke steps forward, revealing her face. The blonde elf identifies herself as Alpha and states Shadow Garden's mission is to eradicate the Cult of Diablos. Grease realizes the threat Shadow Garden poses and changes his objective from eradication to survival. He unsheathes his sword and strikes at the menacing elf. The sword slash is nonchalantly parried by Alpha, along with subsequent desperate strikes. Grease’s mounting wounds do not seem to deter him, and, at a critical point, he ingests something. Alpha did not have long to wait for an answer to her question regarding his actions. His muscles began to expand along with his magic capacity. The newfound strength allows Grease to land his first decisive strike. It knocks Alpha back, and the impact reverberates through her whole body. Once she regains composure, Grease is nowhere to be seen.

Cid was part of the first wave but ventured in a different direction to find the leader. He grumbles about being lost in the labyrinthine base. Sensing an approaching person, he poses himself to welcome the straggler. Introductions are cut short as the muscular frame lunges at Cid, but a quick lateral parry prevents the lethal blow. Every exchange only increases the shadowbroker’s contempt toward the man. The anonymous dark knight’s unsophisticated movements depend on brute force, neither understanding nor appreciating the intricacies of battle. Cid decides to instruct the mass of muscles in proper combat.

Piece by piece, the black hooded boy's sword fillets Grease’s body. Unnatural regeneration keeps Grease alive, but he knows the child is playing with him. All he can utter is one weak word, “Why?” A sonorous voice confesses that his sole existence is to “hunt down shadows.” Grease detects melancholy in that steadfast voice and understands immediately. He would never succeed. Only despair and suffering await those who plunge into the abyss, not knowing the depths. What could this juvenile swordsman accomplish where Grease has failed? The puerile swordsman should receive a poignant lesson on how cruel the world presents, and he would deliver that point. Aware that these are his last moments, Grease swallows a capsule that increases his strength in exchange for his life. The Cult calls the transformation “awakening.” Grease’s counterattack begins immediately, every strike backed by borrowed strength and raw emotion. Red and black figures blur faster than any human could perceive, but black remains a pillar of composure in the face of such power. The coup de grâce finally arrives; a beautiful slash bisects Grease’s sword and upper body. As death draws near, all Viscount Grease can think about is his powerlessness. The final word on his lips is the name of his dead daughter, [Millia](Millia.md "Millia").

Shadow Garden withdraws from the area after the leader’s defeat. Claire fully recovers but becomes more possessive of Cid, much to his annoyance. He is particularly proud of his shadowbroker act during the operation and is excited about future performances. The Seven Shadows continue investigating the Cult of Diablos, reporting all findings to Cid. The legitimacy of the claims is questionable in Cid’s mind, but the dedication to establishing a proper backstory for the Cult amazes him. One day, the girls approach Cid for permission to disperse the organization to impede The Cult’s activities. They would leave one to act as an attendant and rotate the responsibility. Cid assents, but he knew this day would come. It happened in his last life. Children grow up, imagination cannot last forever; one must face reality. Cid promises to remain faithful to his role, even if the world abandons him.

As Shadow Garden’s numbers continue to grow, the number of novices to train increases. One can explain the sensation, subsequent regrets and lamentations, but it is inadequate to prepare someone to take a life. While executing an operation, Beta observes a new member struggling with this fact and places her hands on the trembling girl's tight grip. Helping initiates the final twist; the girl’s hesitancy reflects a younger Beta. Alpha was quickly desensitized, but Beta remained haunted by the deaths as screams echoed out every night as nightmares threatened to take her sanity. Shadow began to tell the traumatized elf bedtime stories, dissolving the nightmares, and the screams gave way to silence. These stories finally granted Beta a good night's rest—Cinderella and Snow White were her favorites. Beta found her reason for living, devoting her life to Master Shadow and transcribing his journey.

### Princess Alexia's Kidnapping

### Midgar Academy Terrorist Attack

## Chapters

Note: The chapter count does not include the Appendix, which contains character profiles and 'The Chronicles of Master Shadow Complete Version: Volume 1.'

- Prologue: Preparing the Perfect Stage!
- Chapter 1: Starting the Shadowbroker Tutorial!
- Chapter 2: Assuming the Role of a Side Character at School!
- Chapter 3: My Official Beginning as a Mastermind in Action!
- Chapter 4: The Two Sides of the Shadow Garden?!
- Chapter 5: Mastering the Peaceful Life of a Nobody!
- Chapter 6: The Scene Where Terrorists Take Over the School
- Final Chapter: My Idea of the Ultimate Shadow Commander!
- Appendix

## Characters

:   In order of appearance:

- Cid Kagenou (Debut)
- Claire Kagenou (Debut)
- [Alpha](Alpha.md "Alpha") (Debut)
- Mr. Kagenou (Debut)
- Mrs. Kagenou (Debut)
- [Beta](Beta.md "Beta") (Debut)
- [Grease](Grease.md "Grease") (Debut)
- [Delta](Delta.md "Delta") (Debut)
- Alexia Midgar (Debut)
- Skel Etal (Debut)
- Po Tato (Debut)
- Zenon Griffey (Debut)
- Iris Midgar (Debut)
- [Fenrir](Fenrir.md "Fenrir") (Mentioned)
- [Epsilon](Epsilon.md "Epsilon") (Mentioned)
- [Millia](Millia.md "Millia") (Debut)
- [Gamma](Gamma.md "Gamma") (Debut)
- Sherry Barnett (Debut)
- Lutheran Barnett (Debut)
- [Glen](Glen.md "Glen") (Debut)
- [Nu](Nu.md "Nu") (Debut)
- Lukreia Crowley (Mentioned)
- [Chi](Chi.md "Chi") (Mentioned)
- Rose Oriana (Debut)
- Raphael Geerk Oriana (Mentioned)
- [Rex](Rex.md "Rex") (Debut)
- Marco Granger (Debut)

## Illustrations

- [English](#)
- [Japanese](#)

Shadow Garden (EN)

Cid's 'fighting' Rose (EN)

Main Heroines (EN)

Table of Contents (EN)

Title Page (EN)

Cid and Alpha's first meeting

Cid killing Viscount Olba

Alexia asking to sit with Cid

Claire confronting Iris

Cid's "Hidden Technique: I AM ATOMIC"

Gamma in Mitsugoshi's 'throne room'

Principal Lutheran teasing Sherry

Sherry weeping by Lutheran's corpse

Cid Kagenou's Profile (EN)

Alpha's Profile (EN)

Alexia Midgar's Profile (EN)

Sherry Barnett's Profile (EN)

Shadow Garden (JP)

Cid's 'fighting' Rose (JP)

Main Heroines (JP)

Table of Contents (JP)

Title Page (JP)

Cid and Alpha's first meeting

Cid killing Viscount Olba

Alexia asking to sit with Cid

Claire confronting Iris

Cid's "Hidden Technique: I AM ATOMIC"

Gamma in Mitsugoshi's 'throne room'

Principal Lutheran teasing Sherry

Sherry weeping by Lutheran's corpse

Cid Kagenou's Profile (JP)

Alpha's Profile (JP)

Alexia Midgar's Profile (JP)

Sherry Barnett's Profile (JP)

## References

1. [YenPress. The Eminence in Shadow, Vol. 1 (light novel) (EN)](https://yenpress.com/9781975359058/the-eminence-in-shadow-vol-1-light-novel/)
2. [Kadokawa. The Eminence in Shadow 01 (JP)](https://www.kadokawa.co.jp/product/321806000138/)

## Trivia

- [Fenrir](Fenrir.md "Fenrir") and [Chi](Chi.md "Chi") were both characters whose debut appearances unknowingly had already been foreshadowed.

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | **Volume 1** • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
