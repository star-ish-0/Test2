# Yukime

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Yukime](https://the-eminence-in-shadow.fandom.com/wiki/Yukime)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Chronology](Yukime-Chronology.md "Yukime/Chronology")

[Relationships](Yukime-Relationships.md "Yukime/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | The winner will be you, Mr. Shadow, and it will be I. | ” |
| — Yukime, to Shadow, Light Novel Volume 03 | | |

## Yukime

### Japanese

ユキメ

### Romaji

Yukime

### Aliases

Spirit Fox

## Characteristics

### Race

[Therianthrope](Therianthrope.md "Therianthrope") (Fox Therianthrope)

### Gender

Female

### Age

Likely 20s

### Height

Unknown

### Hair Color

White

### Eye Color

Blue

### Birthday

December 11

## Personal Information

### Status

Alive

### Relatives

Unnamed Mother †
Unnamed Father †
[Gettan](Gettan.md "Gettan") † (Ex-Fiancé)

## Professional Information

### Occupation

- President of the Snow Fox Corporation
- Monarch of the White Tower
- Prostitute (Formerly)

### Affiliation

Snow Fox Corporation
Shadow Garden

## Debut

### Web Novel

Chapter 99

### Light Novel

Volume 3

### Manga

Chapter 29

### Anime

Episode 21

### Game

Episode 20

## Portrayal

### Japanese

[Shizuka Itō](https://en.wikipedia.org/wiki/Shizuka_It%C5%8D "wp:Shizuka Itō")

### English

Courtney Lomelo

### French

Sophie Planet

### Italian

[Valentina Pallavicino](https://en.wikipedia.org/wiki/it:Valentina_Pallavicino "wp:it:Valentina Pallavicino")

Yukime (ユキメ, Yukime[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), also known as the Spirit Fox (妖狐（ようこ）, Yōko[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), is the ruler of the White Tower in the Lawless City and the President of the Snow Fox Corporation.[[1]](#cite_note-V3C1-1)[[2]](#cite_note-V3C4-2) Formerly part of the city's triumvirate, she became its sole ruler following the destruction of the Crimson Tower and the death of [Juggernaut](Juggernaut.md "Juggernaut").[[3]](#cite_note-V3C2-3) Leveraging her vast intelligence and corporate resources, she maintains a powerful strategic alliance with Shadow Garden.[[4]](#cite_note-V3E-4)

## Appearance

As a Fox Therianthrope, Yukime possesses the natural traits of her people, which are her long fox ears and nine tails. Yukime was recognized as a bewitching beauty, with a beautiful face with long snow-white hair, blue eyes, and a curvaceous figure. Yukime covered her horrendous scars behind her back by hiding it inside her kimono. After the end of the Trade Conflict, Shadow healed her properly and removed the scars.

She is dressed in her illustrious kimono colored snow-white as well, with fur on the shoulders, has gold accents on the cuffs, and blue lines accompanying them. The kimono is held together by her Obi, a sash around the belly, where she also keeps her two iron war fans for self-defense.

She has a Japanese style ornamentation: ribbon knots in her hair, bracelets in her hands, rings on her fingers, a pair of Geta sandals, a blue necklace accessory worn at her waist, and Japanese rings near the tips of her nine fox tails. These rings seem similar to Buddhist prayer beads, denoting some measure of spiritual or magical meaning.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Verily, I wish for us to get close, Mr. Shadow. | ” |
| — Yukime, to Shadow, Light Novel Volume 03 | | |

Yukime is an aloof Therianthrope who uses vulgar language, but she is a very strong and determined woman who has risen to her current position as the leader of the White Tower through her intelligence and unwavering resolve.

As the ruler of the White Tower, Yukime is known for her firm and decisive leadership, but she is not known for murdering those who oppose her. Instead, she handles challenges and threats with shrewdness and wit, employing her intelligence to maintain her position. She's also a shrewd businesswoman who runs a legitimate company outside the Lawless City.

In her past, Yukime faced hardships, including a period where she was involved in difficult circumstances as a former sex worker. However, she has since transformed her life and now cares deeply for the people in her employ, particularly the ladies under her protection in the pleasure district. She is known for being a supportive and protective leader, always grateful for those who have helped her and her subordinates. When she encounters Shadow for the first time, Yukime expresses gratitude for his help in saving her ladies from danger. This gesture shows her appreciation for those who support her and demonstrates her caring nature.

The motivation for Yukime's change from a kind and loving girl to her current state can be attributed to a traumatic event in her past involving the Cult of Diablos. This event caused her to adopt a more guarded and cautious demeanor, making her wary of others' intentions. However, she is not solely driven by revenge but instead seeks to protect others from similar experiences.

Although Yukime is a formidable and calculating individual, she is not ruthlessly manipulative. She may be willing to strategize and use her wit to achieve her goals, but she still retains a sense of compassion and empathy, especially towards those she respects.

Being a former prostitute, Yukime also has a seductive personality as she would often use her beautiful appearance and teasing personality to entice men to lower their guard, particularly towards Shadow who most likely attempts to persuade him to join her.

Despite this though, Yukime still has feelings for Gettan and after Shadow comes to save her, she returns to her old self.

## Powers & Abilities

As the ruler of the White Tower, Yukime is considerably powerful, possessing the strength that allowed her to rise through the ranks to become one of the rulers of the Lawless City.[[5]](#cite_note-V3P-5)[[1]](#cite_note-V3C1-1)

### Magic

Thanks to the training, as well as practicing magic, Yukime managed to awaken the half-forgotten magical techniques and abilities of her clan, before being completely lost to oblivion by the Cult of Diabolos, when her clan and family perished, which allowed Yukime to return once again as the monarch of the Lawless City.[CITATION NEEDED]

Yukime's magic specializes in elements related to fire and wind, allowing her to perform powerful explosive attacks in just a few moments.[CITATION NEEDED] Yukime's magic is reflected in the number of tails she has, as her magic grows, the more the number of tails she has increases, until she reaches the 9 tails of Zorro, where she is at her best moment of spiritual power and magical, as a member of his clan, which made her power earn her the title of a monarch of the Lawless City.[CITATION NEEDED]

### Intelligence

Yukime is a highly capable and intelligent individual, as demonstrated when she devised a plan to exploit the escalating rivalry between the Major Corporate Alliance (MCA) and Mitsugoshi, Ltd. Partnering with the mysterious John Smith, she orchestrated a massive counterfeiting operation targeting the banknotes of both organizations. Her objective was to trigger a total collapse in public trust, allowing her to seize control and profit from the resulting financial chaos.[[2]](#cite_note-V3C4-2)

### Weapons and Equipment

Yukime fights with a pair of metal-ribbed fans, as she is mastering a dance-like fighting style, resembling the traditional ritual dance: Kagura.

## Trivia

- The name Yukime has the word ユキ in her name which means "snow" in Japanese.
  - The name Yukime often refers to the name of a snow maiden, known as the [Yuki-onna](https://en.wikipedia.org/wiki/Yuki-onna "wp:Yuki-onna"). Yuki-onna is a Yokai in Japanese mythology who handles the snow-covered by an obi.
- Both the design and the character of Yukime reflect [kitsunes](https://en.wikipedia.org/wiki/Kitsune "wp:Kitsune") from Japanese mythology.
- In the web novel and early in the light novel, Yukime was presented as an ancient woman through archaic language and character comments. [Juggernaut](Juggernaut.md "Juggernaut") taunts her by saying, "You goin' senile in your old age, Grandma?" and "The old hag must be forgetting things due to age. Sucks to be you."[[3]](#cite_note-V3C2-3)[[6]](#cite_note-6) However, her later light novel backstory with Cid Kagenou's appearance contradicts this fact. Cid rescued her at 14, meaning she cannot be older than her early 20s.[[4]](#cite_note-V3E-4)
- Yukime is one of the few people who has openly rejected the Cult of Diablos power offerings.[CITATION NEEDED]
- Yukime speaks Japanese in a Kansai dialect. When using honorifics, she uses –han instead of –san.

## References

1. Volume 3 Chapter 1: Lawless City Bandit Hunting!
2. Volume 3 Chapter 4: I’ll Destroy It All and Start from Scratch!
3. Volume 3 Chapter 2: Storming the Crimson Tower!
4. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
5. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
6. Web Novel: Chapter 100

## Site Navigation
