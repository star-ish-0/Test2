# Natsu

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Natsu](https://the-eminence-in-shadow.fandom.com/wiki/Natsu)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Natsu?action=edit).

## Natsu

### Japanese

ナツ

### Romaji

Natsu

## Characteristics

### Race

[Therianthrope](Therianthrope.md "Therianthrope") (Cat Therianthrope)

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Brown

### Eye Color

Gold

### Birthday

July 18

## Personal Information

### Status

Alive

### Relatives

[Kana](Kana.md "Kana") (Sister)

## Professional Information

### Occupation

Servant

### Affiliation

Snow Fox Corporation

## Debut

### Web Novel

Chapter 112

### Light Novel

Volume 3

### Manga

Chapter 33

### Anime

Episode 21

## Portrayal

### Japanese

[Kana Ichinose](https://en.wikipedia.org/wiki/Kana_Ichinose "wp:Kana Ichinose")

### English

[Allison Sumrall](https://en.wikipedia.org/wiki/Allison_Sumrall "wp:Allison Sumrall")

Natsu (ナツ, Natsu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of [Yukime](Yukime.md "Yukime")'s closest aides and sisters with [Kana](Kana.md "Kana").

## Appearance

Natsu is a beautiful Therianthrope woman with brown cat ears and brown tail. She usually wears a kimono

## Personality

Natsu is a mature and womanly person.

## Chronology

### Great Trading Company Conflict

Natsu and her sister Kana occasionally greet Shadow whenever he comes to discuss with Yukime. They also attempt to seduce him as ordered by their mistress to tie Shadow to their group. When Shadow posing as "John Smith" arrives at the hideout, Natsu and Kana informs him of Yukime's disappearance.

## Powers & Abilities

Kana is skilled at charming men with her body and beauty.

## Relationships

### [Yukime](Yukime.md "Yukime")

Natsu displays great respect and loyalty to her mistress, Yukime, shown when she abodes to her orders to seduce John Smith to which she did without hesitation.

### [Kana](Kana.md "Kana")

Natsu and Kana are sisters, often coordinating with whatever endeavors Yukime has planned. Whenever Natsu would be unavailable for an errand, she could trust Kana to continue her duties and vice versa.

### Shadow (John Smith)

Natsu served as Yukime's attendant with Shadow when he operated as John Smith escorting the counterfeit bills from their production hub to various locales in the Lawless city. When Natsu relayed Yukime was walking into a trap by Gettan to John Smith, she was afraid of his intense aura, misreading it as him enraged at Yukime's endangerment. However, Natsu views Shadow/John Smith as a man of immense power and unrivaled intellect.

## Trivia

## References

## Image Gallery

## Site Navigation
