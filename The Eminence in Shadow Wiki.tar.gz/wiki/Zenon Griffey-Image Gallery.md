# Zenon Griffey/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Zenon%20Griffey/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Zenon%20Griffey/Image%20Gallery)

Main

Chronology

Relationships

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Cid uses his "I AM ATOMIC" on Zennon

Character design

Zennon confronts Cid

Alexia fights Zennon

Zennon awakens
