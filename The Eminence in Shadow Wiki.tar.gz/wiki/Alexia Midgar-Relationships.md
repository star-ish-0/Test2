# Alexia Midgar/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Alexia%20Midgar/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Alexia%20Midgar/Relationships)

Main

Chronology

Image Gallery

## Family

### Klaus Midgar

While annoyed by her father's seeming inaction, Alexia still maintains some familial love toward him, silencing Natsume when the latter criticized the monarch.

### Iris Midgar

Alexia deeply loves and respects her older sister. However by constantly being compared to her, Alexia began to distance herself from Iris. This changed when she was kidnapped and managed to understand the true meaning of her sister's words regarding her sword technique. She was also touched by her sister rushing to find her after the conflict with Zenon before they share a hug to celebrate Alexia's rescue.

While having reconciled with her sister and her feelings of inferiority, Alexia's relationship with Iris has become strained regarding the topic of Shadow Garden. Despite her continued warning to Iris to not interfere with Shadow after witnessing his overwhelming might, the latter refuses to listen, believing the masked vigilante must be using some sort of Artifact to boost his strength.

Unfortunately, their relationship would become strained once more when the cult began manipulating Iris into believing that they do not actually exist and are merely a fabrication of Shadow Garden, causing her to ignore all of the evidence Alexia managed to gather on the organization.

## Friends

### Cid Kagenou / Shadow

In the beginning, Alexia started her relationship with Cid (after his fake confession) as a way to annoy Zenon, her betrothed.[[1]](#cite_note-V1C2-1) Despite the façade, being able to drop the princess act and be herself around him has made her genuinely fall in love with Cid. Despite him ending their fake relationship, Alexia still loves him and usually bothers him whenever she has free time. She also tries to include him in other activities to spend more time with him though is annoyed by his lack of interest. Due to the time they were together and the affinity they have in their swordsmanship, Alexia began to imitate the stretching and sword exercises that Cid does, which resulted a significant growth in her strength, something that other people quickly noticed.[[2]](#cite_note-V3C5-2)

Alexia was deeply inspired by the leader of Shadow Garden as his fight against Zenon moved her and reignited her passion for fencing she discarded long ago. It was in the aftermath of his fight that she realized the ideal fencing she dreamt of growing up and began modelling after. Despite Shadow saving her however, Alexia remained cautious about him as she was unsure what his true motives were. She was also terrified of the vast power he possessed which was another reason for her distrust. After being saved on multiple occasions by Shadow, Alexia does believe that Shadow is a heroic individual. Alexia also remains unaware that Shadow is actually Cid who had been responsible for saving her. However, it is hinted that she may be putting it together.

### Rose Oriana

Both hailing from royal backgrounds, Alexia and Rose usually get along and tend to have a friendly relationship. This has led them (along with [Natsume](Beta.md "Beta")) pledging to protect the people who are important to them. Unbeknownst to them, they are love rivals for Cid.[[3]](#cite_note-V2C3-3)

Their friendship appeared to have become distant when Rose fought her off and later became queen of Oriana. She dwelled about her after her sparring session with Cid as she looked for allies after winter break.[[4]](#cite_note-V5C1-4)[[2]](#cite_note-V3C5-2)

### Claire Kagenou

Claire despised Alexia for "breaking" her brother's heart and has never interacted with her until the two were investigating matters regarding Cult of Diablos. During their first interaction, the two made an uneasy alliance to further investigate the cult and student disappearances. To some extent, Alexia cares for Claire since she's Cid's sister. The two are unaware of Shadow's true identity and are beginning to pick up hints about it. Alexia believed Claire when she told her she has [Aurora](Aurora.md "Aurora") "the Witch of Calamity" inside of her.

## Crimson Order

### [Glen](Glen.md "Glen")

Late Vice Commander for the Order, Alexia's safety was one of Glen's priorities until his death. He was also one of the few people to learn Iris' secrets through her.

### Marco Granger

Glen's friend and protégé. Alexia is Marco's superior in the peerage and will prioritize Alexia's safety if she is within reach, being the younger sister of his commander.

Their relationship seemed to deteriorate when he was unable to stop Iris from Adder's manipulation, having her question his stance regarding the matter.

### [Adder](Adder.md "Adder")

Agent for the Cult of Diablos. Alexia first meets him when she tried to give her sister evidence and testimony regarding the Cult. However, the agent posing as Vice Commander manipulated Iris from listening to her with false evidence presented to her first.

## Midgar Academy for Dark Knights

### Sherry Barnett

Assumedly Alexia's former upperclassman, the two have only interacted a few times when it was either about the Diablos Cult or Cid. The first time they've interacted was when the Crimson Order entrusted her an artifact found in Zenon's hideout and last time was when the former student asked Alexia about her relationship with Cid. While apprehensive at first, Sherry was glad that Alexia bitterly clarified that she and Cid were never seriously dating before lashing out after she left her room.

In the game, The princess expressed jealousy toward Cid whenever she talked about her.

### [Nina](Nina.md "Nina")

They first met when she and Claire investigated the Cult's presence in the Academy. Nina gave the two a book from the forbidden library and pinned the source on Cid.[[4]](#cite_note-V5C1-4) Alexia alongside Claire is unaware of her true allegiance to [Zeta](Zeta.md "Zeta").

### Christina Hope

An aristocrat and fellow schoolmate. The two alongside few others worked together to investigate the ghosts and magic collars that have been terrorizing the school. Christina deeply respects the princess to the point of reprimanding her own family for speaking to her in a casual manner. Alexia reassured the aristocrat in testifying against Eliza when they found out that the vice-president had coerced other students into killing each other for their magic.

### [Kanade](Kanade.md "Kanade")

Another fellow student. They first meet when Kanade was almost killed by the magic collars. After she was saved, Alexia went and joined her after Christina put her into witness protection. The two usually interact whenever they find an opportunity to berate Cid's antics.

### Skel Etal & Po Tato

Cid's friends. Alexia usually goes to them for information to blackmail Cid. When they first enrolled, the two and Cid made a bet on the entrance exams and Cid lost. As part of the bet, Cid was forced to confess to Alexia in attempt to get off of the perceived rejection. The confession ultimately backfired at them as Alexia accepted his confession and thus kickstarted their fake relationship, much to their ire.

### [Isaac](Isaac.md "Isaac")

An agent of the Diablos Cult and fellow student. Alexia worked alongside him to investigate the ghosts and magic collars that have terrorized the school. Isaac was the most resistant in investigating the incident and revealed himself as an cult agent after knocking her and the team out with chloroform.

### Eliza Despoht

An aristocrat from a powerful family. Alexia provided testimony against her at height of the student disappearances after it was found that she coerced students into killing each other for their magic. Despite this, she was never found guilty and forced Alexia into redirecting her focus into the Jack the ripper incident.

## Shadow Garden

### Seven Shadows

#### [Alpha](Alpha.md "Alpha")

The two seemed to have recognized each other possibly through Iris. Unlike Beta, Alpha does not seem to take concerned when the Princess tried to get closer to Cid assuming it was part of his investigation of the Cult. However, Alpha does not understand why Cid went as close as to date her to investigate the Cult.

[Beta](Beta.md "Beta")

Beta despises Alexia for having previously forced Cid into a "romantic" relationship with her, viewing the princess as her love rival. As a result, upon their first meeting, Beta was uncharacteristically condescending toward her and held back her anger when Alexia constantly stomped on her foot. While they later agreed to an alliance with Rose to uncover the truth behind the Cult of Diablos, they still have an obvious dislike toward each other. Also, whilst working together, Beta would constantly annoy Alexia by acknowledging the latter's jealously of her more developed body.

#### [Delta](Delta.md "Delta")

Upon witnessing her fight with Nelson, Alexia came to view Delta as savage and felt pity for her opponents. This went as far as to her even wonder how someone so violent could be connected to Shadow.

#### [Epsilon](Epsilon.md "Epsilon")

The princess may recognize her as "Shiron" since the former is noted to take notice of people of influence. The princess is also one of many to know of her fake breasts.

#### [Zeta](Zeta.md "Zeta")

### Numbers

#### [Mu](Mu.md "Mu")

## Cult of Diablos

### Zenon Griffey

From the very beginning, Alexia was suspicious of her seeming "perfect" fiancée, since "no one is perfect". She thus started a fake relationship with Cid to annoy him. After being kidnapped, Alexia's suspicions were proven correct when it was revealed that Zenon was the mastermind. The princess subsequently lost their duel for her freedom through Zenon throwing her off by constantly belittling her. In the end, following Zenon's death at Shadow's hands, Alexia did not seem bothered by her fiancée's passing at all.

### Lutheran Barnett / "Sir Gaunt"

### Jack Nelson

Archbishop and a person of interest, Alexia with the support of her sister and Midgar tried to investigate him for his involvement in the [former Archbishop's](Drake.md "Drake") death and the Holy Church's corruption but to no avail. It was arriving at [Lindwurm](Lindwurm.md "Lindwurm") for the Goddess Trial when she witnessed the Archbishop's corruption and involvement in the cult when Shadow annihilated the Sanctuary with him alongside it.[[3]](#cite_note-V2C3-3)

### Perv Asshat

### [Willow](Willow.md "Willow")

### [Fenrir](Fenrir.md "Fenrir")

### [Gray](Gray.md "Gray")

## Others

### [Millia](Millia.md "Millia")

### [Luna](Gamma.md "Gamma")

One of the Seven Shadows and CEO of the Mitsugoshi Company, Alexia is unaware of Luna's true identity. In contrast to her sister, the princess seems to be a fanatic about her clothing line in hopes of arousing Cid.

### [Natsume Kafka](Beta.md "Beta")

From the moment they met, the two despised each other. This stems from the princess seeing right through the façade the writer puts up, along with the latter throwing several hints at her that she is mocking her and being jealous of Natsume's more developed figure. Despite this, though, they decided to ally with Rose to uncover the truth of Shadow Garden and the Cult of Diablos.[[3]](#cite_note-V2C3-3) However, this did not stop Natsume from continuing to annoy Alexia while working together.[[5]](#cite_note-V2C6-5) Alexia also remains unaware that Natsume is actually [Beta](Beta.md "Beta") from Shadow Garden.

The two have not contacted each other since Rose became queen of Oriana as she thought she was good and useless.

## References

1. Volume 1 Chapter 2: Assuming the Role of a Side Character at School!
2. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
3. Volume 2 Chapter 3: When Things Get Boring, It's Time for Explosives!
4. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
5. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
