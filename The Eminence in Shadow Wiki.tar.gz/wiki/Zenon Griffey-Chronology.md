# Zenon Griffey/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Zenon%20Griffey/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Zenon%20Griffey/Chronology)

Main

Relationships

Image Gallery

## Background

Growing up as a child prodigy and having taken several championships under a former Bushin Festival champion's wing[[1]](#cite_note-V5C2-1), Zenon Griffey climbed up Midgar's hierarchy until finally settling down into the position of an swordsmanship instructor at their Royal Academy. Within the kingdom, there wasn't a swordsman who didn't know his name.[[2]](#cite_note-V1C3-2) Unbeknownst to many however, Zenon was secretly affiliated with the Cult of Diablos and had sought to elevate his position to become a member of the Knight of Rounds.

When the Cult's leadership recognized his strength, they considered making Zenon a prime candidate to fill the vacant position of the 12th seat. However, they noted that he lacked the achievements and waited for an opportunity. Zenon eventually found a chance when he was arranged to be Princess Alexia's betrothed and it was then that he realized that he could harvest her royal blood for the Cult's experiments.

## Volume 1

### Kidnapping of the Princess

He was first introduced training students at his Royal Bushin elective after Alexia started "dating" Cid Kagenou, a lower-class aristocrat. Zenon confronted her about her phase and told her that she'll grow out of it and see himself as a good choice. She rebuffed him however and as the days went on, Zenon simply smiled at Alexia's attempt to get a rise out of him, much to her annoyance.

Sometime later after two weeks had passed, he secretly kidnaped her and framed Cid for the crime. Zenon alongside his followers arrested Cid for her "disappearance" and tortured him for a false confession. Despite their malicious torment, the young man did not relent on his innocence.[[3]](#cite_note-V1C2-3) He later visited Iris Midgar to state that he felt responsible for her sister's kidnapping and reported on Cid's "interrogation". He reported that the interrogation lasted for five days to come with nothing before Claire Kagenou barged in to confront Iris, inquiring about her brother's condition. After a careful response from the Knight, Iris then decided to release the student under his surveillance.

Later on in the night, the mysterious organization called Shadow Garden raided the Cult's hideouts in the capital and forced Zenon to retreat to his facility to find Alexia. It was there he found the princess broken free from her confines and she confronted him. In the confrontation, Zenon revealed himself to be responsible for her kidnapping and intended to use her blood to promote himself to the 12th seat of Rounds until Zenon belittling the confused princess when he also states that he wants her older sister as a more suitable reward but is satisfied with Alexia as his preferred choice.

Surprised that the enraged princess landed a strike, Zenon overwhelmed her and broke her sword in the process. Before he proceeded to recapture her, the two combatants were surprised when a mysterious figure who calls himself Shadow suddenly appeared to intervene. Recognizing the figure to be responsible for raiding several bases, Zenon flaunted at Shadow about his promotion and prepared to face him. In their brief exchange, Shadow easily outmaneuvered Zenon's attacks and mocked his underwhelming strength, infuriating him. Zenon then angrily asks Shadow why he is hiding his identity if he is that strong. Shadow states they are Shadow Garden, and they hunt in the shadows, which is the sole purpose of their existence.

Consumed by rage and frustration, Zenon empowered himself through a small jarful of Beads of Diablos to become a "Third Awakening". Despite mutating from the pills in an ironic twist, Zenon was still no match for the dark figure who belittled and overwhelmed him. Shadow rebuked that there's no road to almightiness from borrowed power until he activated his magical power, shocking the Knight on how powerful it was. After Shadow finished his belittlement with a story about a man that withstood a nuclear bomb became nuclear himself, Zenon thought he was crazy and tried slashing him. Alas, his sword shattered upon impact when he told him to witness his almightiness as he used it. Realizing he lost, Zenon was in despair as Shadow annihilated him with his "I Am Atomic" attack.[[2]](#cite_note-V1C3-2)

## Legacy

After his death, several students dropped out of the Royal Bushin elective after his actions behind Alexia's disappearance came to light. The Royal Bushin fighting style was sullied as a result of his actions as both his name and former subordinates were scorned for their involvement.[[4]](#cite_note-V1C4-4) However, his death revealed the two shadow organizations existence to Midgar and public. In response to the revelation and distrust towards the Knight Order, Iris created the Crimson Order while the Cult was forced to take action and frame Shadow Garden as the world's enemy to avoid internal exposure.[[5]](#cite_note-5)

In the event of Zenon's death, certain higher ups within the Cult have sought to claim the position of 12th seat. The first member was Lutheran Barnett who sought to regain his position through using the Eye of Avarice but failed when he met same fate as his supposed replacement.[[6]](#cite_note-V1FC-6)

The second candidate member to have sought the position was [Gettan](Gettan.md "Gettan") who was tasked with carrying out a mission from the Cult to destroy Mitsugoshi Company which he latterly failed and faced the same fate after being defeated by John Smith in a duel.[[7]](#cite_note-V3E-7) And the last candidate was Perv Asshat who attempted to do so politically through sieging the Kingdom of Oriana within. However, he too faced the same fate when his plan was thwarted after their princess publicly exposed him until another [member](Mordred.md "Mordred") of the Round Knights killed him.[[8]](#cite_note-V4C3-8)

### Post-Mortem

Zenon was briefly mentioned by [his former mentor](Willow.md "Willow") when he was confronted by Shadow after nearly incapacitating Alexia and Claire. The Head Librarian knew this would eventually happen after learning of his pupil's demise and sought to avoid it. In his dying moments, the Head Librarian noted that Zenon was a terrible disciple before revealing that the quantity of Diablos Tears was plummeting and warned the princess to avoid following his footsteps before passing.

The Head Librarian's testimony and incident was later collected as evidence when Alexia tried pleading with her sister. However, by the time she collected the evidence, it was too late as the Cult has already infiltrated both the Academy and Crimson Order with members such as [Isaac](Isaac.md "Isaac") and [Adder](Adder.md "Adder") respectively.[[1]](#cite_note-V5C2-1)

## References

1. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
2. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
3. Volume 1 Chapter 2: Assuming the Role of a Side Character at School!
4. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
5. Episode 5
6. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
7. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fakes Bills!
8. Volume 4 Chapter 3: Crashing the Ceremony!
