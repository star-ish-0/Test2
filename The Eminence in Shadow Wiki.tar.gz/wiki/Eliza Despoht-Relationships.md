# Eliza Despoht/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Eliza%20Despoht/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Eliza%20Despoht/Relationships)

Main

Chronology

Image Gallery

## Family

### Brad Despoht

## Midgar Academy for Dark Knights

### Rose Oriana

### Claire Kagenou

### Alexia Midgar

Eliza was shown to at least respect her as Alexia was part of the royal family, which had more power and influence than her own family. However, it was shown that she somewhat looked down on her as during the ghost incident, she attempted to bribe Alexia with mana thinking that the two of them had a similar mindset given that they were both powerful nobles. However, Alexia did actually care for all nobles regardless of their standing and most likely would’ve rejected her, considering that Eliza had insulted her and the other nobles.

### Christina Hope / "Jack the Ripper"

### [Isaac](Isaac.md "Isaac")

### Cid Kagenou / Shadow ("Suzuki Hope" / Jack The Ripper)

Initially, Eliza didn’t think much of him as he was disguised and pretended to be a victim of the ghost incident. However, she was taken aback when Cid exposed her for murdering her classmates because she had selfishly stolen the mana from her classmates and left them to die. Eliza attempted to bribe Alexia with her mana so that she would keep quiet, however Cid grabbed her collar and threatened her to comply. Eliza terrified and knowing that she was no match for Cid, surrendered and distributed her mana evenly among the other nobles.

### [Kanade](Kanade.md "Kanade")

Eliza didn’t pay much heed to her as she was a lower ranking noble and as a result she was forced to obey her. During the ghost incident, Kanade and her other classmates were forced to fight each other to the death and forcibly restrain those that attempted to rebel against Eliza. She watched as Eliza forced those with a low mana count to act as bait for the ghosts in the hallway, eventually she was forced to act as bait herself. Luckily, Alexia, Claire, and Cid (disguised as Suzuki) rescued her as she on the verge of death, as she was running low on mana. Luckily for her Cid gave her some of his mana, then exposed Eliza for what she did to her classmates. It was then that Kanade turned against her and confirmed what Cid had deduced, along with her other classmates who decided to turn against her after she was exposed.

### Dunder Hedd

## Thirteen Nightblades
