# Annerose Nichtsehen/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Annerose%20Nichtsehen/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Annerose%20Nichtsehen/Relationships)

Main

Chronology

Image Gallery

## Velgalta's Seven Blades

### [Karen von Herzog](Chi.md "Chi")

### Sergey Gorman

## Fellow Swordsman

### Shadow ("Mundane Mann")

Mundane was an opponent Annerose faced in the Bushin Festival. Annerose initially pegged him as weak but was surprised when Mundane proceeded to advance through the tournament. Annerose had gotten more interested in Mundane and his abilities as deep down, she believed the man to be the opponent she had been waiting for.[[1]](#cite_note-V2C5-1) After being defeated by him, Annerose was genuinely happy rather than upset she lost, and she developed deep admiration for the mysterious man. Annerose vowed to train more in hopes she could challenge Mundane once more.[[2]](#cite_note-V2C7-2) She never knew that he was Shadow in disguise when she left.

But due to her obliviousness, Annerose did not know that Mundane's true identity is Shadow, the leader of Shadow Garden and the person who defeated Sergey single-handedly.[[3]](#cite_note-3)

### [Quinton](Quinton.md "Quinton")

Their interactions are limited though expansive enough to elaborate. The Bushin Festival veteran seemed to have recognized her abilities when she stepped in stop his onslaught on Mundane.[[4]](#cite_note-V2C4-4) During Mundane's bout with Goldy, the two tried analyzing his movements with the swordswoman being barely able to see them. Alas unlike the Veteran, she would overanalyze them and embarrassed herself when she tried replicating them.[[1]](#cite_note-V2C5-1)

### Goldy Gilded

Annerose knows the participant as they were matched three times, which he forfeited due to his cowardice of fighting stronger opponents and was aware of the real reason why he got the "Unbeaten Legend" title name.[[1]](#cite_note-V2C5-1)

## Acquaintances

### [Luna](Gamma.md "Gamma")

## References

1. Volume 2 Chapter 5: A Battle to Attract Only MVPs!
2. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
3. The Eminence in Shadow: Master of Garden, Seven Shadows Chronicles, Part 2: Sturm of Velgalta, Chapter 2-12: Evil Ambition's End, Episode 5: Summit of Strength
4. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
