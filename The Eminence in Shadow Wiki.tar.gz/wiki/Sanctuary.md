# Sanctuary

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sanctuary](https://the-eminence-in-shadow.fandom.com/wiki/Sanctuary)

Sanctuary (聖域（せいいき）, Seiiki[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are research facilities of the Cult of Diablos. They often have measures to make sure no one reaches the deepest parts. Sanctuaries are facilities that are known to hide important information inside, and they often seem to work as containment facilities. So far, the only one the public has known about is the one in Lindwurm.[[1]](#cite_note-1) And others such as the sanctuary near Madlid in the Velgalta Empire seem to have been forgotten by even the Cult of Diablos.[[2]](#cite_note-:0-2)

## History

## Chronology

## Locations

- [Lindwurm](Lindwurm.md "Lindwurm"): The sanctuary in Lindwurm was a research facility that held the left arm of Diablos and where the former 11th of the Knights of Rounds, Nelson resided.[[3]](#cite_note-3) Though it has since been destroyed by Shadow.[[4]](#cite_note-4)
- Midgar Academy for Dark Knights: The sanctuary beneath Midgar Academy for Dark Knights held the right arm of Diablos, which was under the control of the Cult of Diablos' 5th seat of the Knights of Rounds, Fenrir, until he was slain by Shadow.[[5]](#cite_note-5)[[6]](#cite_note-6)[[7]](#cite_note-7)
- Velgalta Empire, Madlid: This sanctuary is a forgotten research facility of the Cult of Diablos, and it housed artificial dragons called Malak before being rediscovered by Sergey Gorman.[[2]](#cite_note-:0-2)
- [Laugus](Laugus.md "Laugus"): The sanctuary near [Laugus](Laugus.md "Laugus") was an old forgotten abandoned research facility of the former 11th seat of the Knights of Rounds, Lord Laugus.[[8]](#cite_note-8)[[9]](#cite_note-9) Lord Laugus once sealed [Nidhogg](Nidhogg.md "Nidhogg"), the ruler of the 12th realm within it.[[10]](#cite_note-10)

## Trivia

- In the Light Novel and Manga, it is depicted as a medieval alchemy workshop. But in the Anime, it is depicted as a facility with advanced science and technology that is now lost.[CITATION NEEDED]

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • **Sanctuary** • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |

1. The Eminence in Shadow, Light Novel, Volume 2, Prologue: To Lindwurm, the Sacred Land!
2. The Eminence in Shadow: Master of garden, Seven Shadows Chronicles, Part 2: Sturm of Velgalta, Chapter 2-13: Hero...... Lured by Illusions, Episode 4: Ambition's End
3. The Eminence in Shadow, Light Novel, Volume 2, Chapter 2: Investigating the Sanctuary!
4. The Eminence in Shadow, Light Novel, Volume 2, Chapter 3: When Things Get Boring, It's Time for Explosives!
5. The Eminence in Shadow, Light Novel, Volume 5, Chapter 4: Peace in Our Time!
6. The Eminence in Shadow, Light Novel, Volume 5, Chapter 4: Peace in Our Time!
7. The Eminence in Shadow, Light Novel, Volume 5, Epilogue: I'd Let the Whole World Burn, If That's What It Took!
8. The Eminence in Shadow: Master of Garden, Event Stories, Truth Seekers, Episode 2
9. The Eminence in Shadow: Master of Garden, Event Stories, Truth Seekers, Episode 3
10. The Eminence in Shadow: Master of Garden, Event Stories, Truth Seekers, Episode 6
