# Claire Kagenou/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Claire%20Kagenou/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Claire%20Kagenou/Image%20Gallery)

Main

Chronology

Relationships

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Profile Pictures

Claire's profile in English

Claire's profile in Japanese

Volume Illurstations

Claire on Manga Vol.7 Cover Japanese Version

Claire on Manga Vol.7 Cover English Version

Cid and Claire on Manga Chapter 30 Cover

Claire asking Cid if she looks good Midgar Academy Uniform

Claire strangling Cid angry for neglecting her

Claire being possessed by Aurora

Young Cid and Claire

Claire thinking that her dignity as a big sister is gone after crashing into Cid's classroom

Claire strangling Cid, angry for neglecting and lying to her

Claire revealing that she knows what Cid's thinking

Sketch

Vol 6 Illustration Claire by Sakano Anri

Vol 7 Illustration Claire by Sakano Anri

TEIS illustration Season 2 commencement by SakanoAnri

Summer Event Claire by Sakano Anri

Season 1

Claire in Episode 1

Season 2

Cid curing Claire of her Demon Possession

Claire in episode 32

Design

Young Claire

Claire in her Midgar Academy Uniform

Claire in her Combat Uniform

Sketch

Claire Kagenou by Director, Nakanishi Kazuya

Illustration

Sibling Time: Claire Kagenou

My Innocent Brother: Claire Kagenou

The Power In My Left: Claire Kagenou

Sister in Summer: Claire Kagenou

Dancing Sword: Claire Kagenou

Big Sister: Claire Kagenou

Indomitable Will: Claire Kagenou

Demonic Host: Claire Kagenou

Poster

Master Garden Twitter My Innocent Brother Promo

Master Garden Twitter Sister in Summer Promo

Master Garden Twitter Dreamy Summer Sunset Promo

Master of Garden Twitter Anime Expo 2023

Shadow Garden Twitter Anime Expo 2023

Masquerade: Claire Kagenou & Nu Versus Maximilian

Master Garden Twitter Dancing Sword Promo

Requiem for the Falling Shadows Illustrations

Game Event: Apocrypha "Requiem for the Falling Shadows": Demonic Gamma stabs Claire in a pervious timeline.

Master Garden Twitter Indomitable Will Promo

Game Event: Apocrypha "Requiem for the Falling Shadows": Claire, Beta, and Zeta's spare clothes

Offical Valetine's Day Illustration

Seven Shadows Chronicles: Cid and Claire Family Food
