# Eliza Despoht/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Eliza%20Despoht/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Eliza%20Despoht/Chronology)

Main

Relationships

Image Gallery

## Background

## The Academy Disappearance

## The Mist Terrorists Arc

During the Ghost incident when the Cult of Diablos attacked the academy for the second time, Eliza and the other students were forced to wear mana collars that determined the amount of their mana as a numerical value that went up to a maximum of 9999. During this time, she had her classmates fight one another to survive and for those who tried to rebel against her had their mana forcibly stolen. Eliza during these “matches” figured out that their mana could be transferred from one person to another by touching their collar or one could steal another person’s mana by touching their collar.

Eliza had those who tried to rebel against her and those who were lower ranking nobles or had low mana forcibly restrained and stole their mana. For those who had a low mana count from the start were tied up and thrown outside the classroom as bait for the ghost monsters. As a result, she ended up with the highest amount of mana: 1971, this was due to the fact that she was part of a powerful noble house, and the other nobles did not want to incur her wrath. Unfortunately for her, when she threw out her classmate Kanade, Alexia, Claire, and Cid (disguised as Suzuki) arrived and saved her life. Despite this, Eliza pretended to be a victim of the chaos and lied about how her classmates had died, while the remaining ones kept their mouths shut out of fear. But Cid as Suzuki managed to figure out what had really happened in the classroom and saved Kanade’s life by giving her some of his mana.

Cid then exposed her for what she did, as out of all her classmates she was the only one with a mana count of over one thousand. She tried to deny this, but Cid pointed out that her other classmates weren’t surprised by how he transferred mana to Kanade, meaning they knew about it all long. Kanade then admits and confirms Cid’s theory and also reveals Eliza’s heinous actions and how she had basically caused the deaths of several of her classmates. Eliza at first feigns ignorance but quickly reveals her true personality and attempts to bribe Alexia with some mana. However, Cid threatens her by grabbing her collar and tells her that if she doesn’t share her mana, he will break her collar which would kill her. Eliza terrified of Cid and knowing that she is no match for him, breaks down and agrees to share her mana and states that she did what she did because she wanted to live.

After Cid had defeated Fenrir the fifth seat of the rounds, Eliza was taken into custody to be tried for her crimes. However, when Cid met with Alpha, she mentioned that Eliza had managed to avoid the consequences of her actions as the nobles had made sure of that. Alpha stated that this just showed how truly corrupt the nobility are and what lengths they would go to hide their crimes.

## The Bloody Terror of Midgar Arc

When Eliza learned about Jack the Ripper, she wasn’t afraid as she believed that the thirteen night blades would eventually get the rid of this mysterious individual. During this, Eliza still looked down on the lower nobles and even toyed with them.

Eliza’s father Brad Despoht along with the remaining members of the thirteen night blades set a trap for Jack the Ripper. However, this proved to be a failure as they severely underestimated Jack the Ripper’s strength and as a result he wiped out the last of the thirteen night blades. Due to their demise, the royal family took swift action and proceeded to strip the families of the deceased thirteen blades of all their wealth and assets.

Eliza instead of being grief stricken was left irritated and angered that her father and the other thirteen blades had failed to take down Jack the Ripper. Eliza was also enraged that all the nobles that they had cozied up to, had turned on them as soon as all their family heads were killed. Eliza was left terrified as she knew that there was no one left to protect her from being imprisoned for her actions during the Mist Terrorists incident.

Eliza decided to try and revive the thirteen night blades with herself and the other children of the fallen night blades. Eliza called out for one of her servants, but none of them responded until she heard someone approaching her. Not realizing who it was, she handed a list to the unknown person, but to her shock and disbelief she was stabbed in the chest by the assailant. She turned around and saw it was Jack the Ripper and proceeded to smack the mask off their face.

To her shock, the person behind the mask turned out to be Christina Hope. Eliza asked if she had been Jack the Ripper the whole time, but Christina confessed that she was only succeeding the real one and finishing what they started. Eliza attempted to beg for Christina to spare her, but she ignored her cries and proceeded to remove the knife from her chest, causing her to bleed out and ending her life once and for all.
