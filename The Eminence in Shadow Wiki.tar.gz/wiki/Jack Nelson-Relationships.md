# Jack Nelson/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Jack%20Nelson/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Jack%20Nelson/Relationships)

Main

Chronology

Image Gallery

## Cult of Diablos

### Knights of Rounds

#### [Fenrir](Fenrir.md "Fenrir")

Fellow Round Knight member, the martial fanatic does not seem to respect the former researcher like other members of the Round Knights.

#### [Petos](Petos.md "Petos")

Fellow Round Knight member, their interactions is yet to be expanded upon. However, the two are after Diablos' tears and specialize in research as they target anyone with possession symptoms.

### Subordinates

#### [Venom](Venom.md "Venom")

Direct subordinate and servant. After losing to [Olivier](Olivier.md "Olivier") 10 years prior, Venom at an unspecified time started working for the Archbishop. When Midgar received word regarding [Drake](Drake.md "Drake"), Nelson ordered Venom alongside other assailants the death of the former Archbishop. Their relationship came to an end when the Executioner would fall by hands of [Epsilon](Epsilon.md "Epsilon") when the Archbishop tried to resist capture.

## Three Heroes

### [Olivier](Olivier.md "Olivier")

One of the Three Heroes responsible for sealing [Diablos](Aurora.md "Aurora"), Nelson alongside the Cult of Diablos only has control over a projected memory of her within the [Sanctuary](Sanctuary.md "Sanctuary"). The replica in question was merely a puppet that only acts at Nelson's order with no will of its own and performs as a being summoned at the Goddess' Trial and protect the Sanctuary from intruders. This was until Shadow obliterated the copies of Olivier and Nelson together with the Holy Sword that was used to sever Diablos' left arm along with the entire Sanctuary.

## Enemies

### [Aurora](Aurora.md "Aurora")

Being an original member of the Cult, the Archbishop was aware of her existence and capabilities in the battlefield. This was demonstrated during the briefing before Shadow and Aurora fought. He firmly believed that she will easily win but grew impatient as the battle went on, demanding that the Witch end it before being defeated in one strike. However within the Sanctuary unlike Olivier, neither the Cult nor Round knight seemed to have control over the fragmented memory of Aurora possibly due one of her body parts being alleged to be sealed within the area. When Cid appeared to have been mortally wounded, the Witch pleaded to the Archbishop to stop with his response being that she is useless without magic before agreeing to stop under the conditions that she will help him. This was all for naught when Shadow obliterated the Sanctuary, freeing the fragmented Witch in the process.

## Shadow Garden

### Shadow

At first, Nelson thought that Cid was a nobody who was fooled by Aurora into helping her. He did considered sparring the boy before being irritated by his rude attitude and tried ordering Olivier to kill him. Then, he cried out in horror when Cid revealed his magical capabilities and defeated Olivier while bypassing the Sanctuary's effects. He was killed by Cid's "I Am the All-Range Atomic!", Obliterating the Sanctuary and the Holy Sword that was once used by Olivier alongside it.

### [Alpha](Alpha.md "Alpha")

Despite being aware of her attempted disposal, Nelson was shocked to learn the blonde elven's survival and resemblance to her ancestor Olivier. When the Archbishop tried to set her squad up into an ambush, Alpha saw through it and left Delta to handle him. The two opposing sides fought to a standstill until Epsilon reported to her superior of the mission's success and left.

### [Delta](Delta.md "Delta")

Underestimating the therianthrope, Nelson was horrified of her overwhelming strength as she mindlessly slaughtered countless copies of him despite having the Sanctuary activate its effects. The onslaught continued until Alpha ordered her to stop to which she frightenedly obeyed.

### [Epsilon](Epsilon.md "Epsilon")

Nelson tried to resist capture when she approached him and became one of few people to be aware of her fake slime suit as a result. The prideful elf asked if he saw anything to which he responded that he did not see anything in hopes of saving skin.

## Others

### [Natsume Kafka](Beta.md "Beta")

Fellow host and spectator, Nelson was unaware of the writer's true identity and was seduced by her voluptuous figure into revealing information regarding Aurora when Shadow fought her. When the venue was raided by members of Shadow Garden led by Alpha, he did not care as much when the writer was being held "hostage" as he only tried to save his own skin.

### Alexia Midgar

Lead investigator of Drake's case and fellow host; Nelson was a person of interest as he actively avoided all attempts of investigating, irking the princess that she will need to be reapproved to conduct case within their jurisdiction and that the Church will handle it. Unlike the arrogant Archbishop, Alexia was able to analyze the battle between Shadow and Aurora and confidently conclude that Shadow will win the bout. The long string of avoidance came to an end when the Door of Welcoming activated and he was apprehended in connection. Alexia and Rose decided to follow suit in their own accord soon after.

### Rose Oriana

Fellow host, Nelson was unaware that the Oriana princess was a possessed in connection to the King's involvement with the Cult. However, upon being apprehended by Shadow Garden, Rose alongside Alexia followed them into the Sanctuary to look for answers regarding the recent events that has happen to them. Soon after the Sanctuary became defunct, the remaining hosts of the Goddess' trial formed an alliance out of powerlessness and being left in the dark regarding important information.
