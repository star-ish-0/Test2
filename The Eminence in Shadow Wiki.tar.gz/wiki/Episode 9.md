# Episode 9

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%209](https://the-eminence-in-shadow.fandom.com/wiki/Episode%209)

## The End of a Lie

### Kana

偽りの果て

### Romaji

Itsuwari no Hate

## Special Title

### English

The Eminence in Shadow Sometimes Want To Look up the Sky and Sigh!

### Kana

陰の実力者もたまには天を仰いで息を吐きたい！

### Romaji

Kage no Jitsuryokusha mo Tama ni wa Ten wo Aoi de Iki wo Hakitai!

## Episode Information

### Season

1

### Episode

9

### Air Date

November 30, 2022 JP
February 20, 2023 EN

### Adapted From

Volume 1 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Zeta ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Dark Knight Academy Under Attack | The Sacred Land, City of Deception |

The End of a Lie (偽りの果て, Itsuwari no Hate[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the ninth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

When the students fight back, Shadow Garden joins the fray as their reinforcements. Amidst the chaos, Cid confronts the Gaunt Knight.[[1]](#cite_note-1)

大講堂にたどり着いたシェリーは、“強欲の瞳”を無効化する装置を投入。学生が反撃を開始すると、シャドウガーデンも参戦。混乱の中、首謀者“痩騎士”の前にシャドウが現れる。[[2]](#cite_note-2)

## Summary

At dusk, Princess Iris and the knights are unable to do anything without their magic and are forced to stay outside the academy. As the knights struggle to formulate a counteroffensive, they start to consider another spy among the school, as Zenon Griffey was likely not working alone. Meanwhile, Gamma and her numbers await orders to move in, as [Nu](Nu.md "Nu") continues her vigilance amid the student hostages. In her father's office, Sherry completes her modification of the artifact and is ready to head into the tunnels to disable the Eye of Avarice. But before they step into the tunnels, Sherry reflects on her mother's murder when she was a child, and how Lutheran comforted her, offering to adopt Sherry. As Lutheran supported her mother's research, Sherry is determined to repay him as he'd always be stating how she was as great a researcher as her mother. Sherry thanks Cid for everything he did for her as he leaves her to head into the tunnels alone to complete her objective.

At nightfall, the Cult knight wonders why is [Rex](Rex.md "Rex") taking that long, his coughing getting worse, as a subordinate informs him that Rex and several guards are still unaccounted for. As some of the terrorist start shooting the students for fun, Rose orders the students to not do anything, as they won't stand a chance without their magic; and the Cult Knight being in another league than them. Once Sherry reaches the auditorium, witnessing the cruelty, she sees the Cult knight holding the Eye of Avarice and actives her artifact. In a bright flash, it disables the magic blocking field, providing an opening for Rose to attack one of the terrorists, stating their magic is back and leading the students to start fighting back. As the students retaliate, the terrorists are in disarray until ordered to attack by the Cult Knight, who moves to secure the other artifact Sherry used, observed by [Nu](Nu.md "Nu"). Rose sees the Cult Knight and moves to attack, but several attackers block her, so she resolves herself to end the threat in honor of Cid. However, she is saved by a precision cut of an enemy attacker, reminding her of a distant memory, before looking up and seeing she was saved by Shadow, dropping from the roof with the real Shadow Garden members to engage the terrorists.

Using the battle to cover their escape, Rose orders the students to vacate while Shadow notices the Cult Knight moving to a wall corner. As a terrorist attacks Shadow, he turns and finds the Cult knight left through a hidden door, and activates the pressurized gas system for the school's power and heating. As Sherry tries searching for her father amid the skirmish, she see the gaslights explode from gas flooding, causing the auditorium and the rest of the school to burst into flames, much to Gamma's surprise at the Cult's destroying their own territory.

With the barrier gone, Iris and the knight finally make a move and triage the situation, but find the terrorists are dead and the students are safe outside. Iris finds Rose and learns that once their magic was back, an organization called Shadow Garden came and killed the terrorists. Iris is shocked and asks if that was what they actually said, and Rose affirms as much, while she also notes the terrorists were also calling themselves Shadow Garden. As Rose and Iris express confusion, Nu informs Gamma that they retrieved the necessary articles, with only one piece of business left to address. Elsewhere, Sherry races to escape the bursting gas pipes seeking her father, while the Cult Knight rummages Lutheran Barnett's office to set a growing fire.

Inside the office, Cid appears and wonders why Lutheran is dressed like that, compelling the cult knight to remove his helmet, revealing he is indeed Lutheran. Wondering how Cid deduced his identity, Cid states it was obvious from the moment he saw him, with Lutheran pondering if it was his walk, cough, or stance. But Cid just wonders why he did all this, as he didn't seem the type. So Lutheran explains that he once reached the top of the sword fighting world, but his sickness easily lost him the glory he fought so hard to attain. When he started searching for a way to cure for his disease, he found potential in a certain artifact. He gave funding to Lukreia, Sherry's mother, for her research and eventually found the artifact he longed for, but Lukreia concluded the Eye of Avarice was too dangerous and wanted to give it to the government for safekeeping. Lutheran admits he killed Lukreia and details the method of his kill, and even though Sherry didn't see him there, she never realized it, and is continuing her mother's research.

Content with the explanation, Cid wonders if Lutheran used Sherry for his selfish reasons and the man confirmed as such. Asking if Cid is bother, the student is unsure, as he strives to ensure what's important or not to him. When Lutheran asks if Cid doesn't care for Sherry and Lukreia, Cid closes the book he was reading and suggests they start before someone else comes. Cid and Lutheran then face each other, but Lutheran cuts Cid in an instant and sends him falling through the window. But Shadow comes a moment later, and having experience with strong fighters, Lutheran immediately notes that he knows he is at a disadvantage against Shadow. Not wanting to waste time, he pulls out the Eye of Avarice and the control unit artifact, combining them to show Shadow their true value. As he does, he starts overflowing with magical energy, feeling reborn as his skin pulls back in distortion. Lutheran then starts attacking Shadow, but Shadow easily blocks his attacks without even moving from his spot. Although Lutheran strikes with a serious lunges at Shadow, he ends up cut by him.

Angered, Lutheran still continues to attack Shadow and explains that he ensured Shadow Garden would be blamed for the academy attack, hunted by everyone. Shadow finds that hilarious, explaining that something so small won't end his organization, neither good nor evil, as they walk their own path. Shadow accepts all the guilt for all crimes, but states that such won't change anything and they will continue to do what they must. Seeing Shadow unafraid to antagonize the world, Lutheran tells him that is defined as hubris, lunging to attack. However, Shadow then disarms Lutheran and proceeds stabbing his limbs, recalling precisely how Lutheran stated he killed Sherry's mother. Shadow stabs him the same way and kills him, with Lutheran's final moment realizing Shadow's real identity. In the moment, Sherry arrives just as Shadow is walking away, seeing her dead father and crying over his body. Seeing her, Shadow believes she is that it's better she doesn't know the truth, flying off into the night.

Sometime later, Shadow is labeled as an enemy to the kingdom and is wanted for the charges of mass murder, kidnapping, arson, and armed robbery. Gamma tells Alpha that Shadow stated he would gladly accept the guilt for all crimes, but that won't change anything and they will keep doing what they must. Alpha acknowledges his wise words, and noting that despite the guilt, the Shadow gardens numbers standing sentinel speak in unison that they will do what they will without hesitation. Alpha had thought they stood for righteousness, but Shadow doesn't seem to see it that way, and they must live up to his resolve. With Sherry's research and the remains of the artifacts in their possession, Alpha burns away the wanted poster and tells Gamma to assemble those available of the Seven Shadows.

With the extensive damage to the campus, the academy is closed for an early summer break. Sherry thanks Cid for his help the other day, telling him that she decided to study abroad in [Laugus](Laugus.md "Laugus"). As it is the leading city of scientific research, Cid congratulates and wishes her the best. Sherry explains how she needs to do something, but can't at the moment with her knowledge and having no reason to stay anymore. She wished to get to know Cid better, but Cid tells her they can do that next time. Before leaving, he asks her what she needs to do, and after a moment of silence quelling the pain, she tells him it is a secret. As they part, Sherry swears a vow as Cid continues walking.

## Characters

- Iris Midgar
- Alexia Midgar
- [Gamma](Gamma.md "Gamma")
- [Nu](Nu.md "Nu")
- Rose Oriana
- Lutheran Barnett (Death)
- Sherry Barnett
- Cid Kagenou
- Lukreia (debut; flashback)
- [Rex](Rex.md "Rex") (mentioned)
- [Alpha](Alpha.md "Alpha")

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第９話予告≪ノーマルVer.≫「偽りの果て」

TVアニメ『陰の実力者になりたくて！』第９話予告≪スペシャルVer.≫「陰の実力者もたまには天を仰いで息を吐きたい」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e009>
2. <https://shadow-garden.jp/1st/story/#story9>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • **Episode 9** • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
