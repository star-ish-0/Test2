# Victoria

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Victoria](https://the-eminence-in-shadow.fandom.com/wiki/Victoria)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Chronology](Victoria-Chronology.md "Victoria/Chronology")

[Relationships](Victoria-Relationships.md "Victoria/Relationships")

Image Gallery

## Victoria

- Light Novel
- Manga
- Anime
- Game

### Japanese

ウィクトーリア

### Romaji

Wikutōria

### Aliases

No. 559

Saint (formerly)

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

18[[1]](#cite_note-V4CA-1)

### Height

Unknown

### Hair Color

- Platinum Blonde (formerly)
- Strawberry Blonde[[2]](#cite_note-V4CP-2)

### Eye Color

Azure Blue

### Birthday

December 23

## Personal Information

### Status

Alive

## Professional Information

### Occupation

- Shadow Garden Member (Rank 89, Number 559)
- Priestess (excommunicated)
- Leader of the Templars (excommunicated)

### Affiliation

Shadow Garden
Holy Church of Divine Teachings

## Debut

### Light Novel

Volume 4

### Manga

Chapter 40

### Anime

Episode 20 (cameo)

### Game

Chapter 10 - Seven Chronicles

## Portrayal

### Japanese

[Miku Itō](https://en.wikipedia.org/wiki/Miku_It%C5%8D "wp:Miku Itō")

### English

[Molly Searcy](https://en.wikipedia.org/wiki/Molly_Searcy "wp:Molly Searcy")

### French

Julie Mouchel

### Italian

Elena Mancuso

Victoria (ウィクトーリア, Wikutōria[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a member of Shadow Garden and an excommunicated clergyman of the Holy Teaching religion. Inside the church, she held the position of Saint and led the [Templars](Templars.md "Templars")—a powerful group of zealous warriors.[[2]](#cite_note-V4CP-2)[[3]](#cite_note-SSC_P2C2E4-3) After joining Shadow Garden, she received the numerical designation of 559 and began to collaborate with [Zeta](Zeta.md "Zeta")'s clandestine faction. Now, her pious devotion is directed towards Shadow instead of her past vocation.[[4]](#cite_note-V5C1-4)

## Appearance

Victoria is a rather statuesque woman, standing nearly as tall as Cid was in his previous life and towering over 664, 665, and 666. In the anime she has long strawberry blonde pink hair that reaches below her hips and covers her left eye. Others have described Victoria as a beautiful girl. Rose Oriana depicted her beauty as sublime as a goddess. Her face typically bears a cold and intimidating expression. The eyes reflect lifeless countenance unless they are in the presence of Cid. Victoria's apathetic face becomes animated and attentive.

In terms of attire, Victoria wears a unique version of the Shadow Garden standard slime bodysuit. She sports a short-torn cape on her back and a large shoulder pauldron, giving a more armored look than regular members. The pauldron has several belt straps dangling over her cape. Each strap is measured at her arm's length and continues from the pauldron to her right shoulder and connects to her cape. Her attire has a frilled neckline at the collar, dress with an opening at the bust that ends in a tattered material, while there are more belt straps coming from her abdominal section. Her leg is a standard Bodysuit design but with long thigh high boots, or stockings given the clip-on straps, with a pattern at the top then again at her lower legs in a V shape edging, and with short-heeled soles.

She is also adorned with a veil on the temples of her head, held there by a tiara giving her the alluded appearance of having horns. In the light novel, these horns are depicted as floating just off the tiara only connected by stands of slime from the bodysuit. While in the manga, the horns are solid in design, more like a one-piece item. In the anime, although brief, her tiara appears to be a one-piece item as well with the horns intact.

### The Saint

As Saint, Victoria previously wore a bright white outfit with gold accents. A long apron that covered her reaching down to her feet, her arms were covered with tight white sleeves, which covered her from almost her upper arms to her hands. Her black undershirt was the only part of the uniform that was not a bright color. The shoulder pads are made of a angelic feather-shaped fabric with golden edges on the tips and sides, and she had a long white cape, which was behind Victoria's back, reaching almost to her knees. On Victoria's neck, it was half covered with a long feather-patterned cloth, with an ornament, in the shape of a golden Jewel right in the center of her neck.

Victoria's hair used to be a semi-golden vanilla color, complemented by bright light blue eyes. Those eyes were frequently covered by a lace-like black mask with spider web-like patterns. Victoria also sported a crown of golden leaves on her head, paired with a long, thin white apron featuring a feather-like design on the sides and golden striped patterns along the edges. Her hair color later changed to bright pink due to exposure to unspecified sorcery. But later on her hair color changed to Strawbery Blonde due to the Shadow healing her eyesight.[GAME ONLY][[5]](#cite_note-5)[[6]](#cite_note-6)

## Personality

|  |  |  |
| --- | --- | --- |
| “ | It’s my duty to purge any who are unworthy of his grace. | ” |
| — Victoria, Light Novel Volume 04 | | |

During her time as the Saint, Victoria was noted for her kindness and naivety, possessing a gentle and kind-hearted soul towards believers.[CITATION NEEDED] Cid once recollected her as an innocent and timid girl.[[2]](#cite_note-V4CP-2) While leading the Templars, Victoria displayed care for her subordinates and maintained a saintly demeanor, even when discussing matters like purging heretics or condemning Shadow Garden as a heretical organization. However, after a demonic possession and subsequent betrayal by those she once relied upon, Victoria's personality underwent a drastic change. In her current state, she typically projects a cold and intimidating aura, having lost her kind and caring nature due to her tragic past.

What sets her apart is her unwavering dedication to her cause, even at the cost of her own safety and life. Victoria's approach is ruthless when dealing with those she perceives as enemies, without hesitation or remorse. She harbors an absolute and deadly hatred toward the Cult of Diablos as well as the Church and their preaching and is solely dedicated to Shadow Garden's mission of destroying them by all possible means. She is utterly unconcerned about the safety of innocent people and will eliminate anyone she deems unworthy to be by her master's side, regardless of whatever side that they are aligning to: Shadow Garden or the other. This includes her fellow Shadow Garden members, as she has demonstrated a strict and unforgiving leadership style. She doesn't hesitate to scold or even brand them as traitors if they deviate from their mission, further emphasizing her single-minded and relentless pursuit of her goals.[CITATION NEEDED]

However, Victoria is not without faults. She is headstrong and reckless, at times charging into battle without any strategy. This is further supported by her communication problems, as she does not even bother to explain mission objectives to her subordinates.[CITATION NEEDED]

But the truth is that Victoria is a spoiled girl when she is with her master, Shadow. Evidently, she would make a cute expression on her face and grab the sleeve of Shadow's coat which is her first habit after he completely healing her [Possession](Possession.md "Possession") symptoms, also make a dissatisfied expression and kept tugging at his coat sleeve when her request was rejected by Shadow. However, when her wish was granted, her eyes would light up with joy. Victoria still, to this date, likes to tug on his coat whenever she gets the chance to meet him personally.[CITATION NEEDED]

Similar to the members of the Seven Shadows, Victoria utterly adores Shadow. In his presence, the usual cold demeanor immediately disappears, and her attitude is replaced with that of an infatuated young girl. On the other hand, her adoration causes her to be jealous of others. For example, she exhibits needless cruelty toward Rose Oriana (666), whom she considers unworthy of her lord's attention. She also desperately tries to rise through the ranks and wishes to become a higher-ranked member of Shadow Garden and eventually a member of the Seven Shadows so that she can get closer to Shadow.[CITATION NEEDED]

## Power & Abilities

Prior to joining Shadow Garden, Victoria was already a powerful individual, being known as the Saint. [Drake](Drake.md "Drake") considered her to be the most suited to lead the [Templars](Templars.md "Templars") and even the 5th seated Knight of Rounds, [Fenrir](Fenrir.md "Fenrir"), acknowledged her capabilities. After joining Shadow Garden, she quickly rose through the ranks and her current abilities are rumored to rival those of the Seven Shadows, with even [Alpha](Alpha.md "Alpha") noting that she was almost as strong as her when they first met.

### Swordsmanship

Prior to joining Shadow Garden, Victoria had already honed her skills as a formidable swordsman under the Church's rigorous training. In a childhood encounter with two of the seven shadows, Alpha and Zeta, she demonstrated remarkable resilience in a battle of attrition, though it's worth noting that she had the support of her Templar soldiers. Despite her prowess, they observed that Victoria's swordsmanship lacked discipline and she would find herself lagging behind the Seven Shadows in subsequent encounters. However, after joining Shadow Gardens, Victoria's swordsmanship rapidly improved, rivaling the Numbers.

### Magic

In terms of magical power, Victoria was already strong before joining Shadow Garden. When she joined the organization after being healed and receiving Shadow's power, her abilities grew to a point where she could nearly rival those of the Seven Shadows, even being able to defeat some of the weaker members.[[2]](#cite_note-V4CP-2)

### Physical Capabilities

Strength: Victoria's combat prowess is rumored to almost rival that of the members of the Seven Shadows, defeating the far more experienced [No. 89](89.md "89") without much effort. She was also able to almost single-handedly battle a large squadron of First Children and, though she was ultimately defeated through sheer numbers, she managed to defeat all but one of her opponents.[[2]](#cite_note-V4CP-2)

Endurance: Victoria has shown to be able to continuously fight for three days straight, during which she was unable to sleep, eat, or drink and suffered multiple injuring including losing an arm and gaining a large gash in her stomach, before ultimately being overwhelmed by sheer fatigue.

### Equipment

- Slime Bodysuit: After being rescued and joining Shadow Garden, Victoria received and began to use the Slime suit from Shadow Garden. After understanding its operation and explanation of its use within the organisation, Victoria used it and improved to fit her, giving a defense, resistance, versatility, and use of magic that was much stronger than when she was the Saint.
- Slime Weapons: Like the other members of Shadow Garden, Victoria can use her Slime sword very effectively, being able to be on par in fencing combat approximately to the level of the Numbers. Claiming that she was able to defeat any enemy from the First Children to even the generals of the Cult of Diablos.[[2]](#cite_note-V4CP-2)

## Trivia

- Victoria gained a portion of [Epsilon](Epsilon.md "Epsilon")'s role in the Web Novel, where she was the injured Shadow Garden member saved from defeat by Shadow.[CITATION NEEDED]
- For a time, it was unclear what race Victoria was in Light Novel, Manga and Anime, until the release of the Game. In the game, she is confirmed to be an [Elf](Elf.md "Elf").[CITATION NEEDED]
- According to the Game, Victoria seems like she was good at dancing, both for ceremonies she did in private and occasionally when she fought beautifully. According to her, it seems she did it in honor and pleasure of the Goddess Beatrix, before losing her position as Saint. [CITATION NEEDED]
  - In the Game, when Victoria prayed to the Goddess Beatrix, she believed that this goddess lived in the heavens, specifically the Moon. When she met [Zeta](Zeta.md "Zeta") again, Victoria was seen looking at the full Moon, saying that it was the Will of the goddess that they met again.[CITATION NEEDED]

## References

1. Volume 4 Appendix
2. Volume 4 Prologue: It's Time for a War in the Oriana Kingdom!
3. Seven Shadows Chronicles, Part 2: Sturm of Velgalta, Chapter 2: A Brilliant Mission!, Episode 4: Prophetess' Doubt
4. Volume 5 Chapter 1: Claire’s Back, and Her Symptoms Are Worse Than Ever!
5. Seven Chronicles. Chapter 26: Faith and Conviction!
6. Seven Chronicles. Chapter 41: Flash! God-Killing Shadow

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • **No. 559** • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
