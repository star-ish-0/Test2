# Delta

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Delta](https://the-eminence-in-shadow.fandom.com/wiki/Delta)

[Chronology](Delta-Chronology.md "Delta/Chronology")

[Relationships](Delta-Relationships.md "Delta/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | I’m good at hunting. | ” |
| — Delta, Light Novel Volume 02 | | |

## Delta

- Light Novel
- Manga
- Anime
- Game

### Japanese

デルタ

### Romaji

Deruta

### Aliases

Gunshot Delta
Suicide Weapon Delta
Sara (birth name)
Tyrant
Deltan [[1]](#cite_note-1)[ANIME-ONLY]

## Characteristics

### Race

[Therianthrope](Therianthrope.md "Therianthrope") (Wolf Therianthrope)

### Gender

Female

### Age

10-13 [[2]](#cite_note-V1CP-2)
15 [[3]](#cite_note-V1C1-3) (Currently)

### Height

Unknown

### Hair Color

Black

### Eye Color

Purple

### Birthday

April 29

## Personal Information

### Status

Alive

### Relatives

- Unnamed Father
- Unnamed Biological Mother †
- [Zabra / Leaf Four](Zabra.md "Zabra") † (Older Half-Brother)
- [Ren](Ren.md "Ren") † (Older Brother)
- [Ral](Ral.md "Ral") † (Older Brother)
- Several Hundred Siblings

## Professional Information

### Occupation

4th Seat of the Seven Shadows

### Affiliation

Shadow Garden

## Debut

### Web Novel

Chapter 4

### Light Novel

Volume 1

### Manga

Chapter 2

### Anime

Episode 1

### Game

Chapter 1 - Episode 1

## Portrayal

### Japanese

[Fairouz Ai](https://en.wikipedia.org/wiki/Fairouz_Ai "wp:Fairouz Ai")

### English

Raven Troup

### French

Charlotte Hervieux

### Italian

Katia Sorrentino

### German

Lara Schmidt

Delta (デルタ, Deruta[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Δέλτα), born Sara (サラ, Sara[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), is the fifth initial member of Shadow Garden and the fourth seat of the Seven Shadows. Primarily dispatched for combat missions, she frequently undertakes assassinations or military campaigns that necessitate overwhelming force, lacking the intelligence to do much else.[[4]](#cite_note-V1C3-4)[[5]](#cite_note-V3C6-5)[[6]](#cite_note-V6C3-6)

## Appearance

Delta is a young female wolf [therianthrope](Therianthrope.md "Therianthrope") with large canine ears and a fluffy tail. She sports purple eyes with vertical slit pupils that become circular when she is happy.[ANIME ONLY][[7]](#cite_note-AS2E6-7) Retaining an athletic yet curvaceous build, Delta's body possesses chiseled muscles and well-defined contours.[[8]](#cite_note-8)[[9]](#cite_note-AS1E13-9)

In her daily life, she wears a dark suit with long-sleeved clothes around her neck and opens around her stomach, a pair of gloves, shorts combined with stockings, and a pair of shoes. Oftentimes, Delta will wear a variation of this trend with different materials, but always wears something to accentuate her athleticism and form. However, some exceptions occur, such as during the winter she helped Cid dig for Gettan's buried treasure.

When serving in Shadow Garden, she wears the customary slime bodysuit with black and gold decorations, but with the individualized accessories of fur adornments on the collar, wrists, and ankles. Delta's top has the basic dark attire with twin vertical gold lines running up the central third of her torso before joining two violet gems accents. The gems fall in line where another gold lining traverses her upper pectoral outline above her bust, with gold shoulder pads connected to the gems. Her shoulders have a slight bagginess before connecting to two gold rings where her deltoids meet her arms in regular black sleeve, connecting to standard cestus around both of her forearms and black gloves. Her top is wrapped around the diaphragm by a slight belt where the seam splits underneath to reveal her abdomen.

Her lower half is dressed in leggings with lighter black that have straps from both edges of her lower abdomen wrapping around her hips to the back, resembling short shorts. Her upper thighs have a gold ring each where the leggings get darker going further down the limbs, with a gold diamond shape a few centimeters down the center fold on both legs from the gold rings. Down the legs past the fur accents on her ankles, Delta has a pair of gold chevrons pointing up her feet. Delta's tail has a thick gold ring with an inlaid division around the center at the base of her tail and a matching ring towards the end of her tail with an ornament of two bells and a tassel ribbon at the end.

In the game and light novel, Delta wears a gold laced gem on both hips of her trouser line.

In the light novel, there are more detailed grooves on her leggings as well as a trio of belt wraps on both arms around the biceps/triceps.

In the manga, she sometimes she wears a mask to protect her original identity.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Don’t care; shut up. Weaklings should just be quiet. | ” |
| — Delta, Light Novel Volume 03 | | |

Hunting for Delta surpasses a mere way to get food; it is inseparable from her identity. Ever since she was three, she concluded that hunting was the reason for her existence. It revealed to her that one can sustain oneself through strength. The only things that retain value are obtained by oneself.[[10]](#cite_note-10)[[11]](#cite_note-V2C3-11) Her therianthrope background and hunting connection feed into her life philosophy of might makes right—the strong dictate direction and morality and those who are weaker follow.[[11]](#cite_note-V2C3-11)[[12]](#cite_note-V3C4-12) Consequently, Delta only acknowledges and answers to strength, holding the weak in contempt. Wanting to overcome the stigma of her mother's tragic death from sickness, this ideology remains constant and pertains even to family members.[[12]](#cite_note-V3C4-12)[[13]](#cite_note-V6SS-13)

Delta’s might logic—musclehead—and reliance on strength-based solutions leave fellow Shadow Garden members exasperated. For those who Delta acknowledges or accepts as family, she presents a docile nature. She displays a childish innocence that manifests through a playful demeanor and naïve interpretation of the world.[[4]](#cite_note-V1C3-4) Delta’s juvenile perceptions likewise make her easily excitable and impulsive. These impulsive tendencies are near-uncontrollable. Even if she temporarily suppresses urges, they will manifest later through more damaging actions.[[12]](#cite_note-V3C4-12)

Conversely, her enemies receive the full brunt of her feral temperament, revealing a brutal and merciless character.[[14]](#cite_note-V2C2-14)

## Powers & Abilities

Delta’s environment and societal reinforcement shaped her into a warrior.[[13]](#cite_note-V6SS-13) When she was three, she killed a wild boar, an unheard-of achievement even among therianthropes. At age twelve, only the chief of the tribe could challenge her strength.[[11]](#cite_note-V2C3-11) After joining Shadow Garden, her power continued to develop until she became one of the organization's strongest combatants. Cid has identified Delta as the Seven Shadows' "most talented (physical) fighter."[[4]](#cite_note-V1C3-4)[[12]](#cite_note-V3C4-12)

### Swordsmanship

Delta initially adopted the katana as a primary weapon; however, she failed to comprehend the subtleties of swordsmanship. Instead, Delta substitutes technique for brute force. Movements might be simple, but massive power lies behind them. Each swing possesses enough force to create shock waves, further augmenting the power of her unceasing onslaughts. This strength compliments the adaptability of slime weapons. Increasing the size of a sword and instilling enough force maintains the benefits of a blunt weapon without composing the advantages of slicing weapons. Onlookers describe watching this combat approach as “unbridled violence.”[[15]](#cite_note-V1C4-15)[[14]](#cite_note-V2C2-14)[[9]](#cite_note-AS1E13-9)

### Martial Arts

Delta's hand-to-hand combat lacks the artistry of Cid’s grappling techniques, but the simplicity allows for the injection of substantial might. Drawing from her therianthrope roots, Delta commonly reverts to claw-based attacks whenever the situation permits open-handed strikes.[[14]](#cite_note-V2C2-14)[[7]](#cite_note-AS2E6-7)

### Physical Capabilities

In terms of raw physical power, no Seven Shadow or Number is Delta’s equal.[[15]](#cite_note-V1C4-15)[[12]](#cite_note-V3C4-12) She adeptly utilizes this strength to augment personal shortcomings in other areas of combat. On numerous occasions, she demonstrates physical feats that well exceed other dark knights. These can include bombastic displays of bisecting a building or a subtler—but not less powerful—display of shattering a magically reinforced sword with her canines.[[4]](#cite_note-V1C3-4)[[14]](#cite_note-V2C2-14)

Delta's sensory capabilities are also one of her most potent attributes. Bolstered by her natural therianthrope body, hunter identity, and superior ability, Delta's hearing and sense of smell exceed almost every other member of Shadow Garden. Cid confesses that even with magic augmentation, he cannot equal her sensory powers. She demonstrates an ability to track and identify targets even through high-level camouflage. Another physical skill that Cid complements is Delta's presence suppression. A self-proclaimed master of hide and seek, Delta's concealment mastery is the highest out of the Seven Shadows.[[14]](#cite_note-V2C2-14)[[12]](#cite_note-V3C4-12) The aforementioned covert movement, Delta's innate tracking, and speeds that surpass typical visual perception make her invaluable for assassinations and abductions.[[5]](#cite_note-V3C6-5)[[12]](#cite_note-V3C4-12)[[6]](#cite_note-V6C3-6)

### Magic

Despite never receiving a formal dark knight education, Delta intuitively learned to use magic before becoming affiliated with Shadow Garden.[[11]](#cite_note-V2C3-11) Cid's later teachings failed to instill magic nuances. As an alternative, Delta adheres to his advice of "infuse your slash attack with a bunch of magic."[[15]](#cite_note-V1C4-15) Every attack is backed by immense physical strength and copious amounts of magical power. While Delta does not have the same level of control as her fellow Seven Shadows, she can satisfactorily manipulate her custom slime bodysuit. In magic-suppressant circumstances, it proved adequate to maintain and control a large slime weapon and minimal body cover.[[14]](#cite_note-V2C2-14)

Delta further demonstrates a capacity for both body and weapon enhancement. Taking full advantage of her "superlative" physique, Delta displays creative techniques by augmenting body parts outside the core and limbs. As an example, by enhancing her lungs, Delta can launch a powerful breath-like attack. It has shown to be capable of heavily damaging her opponent's hearing, repelling projectiles, and destroying the surrounding area.[[9]](#cite_note-AS1E13-9)[[7]](#cite_note-AS2E6-7)[ANIME ONLY]

### Intelligence

Despite being a capable warrior, Delta's weakness is her lack of intelligence—derived from simple-mindedness and an inability to control personal bloodlust. She is incapable of any complex thought in or out of combat. Her powerful combat instinct compensates for the lack of strategy and tactics.

### Weapons and Equipment

- Slime Bodysuit: A standard issue Shadow Garden bodysuit.
- Slime Weapons: Delta, like the other members of Shadow Garden, uses a sword made of Slime. In the Game and Anime, Delta explores other slime weapon variations.
  - Bagh Nakh: In the Game, Delta uses huge claws made of slime as her primary weapon.

## Trivia

- The manga depiction of the assault of Midgar Academy featured other Seven Shadows, including Delta. [Gamma](Gamma.md "Gamma") was the only Seven Shadow who could respond to the situation in all other adaptations.[[16]](#cite_note-16)
- Delta's character is based on a dog that Daisuke Aizawa once raised.[[17]](#cite_note-17)
- In the Game, Delta, like Shadow, uses training weights.[GAME ONLY][[18]](#cite_note-18)
- Delta claims that she can tell if someone is lying just by licking their face.[KAGEJITSU ONLY][[19]](#cite_note-19)

## References

1. Anime Season 2 Episode 8: The Dragon's Tears
2. Volume 1 Prologue: Preparing the Perfect Stage!
3. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
4. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
5. Volume 3 Chapter 6: Circulating Counterfeit Cash!
6. Volume 6 Chapter 3: Deciphering the Calling Card!
7. Anime Season 2 Episode 6: John Smith
8. Volume 1 Color Inserts
9. Anime Season 1 Episode 13: A Bloody Showdown as an Offering to Annihilation
10. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
11. Volume 2 Chapter 3: When Things Get Boring, It’s Time for Explosives!
12. Volume 3 Chapter 4: I'll Destroy It All and Start from Scratch!
13. Volume 6 Side Story: The Grassland Vow
14. Volume 2 Chapter 2: Investigating the Sanctuary!
15. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
16. Manga Chapter 12
17. [Animate Time: Interview with Daisuke Aizawa](https://www.animatetimes.com/news/details.php?id=1672213867&p=3)
18. Seven Shadow Chronicles Part 1, Chapter 14-1
19. [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu"): Episode 15

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • **Delta** • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
