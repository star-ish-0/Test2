# Nina

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Nina](https://the-eminence-in-shadow.fandom.com/wiki/Nina)

[Chronology](Nina-Chronology.md "Nina/Chronology")

[Relationships](Nina-Relationships.md "Nina/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | Man, I always get stuck with the dirty work. | ” |
| — Nina, Light Novel Volume 05 | | |

## Nina

### Japanese

ニーナ

### Romaji

Nīna

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

18

### Height

Unknown

### Hair Color

Red

### Eye Color

Yellow

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Student (Cover)

### Affiliation

Midgar Academy for Dark Knights (Undercover)
Shadow Garden (Unofficially)

## Debut

### Light Novel

Volume 5

### Manga

Chapter 57

### Game

Seven Shadows Chronicles: Edge of Realm: Chapter 3 - Mechanical Heartbeat

Nina (ニーナ, Nīna[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a third-year student at Midgar Academy for Dark Knights and Claire's best friend. She's secretly the personal subordinate of [Zeta](Zeta.md "Zeta"), but she works outside of the organization Shadow Garden and part of Zeta's faction in resurrecting [Diablos](Aurora.md "Aurora").

## Appearance

Nina is a human girl with long red hair, tied in a ponytail, with ornaments, yellow eyes, brown skin, with a cat or dog-shaped smile. She usually wears semi-revealing clothing and has a large and mysterious scar on the left side of one of her breasts (see the [Trivia](#Trivia) section). As a student of Midgar Academy, she wears the Midgar Academy for Dark Knights uniform, she also lets loose of her upper white dress shirt's buttons, she also wears a black pair of stockings with garter belts, and high heels.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Haven't seen you in a while, Young'un. | ” |
| — Nina to Cid Kagenou, Light Novel Volume 05 | | |

Nina is a cheerful and easygoing girl who does most things with an upbeat attitude, even displays a smile on her face most of the time. Highly social and excitable, she loves to hang out with her friends, especially Claire. But in fact, Nina is noticeably calm and collected, being able to stay levelheaded and focused even during the most stressful situations.

At first glance, Nina may seem like the typical Gyaru type girl while she hides her smart and talented self as a cover to protect Claire. However, Nina possesses a kind side despite her calm demeanor as seen when she had shown to care for Claire upon seeing her painful condition during the process of fusing the severed right arm of Diablos into her body.

Nina is also seeming to have little sense of shame as she shamelessly talks to Claire and Alexia while only wearing in her undergarments, even she doesn't mind being seen with her breasts when her bra fell off later due to Claire.

## Powers & Abilities

Nina's overall abilities remain mostly unseen. However, the fact that she became the personal subordinates directly under [Zeta](Zeta.md "Zeta"), one of the Seven Shadows showed that her skills had been recognized so that she became Claire Kagenou's secret bodyguard. Despite not being Shadow Garden's official member, [Victoria](Victoria.md "Victoria") herself notes that Nina would be strong enough to challenge the Numbers if she actually joined Shadow Garden.

### Physical Prowess

Nina isn't really good at academics nor ability at the Midgar Academy for Dark Knights, but Cid notices that she hides her true prowess and that she's stronger than his sister Claire. She is proficient at regular tasks at the school level and routine work.

### Adept Intellectual

During her infiltration at the Academy, Nina apparently faked her grades so that her academic performance is quite poor, but the actuality is not.

### Strong Intuition

Although her abilities are unknown, Nina appears to be highly intuitive as she able to escape the Cult's trap prepared by [Isaac](Isaac.md "Isaac") without a second thought.

### Stealth

Nina is also talented in stealth and infiltration due to her ability to blend in anywhere. She is able to sneak into the forbidden library easily to retrieve any book when Cid wants to read it completely undetected, even the [Head Librarian](Willow.md "Willow") who was a member of the Cult of Diablos when he intercepted Alexia Midgar and Claire Kagenou who were intending to take the forbidden book out of the library didn't notice and sense her presence.

## Trivia

Nina has an artificial heart. Her heart was gouged out by members of the cult and Zeta replaced it with an experimental artifact.[[1]](#cite_note-1)

## References

1. The Eminence In Shadow: Seven Shadows Chronicles, Edge of Realm Ch. 3: Mechanical Heartbeat

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • **Nina** | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • Alexia Midgar • Christina Hope • [Isaac](Isaac.md "Isaac") • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |
