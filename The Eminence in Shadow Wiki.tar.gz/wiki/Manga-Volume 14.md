# Manga/Volume 14

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2014](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2014)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_14?action=edit).

## Manga Volume 14

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041155745

### ISBN EN

ISBN 979-8855423136

### Release Date

November 25, 2024 JP
April 28, 2026 EN

## Volume Information

### Pages

144

Publication Order

| Previous | Next |
| --- | --- |
| Volume 13 | Volume 15 |

This is the fourteenth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

“What a fine night it is to cut the past loose.” Cid’s enjoyed his little visit to his old stomping grounds in post-apocalyptic Japan, but he beat the big monster already, and all the secret conspiracies around here seem to be falling apart, so it’s probably about time he returned to the awesome fantasy world he came from. Just one hitch, though—in the end, just what was his former classmate Akane’s deal?[[1]](#cite_note-1)

「過去を断ち切るには、いい夜だ」。在りし日の宿縁の果てには――。

異世界に転生し、あらゆる物事に陰から介入し
実力を示す「陰の実力者」設定をエンジョイしているシド。
前世で暮らしていた日本に飛ばされるが…「漆黒の騎士」として、魔獣ブルートゥルを倒す。
そして計画が整い、西野アカネを取り巻く日本での闘いが――。

重度の勘違いと比類なき強さで無双する、克服の第１４巻！[[2]](#cite_note-2)

## Summary

## Chapters

- Episode 54
- Episode 55
- Episode 56
- Episode 57

## Characters

:   In order of appearance:

## References

1. [The Eminence in Shadow, Vol. 14 (manga) Yen Press](https://yenpress.com/titles/9798855423136-the-eminence-in-shadow-vol-14-manga/)
2. [The Eminence in Shadow (14). Kadokawa](https://www.kadokawa.co.jp/product/322407001889/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • **Volume 14** • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
