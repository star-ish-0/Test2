# Lambda/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lambda/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Lambda/Image%20Gallery)

[Main](Lambda.md "Lambda")

[Chronology](Lambda-Chronology.md "Lambda/Chronology")

[Relationships](Lambda-Relationships.md "Lambda/Relationships")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Lambda in in slime suit without her cloak

Lambda in in slime suit with her cloak

Ending art

Polaris in the Night

Ruthless Instructor: Lambda

Bitter Patissier: Lambda

Game Event: Be Mine! Sweet Valentine

Game Event: Interlude
