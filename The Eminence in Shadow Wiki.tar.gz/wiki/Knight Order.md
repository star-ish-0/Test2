# Knight Order

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Knight%20Order](https://the-eminence-in-shadow.fandom.com/wiki/Knight%20Order)

The Knight Order (騎士団（きしだん）, Kishi-dan[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a principal body for public chivalric orders in the New World.

## Overview

Other World

The ranks in the knight order are separated by uniforms. In the Anime the knights' uniforms are by color.

[Earth](Earth.md "Earth")

The knights on earth are categorized by their ranks.

## History

It has always been that the knight order is this world that the police but now they are a support organization for the Crimson order.

## Chronology

### Princess Alexia's Kidnapping

## Equipment and Artifacts

Other World

- Swords
- Riot Shields (Anime only)
- Firearms (Anime only)

Earth

- Katana
- Spear
- Firearms

## Known Members

Other World

### Midgar Kingdom

- Iris Midgar (Leader formally now a high-ranking official as leader of the Crimson Order)
- [Glen](Glen.md "Glen"), the "Lion Mane" (Deceased)
- Marco Granger
- Marquis Zenon Griffey (Deceased)
- [Viscount Jean](Jean.md "Jean") (Deceased)
- [Adder](Adder.md "Adder")
- [Gray](Gray.md "Gray")

### Oriana Kingdom

- [Kouadoi](Kouadoi.md "Kouadoi") (Deceased)
- [Kevin](Kevin.md "Kevin")

### Velgalta Empire

- Annerose Nichtsehen: Member of the Velgalta's Seven Blades (Formerly)
- [Zinaida](Lambda.md "Lambda") (Formerly)
- [Baroness Karen von Herzog](Chi.md "Chi"): Member of the Velgalta's Seven Blades (Formerly)
- Sergey Gorman: Member of the Velgalta's Seven Blades (Deceased)
- Stan Bach: Member of the Velgalta's Seven Blades (Deceased)
- [Olga](Omega.md "Omega") (Formerly)

Earth

### [Messiah](Messiah.md "Messiah")

- Akane Nishino
- [Haitani](Haitani.md "Haitani") (Commander)
- Yuudai Saejima (Vice Commander; Deceased)

## Image Gallery

## Trivia

- The high-ranking members wearing blue cloak, the middle ranking members wearing green cloak, and the lower ranking members wearing black cloak.
  - [Earth](Earth.md "Earth")'s version of the order as members of [Messiah](Messiah.md "Messiah") wear school uniforms from Sakurazaka High School.

## References

## Site Navigation
