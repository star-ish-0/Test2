# Elisabeth/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Elisabeth/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Elisabeth/Chronology)

[Main](Elisabeth.md "Elisabeth")

[Relationships](Elisabeth-Relationships.md "Elisabeth/Relationships")

Image Gallery

## Background

### Tragedy of a Dream

A thousand years ago, Elisabeth is a Vampire Progenitor, making her one of the most powerful vampires in existence. However, unlike other [Vampire](Vampire.md "Vampire") Progenitors who had used their abilities for survival or for evil, she preferred to have a calm and peaceful life, even eating normal human food and not drinking human blood. Elisabeth wants to believe that vampires can coexist with the other races, even if she had to sacrifice herself in order to build her utopia. To make it happen, Elisabeth and her subordinates worked to protect the borders of the small country they controlled. They join forces with people to cultivate fields, fight monsters, and rule over territories.

On the night of the rise of the Red Moon, [Crimson](Crimson.md "Crimson") manipulating the Progenitor to fulfill his own desires of restoring their race to greatness by making her taste the human blood as he sneaks the food mixed with human blood, making Elisabeth go rampage under the influence of the Red Moon he went out of control by killing and devoured all the humans in the region, along with the vampires who had been driven into a corner and rose up in revolt.[[1]](#cite_note-V3C2-1)

The Red Moon lasted a total of three days, which she even ravaged three countries in three days. Within the first night, one country was obliterated. Within the remaining two nights, three more countries were damaged beyond the point of recovery. When the Red Moon finally went down, the Blood Queen and her kin abruptly withdrew and hid themselves, waiting until the day when humans forget about them entirely.[[1]](#cite_note-V3C2-1)

After regained her senses, Elizabeth is filled with immense guilt as she regretted and cried for the terror she unknowingly brought upon the world and decides to take her own life to ensure she will never harm any more lives when she lost control of her vampire nature. However, she didn't die but was merely put into a comatose state that looks like she was dead and asked [Mary](Mary.md "Mary") who is her follower also her second-in-command to kill her by stabbing her heart and cast her ashes into the sea, so that she can never rise again, and the incident will not be repeated.[[1]](#cite_note-V3C2-1)

After giving the order, she pierced Elisabeth heart with a sword but missed as Mary can't do the deed even if she couldn't go against her master's will and decides to hide the Blood Queen's body in a coffin and protected by Mary as she vowed to protect her forever from Crimson after the incident. However, a few years later, Crimson snatched the coffin from her and want to use its power by revived her for subduing humans again, waiting for the "Red Moon" to return and her body to be kept in the Crimson Tower at the Lawless City.[[1]](#cite_note-V3C2-1)

## Volume 3

### Red Moon Incident

#### Light Novel & Manga

1000 years later, another Red Moon appeared. [Crimson](Crimson.md "Crimson") preparing the sacrifice for her resurrection. At the moment, Mary and Claire Kagenou reached the room where Elisabeth was finally resurrected as she impaled Claire and sucked her blood, allowing Elizabeth to regain full power. Suddenly, [Beta](Beta.md "Beta") and her squad from Shadow Garden attacked her while protecting Claire, even both tower ruler, [Yukime](Yukime.md "Yukime") and [Juggernaut](Juggernaut.md "Juggernaut") have arrived to fight against the Vampire Queen, but Elisabeth overpowers them.[[2]](#cite_note-V3C3-2)

Elisabeth suddenly attacks by Claire (which possessed by [Aurora](Aurora.md "Aurora") by took over her body) and unlocked her full abilities to combat Elizabeth. This fight held the Vampire Queen long enough for Shadow to finish it. Elisabeth, upon coming face to face with Shadow, realizes how strong and dangerous he is, so she decides to fight Shadow even more ferociously, to the point of having to use her formidable Blood Clone ability against Shadow, which makes Shadow retreat in combat, but then Shadow decides to get a little serious against her, and manages to dodge each of Elisabeth's attacks. Shadow notice what Elisabeth wants and decide ending the battle using his opposite ultimate attack, "I Am Recovery Atomic", which heals everyone equally and destroys the Crimson Tower and ending her rampage due to Shadow intervened before tragedy struck.[[2]](#cite_note-V3C3-2)

After the fight, Elisabeth decides to travel around the world with [Mary](Mary.md "Mary") before she gives him a light bow to Shadow for his help when he's on Cid Kagenou guise as thanks for him stopping her rampage.[[2]](#cite_note-V3C3-2)

#### Anime & Game

The events would be almost the same, except that in the final battle, Elisabeth faces Shadow in the sky of the Lawless City, under the light of the Red Moon, at super-fast speeds. After a while fighting, Shadow tells Elisabeth that the game time was understood a lot for tonight, which makes Elisabeth briefly regain her consciousness and asks Shadow about her name, to which Shadow responds with his technique, "I Am Recovery Atomic", healing everyone in the process and curing Elisabeth's disorder.[[3]](#cite_note-3)

After the battle the next day, Elisabeth and Mary say goodbye to Claire and Cid at the Lawless City train station, and as the train leaves, Elisabeth is seen looking from the Red Tower at the Knight who saved her, knowing that Shadow was Cid Kagenou in the process.

## Volume 4

## References

1. Volume 3 Chapter 2: Storming the Crimson Tower!
2. Volume 3 Chapter 3: Pursuing the Blood Queen!
3. Episode 23
