# Ragnarok

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Ragnarok](https://the-eminence-in-shadow.fandom.com/wiki/Ragnarok)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Ragnarok

- Manga
- Anime

### Japanese

ラグナロク

### Romaji

Ragunaroku

## Characteristics

### Race

Magical Beasts

### Gender

Male

### Age

Several Millennia

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Yellow (Novel)
Green (Anime)

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Grand Ruler of the Fourth Realm

### Affiliation

Himself

## Debut

### Light Novel

Volume 4

### Manga

Chapter 45

### Anime

Episode 31

Ragnarok (ラグナロク, Ragunaroku[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a demon who ruled and hailed from the 4th [Realm](Realms.md "Realms"). It was summoned by [Mordred](Mordred.md "Mordred") to destroy the Oriana Kingdom and defeat Shadow. The demon succeeded in entering their realm, but Cid soon destroyed it.[[1]](#cite_note-:V4C3-1)

## Appearance

It bore the visage of a bluish-black demon, reminiscent of a bat, and boasted a colossal physique akin. With a fanged maw, it possessed four razor-sharp claws protruding from the ends of its sinewy, blood-hued limbs. Its sturdy legs featured three formidable fingers each, and its entire form blazed with fiery intensity. Additionally, a pair of colossal wings adorned its frame.

## Personality

Despite being a magical beast and a demon king, Ragnarok's behavior often mirrors that of a creature driven by primal instincts. He strikes at his own discretion and, occasionally, when provoked. Shadow likened him to a being lacking in intellectual prowess, drawing a comparison to [Delta](Delta.md "Delta"), as Ragnarok rarely harnesses his magical abilities and struggles to wield them effectively.

Being a rather simple-minded magical beast, the Cult of Diablos found a way to partially control him for their benefit.

## Chronology

### Background

When the Black Rose incident occurred, the demon king Ragnarok had the opportunity to briefly appear in Oriana Kingdom but was repelled by the Cult of Diablos, who were very interested in the phenomena of the so-called "Black Rose" and that there is more than one world, apart from the one inhabited by the people of the world where Cid reincarnated, (this was long before Cid reincarnated).

Through a treaty that was made between Oriana's past kings and the leaders of the cult, a calamity was avoided thanks to the cult. But, in exchange for the royal family having to hand over their royal daughters, since Oriana's royal family has a bond of blood with the human Heroin, and the kingdom were to give a majority of their tax revenue to them, resulting in the kingdom to heavily invest on the arts. Also, the cult manipulating the church to vilify their kingdoms Dark Knights and the kingdom basically became a cult's puppet.

### Oriana's "Black Rose" Wedding Incident

Ragnarok is summoned again to the magical world where Oriana's kingdom was there, through the Black Rose portal using the Ring of Succession that Rose Oriana wore at her wedding, which was really the key to activate the Black Rose. Then, it begins to generate chaos but quickly loses one of its wings at the hands of Shadow, and they begin fighting to the death outside the capital, which ultimately results in his death at the hands of Shadow as he cutting every demonic members that falls near the battle that [Mordred](Mordred.md "Mordred") had against [Epsilon](Epsilon.md "Epsilon"), [Beta](Beta.md "Beta"), and Rose, who was watching how they fought.

## Powers & Abilities

Ragnarok boasts formidable brute strength and magical prowess. However, he appears to lack rapid self-healing abilities and the intelligence to utilize his magical powers for self-preservation and strategic purposes. He wields a demonic force of such immense magnitude that a single strike from it can obliterate a dozen houses or buildings, leaving behind nothing but a colossal crater. Its remarkable speed enables it to unleash consecutive, tireless barrages of these devastating blows.

### Body on fire

Ragnarok's entire form is enshrouded in an infernal blaze, emanating deadly temperatures capable of liquefying solid rock and proving fatal to any warrior or magical knight who ventures within a meter's range. This searing heat can be harnessed by Ragnarok to enhance the power of his punches, and when his anger surges, his body temperature escalates even further. Shadow stands as a remarkable exception, as he was the sole individual able to confront Ragnarok without succumbing to the searing heat, thanks to his protective slime bodysuit and his exceptional control over it.

### Magic

Speculations abound regarding Ragnarok's magical prowess, suggesting that he possesses the potential to stand on par with the formidable demon Diablos, the reigning monarch of the fourth demonic realm. While his intelligence might not be a standout trait, Ragnarok commands the unique capability to emit bursts of magical energy from both his maw, akin to a dragon, and his wings.

In addition to these formidable talents, Ragnarok exhibits a notable capacity for self-healing. However, in comparison to [Diablos](Aurora.md "Aurora"), his regenerative abilities are pale, as he lacks the capacity to magically regenerate severed limbs to the same extent as the demon king.

### Special Techniques:

#### Demon Breath

Ragnarok wields a formidable ability to concentrate his magical energy within his maw, unleashing a devastating demonic breath that possesses the potential to obliterate anything in its path. Shadow, though confident in his capacity to withstand this attack, wisely chose to avoid facing Ragnarok's unleashed might out of concern that the residual effects could wreak havoc upon Oriana’s capital, a decision driven by the desire to avert needless destruction.

## Trivia

- [Ragnarok](https://en.wikipedia.org/wiki/Ragnar%C3%B6k "wp:Ragnarök"), means the apocalypse in Norse mythology.[CITATION NEEDED]
- While in the Light Novel and the [Manga](Manga.md "Manga"), Ragnarok is depicted with a demonic appearance with bat-like characteristics, the [Anime](Anime.md "Anime") visualizes him as a semi-robotic hybrid. His visuals reflect a dragon-like appearance.[[1]](#cite_note-:V4C3-1)[[2]](#cite_note-2)[[3]](#cite_note-3)

## References

1. Volume 4 Chapter 3: Crashing the Ceremony!
2. [Manga](Manga.md "Manga"): Chapter 46
3. Episode 31
