# Lindwurm

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lindwurm](https://the-eminence-in-shadow.fandom.com/wiki/Lindwurm)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Lindwurm

### Japanese

リンドブルム

### Romaji

Rindoburumu

## Location Information

### Leader

Unknown

### Status

Active

### Affiliates

Midgar Kingdom

### Type

Holy Land

### Government

Unknown

### Location

Inside of the Midgar Kingdom

### Inhabitants

Humans
Cult of Diablos

## Debut

### Web Novel

Chapter 43

### Light Novel

Volume 2

### Manga

Chapter 14

### Anime

Episode 10

Lindwurm (リンドブルム, Rindoburumu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a city and holy site for the most popular religion in the world, Divine Teachings. The city's pious history and reverence garnered it the nickname the Sacred Land (聖地, Seichi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). Secretly, Lindwurm's [sanctuary](Sanctuary.md "Sanctuary") shelters and seals the demon [Diablos](Aurora.md "Aurora")' left arm.[[1]](#cite_note-V2CP-1)[[2]](#cite_note-V2C2-2)

## History

Lindwurm is a famous city which is one of the holy sites of the most widespread religion of this world, the Divine Teachings. It is a monotheistic religion that believes in the Goddess Beatrix, the one who granted powers to heroes in the legends and that she’s the one true deity.

Plus, Lindwurm has a battle event called "Goddess' Trial" which is held every once a year on the day when the doors to the [Sanctuary](Sanctuary.md "Sanctuary") are open where all warriors around the world applies to participate for a fight as a challenger against the memories of ancient warriors in duels to prove their worth by answering their call to summons any warriors spirit that are awoken.

## Location

Lindwurm is relatively close located in Midgar Kingdom's eastern region, adjacent to the Abyss Woods and to get there from Midgar Academy in royal capital to the Sacred Land takes about four days by using carriage (two days on train in the anime).

## Layout

Lindwurm is home to a massive church that looks like it’s been carved directly out of the mountain, and the townscape laid out below it has whitewashed buildings. The main street running through the town is swarming with tourists, and it ends in a long set of stairs leading directly to the church.

Lindwurm has also developed into a major city second only to the Midgar Kingdom since the construction of the reservoir dam, which maximized its abundant water resources. The dam's development also consisted of improving the Sacred Land's water and sewage systems and building multiple aqueducts throughout the city.

As a result, there are an increased number of small and large underground facilities at an accelerating rate to the point where no one could keep track on all of them.

## Trivia

- A lindworm (worm meaning snake), also spelled lindwyrm or lindwurm, is a mythical creature in northern and central European folklore traditionally of the form of a gigantic serpentine creature or a dragon.

## References

1. Volume 2 Prologue: To Lindwurn, The Sacred Land!
2. Volume 2 Chapter 2: Investigating the Sanctuary!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • **Lindwurm** • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
