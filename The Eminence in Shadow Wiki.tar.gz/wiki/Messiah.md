# Messiah

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Messiah](https://the-eminence-in-shadow.fandom.com/wiki/Messiah)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Messiah?action=edit).

## Messiah

### Japanese

メシア

### Romaji

Meshia

## Location Information

### Leader

[Haitani](Haitani.md "Haitani")

### Status

Active

### Affiliates

Unknown

### Type

Settlement

### Government

Unknown

### Location

[Earth](Earth.md "Earth")

### Inhabitants

Humans

## Debut

### Light Novel

Volume 4

### Manga

Chapter 49

Messiah (メシア, Meshia[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a human settlement during and after Japan's fall. It is regarded as the second Arcadia following [Arcadia](Arcadia.md "Arcadia")'s destruction at the hands of the "Original Knight". Before being made into a settlement, it used to be Nishino University.

## History

## Layout

### Infirmary

### Dormitory

### Pavilion

### Research Facility

## Equipment and Artifacts

- Katana
- Spear
- Fire Arms

## Personnel

- Akane Nishino
- Akira Nishino (Head Scientist; Deceased)
- [Yuuka](Yuuka.md "Yuuka") (Nurse/Spy; Deceased)
- [Haitani](Haitani.md "Haitani") (Commander)
- Yuudai Saejima (Vice Commander; Deceased)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • **Messiah** • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
