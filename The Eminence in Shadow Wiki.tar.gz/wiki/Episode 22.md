# Episode 22

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2022](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2022)

## The Haven

### Kana

安息の地

### Romaji

Ansoku no Chi

## Special Title

### English

The Eminence in Shadow Wants to Live for At Least 300 Years!

### Kana

陰の実力者は300年は生きたい！

### Romaji

Kage no Jitsuryoku-sha wa 300-nen wa ikitai!

## Episode Information

### Season

2

### Episode

2 (22)

### Air Date

October 11, 2023 JP & EN

### Adapted From

Volume 3 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

Grayscale dominator

### Ending

Polaris in the Night (Lambda ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| The Lawless City | The Hour of Awakening |

The Haven (安息の地, Ansoku no Chi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the second episode of the second season, and the twenty-second episode of [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

The moon is red. The frenzy has begun. Shadow is introduced to power players in Lawless City. Meanwhile, Mary and Claire run into Juggernaut.[[1]](#cite_note-1)

紅の塔に続々と集まる血の女王を狙う者たち。シャドウは白の塔と黒の塔の支配者ユキメ、ジャガノートと鉢合わせし、一方のクレアたちはシャドウガーデンのベータに遭遇する。[[2]](#cite_note-2)

## Summary

The White Demon, a serial killer, terrorized the populace by killing indiscriminately, asserting that it was the very purpose of his life. In search of more victims, he ventured into Lawless City, where he confronted [Crimson](Crimson.md "Crimson") and suffered defeat, ultimately becoming a watchdog for the Crimson Tower in the city. One day, while standing guard, the Red Moon triggers a frenzy among all the [ghouls](Ghouls.md "Ghouls") in Lawless City, causing chaos and transforming people into lifeless monsters. Witnessing this, the White Demon yearns to break free and exploit the opportunity to kill both people and ghouls. However, his inability to move past a set distance forces him to wait for unsuspecting individuals to approach. During his wait, three individuals approach the gate of the Red Tower. They are [Juggernaut, the Tyrant](Juggernaut.md "Juggernaut"), ruler of the Black Tower; [Yukime, the Spirit Fox](Yukime.md "Yukime"), ruler of the White Tower, and a mysterious man dressed entirely in black, whose power remains inscrutable. With a single mighty swing of his massive cleaver, Juggernaut breaks through the artifact gate of the Crimson Tower and strides inside, with Yukime following closely. The man in black trails behind them. The White Demon decides to attack the man in black, deeming the other two beyond his ability. Instantly, he witnesses his body being severed in half, collapsing to the ground. It is at this moment the White Demon realizes he had gravely erred by provoking someone he should never have assaulted.

As Claire and Mary ascend the Crimson Tower, they fend off vampires together. During the battles, Mary shares her knowledge about vampires to aid Claire. However, Claire becomes suspicious of Mary and questions her loyalty, especially regarding vampires. Mary deflects Claire's inquiries about possession and urges her not to pry into her secrets, promising the same respect in return. Feeling a surge of magical energy, they investigate and witness Juggernaut engaging in combat with high-ranking vampires. Realizing the danger, they attempt to escape, but someone intercepts their retreat. Juggernaut attacks, striking Claire and causing her to bleed profusely through her mouth. Mary gets sliced across her abdomen, losing a lot of blood. Claire attempts to heal Mary's wound, but the damage is too severe. Mary, in an act of desperation, sucks the blood off Claire's mouth, awakening her dormant vampiric abilities. With her newfound abilities, Mary holds off Juggernaut momentarily. As Juggernaut is about to deliver a fatal blow to Claire, Shadow intervenes, kicking Juggernaut off the Crimson Tower. After Shadow departs, Mary decides to reveal the secrets she had been concealing to Claire.

More than a thousand years ago, vampires thrived during a golden age, hunting and feasting on humans like animals. However, this changed when humans discovered their vulnerabilities:

1. Vampires turned to ash when exposed to sunlight.

2. They could not regenerate if they lost their hearts.

3. Without consuming human blood consistently, they would lose all of their vampire abilities.

The tides changed and the vampire population rapidly declined. During this period, [Elisabeth](Elisabeth.md "Elisabeth"), their ruler, chose to coexist with humans, ruling over a small territory that she referred to as the Haven. She and her subjects refrained from drinking blood, allowing them to endure sunlight, albeit with reduced powers, except for Elisabeth herself.

One fateful night, when the Red Moon appeared, Crimson secretly added blood to Elisabeth's meal. This caused her to go into a frenzy, leading to the massacre of humans and the destruction of their haven. Elisabeth then went on to wreak havoc in three other countries. Mary pursued her and found her after the Blood Moon had set. Elisabeth pleaded with Mary to scatter her ashes into the ocean to prevent her revival and further bloodshed. She stabbed herself but did not turn to ash. Lacking the courage to either revive or end Elisabeth's existence, Mary made a solemn vow to watch over her remains for eternity. Shortly thereafter, Crimson absconded with Elisabeth's body, with the intention of resurrecting her during the next Blood Moon, a thousand years later, to restore the vampires to their former glory.

In response, Claire opens up to Mary about her own history with possession. She explains that when she was younger, she displayed signs of demon possession, and now she lives in constant fear of one day transforming into a monster. Claire reveals that her primary wish is to assist her brother in accomplishing something significant before she potentially succumbs to the possession herself. This is why she brought him to the Lawless City. With their newfound understanding and connection, they resolve to press forward in their quest to locate the Blood Queen.

Meanwhile, in the tower's treasury, Cid contemplates which treasures to loot for financing his shadow activities. After careful consideration, he settles for gold coins, given their high value and ease of transport. He proceeds to fill his slime suit with one thousand gold coins, which amount to a hundred million zeni, before embarking on his mission to confront the Blood Queen.

Atop the tower, Crimson commences the ritual to resurrect the Blood Queen. As he positions Elisabeth's heart for the sacrifice, Shadow suddenly enters, interrupting him. The vampire proved less durable than Shadow's expectations and dies.

## Characters

- White Demon
- [Quinton](Quinton.md "Quinton")
- Goldy Gilded
- [Juggernaut](Juggernaut.md "Juggernaut")
- [Yukime](Yukime.md "Yukime")
- Cid Kagenou/Lord Shadow
- [Beta](Beta.md "Beta")
- Claire Kagenou
- [Mary](Mary.md "Mary")
- [664](664.md "664")
- [665](665.md "665")
- Rose Oriana (No. 666)
- [Aurora](Aurora.md "Aurora") (Image)
- [Elisabeth](Elisabeth.md "Elisabeth") (Flashback)
- Po Tato
- Skel Etal
- [Crimson](Crimson.md "Crimson")

## Promotional Videos

「陰の実力者になりたくて！ 2nd season」 第2話予告≪ノーマルVer.≫「安息の地」

『陰の実力者になりたくて！ 2nd season』 第2話予告≪スペシャルVer.≫「陰の実力者は300年は生きたい！」

## Trivia

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e022>
2. <https://shadow-garden.jp/story/#story2>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • **Episode 2** • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
