# Blu-ray & DVD Release

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Blu-ray%20%26%20DVD%20Release](https://the-eminence-in-shadow.fandom.com/wiki/Blu-ray%20%26%20DVD%20Release)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Blu-ray_%26_DVD_Release?action=edit).

The Eminence in Shadow [anime](Anime.md "Anime") was released in 7 Blu-Ray/DVD discs; 4 for season one and 3 for season 2. In addition to the anime episodes, the discs also contain some extra content such as art illustrations and bonuses for the Game.

## Volume 1

|  |  |
| --- | --- |
| Cover |  |
| On Sale | January 25, 2023 |
| Episodes | - Episode 1 - Episode 2 - Episode 3 - Episode 4 - Episode 5 |
| Bonus content | - Kagejitsu episodes 1 & 2 - Non-credit OP Ver.1 - 7 non-credit EDs - Preview for episodes 1 to 5(normal and special versions) |
| Product no. | BD: ZMXZ-16261 DVD: ZMBZ-16271 |
| Price | BD: ¥14,300 DVD: ¥12,100 |
| Limited time bonus | - Three-sided back case with original character design and illustrations by Touzai - Special digipak - Storyboard collection - "Master of Garden' bonus serial code:   - 1 SS character summon ticket   - 100x Crystal of wisdom   - 10x Burger   - 100x Magic gummy   - 50000 Zeni |

## Volume 2

|  |  |
| --- | --- |
| Cover |  |
| On Sale | February 22, 2023 |
| Episodes | - Episode 6 - Episode 7 - Episode 8 - Episode 9 - Episode 10 |
| Bonus content | - Kagejitsu episodes 3 to 7 - Non-credit OP Ver.2 - PV/CM collection - Preview for episodes 6 to 10(normal and special versions) |
| Product no. | BD：ZMXZ-16262 DVD：ZMBZ-16272 |
| Price | BD：¥14,300 DVD：¥12,100 |
| Limited time bonus | - Three-sided back case with original character design and illustrations by Touzai - Special digipak - Special booklet - Original art collection - "Master of Garden' bonus serial code:   - 1 SS character summon ticket   - 100x Crystal of wisdom   - 10x Burger   - 100x Magic gummy   - 50000 Zeni |

## Volume 3

|  |  |
| --- | --- |
| Cover |  |
| On Sale | March 24, 2023 |
| Episodes | - Episode 11 - Episode 12 - Episode 13 - Episode 14 - Episode 15 |
| Bonus content | - Kagejitsu episodes 8 to 12 - Non-credit OP Ver.3 - PV/CM collection - Preview for episodes 11 to 15(normal and special versions) |
| Product no. | BD：ZMXZ-16263 DVD：ZMBZ-16273 |
| Price | BD：¥14,300 DVD：¥12,100 |
| Limited time bonus | - Three-sided back case with original character designs and illustrations by Touzai - Special digipak - Special booklet - Storyboard collection - "Master of Garden' bonus serial code:   - 1 SS character summon ticket   - 100x Crystal of wisdom   - 10x Burger   - 100x Magic gummy   - 50000 Zeni |

## Volume 4

|  |  |
| --- | --- |
| Cover |  |
| On Sale | April 26, 2023 |
| Episodes | - Episode 16 - Episode 17 - Episode 18 - Episode 19 - Episode 20 |
| Bonus content | - Kagejitsu episodes 13 to 17 - Non-credit OP Ver.4 - PV/CM collection - Preview for episodes 16 to 20(normal and special versions) |
| Product no. | BD：ZMXZ-16264 DVD：ZMBZ-16274 |
| Price | BD：¥14,300 DVD：¥12,100 |
| Limited time bonus | - Three-sided back case with original character designs and illustrations by Touzai - Special digipak - Special booklet - Original art collection - "Master of Garden' bonus serial code:   - 1 SS character summon ticket   - 100x Crystal of wisdom   - 10x Burger   - 100x Magic gummy   - 50000 Zeni |
