# Sinmara

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sinmara](https://the-eminence-in-shadow.fandom.com/wiki/Sinmara)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Sinmara?action=edit).

## Sinmara

### Japanese

シンマラ

### Romaji

Shinmara

## Characteristics

### Race

[Elf](Elf.md "Elf")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Green

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Leader of the Emirate of Muspel

### Affiliation

Emirate of Muspel

Sinmara (シンマラ, Shinmara[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the ruler of the Emirate of Muspel on a volcanic island where she pays mercenaries to hunt down monsters who attack the island.[[1]](#cite_note-1)

## Appearance

## Personality

## Chronology

## Relationships

## Powers & Abilities

## Trivia

## References

1. Seven Shadows Chronicles - Edge of the realm - Chapter 1

## Site Navigation
