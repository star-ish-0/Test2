# Kagejitsu - Episode 21

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%2021](https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%2021)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu_-_Episode_21?action=edit).

## Operation 4

## Special Title

### English

The Seven Shades want to make awesome banknotes!

### Kana

七陰はすごい紙幣を作りたい！

### Romaji

Shichi kage wa sugoi shihei o tsukuritai!

## Episode Information

### Season

2

### Episode

4 (21)

### Air Date

October 25, 2023

### Adapted From

Light Novel

## Staff

### Director

Minoru Ashina

### Writer

Daisuke Aizawa

Episode Navigation

| Previous | Next |
| --- | --- |
| Operation 3 | Operation 5 |

Operation 4 is the fourth episode of the second season and the twenty-first episode of the spin-off series [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu").

## Summary

## Characters

- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Gamma](Gamma.md "Gamma")
- [Delta](Delta.md "Delta")
- [Epsilon](Epsilon.md "Epsilon")
- [Zeta](Zeta.md "Zeta")
- [Eta](Eta.md "Eta")
- [Nu](Nu.md "Nu")

## Trivia

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • **Episode 4** • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
