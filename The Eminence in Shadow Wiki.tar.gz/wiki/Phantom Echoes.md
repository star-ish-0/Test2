# Phantom Echoes

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Phantom%20Echoes](https://the-eminence-in-shadow.fandom.com/wiki/Phantom%20Echoes)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Phantom_Echoes?action=edit).

## The Eminence in Shadow: Phantom Echoes

### Kana

陰の実力者になりたくて！　Phantom Echoes

### Romaji

Kage no Jitsuryokusha ni Naritakute! Phantom Echoes

## Infomation

### Publisher(s)

NIS America Inc.
Clouded Leopard Entertainment Inc.

### Platform(s)

[PS5](https://en.wikipedia.org/wiki/Playstation_5 "wp:Playstation 5"), [Switch 2](https://en.wikipedia.org/wiki/Nintendo_Switch_2 "wp:Nintendo Switch 2"), [PC](https://en.wikipedia.org/wiki/Personal_computer "wp:Personal computer")

### Release Date

2027

### Genre

[Action](https://en.wikipedia.org/wiki/Action_game "wp:Action game")

### Mode(s)

Single-player

The Eminence in Shadow: Phantom Echoes (陰の実力者になりたくて！　Phantom Echoes, Kage no Jitsuryokusha ni Naritakute! Phantom Echoes[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is an upcoming game and it's the first console game in the series.

## External Links

- [Official Website](https://www.shadow-garden-pe.jp/)
- [Global Website](https://www.nisamerica.com/eminence-in-shadow-phantom-echoes/?lang=en)
- [Playstation Page](https://store.playstation.com/en-us/concept/10017425)
- [Official Twitter](https://x.com/Shadowgarden_PR?lang=ja)
