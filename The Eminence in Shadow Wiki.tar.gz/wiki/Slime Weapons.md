# Slime Weapons

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Slime%20Weapons](https://the-eminence-in-shadow.fandom.com/wiki/Slime%20Weapons)

Slime Weapons are crafted tools and weapons that originate from the Slime Bodysuit. They are extensions of the user's mana control and focus, as versatile as their imagination.

## Overview

Slime weapons, like the slime suit, are originally invented by Cid Kagenou and were made from the slimes in his domain. While slimes are normally very fragile, they are also excellent mana conductors, allowing a user with excellent control over their mana to channel their magic through the slime suit and create just about anything conceivable, from swords to armor, fake breasts and wings etc. forward.

Due to how flexible and versatile they are, it can become an instant weapon as long as the mana channel through which it is injected continues to function, and the mana imbued from it is maintained.

### Origin Of Creation

This equipment was developed by Cid Kagenou before founding Shadow Garden and rescuing the Elf girl who would become Alpha, which has now become standard equipment used by all members of Shadow Garden, except that it took a while. He was able to perfect it over time, since he was first trying out his slime suit prototype, when he was just 6 years old. As time went by, like the suit, the slime weapons gained different designs, to the taste of their wearer.

Like the slime suit, these weapons are made with slime jelly, an element of the corpses of slimes, which has a conductivity efficiency of 99% for magic. The slimes in this world are liquid monsters that transform using magic. A large number of them were collected and solidified into a gelatinous suit and equipment that transformed into a sword.

Using slime jelly and equipment enhancement magic, the slime suit has a ridiculous amount of utility, allowing users to manipulate it however they see fit and making for extremely user-friendly gear that combines offense and defense. By detaching a part and shooting it, it is possible to perform a long-range attack like a bow and arrow. You can also change the color, and by adjusting the amount of slime, Shadow Garden members can change their appearance and become a completely different person, so it can be used as a disguise tool.

At the beginning of development, Cid captured many Slimes and extracted their magic cores without affecting their magic structure, and perfected their control by uniting magic with them.

## Design of slime guns

## Functions

- Slime Crossbow: Used during the attack on Midgar Academy, Shadow created a finger length, handheld crossbow and could snipe all opposition from a distance within a second of firing.
- Slime Swords: Used as the basic instruments of the Slime technology, the swords are manifested almost instinctively by Shadow Garden members, trained beyond First Rate and refine to the point of shattering their opponent's swords.
  - Slime Weapon Change: The Slime Weapon, as such, can not only become a sword, it can also change into all kinds of possible and imaginary weapons, from spears, bayests, bows, whips, shields, scythes, among many others, to the taste of the bearer, to even become a chemical weapon, such as a gun or grenade, oh even a mixed mix of both weapons.
- Solidity of Slime Weapon: The slime weapon, when imbued with its wielder's magic, like the slime suit, can remain in a very hard solid state, depending on the wielder's magic level, as well as their control level, the higher it is. his magic level, along with his control over his magic, the greater his rigidity and toughness, allowing him to retain his same appearance, no matter how detailed, as long as the user allows it, he can even stay in place on his same solid state, if its bearer is unarmed, maintaining the order given by him, while he has the magic imbued by him, for a short or long period of time, depending on his level. This is seen when Shadow released his slime sword into the air for a short time, while fighting [Beatrix](Beatrix.md "Beatrix") and Iris Midgar, and his slime weapon retained its same appearance as such.
  - Response of Will: Like the slime suit, the slime weapons respond to the will of its wielder, whether it has been separated from it or not, they can return to their owner's hand without any problem, at a super fast speed, within a few seconds, (if not even a millisecond), depending on the wielder's magic control.
- Conductivity: Like the slime suit, the greater the destructive magic of its wearer, along with their level of control over it, the slime weapon will channel more magic from it, making the weapon increasingly difficult to break, or to destroy, or stop the magic and channeled power of its wielder.
- Weapon Restoration: Even if the slime weapon were destroyed or broken, as long as it retains the magic already imbued with its bearer, and maintains its bond with it, the slime weapon can be restored without any problem.

## Weakness

Like the Slime Suit, as a shared weak point, its entire performance depends on the control of its wearer's magical power. If its wearer's magic power is sealed, it will become a mere liquid and can't even hold its shape as equipment or clothing, rendering it useless. So far only Shadow, the Seven Shadows and their subordinates can take control of this, preventing their suits from disappearing. If the slime weapon is separated from its bearer, even if it maintains the last order given by it, it will be fragile so that the magic that is still imbued with its bearer will be absorbed more easily. although it takes a long time to become normal liquid, depending on the control and strength of the magic of its bearer.

## Trivia

- Unlike the anime, whose designs are simple, as if it were a rapier sword , the designs of the slime weapons in the Light Novel, Manga, and especially in the game, are more complexly decorated and fine, with their different shapes specific to each elite member, the 7 shadows and Shadow himself in part, from Shadow garden.
  - It is speculated that the detailed design of the 7 Shadows Slime Weapons and the rest of the Shadow Garden members, according to the game, reflect the nature, ability, desire and talent of its wielder as such, which is a bit ironic. since sometimes it differs with his way of being or fighting. (Until now, it is not known if the information that comes from the game is 100% canonical, but for now, it will be assumed that it is).
  - While the design of the slime weapons is somewhat normal for Shadow Garden members, in the manga and light novel, Shadow's is the only one with more details and different decorations.
  - In the light novel and manga, Cid in his alias Shadow, keeps his Slime Sword, constantly solid, stored in its sheath, disappearing a few times, while in the anime, he only manifests it when he wants to quickly attack someone, ( It is speculated that in the anime he does it, this way, to have more mobility, while in the manga and Light Novel, he keeps it in a solid state to always be prepared for anything).
- Up to the present date, there has not been any weapon or tool, be it sword, gun, or fire or magic, capable of breaking the slime weapon, as such.
- Up to the present date, it is not known, how much is the distance that the slime weapon can respond to the will of its bearer when it is well distanced from it, (as far as it is known it can respond from a distance of 5 to 15 meters maximum) .
