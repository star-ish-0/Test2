# Aurora

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Aurora](https://the-eminence-in-shadow.fandom.com/wiki/Aurora)

[Chronology](Aurora-Chronology.md "Aurora/Chronology")

[Relationships](Aurora-Relationships.md "Aurora/Relationships")

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | This is... My malice | ” |
| — Aurora, Light Novel Volume 05 | | |

## Aurora

### Japanese

アウロラ

### Romaji

Aurora

### Aliases

The Witch of Calamity
Demon Diablos
Violet

## Characteristics

### Race

[Human](Human.md "Human")
Image Fragment (Present)

### Gender

Female

### Age

1,000+

### Height

Unknown

### Hair Color

Black (Novel)
Violet (Anime)

### Eye Color

Violet

### Birthday

March 25

## Personal Information

### Status

Deceased (Incorporeal existence)

## Professional Information

### Affiliation

Cult of Diablos

## Debut

### Web Novel

Chapter 48

### Light Novel

Volume 2

### Manga

Chapter 15

### Anime

Episode 11

## Portrayal

### Japanese

[Kaori Nazuka](https://en.wikipedia.org/wiki/Kaori_Nazuka "wp:Kaori Nazuka")

### English

[Shelley Calene-Black](https://en.wikipedia.org/wiki/Shelley_Calene-Black "wp:Shelley Calene-Black")

### French

Virginie Hénocq

### Italian

Ilaria Silvestri

### German

Janina Dietz

Aurora (アウロラ, Aurora[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was an enigmatic sorceress from the time of the three heroes. Known by the epithet Witch of Calamity, the Holy Teachings Church claimed her to be the most powerful woman in recorded history who plunged the world into chaos.[[1]](#cite_note-V2C1-1) While few know of her existence, her other identity of demon Diablos (ディアボロス, Diaborosu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a pillar of the Church's dogma and the New World's societal structure. Though long dead, the eponymous Cult of Diablos continues to exploit her corpse for power.[[2]](#cite_note-V2C2-2) Following the Red Moon Incident, a portion of her spirit began residing within Claire Kagenou.[[3]](#cite_note-V3C3-3)[[4]](#cite_note-V5C5-4)

## Appearance

Aurora is described as an "artistic beauty" whose looks are akin to a sculpture coming to life.[[1]](#cite_note-V2C1-1) Long black hair is complimented by pale-white skin and purple eye.

Aurora wears 2 half-shaped golden decorative earrings with an earring drop in both ears, with a tied-up hairstyle of 3 large tails that reach down to her feet, being the one in the middle length and more collected than those of the other 2 sides.

She wears a purple-black dress with gold accents, a long black robe that had long sleeves that reached her hands accented with a gold decorative silhouette that covered the back, and black high-heeled shoes.

Her dress is generally looks like a veiled woman, leaving her medium neckline uncovered with green jewels around the neck, with a golden-yellowish green jeweled silhouette on the right-side of the middle above the abdomen, attached to a long 2-layer skirt, which raised the front part a little slightly to cover the knees and dark purple heels.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | Crying won’t do you any good | ” |
| — Aurora, Light Novel Volume 02 | | |

Little is known about Aurora's true motives and personality due to her self-reported amnesia and reticence. Aurora voiced that many of her memories have decayed from centuries of isolation; although, she continues to offer explanations regarding current or past events that contradict that statement.[[2]](#cite_note-V2C2-2)[[3]](#cite_note-V3C3-3) Outwardly, Aurora projects a playful, often humorous demeanor with confidence that further calls into question her supposed ignorance. The only times Aurora has shown anything other than quiet amusement is when interacting with her younger self. There, she has displayed clear contempt for her past cowardice and pleading for a better future.[[2]](#cite_note-V2C2-2)[[5]](#cite_note-:1-5)

After having entered the body of Claire Kagenou, she spends her time observing the young heiress's life and personal interactions. Sometimes, she offers comments, much to the annoyance of Claire and amusement of Aurora.[[4]](#cite_note-V5C5-4)

## Powers & Abilities

While the full extent of Aurora’s strength remains unknown, the Church of Holy Teachings  historic records denote her power as a threat to the New World. During her time as the Witch of Calamity, she reportedly caused unprecedented death and destruction. As Diablos, it took the joint effort of the three heroes to subdue and seal away her body parts. Those parts continue to have a tangible impact in contemporary times.[[1]](#cite_note-V2C1-1)

Despite having been imprisoned for so long, Aurora’s fragments rival the powers of Midgar’s strongest dark knights, even temporarily overpowering enemies Beta and her subordinates failed to equal.[[3]](#cite_note-V3C3-3) Likewise, Cid recognizes Aurora’s strength. He lamented at the fact the echoes and manifestations pale in comparison to her apparent prime.[[1]](#cite_note-V2C1-1)

### Magic

Aurora’s main method of fighting revolves around keeping her opponent at long to medium range while bombarding the combatant with relentless magic attacks. Through the bodily infusion of magical energy, her blood acts as a conduit, allowing for blood constructs. This manifests through the manipulation and summoning of blood tendrils. Vampires utilize a similar technique; although, their ability has proven to be susceptible to hijacking by Aurora.[[3]](#cite_note-V3C3-3)

Aurora displayed the capacity of mimicking the I AM ALL RANGE ATOMIC technique, but Claire’s bodily vessel proved incapable of withstanding the strain.[[6]](#cite_note-:0-6)[ANIME ONLY]

### Physical Capabilities

The organism that facilitated Aurora’s transformation came from what the Cult of Diablos calls the First Realm. They experimented on the alien and Aurora’s body, leading to the development of demon-adjacent biology.[[7]](#cite_note-V4C3-7)

The early effects have yet to be elucidated, but after fully emerging as the Demon Diablos, it granted Aurora a potent regenerative ability. Even after the heroes severed her limbs, they persist as a strong magical resource. They facilitate the Knight of Rounds immortality and can manifest Aurora’s conscience.[[2]](#cite_note-V2C2-2)

### Possession of Claire Kagenou

A fragment of Aurora manifested inside of Claire after the intermingling of her and vampiric blood. Claire’s hero heritage and Elisabeth’s progenitor blood fused together, causing two separated bloodlines to mimic its original source—Aurora. Claire can now borrow some of Aurora's magical abilities, while Aurora can communicate with Claire, and temporarily possess her body.[[3]](#cite_note-V3C3-3) This connection has been further amplified through Zeta forcibly implanting Diablos’s right arm into Claire’s body.[[5]](#cite_note-:1-5)

### Weapons and Equipment

Aurora's primary weapon is a scythe, using one in her projection's fight against Shadow and again later while possessing Claire's body. In the manga, Aurora manifests various blood weapon projectiles, such as spears, swords, and scythes.[[8]](#cite_note-MC16-8)

## Trivia

- The name Aurora means dawn in Latin.[CITATION NEEDED]
  - The Name of Aurora, in turn, represents the name of the "goddess from Greek mythology", who announces the arrival of a new dawn, and the natural phenomenon that occurs at the north and south elated poles of the planet, in the night sky.[CITATION NEEDED]
- Aurora's mana color is red.[[6]](#cite_note-:0-6)[ANIME ONLY]
- In the light novel, Aurora's possession of Claire causes only her irises to change color.[[3]](#cite_note-V3C3-3) The change is more drastic in the anime, as it causes Claire's body to adopt the corporeal form of Aurora.[[6]](#cite_note-:0-6)

## References

1. Volume 2 Chapter 1: Fun Times at the Goddess’s Trial!
2. Volume 2 Chapter 2: Investigating the Sanctuary!
3. Volume 3 Chapter 3: Pursuing the Blood Queen!
4. Volume 5 Chapter 5: Terrorists Attack the School…Again!!
5. Volume 5 Epilogue: I’d Let the Whole World Burn, If That’s What It Took!
6. Episode 23
7. Volume 4 Chapter 3: Crashing the Ceremony
8. [Manga](Manga.md "Manga") Chapter 16

## Site Navigation
