# Light Novel/Volume 6

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%206](https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%206)

## Light Novel Volume 6

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Touzai

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4047376915

### ISBN EN

ISBN 979-8855406986

### Release Date

October 30, 2023 JP
February 4, 2025 EN

## Volume Information

### Pages

376 JP
266 EN

### Chapters

9

## Adaptations

### Manga

Chapter 66.2 - Chapter 79.2

Publication Order

| Previous | Next |
| --- | --- |
| Volume 5 | Volume 7 |

This is the sixth volume of the light novel series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

A mysterious cabal called the Thirteen Nightblades has been running things in the Midgar Kingdom from the shadows, and its members have concealed all manner of crimes through their connections to the Cult of Diablos. How impressi―no, how terrible. These dastardly nobles commit so many evil deeds, and yet justice always evades them. That’s when a serial killer known only as “Jack the Ripper” appears, plunging the corrupt capital into chaos! In order to eradicate evil, an even greater evil is needed… [[1]](#cite_note-1)

「見届けよ。その血塗られた道を――」　シリーズ累計400万部突破！！

秘密結社『十三の夜剣』に陰から支配されるミドガル王国。
『ディアボロス教団』とも繋がる貴族たちは、その権力によってどんな悪事も隠蔽してきた。

「陰の支配者だと……？」

なんて羨まし……悪い奴らなんだ。
どれだけ悪いことしても無罪になる、悪徳貴族たち。

「……いいことを考えた！」

腐敗の蔓延した王都を、連続殺人鬼『ジャック・ザ・リッパー』が恐怖に陥れる...！？　
悪を断つには、更なる悪を――

「これは、中二病黒歴史ノートだ……！」[[2]](#cite_note-2)

## Summary

## Chronology

Following an incident at Midgar Academy for Dark Knights, The Midgarian Court was to try Eliza Despoht for her participation in the deaths of several students. Eliza's father, Marquis Brad Despoht, employed the Thirteen Nightblades' authority to keep his daughter from being imprisoned. In accordance with the order, Earl Shoddi Goodz began the laborious paperwork necessary for bribes, false testimonies, and assassinations. Earl Goodz never completed his work and was unceremoniously murdered by a man in a clown suit.[[3]](#cite_note-V6CP-3)

The Thirteen Nightblades quickly learned about Goethe's death. Deciding issues needed a swift solution, the organization assigned Earl Azukay and Baron Stergang to the assassination of Christina Hope and [Kanade](Kanade.md "Kanade"). [Baron Stergang](Stergang.md "Stergang") and [Earl Azukay](Azukay.md "Azukay") met the same fate as their compatriot.[[4]](#cite_note-V6C1-4) The killer clown hung their dead bodies on a fountain; all that remained was letters in blood. It revealed the killers name, Jack the Ripper.[[5]](#cite_note-V6C2-5)

Compensating for the aforementioned failures, Haushold Hedd, [Viscount Shinobi](Shinobi.md "Shinobi"), and [Marquis Jet](Jet.md "Jet") gathered a small army of assassins to storm the Hope Estate. Their objective was again to eliminate Christina and Kanade. The battalions encountered fierce resistance from Jack the Ripper, and their counteroffensive proved inadequate. Jack eliminated the surrounding army, decapitating Viscount Shinobi and Marquis Jet. Haushold Hedd and his son, Dunder Hedd, headed to Christina and Kanade while Jack was preoccupied with the outside men. Quickly dealing with the outside threat, Jack the Ripper entered the manor, and encountered Haushold Hedd's backup, Sword Demon. Jack then proceeded to burst his head open, followed by a one-sided slaughter of Haushold Hedd and his entourage. This decisive and swift action saved the frightened schoolchildren from their previous fates.[[5]](#cite_note-V6C2-5)

Hearing about the massacre, the remaining Nightblades regrouped at Earl White's mansion to set up a trap for Jack the Ripper. They lured him to the Thirteen Nightblades' underground colosseum, where a massive force of the best mercenaries, Dark Knights, and [a mutated girl](Millia.md "Millia")—courtesy of the Loki sect—was assembled. They likewise erected a magical barrier around the arena to prevent the clown from escaping.[[6]](#cite_note-V6C3-6) To the Thirteen Nightblades' horror, Jack the Ripper turned the arena into a one-sided bloodbath and escaped the barrier to confront them. Jack butchered the remaining members, with Earl White and Marquis Despoht being the last to meet their end.[[7]](#cite_note-V6C4-7)

## Chapters

- Prologue: There Are People Ruling the Midgar Kingdom from the Shadows? I'm So Jealous!
- Chapter 1: Enter Jack the Ripper!
- Chapter 2: Assassins at the Sleepover!
- Chapter 3: Deciphering the Calling Card!
- Chapter 4: The Monster Becomes a Legend!
- Auxiliary Chapter: Following in the Monster's Footsteps!
- Side Story: The Grassland Vow
- Chapter 5: Welcome to the Shadow Garden!
- Epilogue: That Nostalgic Smell
- Appendix

## Characters

:   In order of appearance:

- Cid Kagenou
- Skel Etal
- Po Tato
- [Isaac](Isaac.md "Isaac") (Mentioned)
- [Zeta](Zeta.md "Zeta") (Mentioned)
- Christina Hope
- [Kanade](Kanade.md "Kanade") (Debut)
- [Gamma](Gamma.md "Gamma") (Mentioned)
- [Omega](Omega.md "Omega") (Debut)
- [Chi](Chi.md "Chi") (Debut)
- [Alpha](Alpha.md "Alpha")
- Rose Oriana (Mentioned)
- [Fenrir](Fenrir.md "Fenrir") (Mentioned)
- [Victoria (No. 559)](Victoria.md "Victoria") (Mentioned)
- Earl Shoddi Goodz (Debut)
- Alexia Midgar
- [Gray](Gray.md "Gray") (Debut)
- [Earl Azukay](Azukay.md "Azukay") (Debut)
- [Baron Stergang](Stergang.md "Stergang") (Debut)
- Eliza Despoht
- [Nina](Nina.md "Nina")
- Claire Kagenou (Comatose)
- [Mu](Mu.md "Mu") (Debut)
- Earl Haushold Hedd (Debut)
- Dunder Hedd (Debut)
- [Viscount Shinobi](Shinobi.md "Shinobi") (Debut)
- Sword Demon (Debut)
- [Marquis Jet](Jet.md "Jet") (Debut)
- Klaus Midgar
- Iris Midgar (Mentioned)
- [Delta](Delta.md "Delta")
- [Pi](Pi.md "Pi") (Debut)
- Earl Korrupt White (Debut)
- [Earl Battler](Battler.md "Battler") (Debut)
- [Butcher](Butcher.md "Butcher") (Debut)
- Marquis Brad Despoht (Debut)
- [Millia](Millia.md "Millia")
- [Grease](Grease.md "Grease") (Mentioned)
- [Loki](Loki.md "Loki") (Debut)
- [Ral](Ral.md "Ral") (Flashback)
- [Ren](Ren.md "Ren") (Flashback)
- Akane Nishino
- [Beta](Beta.md "Beta")
- [Lambda](Lambda.md "Lambda")
- [Eta](Eta.md "Eta")
- [Nu](Nu.md "Nu")
- [Epsilon](Epsilon.md "Epsilon")
- Sherry Barnett (Mentioned)

## Illustrations

- [English](#)
- [Japanese](#)

Table of Contents (EN)

Title Page (EN)

Cid, Alpha and Chi at Mitsugoshi Royale Luxury Bar

Cid and Kanade estimate art pieces at Hope mansion hallway

Christina encounters Eliza in the hallway while Cid is blown away by Eliza's entourage

Cid meets Delta and Pi near White Mansion

Jack the Ripper standing in front of Night Blades in White Mansion

Millia fighting Shadow in White Mansion Colosseum

Christina appears before Eliza as Jack the Ripper

Young Delta after killer her brothers Ren and Ral

Millia half asleep thinking Akane is her mother

Seven Shadows during their early days

Christina Hope's Profile (EN)

Kanade's Profile (EN)

Chi's Profile (EN)

Omega's Profile (EN)

Table of Contents (JP)

Title Page (JP)

Cid, Alpha and Chi at Mitsugoshi Royale Luxury Bar

Cid and Kanade estimate art pieces at Hope mansion hallway

Christina encounters Eliza in the hallway while Cid is blown away by Eliza's entourage

Cid meets Delta and Pi near White Mansion

Jack the Ripper standing in front of Night Blades in White Mansion

Millia fighting Shadow in White Mansion Colosseum

Christina appears before Eliza as Jack the Ripper

Young Delta after killer her brothers Ren and Ral

Millia half asleep thinking Akane is her mother

Seven Shadows during their early days

Christina Hope's Profile (JP)

Kanade's Profile (JP)

Chi's Profile (JP)

Omega's Profile (JP)

## References

1. [Yen Press. The Eminence in Shadow, Vol. 6 (light novel) (EN)](https://yenpress.com/titles/9798855406986-the-eminence-in-shadow-vol-6-light-novel/)
2. [Kadokawa. The Eminence in Shadow 06 (JP)](https://www.kadokawa.co.jp/product/322306001277/)
3. **Volume 6** Prologue: There Are People Ruling the Midgar Kingdom from the Shadows? I'm So Jealous!
4. **Volume 6** Chapter 1: Enter Jack the Ripper!
5. **Volume 6** Chapter 2: Assassins at the Sleepover!
6. **Volume 6** Chapter 3: Deciphering the Calling Card!
7. **Volume 6** Chapter 4: The Monster Becomes a Legend!

## Trivia

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • **Volume 6** • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
