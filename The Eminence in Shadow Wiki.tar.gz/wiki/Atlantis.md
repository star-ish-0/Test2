# Atlantis

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Atlantis](https://the-eminence-in-shadow.fandom.com/wiki/Atlantis)

## Atlantis

### Japanese

アトランティス

### Romaji

Atorantisu

## Location Information

### Leader

Unknown

### Status

Spirited away (missing)

### Affiliates

Unknown

### Type

Country

### Government

Unknown

### Location

Unknown

### Inhabitants

Unknown

## Debut

### Anime

Episode 32

Atlantis (アトランティス , Atorantisu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a kingdom[[1]](#cite_note-1) located on an island which existed a long time ago before being spirited away.[[2]](#cite_note-2)

## History

Once upon a time there was a kingdom called Atlantis. The kingdom was said to have disappeared without a trace, but the Cult of Diablos theorized that it might have disappeared in a collision between [realms](Realms.md "Realms"). At the current moment not much else is known about Atlantis.

## Trivia

- The shape of the island is exactly the same as the map of the mythical island of Atlantis illustrated by [Athanasius Kircher](https://en.wikipedia.org/wiki/Athanasius_Kircher "wp:Athanasius Kircher").

## References

1. Episode 32 Highest
2. Volume 4 Chapter 3: Crashing the Ceremony!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • **Atlantis** • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
