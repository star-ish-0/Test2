# Cult of Diablos

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Cult%20of%20Diablos](https://the-eminence-in-shadow.fandom.com/wiki/Cult%20of%20Diablos)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Cult of Diablos

### Japanese

ディアボロス教団（きょうだん）

### Romaji

Diaborosu Kyōdan

## General Information

### Leader(s)

Twelve Knights of Rounds

### Status

Active

### Affiliates

Holy Church of Divine Teachings
[Templars](Templars.md "Templars") (loosely rival associate)
Major Corporate Alliance (Formerly)
Thirteen Nightblades (Formerly)

### Base of Operation

Worldwide

## Debut

### Web Novel

Chapter 3

### Light Novel

Volume 1

### Manga

Chapter 1

### Anime

Episode 2

The Cult of Diablos (ディアボロス教団（きょうだん）, Diaborosu Kyōdan[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a secret organization operating covertly to resurrect the demon [Diablos](Aurora.md "Aurora").

For this task, they infiltrated many high-ranking positions and manipulated history so that the descendants of the heroes who originally sealed [Diablos](Aurora.md "Aurora") would get persecuted and abandoned by renaming the "Curse of Diablos" into [Possession](Possession.md "Possession"). They managed to go unopposed for years until a new opposition called the Shadow Garden appeared.

## Overview

Little is known about the organization, except that it controls the world by resurrecting the [Demon Diablos](Aurora.md "Aurora") and harnessing its powers to maintain the Cult's rule. Their research primarily focused on developing a medicine from Diablos Cells that grants immense strength and immortality. However, they were unable to perfect it due to its severe side effects.[CITATION NEEDED]

The Cult of Diablos has deceived the world into condemning the descendants of heroes who show symptoms labeled as [Possession](Possession.md "Possession"). These individuals are handed over to the Church as "possessed," where the Cult secretly uses them as test subjects in their experiments to perfect the Beads of Diablos. This also serves to eliminate any threats, ensuring that nothing obstructs their work.[CITATION NEEDED]

After the emergence of a hidden organization called Shadow Garden, which unexpectedly discovered the Cult’s existence, they set out on a mission to disrupt their plans. Shadow Garden focused on dismantling the Cult’s operations, particularly their efforts to refine the Beads of Diablos and seize control of the world. In doing so, they exposed the Cult’s crimes. As a result, the Cult suffered immeasurable heavy losses and considers Shadow Garden as their greatest adversary.[CITATION NEEDED]

## Known Members

### Knights of Rounds

The Knights of Rounds (ナイツ・オブ・ラウンズ, Naitsu obu Raunzu) are the leadership echelon of the organization, consisting of the 12 strongest Cultists. Gaining a Seat position among them could bring an unbelievable amount of influence, prestige, and wealth. Being "Named" is almost considered a requirement as a gateway for a position in the Rounds.

#### Current Rounds Seat Holder

- [Loki](Loki.md "Loki"), Unknown seat
- [Hel](Hel.md "Hel"), Unknown seat
- [Jormungandr](Jormungandr.md "Jormungandr"), Unknown seat
- [Fenrir](Fenrir.md "Fenrir"), 5th seat (Deceased)
- [Mordred](Mordred.md "Mordred"), 9th seat and the "Knight Beyond Men" (Deceased)
- [High Priest Petos](Petos.md "Petos"), 10th seat
- Acting Archbishop Jack Nelson, 11th seat and the "Avaricious" (Deceased)

#### Former Rounds Seat Holder

- [Shiva](Shiva.md "Shiva"), 5th seat (Abnegated, Deceased)
- Sergey Gorman, 10th seat and the "Storm Sword" (Deceased)
- Stan Bach, 10th seat - prior to Sergey (Deceased)
- Lord Laugus, 11th seat (Deserted, Traveling)
- Assistant Principal Lutheran Barnett (Sir Gaunt), 12th seat (Revoked, Deceased)

### Children of Diablos

The Children of Diablos (ディアボロス・チルドレン, Diaborosu Chirudoren) begin as orphans or young citizens (typically from poorer families) who possess magic affinity, even the smallest amount, that the Cult kidnaps and brings to special facilities to be raised under the Cult's eye. These children will proceed to undergo a brutal regimen of harsh training, brainwashing, and administration of drugs that kills most of them in order to become the vanguard of the Cult of Diablos with their combat power that far surpasses any normal knight. It's said that fewer than 10 percent of them manage to survive this process.

#### Named First Children

- [Rex](Rex.md "Rex"), the "Game of Betrayal" (Deceased)
- [Kouadoi](Kouadoi.md "Kouadoi"), the "Gale" (Deceased)
- [Viscount Jean](Jean.md "Jean"), the "Wicked Smile" (Deceased)
- Dark Spider (Deceased)
- [Baroness Karen von Herzog](Chi.md "Chi"), the "Shooting Star" (Defected to Shadow Garden)
- [Maximilian](Maximilian.md "Maximilian"), the "Ruthless" (Deceased)

#### Second Children

#### Third Children

These children are the 10 percent who are deemed worthless; bearing no names, and as such, will never be recorded.[CITATION NEEDED]

### Other Members

- [Willow](Willow.md "Willow") (Deceased)
- [Gray](Gray.md "Gray")
- [Adder](Adder.md "Adder")
- Marquis Zenon Griffey, Vying for the 12th Seat (Deceased)
- [Gettan](Gettan.md "Gettan"), Candidate for the 12th Seat (Deceased)

### Associates

Over time, the Cult of Diablos managed to persuade or force the individuals of other races and people with different statuses and positions to temporarily work with them from the outside and complete missions requested by the Cult's leadership before being able to fully enter the organization, acting as collaborators, conspirators, sleeper agents, and spies. Regardless of their loyalty, they are easily expendable for the organization.[CITATION NEEDED]

#### Enforcers

- [Executioner Venom the Wandering Swordsman](Venom.md "Venom") (Deceased)

#### Accomplices

- Garter Kikuchi (Imprisoned)
- Queen Reina Oriana (Deceased)
- [Isaac](Isaac.md "Isaac") (Deceased)
- Thirteen Nightblades (Defunct)

## Sect Factions

Considering the fact the Cult exists since ancient times and all attempts to oppose them were swiftly dealt with, they become arrogance as they always been at odds with each other member that always wishing for eternal life and ruling the world from the shadows, as well as possessing wealth and fame. Also, doing engaged in the strife tension of internal power struggles against each other faction, because their own desired of selfishness and greed as they only lusted on the demon's power which they have not worked together for hundreds of years.

Each member of the Knights of Rounds has their own faction, which divided into 12 different Sect faction using their name on their faction;

- Loki's Sect Faction
- Hel's Sect Faction
- Jormungandr's Sect Faction
- Fenrir's Sect Faction (Defunct)
- Mordred's Sect Faction (Defunct)
- Petos' Sect Faction
- Nelson's Sect Faction (Defunct)
- Barnett's Sect Faction (Defunct)

## Trivia

- The name Diablos is derived from the Greek word Diabolos (διάβολος), which translates to Devil.
- The Knights of Rounds are most likely based on the [Knights of the Round Table](https://en.wikipedia.org/wiki/Knights_of_the_Round_Table "wp:Knights of the Round Table") from Arthurian legend, since the Round Table Committee being inspired by the real, historical [Round Table](https://en.wikipedia.org/wiki/Round_Table "wp:Round Table") and [some](Mordred.md "Mordred") of its members even sharing the same names of the actual knights.
  - Among the other Knights of Rounds members, there were several names derived from [Norse mythology](https://en.wikipedia.org/wiki/Norse_mythology "wp:Norse mythology") and [Hindu mythology](https://en.wikipedia.org/wiki/Hindu_mythology "wp:Hindu mythology").

## References
