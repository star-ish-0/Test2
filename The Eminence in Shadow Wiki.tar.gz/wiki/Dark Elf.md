# Dark Elf

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Dark%20Elf](https://the-eminence-in-shadow.fandom.com/wiki/Dark%20Elf)

Dark Elf (ダークエルフ, Dāku Erufu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is one of the races in the world of The Eminence in Shadow.[[1]](#cite_note-1)

[Elves](Elf.md "Elf") are a close relative of the Dark Elves.

## Abilities

## Known Individuals

- [Lambda](Lambda.md "Lambda")
- [Mu](Mu.md "Mu")

## References

1. Volume 6. Chapter 2: Intruders at the Sleepover Party!
