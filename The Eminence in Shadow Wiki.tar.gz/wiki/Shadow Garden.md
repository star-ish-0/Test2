# Shadow Garden

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Shadow%20Garden](https://the-eminence-in-shadow.fandom.com/wiki/Shadow%20Garden)

NOTE: This page is locked due to high traffic. If you would like to help help, contact the staff.

Image Gallery

|  |  |  |
| --- | --- | --- |
| “ | We are Shadow Garden. We lurk in the darkness and hunt down from the shadows. | ” |
| — Shadow Garden's mission statement, Light Novel Volume 01 | | |

## Shadow Garden

### Japanese

シャドウガーデン

### Romaji

Shadō Gāden

## General Information

### Leader(s)

Shadow [Founder & Leader]

[Alpha](Alpha.md "Alpha") [Co-Founder & Deputy Leader]

### Status

Active

### Affiliates

Mitsugoshi Company [Front Company]
Snow Fox Corporation [Underworld Liaison]

### Base of Operation

[Alexandria](Alexandria.md "Alexandria") [Headquarters]
Midgar Kingdom [Main City]
Oriana Kingdom [Branch]

## Debut

### Web Novel

Chapter 3

### Light Novel

Volume 1

### Manga

Chapter 1

### Anime

Episode 2

### Game

Episode 1

Shadow Garden (シャドウガーデン, Shadō Gāden[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a clandestine organization founded by Cid Kagenou, also known as Shadow. The members primarily focus on hindering the Cult of Diablos' perpetual control over the world.[[1]](#cite_note-V1CP-1) By weakening the Cult’s international influence and thwarting their [Diablos](Aurora.md "Aurora") experimentations, Shadow Garden hopes to weaken and eventually eradicate the Cult for good. The leader of Shadow Garden remains unaware of the true breadth and power of the organization. He believes that it is merely theatrical appeasement for his shadow broker fantasies.[[2]](#cite_note-V1C1-2)[[3]](#cite_note-V1C4-3)

## History

The origins of Shadow Garden dates back to the boyhood of Cid Kagenou, a reincarnated boy determined to fulfill a dream of becoming a shadow broker. To accomplish this, Cid routinely snuck out of his home to fight bandits. During one such outing, he discovered a rotting but surprisingly alive body; the effects of possession heavily mutated it. He performed multiple experiments on the body and accidentally reversed the mutation after a month's work. Under the rotting flesh was a young elf girl.[[1]](#cite_note-V1CP-1)

Cid named the elf [Alpha](Alpha.md "Alpha") and officially made her a shadow broker subordinate. Her job was to prevent the resurrection of Diablos. Initially confused by the mission, Cid explained that Alpha was a descendant of the Three Heroes who defeated the demon Diablos. After the demon's death, a curse plagued all future descendants. He claimed that an organization called The Cult of Diablos was responsible for not only hiding the cure, but they made the possessed ostracized by society.[[1]](#cite_note-V1CP-1) Although Cid hastily constructed the story to justify his actions, the improtou story turned out to be rooted in reality—details, such as the propagation of the curse, remain partially inaccurate.[[4]](#cite_note-V2C2-4)

Alpha's acceptance of the mission signaled the founding of the organization Shadow Garden. The two subsequently recruited six more possessed girls. Overtime, these girls became Cid's friends and trusted subordinates.[[5]](#cite_note-V6SS-5)[[6]](#cite_note-V2C8-6)

## Power & Influence

Shadow Garden first began as a grassroots organization with nothing except a rustic cabin and eight prepubescent members.[[5]](#cite_note-V6SS-5) Over five years, the Shadow Garden's influence and power grew significantly with the final two years demonstrating the most substantial growth. Accommodating this expansion, the long-lost capital city [Alexandria](Alexandria.md "Alexandria") became their new base of operations.[[7]](#cite_note-V2CF-7)[[8]](#cite_note-MOG-SSC_P1C3E1-8) Armed with a new base, the pious devotion of their members and advanced training methods, the organization's global presence now surpasses nearby kingdoms with only the hegemonic Cult of Diablos and the sanctimonious Holy Teaching Church matching their societal influence and military might. Although Shadow Garden's military might and pious devotion contributed to their present success, Shadow Wisdom remains the largest contributing factor to their monolithic growth. Utilizing this knowledge, Shadow Garden garnered resources and created connections that quickly transformed their organization into its present state.[[3]](#cite_note-V1C4-3)[[9]](#cite_note-V3C4-9)

### Shadow Wisdom

Shadow Garden's advanced technology and knowledge, internally called Shadow Wisdom (陰の叡智, Kage no Eichi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), allows them to compete against other organizations and countries for world supremacy. The source of the wisdom comes from Shadow Garden's leader, Shadow. His epiphanies are viewed as innovative and a glimpse at an incomprehensible intellect.[[10]](#cite_note-V5CS-10) In actuality, everything he provides is derived from widespread information regarding modern concepts and products—outside of personal magical research.[[3]](#cite_note-V1C4-3) These include but are not limited to modern engineering, martial arts, economics, agriculture, architecture, music, and literature.[[11]](#cite_note-V2CP-11)[[12]](#cite_note-V2C6-12)[[13]](#cite_note-WN200-13)

Thanks to the ingenuity and tireless pursuit of [Gamma](Gamma.md "Gamma") and [Eta](Eta.md "Eta"), Cid's generic ramblings about contemporary inventions became a reality in the Other World. The two of them working in concert have manufactured and distributed many modern luxuries through their front operation, the Mitsugoshi Company.[[3]](#cite_note-V1C4-3)[[14]](#cite_note-V6C5-14) Furthermore, Gamma acts as Mitsugoshi Company's president and funds most of Shadow Garden's clandestine operations. Outside of general products, the company pursues ventures to maintain financial monopolies for continual economic dominance.[[9]](#cite_note-V3C4-9)

### Intelligence Network

Shadow Garden benefits from a vast intelligence and spy network. Between the Midgar Newspaper Association and aristocratic connections, they gained access to private archives and document depositories.[[15]](#cite_note-V4C1-15)[[16]](#cite_note-MOG-SSC_P1C11E4-16) The organization itself has operatives who specialize in espionage. Agents leverage their public identities to infiltrate influence circles to curry favor, gather information, or leverage sensitive data.[[17]](#cite_note-V5CP-17)[[3]](#cite_note-V1C4-3)

## Organizational Structure

Shadow, Shadow Garden's founder and sovereign leader, possesses complete control over the organization and all ancillary or affiliate institutions. Although he rarely exercises this authority due to ignorance and flippancy, it grants him the power to make decisions that supersede those of any other leading administrator.[[18]](#cite_note-V3C6-18) Considering Shadow's approach to Shadow Garden, daily operations are managed by Alpha and Gamma. Alpha acts as the organization's commander-in-chief, monitoring overall operations and participating in complex or delicate missions.[[19]](#cite_note-V1C3-19) At the same time, Gamma oversees Shadow Garden in a collective capacity, primarily focused on coordinating daily affairs and gaining capital.[[20]](#cite_note-V5C4-20)[[21]](#cite_note-MOG-SSC_P3C1E3-21)

The overall managerial structure of Shadow Garden reflects a hierarchical framework. Internally, subordinates are partitioned into various divisions with supervisorial individuals delegating tasks. Shadow Garden brooks no dissent; inferiors are expected to obey their superiors without question. While these subordinates can remain attached to a specific division, some are assigned to assist an individual administrator. Furthermore, there is no strict adherence towards stations. Cross-participation frequently occurs, and missions are regularly assigned to individuals or a group. For such missions, members will commonly form a three-woman squad. One acts as the leader and the other two follow commands. If more people are deemed necessary, multiple cells can congregate with an assigned individual who becomes the commanding officer.[[22]](#cite_note-V4CP-22)[[15]](#cite_note-V4C1-15)

## Membership

Shadow Garden has gathered roughly 600 women before Cid's enrollment in Midgar Academy. After the second year, their numbers have grown to over 700.[[14]](#cite_note-V6C5-14) Their recruitment practices emulate an invite-only system. Those approached for official membership share one commonality: all are recovered possessed—the only exception is Akane, as [Beta](Beta.md "Beta") initially kidnapped her for potential knowledge not recruitment.[[23]](#cite_note-V4CE-23) Leadership does actively seek the afflicted; however, it is firstly done to cure the alignment and free trafficked victims.[[1]](#cite_note-V1CP-1) Consequently, all members, besides the leader, are female due to possession being sex-specific.[[4]](#cite_note-V2C2-4)

Those rescued and healed are given a choice: be free and remain ignorant of the truth, or forsake your existence and pledge eternal loyalty to Shadow.[[24]](#cite_note-MOG-SSC_P1C1E5-24) If someone accepts the invitation, the new recruits receive a numerical designation and get assigned to an operation squad. Regular members refer to themselves by this numeric identity, but the number is not a ranking system.  It denotes the order in which individual members joined the Shadow Garden.[[7]](#cite_note-V2CF-7) The only exception is 1-24, as those are appointed positions.[[22]](#cite_note-V4CP-22)

Numerical order notwithstanding, it serves a function for seniority and the general chain-of-command. For example, No. 100 has seniority and higher authority than No. 200 unless specified by higher authorities. While it might not immediately indicate strength, members have commented that it can reflect a good approximation. Each hundredth number can be considered a tier; it indicates more training and time within Shadow Garden.[[22]](#cite_note-V4CP-22)

### Seven Shadows

The Seven Shadows (七陰（しちかげ）, Shichikage[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are the first seven members to join Shadow Garden and Shadow's most loyal confidants. As Shadow's earliest subordinates, he took it upon himself to impart his knowledge and named them after Greek letters from Alpha (Α/α) to Eta (Η/η). He taught subjects such as swordsmanship and martial arts. Furthermore, Shadow's pontificating about the technological, economic, art, and literature advances in his previous life inspired them to explore those concepts. Each of them gravitated towards fields that spoke to them such as combat, espionage, physical science, or economics. Friends, comrades-in-arms, and disciples, the Seven Shadows are now indispensable to the organization.[[3]](#cite_note-V1C4-3)[[25]](#cite_note-MOG-SSC_P1C1E2-25)

Within Shadow Garden, Seven Shadows retain the highest governing authority; they can only be overruled by Shadow.[[23]](#cite_note-V4CE-23) Similar to the numerical structure of rank-and-file members, their ranking order is based on their sequential position, not power. As an example, Gamma's numerical designation marks her higher than Delta, but Cid identifies her as the weakest fighter among the Seven Shadows.[[3]](#cite_note-V1C4-3) The tag of Gamma's weakness is relative; all of the Seven Shadows demonstrate combat capabilities or physical prowess well beyond those classified as strong dark knights.[[26]](#cite_note-V3C5-26) Queen Rose Oriana, the present ruler of the Oriana Kingdom, expressed genuine fear regarding the leader of the Seven Shadows, Alpha. From her perspective, the leader alone could prove detrimental to the existing hegemonic powers. She believes an entire nation would inevitably incur massive losses and expend considerable resources just to subdue her, let alone all seven.[[4]](#cite_note-V2C2-4)

### Numbers

The Numbers (ナンバーズ, Nanbāzu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) are a membership classification that denotes the higher echelons of Shadow Garden. Instead of the typical Arabic numeral, the Numbers receive a letter from the Greek alphabet. The assigned name ranges from the eighth Greek letter, Theta (Θ/θ), to the twenty-fifth and final letter Omega (Ω/ω). Inside Shadow Garden, the Numbers influence and administrative power rank below the Seven Shadows. The Numbers likewise demonstrate capabilities beyond ordinary dark knights; they are often entrusted with delicate operations or assigned to work directly under a Seven Shadow.[[22]](#cite_note-V4CP-22)

Outside of covert missions, most of the Numbers ostensibly work as staff at the Mitsugoshi Company. The public identity allows them to continue being effective subordinates, and cultivating civilian personas to assist in urban-legwork.[[27]](#cite_note-V6CP-27)[[21]](#cite_note-MOG-SSC_P3C1E3-21)

### Zeta's Faction

Dissatisfied at Alpha's leadership approach, Zeta founded a secret faction in dissent. Despite the faction sharing Shadow Garden's purpose of destroying the Cult of Diablos, Zeta articulated her disdain for Alpha's foresight and planned destruction of the Demon Diablos. Instead, she desires to revive the Demon through Claire Kageno—[Aurora](Aurora.md "Aurora")'s vessel–with the intent to grant Shadow immortality and implant him as the world's new god.[[28]](#cite_note-V5C3-28) Misinterpreting Cid's roleplaying as acceptance, Zeta believes she has Shadow's blessing to continue running her clandestine operation.[[29]](#cite_note-V5C2-29)

The surreptitious faction exclusively consists of people who have offered complete subservience to Zeta and possess a zealous deviation to Shadow. These include outsiders who are not affiliated or official members of Shadow Garden. Continuing to realize the faction's alternative motives, the active Shadow Garden members move cautiously to avoid arousing suspicion from their superiors.[[28]](#cite_note-V5C3-28) Although Alpha remains unaware of the extent of the operation, she is conscious of Zeta's passive insubordination—such as rarely reporting progress—and continues to give leniency despite the opinions of the other Seven Shadows.[[20]](#cite_note-V5C4-20)

## International Presence

Shadow Garden maintains a steady growth in power and personnel. Their area of activity continuously expand, and a part of that expansion is foreign influence. Presently, Shadow Garden, or their front company Mitsugoshi Company, is established in several countries and dozens of cities.[[3]](#cite_note-V1C4-3)

### Midgar Kingdom

Despite becoming based out of the city of Alexandria, Shadow Garden originated in the Midgar Kingdom. Alpha and Epsilon continue to recruit mostly around Midgar, but it is not exclusive. After five years, Shadow Garden officially debuted, and Midgar became their stage. The members demonstrated their power by crippling several Cult installations, thwarting Cult attacks, besting Princess Iris Midgar and Beatrix in single combat, and other feasts of strength.[[19]](#cite_note-V1C3-19) Afterwards, the King felt politically forced into branding them as a terrorist organization, personal feelings notwithstanding.[[30]](#cite_note-30)[[31]](#cite_note-:0-31)

The Midgar Kingdom’s attitude towards Shadow Garden might be that of contempt; however, the country’s attitude and reliance on Mitsugoshi Company is a stark contrast. Unbeknownst to the Kingdom, their mortal enemy retains a controlling share of Midgar’s commerce and finance. Mitsugoshi Company and the Midgar Kingdom economy are so intertwined that Mitsugoshi’s collapse would be a systematic risk for the country.[[32]](#cite_note-32)[[5]](#cite_note-V6SS-5)

### Oriana Kingdom

After the death of King Oriana, his daughter, Rose Oriana, became the Queen after a tumultuous civil war. Her ascension to the throne was mired in controversy, exacerbated by the Church of Holy Teaching internationally denouncing the Oriana Kingdom as a heretic state. The Church and Kingdom continue to feud over theological differences; however, the entire conflict is a proxy war. The Cult of Diablos supports the Church while Shadow Garden quietly aids Oriana. Shadow Garden hopes that by leveraging Oriana, they can encourage the clergymen to exercise the Cult from their organization.[[20]](#cite_note-V5C4-20)

### Velgalta Empire

Shadow Garden has been interjecting themselves into Velgalta's economy through Mitsugoshi's housing and transportation investments. Natural petroleum reserves in the Empire signify a massive financial opportunity. Their present goal is to monopolize Velgalta's domestic and foreign commerce distribution.[[33]](#cite_note-33)[GAME ONLY]

### Lawless City

## Known Members

### Founder

Shadow Garden members view the organization’s founder in a plethora of ways. Whether it is a leader, master, boss, or deity, all personnel hold Shadow in high regard. Despite being the founder, he remains the nominal leader and rarely interferes in daily operations.

- Shadow: Shadow Garden's Founder; Leader; Ideological Inspiration[[2]](#cite_note-V1C1-2)

### Seven Shadows

The Seven Shadows are the original seven members of Shadow Garden, recruited and trained directly by Shadow himself. Shadow titled their names after the Greek alphabet, letters from Alpha (Α/α) to Eta (Η/η). Collectively, they are Shadow Garden's collegial body, placing them at the top of the organization hierarchy.

- [Α] [Alpha](Alpha.md "Alpha"): Director; Commander-in-Chief [[2]](#cite_note-V1C1-2)
- [Β] [Beta](Beta.md "Beta"): Academia Intelligencer;[[11]](#cite_note-V2CP-11) Data and Record Manager;[[34]](#cite_note-V3C2-34) Archivist[[21]](#cite_note-MOG-SSC_P3C1E3-21)
- [Γ] [Gamma](Gamma.md "Gamma"): Chief Operating and Finance Officer; Lead Military Strategist; Head of Research and Development; Mitsugoshi Company Founding President[[3]](#cite_note-V1C4-3)[[19]](#cite_note-V1C3-19)
- [Δ] [Delta](Delta.md "Delta"): Stealth Instructor;[[21]](#cite_note-MOG-SSC_P3C1E3-21)[GAME ONLY] Independent Combat Operative[[19]](#cite_note-V1C3-19)
- [Ε] [Epsilon](Epsilon.md "Epsilon"): Leader of the Cure and Rescue Commando Unit;[GAME ONLY][[21]](#cite_note-MOG-SSC_P3C1E3-21) Auxiliary Support;[[25]](#cite_note-MOG-SSC_P1C1E2-25)[GAME ONLY] Aristocratic Informant[[35]](#cite_note-V4C2-35)
- [Ζ] [Zeta](Zeta.md "Zeta"): Head of Exploration and Infiltration;[[17]](#cite_note-V5CP-17) Director of Archaeological Retrieval[[21]](#cite_note-MOG-SSC_P3C1E3-21)[GAME ONLY]
- [Η] [Eta](Eta.md "Eta"): Chief Engineer[[20]](#cite_note-V5C4-20)

### Numbers

The Numbers are those whose abilities were recognized by the Seven Shadows.[[3]](#cite_note-V1C4-3) They granted them a Greek letter like themselves. Their ranking starts at Theta (Θ/θ) and ends at Omega (Ω/ω).

- [Ⲓ] [Iota](Iota.md "Iota") (No. 9): Gamma's Subordinate[[36]](#cite_note-36)[GAME ONLY]
- [Λ] [Lambda](Lambda.md "Lambda") (No. 11): Shadow Garden's Combat Instructor[[7]](#cite_note-V2CF-7)
- [Μ] [Mu](Mu.md "Mu") (No. 12): Health Professional; Midgar Academy for Dark Knights Plant[[27]](#cite_note-V6CP-27)
- [Ν] [Nu](Nu.md "Nu") (No. 13): Gamma's Administrative Assistant; Shadow's General Liaison[[3]](#cite_note-V1C4-3)
- [Π] [Pi](Pi.md "Pi") (No. 16): Delta's Subordinate[[31]](#cite_note-:0-31)
- [Σ] [Sigma](Sigma.md "Sigma") (No. 18): Beta's Subordinate[[37]](#cite_note-37)[GAME ONLY]
- [Χ] [Chi](Chi.md "Chi") (No. 22): Epsilon's Subordinate[[27]](#cite_note-V6CP-27)
- [Ω] [Omega](Omega.md "Omega") (No. 24): Epsilon's Subordinate[[27]](#cite_note-V6CP-27)

### General Members

Outside of the Seven Shadows and Numbers, they categorize all other members with Arabic numerals. Their enumeration starts at 25 and continues onward, with the highest numerical designation mentioned at 712.

- 80: A general member scolded by Lambda
- [89](89.md "89"): Number Admittance Custodian[[22]](#cite_note-V4CP-22)
- 91: A general member scolded by Lambda
- [559](Victoria.md "Victoria"): Number Nominee; Member of Zeta's faction; Ex-Saint[[22]](#cite_note-V4CP-22)
- 664: Queen Rose's Handmaid; Ex-Platoon leader
- [665](665.md "665"): Queen Rose's Handmaid; Ex-Member of 664's Platoon
- 666: Juvenile Queen of Oriana Kingdom; Ex-Member of 664's Platoon
- [711](Millia.md "Millia"): An Ex-Lab Rat of the Cult
- 712: A New Recruit from the Realm Earth—previously known as Akane Nishino.

### Allies

Shadow Garden possesses many personnel; however, not everyone is an official employee. Instead of organizing everything in-house, they outsource or contract operational intermediaries. These people or companies share Shadow Gadoen's mutual objectives Cult or view themselves as hired support.

- [Yukime](Yukime.md "Yukime"): Monarch of the Lawless City; Owner of the Snow Fox Corporation; Shadow Garden's Underworld Liaison and Trade Partner
- Mist Dragon: An Ancient Dragon; Alexandria's Warden
- [Nina](Nina.md "Nina"): Unsanctioned Subordinate of Zeta

## List of Mission Accomplishments

Two Year Time skip: Seven Shadows Chronicles

- Rapid Growth of Shadow Garden's Martial, Political, and Financial Influence
  - Standardization of education and sword techniques
  - Relocation of Shadow Garden to the [Ancient City of Alexandria](Alexandria.md "Alexandria")
  - Tuna King franchising
  - Opening Mitsugoshi Company
  - Recruitment of powerful members

- Investigation of the [Templars](Templars.md "Templars")
  - Sacred Land of Lindwurm infiltration
  - Assassination of a templar leader
  - Recruitment of [The Saint](Victoria.md "Victoria") into Shadow Garden’s ranks

- Continual Possessed Research and Rescue
  - Successful Assaults on Cult and Church’s convoys
  - Further development of efficient curing procedures for the possessed
  - Destruction of testing and holding facilities

- Cult of Diablos Investigations
  - Supplementary intelligence provided by Beta’s infiltration of the Midgard Newspaper Association
  - Gamma’s Purchase of Midgard Newspaper Association
  - Deduction of the Cult and Church’s relationship

Present: 1st Year on Cid's Command

- Revealing the Cult of Diablos and Shadow Garden to the Public
  - Fenrir Sect weakened
  - Eliminated Zenon Griffey
  - Rescuing Princess Alexia Midgar
- Saving Midgar Academy
  - Eliminating terror attack mastermind and former Knight of Rounds, Lutheran Barnett
  - Gaining intelligence on the Eye of Avarice
- Infiltrating [Lindwurm](Lindwurm.md "Lindwurm")'s Holy [Sanctuary](Sanctuary.md "Sanctuary")
  - Attaining copies of ancient records via The Rolapoid
  - Annihilating Sanctuary
  - Eliminating Nelson Sect
- Recruitment of Rose Oriana
  - Preventing the Cult's assassination of King Klaus Midgar
  - Strength assessment of [Beatrix](Beatrix.md "Beatrix"), the goddess of war
- Infiltration and Destruction of the Crimson Tower
  - Securing [Elisabeth](Elisabeth.md "Elisabeth")'s Blood for possession research
  - Allying with Vampire Queen Elisabeth
  - Alpha and Beta learn the Red Mist vampire ability
- Making the Midgar Kingdom Economically Dependent on the Mitsugoshi Company
  - Absorbing the Major Corporate Alliance funds and assets
  - New ally [Yukime](Yukime.md "Yukime")
    - Lawless City becomes allied territory
    - Snow Fox Corporation partners with Mitsugoshi
- The Oriana Kingdom Becoming an Ally State
  - Exposing crimes of the Cult's puppet Royal Chancellor Perv Asshat
  - Exposing the treachery of Queen Reina Oriana
  - Eliminating [Mordred](Mordred.md "Mordred") Sect
  - Installing allied ruler, Queen Rose Oriana
  - Retained loyalty of Rose Oriana
    - Preparing for an eventual proxy war against the Cult's international instigations. (Ongoing)
- Attained Advance [Earth](Earth.md "Earth") Technology
  - Continual observation and study on an otherworlder
  - Reverse-engineered laptop (ongoing)

Present; 2nd Year on Cid's Command

- Preventing [Fenrir](Fenrir.md "Fenrir") Sect's Attempt to Resupply Tears of Diablos
  - Eliminating Fenrir Sect
    - [Zeta](Zeta.md "Zeta") secretly bonded Claire Kagenou to Diablos' right arm

## Trivia

- Only 9 of more than 700 members in the Shadow Garden have been directly cured by Cid, these being the original Seven Shadows, [Victoria](Victoria.md "Victoria") and Rose Oriana
- Iota and Sigma are the only members of the Numbers who have already been revealed in the game.

## References

1. Volume 1 Prologue: Preparing the Perfect Stage!
2. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
3. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
4. Volume 2 Chapter 2: Investigating the Sanctuary!
5. Volume 6 Side Story: That Nostalgic Smell
6. Volume 2 Chapter 8: Lay Your Eyes on My True Powers!
7. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
8. Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 3: Have Mercy! Eta's Protocol, Episode 1: Eta's Scheme
9. Volume 3 Chapter 4: I’ll Destroy It All and Start from Scratch!
10. Volume 5 Character Sheet: Eta
11. Volume 2 Prologue: To Lindwurm, the Sacred Land!
12. Volume 2 Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
13. Web Novel: Chapter 200
14. Volume 6 Chapter 5: Welcome to the Shadow Garden!
15. Volume 4 Chapter 1: Putting the Kibosh on Rose Oriana's Wedding!
16. Seven Shadows Chronicles Part 1: Rise of Garden, Chapter 11: Deal! Arranged Booking, Episode 4: Sponsor's Intent
17. Volume 5 Prologue: The Case of the Missing Students and the Not-So-Peaceful Academy!
18. Volume 3 Chapter 6: Circulating Counterfeit Cash!
19. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
20. Volume 5 Chapter 4: Peace in Our Time!
21. Seven Shadows Chronicles, Part 3: Secret of Sacra, Chapter 1: Shadow Garden Revamp, Episode 3: Girls Reshuffled
22. Volume 4 Prologue: It’s Time for a War in the Oriana Kingdom!
23. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
24. Seven Shadows Chronicles, Part 1: Rise of Garden, Chapter 1 Shadow Garden, Mobilize!, Episode 5: After the Rescue
25. Seven Shadows Chronicles Part 1: Rise of Garden, Chapter 1: Shadow Garden, Mobilize!, Episode 2: Garden Policy
26. Volume 3 Chapter 5: Printing Fake Money as Mitsugoshi Throws Down with the Major Corporate Alliance!
27. Volume 6 Prologue: There Are People Ruling the Midgar Kingdom from the Shadows? I’m So Jealous!
28. Volume 5 Chapter 3: The Case Is Closed, So, It’s Time for a Flashback!
29. Volume 5 Chapter 2: Morning Comes, and There’s an Impaler on the Loose!!
30. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
31. Volume 6 Chapter 3: Deciphering the Calling Card!
32. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
33. Seven Shadows Chronicles, Part 3: Secret of Sacra, Chapter 3: Shadow Garden Revamp, Episode 2: Reorganizing
34. Volume 3 Chapter 2: Storming the Crimson Tower!
35. Volume 4 Chapter 2: Begin Operation: Obstruction!
36. Seven Shadows Chronicles, Part 2: Sturm of Velgalta, Chapter 2: Possessed Cult Leader, Episode 5: Glorious Escape
37. Seven Shadows Chronicles, Part 3: Secret of Sacra, Chapter 8: Shadow Ninja Girl, Episode 1: Wide-range Investigation

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  **Shadow Garden** | | |
| --- | --- | --- |
| [Leader](#Founder) | Shadow | |
| [Seven Shadows](#Seven_Shadows) | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| [Numbers](#Numbers) | [Iota](Iota.md "Iota") • [Lambda](Lambda.md "Lambda") • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| [Members](#General_Members) | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
