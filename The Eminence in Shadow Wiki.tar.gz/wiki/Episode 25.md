# Episode 25

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2025](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2025)

## He Who Pulls The Strings

### Kana

糸を引く者

### Romaji

Ito o hiku mono

## Special Title

### English

The Eminence in Shadow wants to change up the way he fights!

### Kana

陰の実力者は戦い方にも変化をつけたい！

### Romaji

Kage no jitsuryoku-sha wa tatakai kata ni mo henka o tsuketai!

## Episode Information

### Season

2

### Episode

5 (25)

### Air Date

November 1, 2023 JP & EN

### Adapted From

Volume 3 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

Grayscale dominator

### Ending

Polaris in the Night (Omega ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Mask of Falsehood | John Smith |

He Who Pulls the Strings (糸を引く者, Ito o hiku mono[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the fifth episode of the second season, and the twenty-fifth episode of [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Alpha and Gamma carefully plot not take any actions that would implicate Mitsugoshi's connection to Shadow Garden. Meanwhile, John Smith has a plot of his own.[[1]](#cite_note-1)

ミツゴシ商会にガーター商会の最強部隊「四つ葉」が侵入してくる。その対処に名乗り出たのは、ガンマだった。心配するアルファをよそに自信満々で侵入者に対峙するが……。[[2]](#cite_note-2)

## Summary

At Mitsugoshi’s headquarters, [Gamma](Gamma.md "Gamma") reports to [Alpha](Alpha.md "Alpha") about the company's condition. Thus far, the targeted attacks against transport vehicles have been repealed, and Mitsugoshi remains economically dominant. The Major Corporate Alliance initiatives are ambitious, but they lack the wherewithal to implement them. Gamma confidently predicts that without Shadow Wisdom, they will be destroyed by themselves. Alpha quietly reminds Gamma that under no circumstances should the connection between Shadow Garden and the Mitsugoshi Company be revealed to the public.

Gamma concurs but warns passive measures are the only way to adhere to this restraint. [Nu](Nu.md "Nu") interrupts the women's conversation to announce the arrival of guests. Patience does not seem to be a quality that defines the visitor’s leader. Alpha instructs Nu to welcome the guests with proper decorum. Gamma interposes mid-sentence and asks for the privilege to act as host. The following silence is broken by Alpha repeating her earlier order to Nu. Confirming everyone’s fears, Gamma reiterates her earlier request. Alpha finally agrees, and [Omega](Omega.md "Omega") and [Chi](Chi.md "Chi") grudgingly accompany her.

The uninvited guests have entered Mitsugoshi commenting on the lack of security. Their mission to locate Manager Luna is completed when the target confronts them on her own accord. Omega and Chi rush two of the three intruders, leaving one combatant, Leaf One, to face Gamma. His confidence does not waver, and he judges Gamma’s equanimity as a bluff. That notion quickly vanishes when a swift chop to Gamma’s head only makes her complain about the dull pain. She criticizes his first attack, claiming a powerful frontal assault followed by close observation is the best approach. Gamma materializes her slime sword and begins an onslaught of continuous thrusts.

While fast, the technique is amaturous. Gamma infuses her sword with magic and asks if Leaf One is a practitioner of the school of Western Liechtenroi Fencing. Leaf One is incredulous that she identified his techniques after a few seconds. Magically infused-thrusts continue to assail him. Recognizing that Gamma could perceivably predict his next move, he aims another strike on Gamma’s head. Using a blade rather than an open hand makes no difference; the results were the same. Gamma recognizes her opponent's strength and gives him the honor of facing her full might. She begins the secret strategy that her master taught her. The art of “jam a lot of magical energy into it and hack away!” Collateral damages keep on piling up as Gamma haphazardly swings her sword. The onslaught comes to an abrupt end as the wild combatant stumbles over the protruding slats of the walk. The subsequent unaimed magic blows a hole in the wall of Mitsugosi.

After recovering from her face-plant, Gamma once again acknowledges Leaf One as a master combatant who led her into a trap. Chi and Omega arrive to assist Gamma with her bloody nose, having finished their fights. Leaf One realizes that his companions have been defeated and attempts a tactile retreat through the newly formed hole. Gamma pursues the fleeing man, only to trip again. The sword retains motion and flies out of her hands. The whirling blade miraculously pierces Leaf One’s neck. An explosion, a moribund man, and an exasperated Alpha are the results of the blast. Gamma proudly chuckles and proclaims it as a secret technique: The Self Sacrifice Spinning Wheel.

The unsuccessful raid forces Garter to admit the failure to the lycanthrope warrior [Gettan](Gettan.md "Gettan"). They have lost contact with all [Clover members](Clovers.md "Clovers"), deployed reinforcements, and the surveillance team. Garter articulates that some Major Corporate Alliance members have financial ties with Mitsugoshi and will not remain silent. Gettan dismisses the issue and orders the president to squelch any dissenters. Garter can only swallow his protests as he leaves the wolf lycanthrope.

Gettan reflects that giving the Clovers titles may have overinflated their perceived worth. The Cult of Diablos’ children would have been a better option, but after the deaths of [Grease](Grease.md "Grease") and Lutheran, the allocation of resources has been spread thin. The setbacks do not dissuade Gettan; he views it as a valid way to demonstrate his strength and value to the Cult. After their acceptance, he will have power that no one can challenge.

Under the setting sun, two people are engaged in sparring. Alexia is fiercely engaging the uninterested Cid. After several engagements, Alexia manages to disarm her black-haired opponent. A slow clap follows this accomplishment, drawing a sigh from the winner. The two break for food, selecting a bun food stand for dinner. Alexia asks for Cid’s opinion on her progress. He confirms that she is getting stronger. Cid quietly wonders what triggered the change. He concludes it was either a change in mindset or the discovery of a solution to a previous problem.

Alexia continues to eat her bun and expresses dissatisfaction about her advancement. She believes that her current power is not enough. An unenthusiastic reply forces Alexia to guide Cid on a proper reaction. After Cid is coerced into asking why, Alexia confesses that she no longer wants to feel like a spectator; her one friend is suffering. The world is moving without her, and if she stays ideal, she will be abandoned. Parting from Cid, Alexia expresses how carefree Cid is about life. She wishes Cid could remain that way for as long as he lives.

Later that night, John Smith quietly drinks sake at a noodle shop. A cat lycanthrope approaches the counter and asks for an extra large order of char siu. Without turning her gaze, Yukime’s attendant reports that production has been completed. The debonair gentleman’s face finally changes, warping into a smile. He sneers that the time has arrived.

[Yukime](Yukime.md "Yukime") subsequently explains to John Smith how the operation is organized. The production center is located in an inconspicuous viscountcy. Law enforcement is not the highest priority, as a desultory magistrate oversees the fiefdom’s governance. Printing presses will be housed in an abandoned coal mine, and all produced items will be transferred to a Lawless City distribution center. Counterfeit banknotes will be circulated into Midgar Kingdom from Lawless City to avoid backtracking. Yukime’s second attendant presents John Smith with a genuine and imitation banknote. The Spirit Fox asks the suave gentleman if he can tell the difference between the two. Rapidly darting his eyes back and forth, John Smith deridingly declares it is obvious. He flicks the bills back to Yukime and pontificates the discrepancies.

One of them uses coarser paper; consequently, the ink bleeds differently, and there are distortions in the print. Yukime exclaims in shock about his deductions while John Smith secretly fist bumps. She avers that the higher-quality bill is fake. John Smith started to say the same thing verbatim, but the end sounded off. In an attempt to replicate it perfectly, Yukime surpassed the original design. John Smith assures the worried Yukime that few people could tell the difference. She announces distribution will begin immediately and reminds John Smith of his two promises: to thwart any pursuers and to leave Gettan for her. He took everything from her; it is only suitable to reciprocate and take his life as reparation. The masked man sighs and agrees to the terms. He reminds Yukime to mind her steps; revenge can lead people astray if the path gets muddied.

Shadow Garden caught onto the counterfeits after a few bills appeared in their Mitsugoshi stores. Gamma explains to Alpha that the patrons seemed unaware that the currency was forged. Alpha asks about The Major Corporate Alliance's awareness of the issue. Gamma states they are oblivious to the threat and keep issuing new cash. As it may lead to a predicament, Alpha orders Gamma to bring their attention to it. Mistrust about one currency would lead to doubt about the other—leading to a credit crisis. Mitsugoshi’s adoption of fractional-reserve banking would make a bank run catastrophic. Alpha considers this scenario may be their intention but dismisses conjecture for another time. Their priority is to find the distribution site.

Thanks to Shadow Garden, MCA discovers the spreading of fake money. Garter quickly reports this development to Gettan. The blind warrior asks which note is inauthentic, but Garter is not confident in his answer. Gettan orders the corpulence merchant to track down the origin. Garter quickly accepts, dashing out of the room. Now alone, Gettan admits the circulation of MCA currency exceeds their total liquid capital. He assumes it is the same for Mitsugoshi. The plan Alpha was worried about is revealed to be Gettan’s true purpose, but it was not supposed to go into effect this early. The Cult of Diablos’ capital is wrapped up in MCA assets, and Gettan has not finished separating them. If the premature circulation continues, the Cult could lose a sizable fortune.

As darkness falls on Lawless City, [664](664.md "664"), [665](665.md "665"), and 666 descend on an outward-bound train. It is confirmed to be carrying contraband, including counterfeit MCA banknotes. Other teams will search for the counterfeiters, but 664’s squad is in charge of intercepting the cargo. The leader singles out 666 for making questionable decisions. All she has to remember is to follow orders. 666 says she understands, but 664 expresses doubt. 665 sneakily eats something and tells the two to get along. After jumping down from the roof, the three-women cell begins its infiltration. The absence of passengers is understandable, but no guards is abnormal. 666 notices something glistening and warns her teammates to be cautious. Before any response could be expected, a web of wires binds 664 and 665.

A sonorous voice asking the women for their tickets makes 666 turn her head. Instead of a conductor or ticket collector, there is a dapper gentleman controlling the wires with the tips of his fingers. 664 pulls out a knife to cut the constricting threads, but the blade snaps before making a mark. 666 realizes it is reinforced with magic and demands his name. John Smith obliges and manipulates his obscure weapon of choice to ensnare the remaining Number. 666 valiantly charges forward, but her sword catches on a few strands at the last second. John Smith acknowledges that her decision was correct but chastises her for being too inexperienced to do it properly. Untroubled by her proximity, he tightens the bound around 666.

John Smith announces that he knew they would come, but their appearance is too soon. They cannot be allowed to know anymore and with a swift motion of his hands, John Smith defenestrates the bound trio. Recovering on the ground outside, 666 prepares for a counterattack, but 664 orders her to stand down. Engaging the target without a plan would lead to the same result. As if to signal their withdrawal, the train accelerates away from the defeated women. The only option is to report to Gamma about the man in the suit. Walking away, 666 remembers the power John Smith displayed. Frustration gives way to lamentation as 666 questions why she is weak.

## Characters

- [Alpha](Alpha.md "Alpha")
- [Gamma](Gamma.md "Gamma")
- [Chi](Chi.md "Chi")
- [Omega](Omega.md "Omega")
- [Nu](Nu.md "Nu")
- Leaf One (Debut)
- Leaf Two (Debut)
- Leaf Three (Debut)
- Garter Kikuchi
- [Gettan](Gettan.md "Gettan")
- Cid Kagenou/John Smith
- Alexia Midgar
- Raphael Geerk Oriana (Flashback)
- Iris Midgar
- [Natsu](Natsu.md "Natsu")
- [Yukime](Yukime.md "Yukime")
- [Kana](Kana.md "Kana")
- Skel Etal
- Po Tato
- [664](664.md "664")
- Rose Oriana/No. 666
- [665](665.md "665")

## Promotional Videos

「陰の実力者になりたくて！ 2nd season」 第5話予告≪ノーマルVer.≫「糸を引く者」

『陰の実力者になりたくて！ 2nd season』 第5話予告≪スペシャルVer.≫「陰の実力者は戦い方にも変化をつけたい！」

## Trivia

- In the Light Novel and Manga, [Nu](Nu.md "Nu") was the one to aid [Gamma](Gamma.md "Gamma") against the Clovers. For the anime, [Chi](Chi.md "Chi") and [Omega](Omega.md "Omega") filled her role.

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s02e025>
2. <https://shadow-garden.jp/story/#story5>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • **Episode 5** • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
