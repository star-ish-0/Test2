# Raphael Geerk Oriana/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Raphael%20Geerk%20Oriana/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Raphael%20Geerk%20Oriana/Relationships)

Main

Chronology

Image Gallery

## Family

### Rose Oriana

Raphael's love for his daughter, Rose was immeasurable. It was because of her that Raphael chose to turn against the cult and he did everything in his power to ensure her protection from the cult even if it results in his own death. Even allowing her to study abroad in the hopes Rose would be safe from the cult's clutches. After being turned to a mindless puppet of the cult, part of the real Raphael emerged to have a last conversation with his daughter, as he begs Rose to kill him to which she tearfully complies and entrusting the future of the Oriana Kingdom to her before Rose put him out of his misery.

### Reina Oriana

Raphael loved his wife and trusted her to switch his meals in case they might be laced with the mind-altering drug. Tragically, Raphael didn't know that that Reina is Perv's lover and was complicit in turning him into a mindless puppet.

## Midgar Kingdom

### Klaus Midgar

The two kings have had a long history of friendship together, holding a truce between their nations for Midgar to protect Oriana in the event of any external conflict. It was shown when after King Klaus ensured to have his body be treated with utmost respect and be returned safely to Oriana through the leader of anti-Duke faction, Marquess [Grant](Grant.md "Grant").

## Enemies

### Cult of Diablos

Raphael aware about the Cult of Diablos and understands the organization's strength, because from the deal that have been made between the Oriana Royal Family and the Cult long ago. But, Raphael wanted to end the Cult's tradition on his kingdom and chooses to stand up to the Cult of Diablos in order to protect his daughter by plotting to gain independence form the Cult and build a force to stand up against them by forge an alliance with the Midgar Kingdom, even secretly sending his daughter to Midgar Academy to protect her from cult's clutches despite knowing that the Cult will make Raphael and his kingdom will suffer because of his treachery and will try to seize control of his kingdom.

After Raphael becoming their puppet, he hoped that all of his plans in order to save his daughter and expose the Cult and their collaborator crimes would not be in vain, even if it cost him his life. In the end, Raphael got what he wished for when Rose put on the "Ring of Succession" and activates the recording inside the ring which exposes the Cult crimes and their collaborator Perv Asshat, the man that brainwashed him into becoming the cult's puppet in public, although he can't divulge the organization's name to the Oriana's people.

### Perv Asshat

Raphael knew that Perv was affiliated with the Cult of Diablos and had gathered all evidence of his crimes and stored them in the "Ring of Succession". Unfortunately, before he could take action, Perv had drugged him with the use of his wife and queen, Reina, reducing him to a mindless puppet who was only put out of his misery when his daughter, Rose was forced to kill him. In the end, Raphael ended up getting the last laugh when Rose activated the "Ring" and exposed Perv's crimes during their wedding ceremony that would have made him the new king of Oriana.
