# 664/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/664/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/664/Relationships)

[Main](664.md "664")

[Chronology](664-Chronology.md "664/Chronology")

Image Gallery

## Shadow Garden

### Shadow / John Smith

She has a deep respect and loyalty to her lord Shadow. When 664 faced John Smith, she attacked him without knowing that it was her Lord, Shadow. Although she defended the innocence of her squad mate, 666, when Shadow exclaimed, he would not forgive her, 664 accepted and respected her lord's will, even when it did not fit her. However, 664 was happy to see Rose was still alive by Shadow's will and aided them in the counterassault against Mordred. Being able to stay with Rose as one of her undercover maids while Oriana Kingdom rebuilt after the Black Rose, 664's loyalty to her master was steadfast and grateful.

### [Alpha](Alpha.md "Alpha")

She has respect and loyalty to Alpha, since she is the second-in-command of Shadow Garden, to which 664 wants to demonstrate her good results to her superiors and does not like things to get out of control. When she reported her failure in the mission to investigate the source of the counterfeit bills to Alpha and Gamma, the sudden interjection by 666 pleading with their leaders to give them another chance startled 664 and they began to argue in front of their superiors without knowing that they were not complaining about nothing.

### [Beta](Beta.md "Beta")

She has respect and loyalty to Beta like the other Seven Shadows of Shadow Garden. When Beta led the Crimson Tower investigation and the support measure for Cid's sister, 664 followed her orders to the letter and adapted under pressure.

### [559](Victoria.md "Victoria")

664 holds respect for 559 given the latter is her superior in rank and senior within Shadow Garden. Even though she makes hasty and jumpy decisions at times, when 559 accused 666 of being a traitor in front of lord Shadow, 664 would vocally disagree and defended the innocence of her partner, 666.

### [665](665.md "665")

She has a sympathy and trust with 665, despite their opposite behaviors, since more than once has 664 scolded her for her sleepy and semi-distracted way of working. When they reported their failure in the mission to Alpha, 664 began to argue with 666 before Alpha ordered them to leave quietly to which 665 removed both of her teammates. 665 would fight alongside 664 as they helped Rose in the battle against Mordred, and 665 would happily join 664 undercover as Rose's maids as Oriana Kingdom rebuilt after the Black Rose event.

### Rose Oriana

Rose is one of 664's squad-mates following her induction into Shadow Garden as no.666. While 664 was annoyed at how Rose didn't follow protocol and acted on her own, 664 cared for Rose and even defended her when she abandoned Shadow Garden to protect her mother. When Shadow Garden chose to defend the Oriana Kingdom, 664 immediately came to Rose's aid and made her friendship with the new monarch blatant. After Mordred's defeat and the Black Rose was ceased, 664 continued to watch over Rose as one of her maids alongside 665, undercover for Shadow Garden.
