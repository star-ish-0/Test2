# Jet

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Jet](https://the-eminence-in-shadow.fandom.com/wiki/Jet)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Jet?action=edit).

## Jet

### Japanese

ジェット

### Romaji

Jetto

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- Marquis

### Affiliation

Thirteen Nightblades

## Debut

### Light Novel

Volume 6

### Manga

Chapter 70

Jet (ジェット, Jetto[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), also known as Marquis Jet, was a nobleman of the Midgar Kingdom and was the member of the Thirteen Nightblades.

## Appearance

## Personality

## Chronology

### Bloody Midgar Serial Murder Terror

He was tasked to assassinate [Kanade](Kanade.md "Kanade") and Christina Hope when the Thirteen Nightblades suspected that the Hope family hired Jack The Ripper to kill them however he ended up getting killed himself alongside [Viscount Shinobi](Shinobi.md "Shinobi") by Jack The Ripper.[[1]](#cite_note-1)

## Relationships

## Powers & Abilities

## Trivia

## References

1. Volume 6 Chapter 2 - Surprise Assassins at the sleepover

## Site Navigation
