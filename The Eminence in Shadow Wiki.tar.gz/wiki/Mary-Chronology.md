# Mary/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mary/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Mary/Chronology)

[Main](Mary.md "Mary")

[Relationships](Mary-Relationships.md "Mary/Relationships")

Image Gallery

## Tragedy of a Dream

In the past, Mary was a devoted follower of the "Blood Queen" [Elisabeth](Elisabeth.md "Elisabeth"), serving as her loyal second-in-command. Among her responsibilities, she regularly switched shifts to deliver meals to Elisabeth's quarters. However, tragedy struck when it was [Crimson](Crimson.md "Crimson")'s turn for the task. Mary resorted to drinking the deceased's blood to regain control over the uncontrollable Elisabeth. She subsequently pursued Elisabeth and the others who had fled the territory. After three grueling days, she eventually located Elisabeth, but by that time, darkness had already fallen on the chapter of events.

In a moment filled with remorse and tears, Elisabeth, repentant, implored Mary to end her life and scatter her ashes into the sea. However, Mary's blade veered away from Elisabeth's vital organ, leaving her in a deep slumber. Days turned into weeks, and Elisabeth miraculously awakened. Mary found herself torn between obeying her mistress's command to end her life and her inability to do so. In her dilemma, she resolved to conceal herself within an immortal coffin, unwaveringly dedicated to safeguarding Elisabeth regardless of the cost.

Having halted her mistress’s unrelenting genocidal spree, Mary dedicated herself to eliminating rogue vampires who posed a threat to humanity and other species, ultimately ascending to the rank of an Ancient Vampire Hunter. A millennium later, Crimson absconded with Elisabeth's body, and Mary, rendered powerless both by her inability to protect and her aversion to blood, could only watch as her charge was taken from her.

## Red Moon Incident

## Mitsugoshi Hot Springs Land

During a relaxation and the opening of a new hot spring in Midgar, Elisabeth and Mary manage to attend as guests to take a relaxing bath, waiting in line like everyone else to attend. During that short time, Elisabeth spent her time reading the magazine. of tourism that they offered, and then finally enter the place. All day long until nightfall they enjoyed the pleasures and comforts of the place (but took no part in the brief commotion of the place).

## Volume 4

### Oriana's "Black Rose" Wedding

During the battle of the kingdom of Oriana, Elisabeth and [Mary](Mary.md "Mary") remained oblivious to everything, since they were in the Lawless City, but they witnessed the magical glow that Shadow unleashed, throughout the night sky, of the Other World.

## References
