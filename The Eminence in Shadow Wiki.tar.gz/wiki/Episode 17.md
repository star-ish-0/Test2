# Episode 17

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2017](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2017)

## Moonlight That Pierces the Darkness

### Kana

闇に射す月光

### Romaji

Yami ni Sasu Gekkō

## Special Title

### English

The Eminence in Shadow Wants To Show off That He’s Good at Musical Arts Too!

### Kana

陰の実力者は芸術方面でも凄いところを見せつけたい！

### Romaji

Kage no Jitsuryokusha wa Geijutsu Hōmen Demo Sugoi Tokoro wo Misetsuketai!

## Episode Information

### Season

1

### Episode

17

### Air Date

January 25, 2023 JP
April 17, 2023 EN

### Adapted From

Volume 2 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Mio Inoue

### Storyboard

Susumu Nishizawa

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Epsilon ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Unseen Intentions | Betting on a Moment |

Moonlight That Pierces the Darkness (闇に射す月光, Yami ni Sasu Gekkō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the seventeenth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Cid recollects piano lessons from his past life – what impact does this have on his present? Meanwhile, Epsilon's performance sets the soundtrack for something else...[[1]](#cite_note-1)

アレクシアとナツメは、ローズ保護のため王都地下道へ。ローズが事件を起こしたのは、ドエムの野心を察したからだった。そんな中、ピアノに導かれたローズはシャドウと再会する。[[2]](#cite_note-2)

## Summary

When Cid struggles to imagine his hypothetical reveal of his true power in the Bushin Festival, Skel comes knocking on his door with a plan on how to get rich fast. He shows that Rose has a reward for turning her in or giving information about her location, and tries to convince Cid to work with him and find her, so that he can get rich. While initially uninterested, Cid sees that his sister is coming to visit and decides to avoid her. So he accepts Skel's proposal and uses the window to leave, and while Claire hears something, she thinks nothing of it and enters the dormitory.

With news of Rose's fugitive status taking the front page, Cid goes for a walk around town and considers if Rose was able to escape safely. Learning she stabbed her fiancé, Cid wonders if he could have had a chance to ask her why she'd do something so impressive by his standards. But his thoughts redirect after he hears someone playing a piano and notes the piano playing is from someone good. Recalling his previous life, he was forced to learn to play piano by his parents when he would have rather trained for becoming the Eminence in Shadow, but grew to find the piano quite cool and playing kept social interactions to a minimum as people didn't want to interrupt perceived practice. However, as he recognizes the music, he wonders if it should exist in this world and decides to see who it was playing the piano, since it may be another reincarnated person.

Entering the concert hall, Cid is silently dumbfounded to find [Epsilon](Epsilon.md "Epsilon"), who like [Gamma](Gamma.md "Gamma") and [Beta](Beta.md "Beta"), is using what he taught her to become famous. After her performance, Cid asks if that was the "Moonlight Sonata" and Epsilon confirms such, saying that this one is her favorite out of all the pieces he taught her. When really, Cid didn't mean to teach her, but is happy she likes something he likes. Epsilon reveals that received rewards for her music composition and has gained connections with influential people, especially in the Oriana Kingdom, as Cid quietly realizes that she plagiarized all the music he shared with her. Returning to his earlier thoughts, Cid asks her if she knows where is Rose hiding, but Epsilon states that Beta is working that case, but heard Rose is hiding in the tunnels under the Royal Capital. Cid thanks her and compliments her figure as he leaves, trying to reward her for liking something he likes. On his way out, he notices the piano and smiles having concocted an idea.

In a junction across the capital train station, [Beta](Beta.md "Beta") uses her Natsume Kafka alias to share information with Alexia on the suspicion that Perv Asshat is working with the Cult. Together, they head down to the tunnels under the Royal Capital, as Alexia wants hard evidence on Perv's involvement given the political aspect and delicate connections with the church. Alexia is troubled that the Cult will likely cause problems for the kingdom should nothing be done. Iris also informed her that king Raphael Geerk Oriana didn't seem affected by Rose actions. When Alexia explains that they are heading to the underground passages as there is a chance that Rose had used them to escape, Beta notes that the area is a maze and asks how they can leave, only for Alexia to state that they will just return the way they came; infuriating Beta.

Deep within the tunnels, Rose rests against a wall nursing her [Possession](Possession.md "Possession") wounds as she reflects how she met her father and Perv the other day. When she she went to see her father, the king, she knew something was wrong with him by his vacant stare, soon finding Perv and the guards with sinister smiles. Reaching the obvious conclusion, she drew her sword and attacked Perv, but the guards then yelled that she went mad and called for reinforcements. Rose believed in the moment she made a rational decision, but later realized it wasn't as even if she managed to kill Perv, he is just one of the Cult, whose roots are already too deep within the Oriana Kingdom. Perv ordered her to turn herself in before the Bushin Festival, or he will have her father kill one of his guests. Rose now wonders if its best to turn herself in as that way it may avoid a war. She recalls her time with Cid, but as her possession gets worse, she feels that marrying Cid and living with him would have been a dream anyway.

Echoing across the tunnel network, Rose hears the Moonlight Sonata and starts following the music to its source, eventually finding Shadow as the one playing on the piano in the abandoned hallowed halls of Old Midgar. As he finishes, Rose applauds him as that was the best performance she had heard of the Moonlight Sonata. But Shadow suddenly asks her what she hopes to accomplish, as Rose states she wanted to protect those close to her and deliver a bright future for everyone, but couldn't do anything. Channeling a flame of his magic, Shadow notes that if she has the desire to continue her fight, then he will give her power. Asking if the power can allow her to change the future, Shadow only answers that such is contingent on her, so Rose accepts as there are things she wants to do and protect. Once Shadow gives her his power, the magic heals her of possession, as Shadow tells her that true strength lies not in one's power, but in one's way of being. After Shadow leaves, several Cult assassins arrive and Rose easily defeats them with her evolved power, admiring Shadow's power as moonlight against the darkness.

Feeling the burst of magic, Alexia and Beta run towards the origin and find Rose. As she is walking to the exit, Rose states she has obtained power and will follow the path she believes in. Despite Alexia's questions, Rose refuses to say anything for not wanting to drag Alexia into this. Alexia reminds Rose of their promise at the Sanctuary, to not lose what they care about as spectators, but Rose apologizes as she will be defamed as evil for what she must do. Enraged, Alexia draws her sword, stating she will make Rose talk, but Rose defeats Alexia and leaves her to Beta, who states that she won't stop Rose. She notes that they are each different, but the ideals they strive for may be the same, and their alliance may not have been such a bad idea. She wishes Rose success, suspecting and hoping that they may reunite before too long. Once Rose flees, Beta ponders if gifting his power to the princess was really what he had chosen for her.

At the concert hall, the authorities are investigating the missing piano taken in broad daylight. At sunset, Cid is returning to his dormitory, admiring his work as Shadow. Enjoying the piano as a set piece from his performance with Rose, Cid wishes he had his own so he wouldn't have to borrow one. However, he is surprised to see his sister still waiting for him. As she glares with a fake smile, Cid only smiles and waves back.

## Characters

- Cid Kagenou
- Skel Etal
- Claire Kagenou
- [Epsilon](Epsilon.md "Epsilon")
- Alexia Midgar
- [Beta](Beta.md "Beta")
- Klaus Midgar (Mentioned)
- Rose Oriana
- Raphael Geerk Oriana (Flashback)
- Perv Asshat (Flashback)

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第17話予告≪ノーマルVer.≫「闇に射す月光」

TVアニメ『陰の実力者になりたくて！』第17話予告≪スペシャルVer.≫「陰の実力者は芸術方面でも凄いところを見せつけたい！」

## Trivia

- The English Dub of this episode made a translation error. When Cid was talking about waiting for Rose to cool down, when he was actually waiting for Claire to cool down.
- Among the piano compositions Epsilon learned from Cid, the ones she names include the Moonlight Sonata, the Turkish March, and the Minute Waltz.
- The concert hall Epsilon plays at has a design resembling modern architecture.

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e017>
2. <https://shadow-garden.jp/1st/story/#story17>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • **Episode 17** • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
