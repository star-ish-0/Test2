# Sherry Barnett

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sherry%20Barnett](https://the-eminence-in-shadow.fandom.com/wiki/Sherry%20Barnett)

Chronology

Relationships

Image Gallery

## Sherry Barnett

### Japanese

シェリー・バーネット

### Romaji

Sherī Bānetto

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

16 (Volume 1)
17 (current)

### Height

Unknown

### Hair Color

Pink

### Eye Color

Pink

### Birthday

July 9

## Personal Information

### Status

Alive

### Relatives

Lukreia Crowley † (Mother)
Unnamed Father †
Lutheran Barnett † (Foster Father)

## Professional Information

### Occupation

- Student (formerly)
- Researcher
- Professor (Currently)

### Affiliation

Midgar Academy of Science (Formerly)
[Laugus](Laugus.md "Laugus") (Currently)

## Debut

### Web Novel

Chapter 22

### Light Novel

Volume 1

### Manga

Chapter 7

### Anime

Episode 5

## Portrayal

### Japanese

[Saya Aizawa](https://en.wikipedia.org/wiki/Saya_Aizawa "wp:Saya Aizawa")

### English

[Brittney Karbowski](https://en.wikipedia.org/wiki/Brittney_Karbowski "wp:Brittney Karbowski")

### French

Olivia Masseron

### Italian

Giulia Maniglio

### German

Melanie Olbert

Sherry Barnett (シェリー・バーネット, Sherī Bānetto[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a professor in [Laugus](Laugus.md "Laugus") and formerly a second-year student at Midgar Academy for Dark Knights. She was targeted by the Cult of Diablos after being assigned with studying an artifact retrieved from them. Although saved by Shadow, she developed a vendetta against him for killing her adoptive father, unaware that he was a Cult member.

## Appearance

Sherry is a cute girl of moderate height with a slender physique possessing pastel pink hair and eyes. She has short, shoulder-length hair, braided on both sides with an ahoge on top of her head.

As a student, she wore the standard Midgar Academy for Dark Knights uniform. A navy-blue blazer adorned with white and gold accents. Her white shirt complimented a navy blue waspie and necktie ornamented with gold trim. A white skirt with a navy blue and gold hem covered black tights. White lace-up block heel boots and a black robe with red jewels on the sides rounded out the outfit.

## Personality

|  |  |  |
| --- | --- | --- |
| “ | When it's all over, will you listen to my story? | ” |
| — Sherry to Cid Kagenou, Light Novel Volume 01 | | |

Sherry is a smart and bright young girl with a thirst for knowledge. That intelligence allows her to decipher ancient languages, a rare feat even for intellectuals. She invests a lot of time into academics and as a consequence, Sherry’s social acumen has major gaps. Even basic social interactions prove challenging, making relationships difficult to cultivate. Her foster father was aware of this problem and openly expressed concerns about her lack of friends. For those she has formed a relationship with, Sherry is attentive and loyal.

After receiving chocolate from Cid, she made a conscious effort to actively approach him, in hopes of being closer to him. Sherry eventually developed a one-way crush. In a few instances, the former student displayed clumsiness when she traversed the campus occupied by Cult members posing as Shadow Garden.

Following the death of her stepfather, her personality changes. She becomes more withdrawn and loses her cheery disposition. In the anime, she becomes dangerously obsessed with Shadow, unaware that he and Cid are the same person.[[1]](#cite_note-AS1E20-1)

## Powers & Abilities

Sherry possesses extraordinary intelligence, especially in the field of linguistics. She has been shown to possess both crystallized and fluid intelligence. Such academic mastery allows her to decipher ancient languages and artifacts.[[2]](#cite_note-:4-2)

Her fighting, and especially her stealth capabilities, are close to non-existent. Cid’s constant interventions were required to keep her from an untimely death.

## Trivia

- Sherry likes to put a lot of sugar and milk in her coffee.
- In the anime final episode, there is an anime original scene where Sherry is laughing maniacally after stabbing a news portrait of Shadow with a knife. Whether or not this is canon has yet to be confirmed due to Sherry's absence after her debut in the first light novel.[[1]](#cite_note-AS1E20-1)

## References

1. Episode 20
2. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • Po Tato • Alexia Midgar • Christina Hope • [Isaac](Isaac.md "Isaac") • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • **Sherry Barnett** | |
| Unknown Year | Eliza Despoht | |
