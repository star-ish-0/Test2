# Jormungandr

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Jormungandr](https://the-eminence-in-shadow.fandom.com/wiki/Jormungandr)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Jormungandr?action=edit).

## Jormungandr

### Japanese

ヨルムンガンド

### Romaji

Yorumungando

## Characteristics

### Race

Unknown

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Knight of Rounds

### Affiliation

Cult of Diablos

Jormungandr (ヨルムンガンド, Yorumungando[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a member of Cult of Diablos, being an unknown seat member in the Knights of the Round. They are one the knights of rounds to be known by the Herzog family.[[1]](#cite_note-1)

## Appearance

## Personality

## Synopsis

### Background

## Powers & Abilities

Having ageless immortality by taking the Beads of Diablos as they are part of the knights of rounds.

## Relationship

### Knights of Rounds

## Trivia

## References

1. Seven Shadows Chronicles - Sturm of Velgata - chapter 5 (cult's secrets revealed)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | [Loki](Loki.md "Loki") • [Hel](Hel.md "Hel") • **Jormungandr** • [Fenrir](Fenrir.md "Fenrir") • [Mordred](Mordred.md "Mordred") • [Petos](Petos.md "Petos") • Jack Nelson • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • Sir Gaunt | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • [Jean](Jean.md "Jean") • Dark Spider • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • [Gray](Gray.md "Gray") • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • Reina Oriana • [Isaac](Isaac.md "Isaac") | |
