# Duet

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Duet](https://the-eminence-in-shadow.fandom.com/wiki/Duet)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

## Duet

## Characteristics

### Race

Elf

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Silver

### Eye Color

Blue

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

[Beta](Beta.md "Beta") (Descendant)

## Professional Information

### Occupation

Hero

### Affiliation

The Heroes
Cult of Diablos

## Debut

### Game

Apocrypha: Chapter 1

Duet is one of the Heroes that took part of the fight against the [Demon Diablos](Aurora.md "Aurora"). She is the ancestor of [Beta](Beta.md "Beta").[CITATION NEEDED]

## Appearance

Unlike her Descendant, she has flowing waist length hair.

She also wears a battle armor similar to Olivier. However, hers is in a green and silver color scheme.

## Personality

She is shown to be a lot more reckless than her descendant, blindly charging towards Diabolos during their encounter.

She is also more self-conscious than her counterpart, actively blaming herself and despairing for Cid's (supposed) death despite never even knowing him.

## Abilities

## Relationships

### [Pente](Pente.md "Pente")

Unlike their Descendants, she and Pente seem to be quite close to one another.

## Trivia

- Her name, Duet, means 2 people working in concert. A strange name for when referring to a single person. However, this is likely just to be a reference to her descendant, Beta, being the second member of Shadow Garden.
