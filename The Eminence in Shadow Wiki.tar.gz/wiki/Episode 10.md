# Episode 10

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%2010](https://the-eminence-in-shadow.fandom.com/wiki/Episode%2010)

## The Sacred Land, City of Deception

### Kana

聖地・欺瞞の都

### Romaji

Seichi: Giman no Miyako

## Special Title

### English

The Eminence in Shadow Wants To Do That One While Looking Down From a High Place!

### Kana

陰の実力者は高い所から見下ろすやつをやりたい！

### Romaji

Kage no Jitsuryokusha wa Takai Tokoro Kara Miorosu Yatsu o Yaritai!

## Episode Information

### Season

1

### Episode

10

### Air Date

December 7, 2022 JP
February 27, 2023 EN

### Adapted From

Volume 1 – Volume 2 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Kunihiko Okada

### Storyboard

Daisuke Takashima

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Alpha ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| The End of a Lie | The Goddess' Trial |

The Sacred Land, City of Deception (聖地・欺瞞の都, Seichi: Giman no Miyako[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the tenth episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Cid heads to Lindwurm in response to a summons from Alpha, but he is not the only one traveling there; the annual Goddess’ Trial is quickly approaching.[[1]](#cite_note-1)

夏休み、シドはアルファの要請に応じ、聖地リンドブルムを訪れることに。聖地では、年に一度、聖域の扉が開かれる日に行われる“女神の試練”が開幕の時を迎えようとしていた。[[2]](#cite_note-2)

## Summary

The summer breaks start earlier and most students decide to head home. Having nothing to do at home, Cid decides to stay in the dorm, but soon realizes he doesn't have anything to do there either. He soon receives a letter from [Alpha](Alpha.md "Alpha"), telling him about Lindwurm.

Meanwhile, [Epsilon](Epsilon.md "Epsilon") is happy to start her day. She recalls how she was saved by Shadow and obtained slime magic, which allowed her to fight two faiths. Using the slime magic, she gives herself a larger bust (Epsilon is remembering the distant past when cid told her she could change her destiny she didn't think about the cult like the other girls she watched Beta and her young developing bust.). [Beta](Beta.md "Beta") writes a novel about how Shadow saved a woman from Zenon Griffey, but gets frustrated and decides to take some fresh air. Outside, Beta ends up meeting Epsilon, who states that lately Shadow has been gazing at her at especially her chest. Beta doesn't want to believe it, but Epsilon states that since both have large busts, they are more aware of those sort of glances. Epsilon then teases Beta if she had not received such gazes from Shadow. [Nu](Nu.md "Nu") then comes and tells them that they have a new directive from Alpha.

Iris and Alexia visits Gamma's store to prepare for Alexia's trip to the Sacred Land as a special guest for the Goddess's Trial. Alexia intends to use the opportunity and speak with archbishop and looks into dark rumours about corruption and missing orphans. Gamma meets them and introduces herself as Luna. After explaining why they are there, Alexia requests to see some other more common items for everyday use, which won't be exactly for her, but it won't be a gift to someone either. Gamma then realizes what she means and shows her some panties and thongs. As they barely cover anything and the men like them, Iris is against it, but Alexia likes them and is confident she will look good in them. She ends up trying them and manages to convince Iris to let her buy them.

After the terrorist attack, Rose heard that Cid is alive and rushed to find him. She found him covered in bandages and states he must have survived and caused a miracle by his deep love to her. She accepts his love and as he saved her, she will give him her heart. Later Cid and Rose are traveling together in a train towards the Sacred Lands, with Rose clinging to him. As it will take them two more days until they arrive, Cid feels his decision to take the train as a background character was a mistake and he could have run there faster. Rose guess that Cid is there to take on the Goddess's Trial. Cid is not sure but guesses that Alpha send him for that and confirms it. Rose then explains that those that receive the Goddess blessings may even marry a princess and if he gets it, she will speak with her father about the young brave man. She still can't tell anyone about them, but believe that if they work hard, they will have a happy future. But cid believing that she is trying to recruit him into her faith and doesn't understand that he's talking about her feelings to him.

Reaching Lindwurm, Cid sees some keychains of a sword piercing a left demonic arm. Rose explains that according to the legend, here Olivier cut off the left arm of the demon Diablos. Somewhere within the nearby mountains are the ruins known as the Sanctuary, where its said that Diablos' left arm is sealed. Walking around, Rose notices a signing event of the author Natsume. Rose is a big fan of hers and they line up. She explains how original her works are and how diverse and imaginary they are. Cid then checks some of her books and sees titles like "Romeo e Julietta", "Asherella", "Star It's a Trap Wars", "One Purse", "Dragon Bowl", etc. He quickly realizes they are plagiarized and guesses that someone else had reincarnated like him, and lines up to find out who it is. To his surprise, he sees Natsume is Beta, who used his wisdom to make herself famous. Cid recalls that Beta told him she loves literature, so he told her a few stories from his past life. He thought she was going to use them as an inspiration to come up with a cool story, but she ended up stealing them. Beta signs a book and gives it to him, stating it contains all the details of the mission.

Rose shows her book to Cid, saying that Natsume wrote her name in it. She wonders what Natsume wrote to Cid, but are surprised to see its written in ancient language. Rose knows a bit, but can't read it. She wonders why she wrote it like that and Cid guesses it's because it's cool.

Alpha is next to Archbishop [Drake](Drake.md "Drake")'s dead body and wonders what he was hiding that they even killed a man of his high status. Cid notices a man running on a rooftop and stops him. The man attacks him, but Cid easily blocks. Epsilon then shows up and kills the man. She tells Cid that the target was eliminated by the Cult's executioner. They got his henchmen, but [the executioner](Venom.md "Venom") has gone into hiding. They will be moving to Plan B. Cid informs her that he will be proceeding with his own plans.

## Characters

- Cid Kagenou
- Claire Kagenou
- [Gamma](Gamma.md "Gamma")
- [Delta](Delta.md "Delta")
- [Eta](Eta.md "Eta")
- [Epsilon](Epsilon.md "Epsilon")
- [Beta](Beta.md "Beta")
- [Nu](Nu.md "Nu")
- Iris Midgar
- Alexia Midgar
- Rose Oriana
- Skel Etal (Mentioned)
- Po Tato (Mentioned)
- [Alpha](Alpha.md "Alpha")
- [Drake](Drake.md "Drake")
- [Venom](Venom.md "Venom") (Mentioned)

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第10話予告≪スペシャルVer.≫「陰の実力者は高い所から見下ろすやつをやりたい！」

TVアニメ『陰の実力者になりたくて！』第10話予告≪ノーマルVer.≫「聖地・欺瞞の都」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e010>
2. <https://shadow-garden.jp/1st/story/#story10>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • **Episode 10** • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
