# Lawless City

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lawless%20City](https://the-eminence-in-shadow.fandom.com/wiki/Lawless%20City)

## Lawless City

### Japanese

無法（むほう）都市（とし）

### Romaji

Muhō Toshi

### Alias

Haven[[1]](#cite_note-1)

## Location Information

### Leader

[Yukime](Yukime.md "Yukime")
Status: Active
(Shadow Garden Partner)
[Juggernaut](Juggernaut.md "Juggernaut")
Status: Dead
(Hunted by Delta)
[Elisabeth](Elisabeth.md "Elisabeth")
Status: Inactive
(abdicated)

### Status

Active

### Affiliates

Unknown

### Type

City

### Government

Unknown

### Location

Between the border of the Kingdom of Midgar and the Velgalta Empire's

### Inhabitants

Humans
Therianthropes
Ghouls (previously)
Vampires (previously)

## Debut

### Web Novel

Chapter 80 (Mentioned)
Chapter 92

### Light Novel

Volume 2 (Mentioned)
Volume 3

### Manga

Chapter 24 (Mentioned)
Chapter 27

### Anime

Episode 18 (Mentioned)
Episode 21

### Game

Episode 17 (Mentioned)
Episode 20

Lawless City (無法（むほう）都市（とし）, Muhō Toshi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a city renowned for its infamous reputation as the global epicenter of criminal activity and vice, characterized by its sprawling slums where illicit and corrupt practices flourish with impunity. The city's turbulent atmosphere intensified through the unending power struggle between [Yukime](Yukime.md "Yukime") the Spirit Fox, [Juggernaut](Juggernaut.md "Juggernaut") the Tyrant, and [Elisabeth](Elisabeth.md "Elisabeth") the Blood Queen.[[2]](#cite_note-V3P-2)[[3]](#cite_note-V3C1-3) In the aftermath of Shadow's unorthodox interference, Elisabeth abdicated, while Juggernaut's tenure ended through regicide.[[4]](#cite_note-V3C3-4)[[5]](#cite_note-:0-5) Yukime emerged as the sole and unquestioned ruler of the Lawless City.[[6]](#cite_note-:1-6)

## History

As far as known up to the present date, the enigmatic Lawless City has endured through the annals of time, but its true origin shrouded in obscurity. The city is a cesspool of villainy that operates on the principle of survival of the fittest. It serves as a magnet for the convergence of evil, wealth, and power from all corners of the globe.

The city's history remains an enigma, but it is imperative to note that the reign of the current triumvirate; consisting of Elisabeth, Yukime, and Juggernaut, was not its initial governance. Crimson Tower was the first edifice built in Lawless City, acting as a lair and last refuge for the remaining [vampires](Vampire.md "Vampire"). Centuries later, the other monarchs arrived amassing power, wealth, and territory. Each ascended to power under distinct circumstances. Once firmly established, they or their loyal followers undertook the monumental task of erecting the tall tower as a symbol of authority to marking their respective domains within the city's boundaries.

## Governance and Economy

Lawless City stands as a sovereign city, detached from any nation, and bears the ominous distinction of being among the world's most perilous urban centers. Its distinct aura combines the characteristics of an expansive slum, fostering an environment that thrives as a breeding ground for criminal activity. Within these city limits, no wrongdoing or even the shadiest of undertakings remains uncharted, openly endorsed, and normalized, marking a routine occurrence.

In stark contrast to conventional cities and nations, Lawless City lacks any semblance of moral order, security, or a functioning legal system. Within its confines, citizens frequently engage in a litany of illegal activities, including but not limited to abuse, murder, harassment, robbery, rape, prostitution, slavery, contraband smuggling, and more. Occupations that contravene common legal or moral precedent make up the vast majority of the working population. A poverty-stricken life is held by the vast majority of citizens, with only tower occupants avoiding the squalor. While the city maintains its perilous character during daylight hours, the dangers escalate exponentially under the shroud of nightfall.[[3]](#cite_note-V3C1-3)

In this city, the sole governing law is "Might." Every resident living there, regardless of age, gender, race, or species, is subject to this unyielding law. Survival hinges solely on one's ability to wield force and employ any available means to shield oneself from the relentless challenges of their environment. The powerful inhabitants establish and enforce their own rules within their domains, though a semblance of order remains somewhat deficient across the city as a whole. Some who are weak congregate under the strong, with the intent of amassing strength or wealth for self-sufficiency (e.g., prostitutes in brothels). This transition rarely occurs as motivation is lost over time.

## The Three Monarch Towers

Lawless City possessed three rulers who partitioned the city into three territories—white, black, and crimson. Each leader holds sway in one of three regions, marked by towering structures that overshadow the surrounding architecture. These rulers were known as the Three Monarchs. They held absolute authority and influence within their respective districts. Out of the three, Yukime remains the sole active monarch in Lawless City.

### White Tower

The Spirit Fox, Yukime, governs the White Tower (白（しろ）の塔（とう）, Shiro no tō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). Acting as the bawd for the city's prostitutes and escorts, Yukime designated the area as a red light district.

Although the tower resides in Lawless City, the district secretly manufactures and distributes Snow Fox Corporation merchandise.

### Crimson Tower

[Elisabeth](Elisabeth.md "Elisabeth"), the Blood Queen, acted as the titular ruler of the Crimson Tower (紅（くれない）の塔（とう）, Kurenai no tō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), but the one who really ran things was [Crimson](Crimson.md "Crimson"). Originally, the Crimson Tower was built as the headquarters, lair and, refuge for vampiric refugees. It was the first tower built in the Lawless City.

The tower was destroyed at the hands of Shadow during the Red Moon incident.

### Black Tower

[Juggernaut](Juggernaut.md "Juggernaut"), the Tyrant, ruled the Black Tower (黒（くろ）の塔（とう）, Kuro no tō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). After the events of the Red Moon, Juggernaut was assassinated by an enthusiastic [Delta](Delta.md "Delta"), and the Black Tower became inactive due to the murder of its leader.

## Location and Layout

Official The Eminence in Shadow media delineates Lawless City along the Midgar Kingdom's northwest border and the Velgalta Empire's east border.[GAME ONLY][[7]](#cite_note-7) With no barriers or regulatory processes, individuals can reach the region through normal means, such as by carriage or foot. In some adaptations, a train running along Lawless City's coast facilitates further transportation options.[ANIME ONLY][[8]](#cite_note-:3-8)[[9]](#cite_note-9)

Inside the city, huts and shanties line the roads. The foul stench of garbage permeates the air, and sloven citizens meander around town.[[3]](#cite_note-V3C1-3)[[10]](#cite_note-WN95-10) What prominently stands out the most in the city are the three enormous skyscrapers towering above its streets: the White, Black, and Crimson Tower.[[2]](#cite_note-V3P-2)

## Culture and Demographics

The Lawless City is a large marginal city and does not belong to or is affiliated with any kingdom or nations. [[11]](#cite_note-AS2E1-11) It distinguishes itself from typical slums, for its residents are no ordinary vagrants; instead, they are relentless hunters, their eyes gleaming with predatory intent as they stalk their prey within the urban landscape. Throughout the day, the sounds of merchants haggling echo down crammed alleys, with occasional violence to enliven citizens' squalid existence. The citizens have become accustomed to these harsh conditions, growing stronger with each passing day, rendering themselves far from easy targets. To those deemed weak, venturing into this city renders them nothing more than prey in the eyes of its formidable residents.[[3]](#cite_note-V3C1-3)

When night falls on the Lawless City, the most crowded area is invariably the Red-Light District (色街（いろまち）, Iromachi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). Indulging in the transient night pleasures offers escapism to those wanting to forget the outside world. The district itself is a bustling place where numerous scantily clad women saunter up and down the streets, trying to entice patronage.[[3]](#cite_note-V3C1-3) Many of these women are tied to Lawless City's brothels through contracts,[[12]](#cite_note-V4CP-12) and violating them can leave ugly consequences.[ANIME ONLY][[11]](#cite_note-AS2E1-11) Whether they have been enslaved or voluntarily sell their own bodies, the brothels maintain basic security; however, the courtesans are overall responsible for themselves. The ages of these sex workers vary, with some arriving in Lawless City during their adolescence.[[3]](#cite_note-V3C1-3)[[6]](#cite_note-:1-6)

The majority do not think about the outside world, which to them is just an illusion and all they have to do is forget everything by indulging themselves in drowning in the transient pleasures of the night.[[3]](#cite_note-V3C1-3)

Lawless City is home to a diverse array of races, rendering it a multicultural city. The total population is undisclosed, but not all citizens are there consensually. Active and free slaves are part of the ongoing population.[[2]](#cite_note-V3P-2) The absence of formal regulations grants its inhabitants unparalleled freedom to pursue their needs, unencumbered by employment restrictions or segregation. People who only look from the outside fail to comprehend the complexities of Lawless City. One needs authentic contact for an accurate impression. The view can change from a desolate slum to a miscellaneous city with a multicultural fusion.[[3]](#cite_note-V3C1-3)

## Governmental Interference

The Dark Knight Association had set up a base to quell the chaos caused by the Blood Queen's underlings outside the city. The surrounding countries close to the Lawless City had suffered from similar damage.[[2]](#cite_note-V3P-2) The temporary base was made for the assassination, not complete control. In this realm, no entity, be it kings, knights, or even the most formidable of monsters holds the power to intervene or exert control. It exists as an autonomous realm where anarchy prevails unfettered.

Even the Cult of Diablos cannot influence Lawless City—not for want of trying. Those who venture outside the city can pose a significant threat, and the Cult dislikes external factors that could lead to unforeseen events or disasters. However, all previous attempts to exploit the area, the monarchs, and their close aides have failed. The Cult is now forced to concede to Lawless City's ingratiated power. Instead, the Cult of Diablos observes and extrapolates the city's internal struggles and the power players. [[13]](#cite_note-V2C7-13)

## Native Inhabitants

- [Natsu](Natsu.md "Natsu")
- [Kana](Kana.md "Kana")
- White Demon (Deceased)
- [Marie](Marie.md "Marie") (Previously)
- [Crimson](Crimson.md "Crimson") (Deceased)
- [Juggernaut](Juggernaut.md "Juggernaut") (Deceased)

## Trivia

- While in the Light Novel, Web Novel and [Manga](Manga.md "Manga"), The Lawless City has a generally decadent development of the Medieval era, in the [Anime](Anime.md "Anime") and Game, this is still maintained but partially, since it also shows development of the Industrial Age, such as train transportation.
- In the Web Novel, Cid Kagenou have able to sense the peculiar smell of a slum that instantly stimulates his nose hair long when he entered the city as he look down upon the city street, as he claims that only people who’ve experienced it firsthand know, but people who live in environments with dirty air have longer nose hair.[[10]](#cite_note-WN95-10)
- The Japanese Kanji in the word for the Vampire's tower 紅 (either Kurenai or Aka) can mean red, crimson, or scarlet. The official English translation chose Crimson.
- The anime designs of the Lawless City towers have more complex designs than their skyscraper manga and light novel counterparts.
  - The design of the White Tower, is of the Asian style, like a huge [feudal castle](https://en.wikipedia.org/wiki/Himeji_Castle "wp:Himeji Castle") of more than several floors, from Japanese folklore, unlike in the manga where it is depicted as a huge and tall tower which is not so wide.
  - The design of the Black Tower, is similar to a huge [industrial plant](https://en.wikipedia.org/wiki/Physical_plant "wp:Physical plant"), with several buildings that expel the smoke produced in the plant, with a central building which stands out in the middle that is very high, unlike in the manga where it is depicted as a huge and tall tower which is not so wide.
  - The design of the Crimson Tower, is identical to the wide and ancient construction of the [tower of babel](https://en.wikipedia.org/wiki/Tower_of_Babel "wp:Tower of Babel"), from biblical history, which stands out with some murals around the building, whose only visible entrance is through the door guarded by the white demon, unlike in the manga where it is depicted as a huge and tall tower which is not so wide.
    - Another difference in the design of the Crimson Tower is that it is not red in color, as reported in the light novel or Manga, but instead is gray in the anime and game.
- While in the Light Novel, Web Novel and the [Manga](Manga.md "Manga"), the Crimson Tower was destroyed by Shadow's magical attack,[[4]](#cite_note-V3C3-4) in the [Anime](Anime.md "Anime") and Game, it was left intact with no apparent damage.[[8]](#cite_note-:3-8)

## References

1. Episode 22
2. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
3. Volume 3 Chapter 1: Lawless City Bandit Hunting!
4. Volume 3 Chapter 3: Pursuing the Blood Queen!
5. Volume 3 Chapter 6: Circulating Counterfeit Cash!
6. Volume 3 Epilogue: The One to Destroy It All and Start from Scratch—with Fake Bills
7. Master of Garden: Game Map
8. Episode 23
9. Note: The steam engine remained a prototype at the start of the Red Moon arc in the light novel. The Other World's technological advancements depicted in the anime and games reflect a society amidst an industrial revolution rather than a budding one.
10. Chapter 95: From Mob Escape to Mob Revenge
11. Episode 21
12. Volume 4 Prologue: It’s Time for a War in the Oriana Kingdom!
13. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • **Lawless City** • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • Sakurazaka High School • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
