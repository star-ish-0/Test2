# Battler

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Battler](https://the-eminence-in-shadow.fandom.com/wiki/Battler)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Battler?action=edit).

## Battler

### Japanese

バトラー

### Romaji

Batorā

### Aliases

Count Battler

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- Count

### Affiliation

Thirteen Nightblades

## Debut

### Light Novel

Volume 6

### Manga

Chapter 71.2

Battler (バトラー, Batorā[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), also known as Count Battler, was a noble of the Midgar Kingdom and an official member of the Thirteen Nightblades.

## Appearance

## Personality

## Chronology

### Bloody Midgar Serial Murder Terror

## Relationships

## Powers & Abilities

## Trivia

## References

## Site Navigation
