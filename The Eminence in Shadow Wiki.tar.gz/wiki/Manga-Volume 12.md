# Manga/Volume 12

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2012](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume%2012)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Manga/Volume_12?action=edit).

## Manga Volume 12

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Anri Sakano

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4041136850

### ISBN EN

ISBN 979-8855408256

### Release Date

October 26, 2023 JP
April 22, 2025 EN

## Volume Information

### Pages

144 JP
162 EN

### Chapters

4

Publication Order

| Previous | Next |
| --- | --- |
| Volume 11 | Volume 13 |

This is the twelfth volume of the manga series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

After casually defeating the big demon thing that showed up at Rose’s wedding, Cid had tried to make a badass exit via the collapsing portal, but…this is Japan, right? How’d he and Beta wind up back on Earth? And what the heck happened while he was away?! Judging by the ruined city, piles of corpses, wandering monsters, and mana lingering in the air, it must have been a pretty wild party![[1]](#cite_note-1)

覇王の産声が、貴様には聞こえるか？

異世界に転生し、あらゆる物事に陰から介入し実力を示す「陰の実力者」設定をエンジョイしているシド。
オリアナ王国に出現した「黒キ薔薇」によってベータとともに飛ばされた先は、シドが前世で暮らしていた「地球」の日本だった。しかしそこは魔力が充満し、魔獣の被害によって変わり果てた世界になっていて――。

いつも通りの勘違いも、いつも通りに炸裂する異世界異聞奇譚、郷愁の第12巻!![[2]](#cite_note-2)

## Summary

## Chapters

- Episode 46
- Episode 47
- Episode 48
- Episode 49

## Characters

:   In order of appearance:

## References

1. [The Eminence in Shadow, Vol. 12 (manga). YenPress](https://yenpress.com/titles/9798855408256-the-eminence-in-shadow-vol-12-manga/)
2. [The Eminence in Shadow (12). Kadokawa](https://www.kadokawa.co.jp/product/322301000486/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • **Volume 12** • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
