# Lutheran Barnett/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lutheran%20Barnett/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Lutheran%20Barnett/Chronology)

Main

Relationships

Image Gallery

## Background

Lutheran was once a master of both literacy and military arts which had earned him a Bushin Festival championship and propelled him to the top of the sword-fighting world. Even the Cult of Diablos took notice of him and recruited him, to which he agreed to reach further heights. Afterward, he would rise through the Cult's ranks to become the 12th seat of the Knights of Rounds. However, just as he had reached the "peak of the sword-fighting world", Lutheran suddenly contracted a terminal illness that crippled him as a fighter. As a result, he was forced to vacate his 12th Seat position and be demoted to a "Second Child" all the while the Cult tries to find a replacement for the vacant title.[[1]](#cite_note-1)

Yearning for his former position, Lutheran sought for cure to his illness, even trying dangerous and illegal methods. During his search, Lutheran met Lukreia Crowley, a brilliant scientist who specialized in deciphering ancient languages. Seeking to use her, he began working with her under the guise of friendship and funded her research. Lutheran eventually stumbled upon an artifact known as the "Eye of Avarice" that was capable of sucking and accumulating magic from its surroundings, which he was sure could cure his illness. However, Lukreia concluded it to be too dangerous and decided to hand it over to the Midgar Kingdom for safekeeping. Upon learning of her relent on the artifact, Lutheran brutally murdered Lukreia by stabbing her in the back, joints, twisted her heart before fleeing the scene with the Eye.

Afterward, Lutheran attended Lukreia's funeral where he met her daughter, Sherry. Seeing that the girl had inherited her mother's intellect, Lutheran took her in and supported her education with the intent of using her to complete the research on the artifact.[[2]](#cite_note-:0-2) Meanwhile, Lutheran infiltrated the Midgar Academy for Dark Knights, where he made his way up to Assistant-Principal. However, he made the mistake of storing the Eye of Avarice in the Cult's Midgar base, which was ran by Zenon, leading to the artifact being confiscated after the place was discovered following Alexia's kidnapping; setting up Lutheran's introduction into the story when Iris entrusted the artifact to Sherry for research.

## Volume 1

### Midgar Academy Terrorist Attack

Lutheran and Sherry Barnett were visited by Princess Iris Midgar and Alexia Midgar. Iris gave Sherry an artifact belonging to the Cult of Diablos and asks her to decipher the text on it. Lutheran encouraged her to do so stating it's a rare opportunity which she accepted. It was then Iris decided to assign the Crimson Order to keep watch on them. Lutheran heard that was the new Knight Order that Iris formed, and she confirmed that it is a small order. She stated that it was formed by the people she trusts, and he went to question her about her distrust towards the Knight Order to which she gave a silent answer. Lutheran allowed it under the condition that he takes only two guards to secure Sherry in her lab, so Princess Iris chose her most trusted men: [Glen](Glen.md "Glen") and Marco Granger.[[3]](#cite_note-3)

For his ambitions to reinstated as 12th seat of the Rounds knowing he's running out of time from his deteriorating health, Lutheran disguised himself under the identity of "Sir Gaunt" and ordered his Cult's henchmen to commit murders throughout the Midgar royal capital while posing as Shadow Garden. This was done in an effort to have the organization they're posing earn the contempt and enmity of the world. When he heard the lost contact report of his men, he stated that it was fine because he located the item, he needs which was his priority retrieving it.[[4]](#cite_note-4)

Later, he saw Sherry having a chocolate and she explained that a boy gave it to her. He told her that it's hard to obtain such good chocolate which meant that her boy must've really like her, and she must consider well what she will reply. On the next day, Lutheran noticed the boy named Cid Kagenou after Sherry told him that they were going to be friends and he chimed into their conversation. He advised Cid to take care of his injuries before he decided to leave.[[5]](#cite_note-5)

The Cult forces under Lutheran's orders took over Midgar Academy by creating a magic blocking field from the artifact to round up all the students and killed anyone that opposed them in order to frame and discredit Shadow Garden as public enemy number 1. He then ordered [Rex](Rex.md "Rex") to go find the catalyst for the Eye of Avarice, but failed to retrieve it. After hearing this, he threatened Rex with death to go and find the artifact until he heard Rex's reports that some of their men had been taken out by someone skilled and guesses that they manage to get Shadow Garden's attention. Rex and his men immediately went out to search for the artifact but never came back. Unaware that Rex was already killed, Lutheran called him useless when the magic field that surrounded the Academy was disabled and the students started fighting back. amidst the chaos, Shadow Garden arrived and engaged the Cult forces in combat.[[6]](#cite_note-6)

Lutheran then fled the auditorium leaving his minions to their deaths and caused an explosion by lighting fire to the gas pipes he uninstalled within the campus. He then snuck into his room to burn evidence to cover his tracks before leaving. It was then Cid was already at his room and told him that he already knows who he is. This surprised Lutheran as he praised the student for his perception as he took off his disguise. Cid asked why he decided to abide by the academy and him answering that he did everything to reach the top he once was, confessing to Cid by describing in detail on all his misdeeds, as well as the murder of Sherry's mother and the manipulation of Sherry. Cid told him that despite all this, he didn't know how to answer him after hearing everything. He told him that even if it's a little bit, it disgusted him which caused Lutheran to strike him down with his sword in response.

Believing he killed Cid off to cover his tracks, Lutheran decided to leave when Shadow appeared before him. Lutheran knew that he was at disadvantage against him because his experience with strong fighters, to which he discarded his little honor that he had left with the sword and began using the Eye of Avarice to its full potential. This allowed him to acquire an immense magical power and his illness was cured. Lutheran attacked Shadow with all his might but was unable to land a decisive blow. Lutheran acknowledged Shadow's strength and explained to him that he will fail, because he already devised the plan so that the world will despises him and his organization. However, Shadow retorted that none of it matters to him because they will continue on the same path they choose and that they'll shoulder all the world's sins.

Lutheran believed that his unfazed statement was arrogant and was prepared to kill him. However, Shadow disarmed and performed retribution on him while recalling how he murdered Sherry's mother before finishing it by twisting his heart. In his final moments, Lutheran realized that both Cid and Shadow are the same person before being killed by the Leader of Shadow Garden.[[2]](#cite_note-:0-2)

## Legacy

After his death, Lutheran succeeded in framing Shadow Garden for his crimes of terrorizing the academy and all over the kingdom. This resulted in the organization being viewed as the "enemy of the world" with Midgar Kingdom are actively hunting them down. Even worse, Lutheran died a martyr to his stepdaughter, Sherry now holds a grudge against Shadow for killing him, unaware that her supposed "adoptive father" was her mother's murderer.[[2]](#cite_note-:0-2)

## References

1. Volume 1 Chapter 3: My Official Beginning as a Mastermind in Action!
2. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
3. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
4. Episode 6
5. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
6. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
