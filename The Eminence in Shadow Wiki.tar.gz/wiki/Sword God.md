# Sword God

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sword%20God](https://the-eminence-in-shadow.fandom.com/wiki/Sword%20God)

WARNING: POTENTIAL SPOILERS—READ AT YOUR OWN RISK

Nobody likes a blabbermouth, even if they are cute doggos. Shadow Garden encyclopedists have marked this page as containing spoilers for anime-only and manga readers. Reading past here voids any claim to punitive damages from lost enjoyment. Shadow Garden encyclopedists will not be held responsible for reckless behavior.
Reader Discretion is Advised

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Sword_God?action=edit).

## Sword God

### Japanese

剣神

### Romaji

Kenjin

## Characteristics

### Race

Elf

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Affiliation

Council of Elders

## Debut

### Light Novel

Volume 7

Sword God (剣神, Kenjin[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), is one of the council of elders in elven country.

## Appearance

Not much is known about his appearance but he is mentioned to have the appearance of an old man.[[1]](#cite_note-1)

## Personality

## Chronology

## Relationships

## Powers & Abilities

## Trivia

## References

1. Volume 7 Chapter 3

## Site Navigation
