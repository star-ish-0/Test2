# Beatrix/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Beatrix/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Beatrix/Chronology)

[Main](Beatrix.md "Beatrix")

[Relationships](Beatrix-Relationships.md "Beatrix/Relationships")

Image Gallery

## Background

## Volume 2

### Bushin Festival Tournament

Having heard rumors of a female elf that resembled her, Beatrix travelled to the Midgar Kingdom, hoping that this mysterious elf is her long-lost niece.[[1]](#cite_note-V2C7-1) Upon her arrival just as the Bushin Festival tournament was starting, Beatrix headed to the stadium arena where she ran into a young boy who had the [Elf](Elf.md "Elf")'s scent on him. A curious Beatrix then want to confirm the young boy whether he knew the elf to which young boy affirming her question by revealing that he had several elf friends to the point of explaining that she was looking for her late sister's daughter and wondered if he had ever seen an elf who bore a resemblance with her. When the young boy said that her face was covered with a robe, Beatrix opened her robe and showed her face, but the boy said that he didn't see the person she was looking for.

Met with a disappointing answer, Beatrix then tested the boy by swinging her blade at his head until it stopped right before his neck to see his reaction. Contrary to her expectations, the boy fell back to the ground and offered a generic scared reaction. Seeing the young boy's reaction, Beatrix later apologized that she had stating thought he was stronger, but it seemed she had been mistaken in her judgement. Beatrix held out her hand to the young boy while asking his name with the boy revealing his name as Cid Kagenou until Beatrix told him back her name. After getting to know each other, Beatrix compliments Cid as she holds his hand as she feels his inner strength by declaring that he will surely become a strong Dark Knight before deciding to leave.[[2]](#cite_note-2)

The day after tomorrow, Beatrix returned to the stadium arena hoping she would find her niece among the many people who would come to see the fight match and bought a lot of burgers for snack until she is reunited with Cid shortly after leaving the VIP room who was surprised by her presence until Beatrix asked him wonders if Cid ignored her before asking if he met an elf that looks like her after their first meeting, but Cid reiterates by still giving the same answer as before. Beatrix revealed the reason for being here to Cid because she thought that she can find the person she is looking for would appear in this tournament since there are a lot of people coming to the festival. At that moment, Beatrix brought too many burgers and gave one to Cid. To return the favor, Cid gives him one of his burgers. After the exchange, the two of them decided to leave again in parting ways with each other.

Following Annerose Nichtsehen's previous losing match, Beatrix watched the ensuing fight while eating her burger and decided to leave. Then not long after, Beatrix was suddenly called by the First Princess Iris Midgar who had been chasing after her by the time she saw her after during on her winning match to confirm her identity until Beatrix wanted to give one of her burgers to her. However, the princess subtly refused the gift from her and asked Beatrix to be invited on watching tomorrow's semifinal match.[[3]](#cite_note-3)

On the last day before near the end of the Bushin Festival, Beatrix, who agreed to an invitation from Princess Iris to watch the semifinal match, entered the VIP area and saw Cid inside. However, she was stopped by the security guard for violating her entry into the area, plus carrying a sword without permission to make a commotion until finally Princess Iris saw Beatrix and explained that she had invited her by revealing her identity, which made the audience who knew her name in the VIP seats become very surprised to realize who Beatrix really is when she made an unexpected visit until everyone gets excited and gathers around her. Once again, she asked the spectators if they had seen an elf who resembled her, but to no avail. The spectators then asked her if anyone has caught her eye, attempting to validate her title of "War Goddess", and she replied that Cid had caught her interest, making the spectators skeptical of her abilities considering his displayed prowess.

When the two kings of the allied countries had entered the VIP seating room to see the Bushin Festival tournament match, Beatrix smelled a strong odor from King Raphael Geerk Oriana and told the Oriana Kingdom's delegation that the king stink, which made Royal Chancellor Perv Asshat surprised to hear her words so he was angry and ordered the guard to take her. But Iris stops him as the princess explains that she is her guest and introducing her identity as Beatrix the Goddess of War, which Perv then realizes who she is. When Beatrix apologizes to him and Perv does the same also telling her to watch the match, so she could enjoy the festival.

Beatrix witnessed the match between two combatants and saw Iris Midgar being easily defeated by a mysterious duelist named Mundane Mann, which impressing her with his strength and desiring to face him.[[4]](#cite_note-V2C8-4) Shortly after the conclusion match, Beatrix and the audience saw that the wanted Princess Rose Oriana with news of her case spreading across the capital had appeared before the public to confront King Raphael Oriana, only to unexpectedly kill her own father before attempting suicide. But at that moment, Mundane suddenly saves and protects Rose from being caught by Perv's men until he later discards his disguise to revealed himself as Shadow, so Beatrix stepped in to face Shadow and the two engaged in an intense battle.[[5]](#cite_note-5)

#### Novel/Manga Outcome

The fight was strong and fast inside the stadium, Beatrix managed to keep up side by side, at the level of speed and super-fast attacks, while cutting raindrops. But when Shadow decided to take out his "true sword", Beatrix was left terribly scared, seeing that she could no longer not only see his attacks, but also could not feel or predict them, as if they were a natural phenomenon, which it was very scary for her, since she didn't know if he could block his next attack. Seeing her disadvantage because Shadow's technique was on a whole other level, Iris Midgar decided to support Beatrix, to see if the two of them could defeat Shadow together, but in the end, it was no use, since Shadow managed to predict their strategy, and easily defeated them, forcefully throwing Beatrix over the other side of the stadium wall with his magical force.

Beatrix interrogated Shadow that, if he has so much power, why he doesn't he finish them off. Beatrix was perplexed as he replied that he was not interested in taking their lives, that he only destroys his enemies. Before he disappeared, Shadow reminded her and Iris that they should not lose sight of the "true enemy", before he escaped in a flash of energy, leaving behind everyone surprised in the coliseum.

#### Anime/Game Outcome

During her initial fight against Shadow, seeing that he had overwhelming speed, capable of moving to such a degree that she was not able to perceive him, and that she could barely react to joust, (although this was only because Shadow allowed it), Iris Midgar proposed to help Beatrix to defeat Shadow, using a Sword of the Three Heroes, and their fight spread to the corners of the capital of the kingdom of Midgar. In their fight Beatrix asks Shadow if they had met before, to which he replies that who knows, since he never forgets powerful opponents, to which he asks her and Iris, if they were deserving to be remembered by him.

Their battle continues until they reach a tall clocktower, where seeing that they were not achieving anything against Shadow, Iris proposes to immobilize him even if it costs her life, so that Beatrix can then attack him, but Shadow found out about her move and easily subdued them against their ground by giving them a crushing gravity kick (contained), which made them suffer a lot, leaving both Beatrix and Iris with little strength to fight. When Shadow was about to leave, Iris reproached him that now the entire kingdom of Midgar, and the entire world have him as an enemy and that he will have nowhere to escape, to which Shadow laughs and responds strongly, questioning the need for him to run away. He then deploys his most powerful technique throughout the capital of Midgar.

Beatrix and Iris Midgar were laying on the ground helplessly, to which their only option was to witness what Shadow was going to do. When tension was at its highest, everything was revealed to be but a trick by Shadow, who disappears without further ado, clearing the rain and lightning and leaving the kingdom of Midgar the light in his stead.

The next day Beatrix decide to part ways and says goodbye to Iris, but not without first advising her to try to refrain from obsessing over this loss, since there are many entities that mortals cannot yet rival, and that she is still very young, to which Iris replies, telling Beatrix not to worry, and that she can't stay still for too long. While she was leaving on the train, Beatrix felt a little sad when she couldn't find any clues about her niece, but at the same time, she felt happy for having met people who came to her like Cid Kagenou.[[6]](#cite_note-6)

## Volume 7

## References

1. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
2. Episode 16
3. Episode 18
4. Volume 2 Chapter 8: Lay Your Eyes on My True Powers!
5. Episode 19
6. Episode 20
