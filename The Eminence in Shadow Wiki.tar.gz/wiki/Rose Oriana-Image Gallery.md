# Rose Oriana/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Rose%20Oriana/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Rose%20Oriana/Image%20Gallery)

Main

Chronology

Relationships

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

In volume 1

Volume 1

Volume 1

Volume 2

Volume 4

Victoria debut

Volume 5

Profile

Time to Reveal

Marriage

In volume 5

Hidden Yearning: Rose Oriana

Rose's Retaliation: Rose Oriana

Driven to Excellence: Rose Oriana

Echoing Radiance: Rose Oriana

In-game model; Echoing Radiance: Rose Oriana

Moonlit Path: Rose Oriana

Game Event: Interlude

Victoria, Rose Oriana and Epsilon - game - Event: "Special mission! In search of the best osechi"

Beauty in Bloom: Rose Oriana

Illuminating Bladre: Rose Oriana
