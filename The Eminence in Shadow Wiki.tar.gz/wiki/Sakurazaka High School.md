# Sakurazaka High School

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Sakurazaka%20High%20School](https://the-eminence-in-shadow.fandom.com/wiki/Sakurazaka%20High%20School)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Sakurazaka_High_School?action=edit).

## Sakurazaka Senior High

### Japanese

桜坂（さくらざか） 高等（こうとう） 学校（がっこう）

### Romaji

Sakurazaka Kōtō Gakkō

## Location Information

### Leader

None

### Status

Unknown

### Affiliates

Unknown

### Type

High School

### Government

Unknown

### Location

Japan

### Inhabitants

Humans

## Debut

### Web Novel

Chapter 145

### Light Novel

Volume 4

### Manga

Chapter 47

### Anime

Episode 1

### Game

Chapter 31, Episode 7

Sakurazaka High School (桜坂（さくらざか） 高等（こうとう） 学校（がっこう）, Sakurazaka Kōtō Gakkō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a school that Minoru Kageno attended in his past life along with Akane Nishino and Yuudai Saejima.

## Overview

## Uniform

### Male

The uniform for male students consists of a standard white school coat, light blue shirt, blue pants, blue tie, and white shoes.

### Female

The uniform for female students consists of a standard white school coat, light blue shirt, blue skirt, blue tie, and white shoes.

## Background

## Chronology

### Prior to the fall of Japan

### After the fall of Japan

After the fall of Japan, Sakurazaka High School was left in ruins.[[1]](#cite_note-1)

## Known Characters

### Staff

- Unnamed Teacher

### Students

- Minoru Kageno
- Akane Nishino (Formerly)
- Yudai Saejima (Formerly)

### Former Students

- Minoru Kageno (Deceased)
- Akane Nishino
- Yudai Saejima

## Trivia

- Sakurazaka High is based on a real-life high school in Ishinomaki, Miyagi that is located in Japan.

## References

1. Episode 32

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Location?action=edit)  Location | | | |
| --- | --- | --- | --- |
| [Alexandria](Alexandria.md "Alexandria") • Altena Empire • [Arcadia](Arcadia.md "Arcadia") • [Atlantis](Atlantis.md "Atlantis") • [Earth](Earth.md "Earth") • [Laugus](Laugus.md "Laugus") • [Lindwurm](Lindwurm.md "Lindwurm") • Lawless City • [Messiah](Messiah.md "Messiah") • Midgar Kingdom • Midgar Academy for Dark Knights • Midgar Academy of Science • Nishino University • Oriana Kingdom • Other World • **Sakurazaka High School** • [Sanctuary](Sanctuary.md "Sanctuary") • [Spartan](Spartan.md "Spartan") • The City-State Alliance • Velgalta Empire • [Wakoku](Wakoku.md "Wakoku") | |
