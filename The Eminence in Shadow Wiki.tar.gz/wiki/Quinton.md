# Quinton

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Quinton](https://the-eminence-in-shadow.fandom.com/wiki/Quinton)

[Chronology](Quinton-Chronology.md "Quinton/Chronology")

[Relationships](Quinton-Relationships.md "Quinton/Relationships")

Image Gallery

## Quinton

### Japanese

クイントン

### Romaji

Kuinton

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Bald

### Eye Color

Brown

### Birthday

November 29

## Personal Information

### Status

Alive

## Professional Information

### Occupation

- Swordsman
- Slave (Former)
- Vow of Black Rose Captain (WN)

### Affiliation

Vow of Black Rose (WN)

## Debut

### Web Novel

Chapter 64

### Light Novel

Volume 2

### Manga

Chapter 20

### Anime

Episode 15

## Portrayal

### Japanese

[Kenta Miyake](https://en.wikipedia.org/wiki/Kenta_Miyake "wp:Kenta Miyake")

### English

Andrew Love

### French

Guillaume Desmarchelier

### Italian

Stefano Albertini

Quinton (クイントン, Kuinton[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a swordsman who participated multiple Bushin Festival tournaments.

## Appearance

At first glance, Quinton looks like a rude pro wrestler as he wears a large great sword on his back and multiple battle scars etched across his face with an eyepatch on his right eye assumable being half blind. This makes him seem more like a grizzled warrior with the atmosphere of a ‘veteran of battlefields’ aura.

## Personality

Quinton is a blunt and brutish man who resorts to violence if he were to be wronged in the slightest. Quinton himself also dislikes weak people participating in tournaments when he demonstrated by harassed Mundane upon hearing him ignore Annerose's warning about competing and assaulting him when the unassuming man talked back at the veteran.[[1]](#cite_note-V2C4-1)

## Powers & Abilities

Quinton is a relatively strong swordsman complimented by his frequent tournament participations and held high estimations on any matches. Even if his opponent has a weak artifact, Quinton states that they cannot win against him.

### Hand-to-Hand Combat

Quinton relies on brute strength without any techniques in his blows.

### Swordsmanship

### Magic

Using magic, he can increase his general vision allowing his to see things much faster than a normal human.

### Equipment

Quinton wields a huge single-edged sword like a buster sword that hung on his waist.

## Trivia

- Quinton's name apparently comes from the coming from Old English, it means "king". Variants: Quinntan, Quonnten, Quintain, Quintyn. as far as is known.
- Despite being a regular participant of the Bushin festival, it is unknown whether at one point he has fought Iris Midgar.[[1]](#cite_note-V2C4-1)
- Like [Lambda](Lambda.md "Lambda") (apparently) and [Chi](Chi.md "Chi"), Quinton has an injured right eye, although this is just a coincidence.

## References

1. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"

## Site Navigation
