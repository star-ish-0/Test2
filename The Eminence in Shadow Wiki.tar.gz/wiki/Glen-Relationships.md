# Glen/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Glen/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Glen/Relationships)

[Main](Glen.md "Glen")

[Chronology](Glen-Chronology.md "Glen/Chronology")

Image Gallery

## Crimson Order

### Iris Midgar

His superior, Iris upon forming her own organization handpicked Glen as her Vice-Commander when she first thought of a Knight she knew and trusted.[[1]](#cite_note-:0-1) His death during the terrorist attack on the Academy was not only personal, but also a prominent loss as Glen's popularity amid the knightly ranks had future candidates doubt Iris' leadership.

Additionally his death affected Iris and her organization when the Cult of Diablos used it as an opportunity to infiltrate and manipulate both the princess and her kingdom behind the scenes.

### Alexia Midgar

Iris' sister and unofficial member of the Crimson Order. Her safety was one of his biggest priorities when Iris recruited him and Marco.

In the Manga, he was one of few to know of his superior's embarrassing secrets of wearing a bunny print underwear and hugging a teddy bear while asleep when Alexia blackmailed her into the ranks of her Order.

### Marco Granger

A student and friend from their times as Dark Knights and protégé. Glen alongside Marco were personally selected as members of Iris' Order after Shadow Garden and the Cult's existence were revealed.[[1]](#cite_note-:0-1) Marco was the most affected by his death when he was too conflicted take a stance regarding [Adder](Adder.md "Adder") when he manipulated Iris into becoming a puppet for the Cult and apologized to Alexia about it.

## Midgar Academy for Dark Knights

### Sherry Barnett

Researcher and daughter of the Assistant Principal, Sherry's safety was Glen's biggest priority when she was tasked in deciphering a device found from Zenon's hideout. When the Academy was terrorized, Glen was able to fend off [Rex](Rex.md "Rex") long enough for the researcher to escape before being killed.[[2]](#cite_note-:1-2)

## Enemies

### Cult of Diablos

#### Zenon Griffey

Former fellow Knight and would be Round Knight for the Cult. When Iris recruited both Glen and Marco, she conveyed the disgraced Knight's involvement with the Cult and her sister's disappearance.[[1]](#cite_note-:0-1) An artifact found from his hideout was used as an instrumental part in stopping the terrorist attack on the Academy.[[3]](#cite_note-:2-3)

#### [Rex](Rex.md "Rex")

His opponent during the Academy attack. Glen was able fend off the Named Child despite the disparity in abilities and the artifact that disabled his magic stating that his skills are enough to match against his magic.. However, Rex easily overwhelmed the Knight before killing him off screen.[[2]](#cite_note-:1-2)

#### Lutheran Barnett

Assistant Principal and foster father of Sherry, Glen alongside the Crimson Order was unaware of his double life as a prominent member and former Round Knight of the Cult.[[3]](#cite_note-:2-3)

## References

1. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!
2. Volume 1 Chapter 6: The Scene Where Terrorists Take Over the School
3. Volume 1 Final Chapter: My Idea of the Ultimate Shadow Commander!
