# Gray

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Gray](https://the-eminence-in-shadow.fandom.com/wiki/Gray)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Gray?action=edit).

## Gray

### Japanese

グレイ

### Romaji

Gurei

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Affiliation

Cult of Diablos

## Debut

### Light Novel

Volume 6

### Manga

Chapter 67

Gray (グレイ, Gurei[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the head of the Knight Order's Investigation Division. It is later revealed that he is a covert agent of the Cult of Diablos, serving under [Loki](Loki.md "Loki").

## Appearance

## Personality

## Synopsis

## Powers & Abilities

## Relationships

### [Loki](Loki.md "Loki")

### Christina Hope

Gray holds suspicions about Christina being the one behind the deaths of the Thirteen Nightblades, due to the animosity she had against them. Although, he seems to have drop it entirely after all the Nightblades had been killed.

### Alexia Midgar

### [Kanade](Kanade.md "Kanade")

### Cid Kagenou / Shadow (Jack the Ripper)

## Trivia

## References

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Cult_of_Diablos?action=edit)  Cult of Diablos | | |
| --- | --- | --- |
| Knights of Round | [Loki](Loki.md "Loki") • [Hel](Hel.md "Hel") • [Jormungandr](Jormungandr.md "Jormungandr") • [Fenrir](Fenrir.md "Fenrir") • [Mordred](Mordred.md "Mordred") • [Petos](Petos.md "Petos") • Jack Nelson • [Shiva](Shiva.md "Shiva") • Sergey Gorman • Stan Bach • Lord Laugus • Sir Gaunt | |
| Children of Diablos | [Rex](Rex.md "Rex") • [Kouadoi](Kouadoi.md "Kouadoi") • [Jean](Jean.md "Jean") • Dark Spider • [Maximilian](Maximilian.md "Maximilian") | |
| Other Members | [Willow](Willow.md "Willow") • **Gray** • [Adder](Adder.md "Adder") • Zenon Griffey • [Gettan](Gettan.md "Gettan") • Perv Asshat | |
| Associates | [Venom](Venom.md "Venom") • Garter Kikuchi • Reina Oriana • [Isaac](Isaac.md "Isaac") | |
