# Kagejitsu - Episode 5

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%205](https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%205)

## Operation 5

## Special Title

### English

The Seven Shades want to create an Artifact!

### Kana

七陰はアーティファクトを作りたい！

### Romaji

Shichi kage wa ātifakuto o tsukuritai!

## Episode Information

### Season

1

### Episode

5

### Air Date

November 23, 2022

### Adapted From

Light Novel

## Staff

### Director

Minoru Ashina

### Writer

Daisuke Aizawa

Episode Navigation

| Previous | Next |
| --- | --- |
| Operation 4 | Operation 6 |

Operation 5 is the fifth episode of the spin-off series [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu").

## Summary

A strange mechanical eye in [Alpha](Alpha.md "Alpha")'s hands holds her and [Eta](Eta.md "Eta")'s attention. That concentration is soon interrupted by [Delta](Delta.md "Delta") slamming the door open. Delta, noticing the shining item, asks about it. Alpha explains that it is an [artifact](Artifacts.md "Artifacts") created by Eta. The answer only brings further questions to Delta's mouth. Her response quickly twists Alpha's face into exasperation, provoking an apology from the ignorant party. No matter how often it has been explained to her, Delta's memory retention has not changed. Alpha decides to explain it to her again, leaving it to Eta. The dropping ears happily perk back up to focus on Eta for the explanation. Eta begins to verbosely expound about artifacts, overwhelming Delta's brain. Trying to stop the inflow of words, Delta proudly announces that she understands, but her plan backfires when Alpha quizzes her on the recent lecture. Delta's dazed mind stutters until Alpha lets the topic go. She thanks Alpha for her kindness and asks about the artifact's purpose. The artifact is to counter the effects of magic obstruction. In the event of magic suppression, one can be adequately equipped to deal with the situation. Delta profoundly announces that she does not require such equipment. Assuming that magic is inaccessible, she would just overwhelm them with physical strength. The motion of her demonstration caused a shockwave, shattering the artifact. A horrified Delta apologizes profusely to an angry alpha and a giant hammer-wielding Eta.

## Characters

- [Alpha](Alpha.md "Alpha")
- [Delta](Delta.md "Delta")
- [Eta](Eta.md "Eta")

## Gallery

## Trivia

## References

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • **Episode 5** • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
