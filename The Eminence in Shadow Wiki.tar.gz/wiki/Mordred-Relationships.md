# Mordred/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mordred/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Mordred/Relationships)

[Main](Mordred.md "Mordred")

[Chronology](Mordred-Chronology.md "Mordred/Chronology")

Image Gallery

## Cult of Diablos

### Perv Asshat

One of his subordinates. Mordred trusted Perv with the responsibility of becoming the cult's puppet ruler within the Oriana Kingdom through an arranged marriage to Rose Oriana, which would have promoted the latter to the 12th seat of the Knights of Rounds. However, after Perv's incompetence led to the cult's entire conspiracy within Oriana being exposed, Mordred saw him as a loose end and killed him to begin covering up the truth.

### Reina Oriana

The former queen of the Oriana Kingdom and a collaborator of the Cult of Diablos. Despite the woman willingly betraying her country and family for Perv's cause, Mordred seems to have viewed Reina as nothing but a useful pawn and killed her once the cult's conspiracy within the kingdom had been exposed to cover up the truth.

### [Gettan](Gettan.md "Gettan")

In the Web Novel, Mordred met Gettan when the cult was trying to capture the Spirit Foxes and the Great Wolves tribe for the experiment and forced him to join.[[1]](#cite_note-WN138-1)

## Shadow Garden

### Shadow

Like so many of his cult members before him, Mordred underestimated Shadow, thinking Ragnarok would easily defeat the leader of the Shadow Garden. Shadow insulted Mordred by calling him a mook. He was then horrified that Shadow was not only able to defeat Ragnarok but also kill it. Mordred's hatred for Shadow looking down on him only grew when Shadow continued to mock him even when Mordred absorbed Ragnarok's power into him. Mordred could only watch in horror as Shadow killed him with his "I Am Atomic!" attack.

### [Beta](Beta.md "Beta")

Beta alongside with Epsilon fought Mordred who did not think highly of them during the climax of the crashed wedding until the two managed to wound him. When Shadow and Beta went to Earth under the aliases "Minoru" and "Natsume", Akira Nishino attempted to experiment on Natsume using Mordred's severed head before Yuuka mortally wounded him.

### [Epsilon](Epsilon.md "Epsilon")

Mordred did not think Epsilon would pose a threat and arrogantly fought her and Beta. He became frustrated with fighting them till Epsilon fired a magic attack that wounded him much to his surprise.

### Rose Oriana

## References

1. Chapter 138: The Man Who Is Burning With Revenge
