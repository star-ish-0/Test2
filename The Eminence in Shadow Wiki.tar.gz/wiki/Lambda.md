# Lambda

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Lambda](https://the-eminence-in-shadow.fandom.com/wiki/Lambda)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

[Chronology](Lambda-Chronology.md "Lambda/Chronology")

[Relationships](Lambda-Relationships.md "Lambda/Relationships")

Image Gallery

## Lambda

- Light Novel
- Manga
- Anime
- Game

### Japanese

ラムダ

### Romaji

Ramuda

### Aliases

No. 11
Zinaida

## Characteristics

### Race

Dark Elf

### Gender

Female

### Age

23

### Height

Unknown

### Hair Color

Gray

### Eye Color

Gold

### Birthday

June 26

## Personal Information

### Status

Alive

## Professional Information

### Occupation

- Numbers
- Shadow Garden's Military Advisor and Training Instructor
- Velgalta Imperial Army (Formerly)

### Affiliation

Shadow Garden
Velgalta Empire (Formerly)

## Debut

### Web Novel

Chapter 88

### Light Novel

Volume 2

### Manga

Chronicles of the 7 Shadows: Chapter 3-2

### Anime

Episode 20

## Portrayal

### Japanese

[Ikumi Hasegawa](https://en.wikipedia.org/wiki/Ikumi_Hasegawa "wp:Ikumi Hasegawa")

### English

Liz Arends

### French

Chantal Baroin

### Italian

[Marisa Della Pasqua](https://en.wikipedia.org/wiki/it:Marisa_Della_Pasqua "wp:it:Marisa Della Pasqua")

Lambda (ラムダ, Ramuda[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) (Λάμβδα), formerly known as Zinaida (ジナイーダ, Jinaīda[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a member of Shadow Garden, being one of the Numbers and serves as the organization's drill instructor in charge of training recruits.[[1]](#cite_note-V2FC-1) Before joining the organization, she was part of the Velgalta Empire military until she contracted [Possession](Possession.md "Possession") and was subsequently rescued by the "Seven Shadows".[CITATION NEEDED]

## Appearance

Lambda is a Dark Elf with platinum hair, sharp golden eyes, beautifully plump lips, with a tall stature and refined muscles from years of military training.

She wears a Slime Bodysuit molded into a military dress uniform with a V collar descended to her bust line attached to gold colored shoulder straps, with a gold trimmed choker on her throat. Her sleeves given a baggy design from the shoulders to the wrists, a single belt around the waist with an extra loop crossing around the ribs, and a dress with no ornamentation from her waist to her calves with a split in the dress, just above one leg, with partial splits at each quadrant of the dress. Her trousers are a simple black design with gold trims, leading to collared high heel boots with gold edges.

Her look is accompanied by an officer's cap and jacket draped on her shoulders, the style of which she is accustomed to having served in the Velgalta Empire's military. Often times, she'll have her left eye open and routinely analyzes whoever crosses her vision, such as Rose Oriana when she joined Shadow Garden.

## Personality

Formerly being a military officer in the Velgalta Empire, Lambda is a strict instructor and harsh towards trainees, given her background and to ensure they're up to whatever tasks soon follow. Such as Rose Oriana, [665](665.md "665"), and [664](664.md "664"). She doesn't even hesitate to reproach and rebuke, if her orders are not obeyed by new members and she also strictly destroys or tears any objects or valuables from new members.

Whenever someone joins Shadow Garden's ranks, Lambda will not inquire into their past, as all numbers are just that, with who they were originally being knowledge privy to the executive officers, like [Alpha](Alpha.md "Alpha"), [Beta](Beta.md "Beta"), [Gamma](Gamma.md "Gamma"), and [Epsilon](Epsilon.md "Epsilon"), since that was the order given in part to avoid continuing to suffer from their hard past that they had, because of the Cult. Although some members, especially the newly new ones, it is not easy for them to discard everything. As a member of the Shadow Garden, she is very obedient towards her superiors.

Even though Lambda is feared by the other members because of her harsh teaching style, she is kind enough to acknowledge when any members perform well. Lambda may have unconsciously allowed her personal feelings to influence her into forcing her actions as she sees fit her desire, in order to prevent her subordinates from suffering the similar fate like her in the past.

## Powers & Abilities

Before joining Shadow Garden, Lambda was already an experienced soldier, having been part of the Velgalta Empire military, allowing her to quickly rise through the rank to become a Number. With her military experience and the teachings from the Seven Shadows, Lambda is perfectly suited to be the organization's drill instructor, overseeing the training rookie members so that their strength surpasses any military in the world.

### Swordsmanship

### Magic

### Intelligence

Lambda is familiar with the climate and situation of each country from her knowledge when she was working as an intelligence agent and sometimes consults with [Alpha](Alpha.md "Alpha") as a military advisor.

Lambda also created a structured plan that proposed forming a team of 3 Numbers members to strengthen their collaboration.

### Expert Combat Instructor

Like the other Numbers in Shadow Garden, Lambda is a master fighter by incorporating her military experience with her training under the Seven Shadows.

As such, Lambda trained each member of the Numbers to ensure they had the skills in the training they underwent to survive their missions of investigating the Cult by being able to alleviate and overcome their fears even a little through harsh training, which could give them the measure of strength to survive on the battlefield.

With Lambda's intensive training method in practicing magic and swordsmanship, the strength of each Numbers member was approximately as strong at the first-rate dark knight standard, exceeding that of the Knight Order and being able to take on the Cult of Diablos's army.

### Weapons and Equipment

In the game, she uses a whip.

## Trivia

- Lambda is the first Number in Shadow Garden to be a Dark Elf.
- Lambda's first animated debut was in the Master of Garden, before she debuted in the anime by the season finale, Episode 20.
- Lambda has an unspecified injury to her right eye.[SPECIFIC CHAPTER NEEDED][[2]](#cite_note-2)
- Despite Lambda's militant attitude and being someone well feared by the lower ranks, as well as several members who share her demeanor, like [559](Victoria.md "Victoria") and [Eta](Eta.md "Eta"), Lambda has a bit of a nurturing side that she doesn't show to anyone in general. The exception is Shadow, since her feelings are awakened for him.[CITATION NEEDED]
  - In the Game, Lambda is seen, a little nervous and affectionate when she is with Shadow, although she tries to maintain the same attitude that she always maintains as a Shadow Garden instructor.[CITATION NEEDED]
- In the Game, Lambda is the first-person Epsilon has cured herself.
- In Episode 22, Lambda has her right eye open in the materializing animation for the ending credits. While open, her right eye has a magic seal-like pattern.

## References

1. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
2. Master of Garden

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Shadow_Garden?action=edit)  Shadow Garden | | |
| --- | --- | --- |
| Leader | Shadow | |
| Seven Shadows | [Alpha](Alpha.md "Alpha") • [Beta](Beta.md "Beta") • [Gamma](Gamma.md "Gamma") • [Delta](Delta.md "Delta") • [Epsilon](Epsilon.md "Epsilon") • [Zeta](Zeta.md "Zeta") • [Eta](Eta.md "Eta") | |
| Numbers | [Iota](Iota.md "Iota") • **Lambda** • [Mu](Mu.md "Mu") • [Nu](Nu.md "Nu") • [Pi](Pi.md "Pi") • [Sigma](Sigma.md "Sigma") • [Chi](Chi.md "Chi") • [Omega](Omega.md "Omega") | |
| Members | [No. 89](89.md "89") • [No. 559](Victoria.md "Victoria") • No. 664 • [No. 665](665.md "665") • No. 666 • [No.711](Millia.md "Millia") • No. 712 | |
