# Goddess' Trial

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Goddess%27%20Trial](https://the-eminence-in-shadow.fandom.com/wiki/Goddess%27%20Trial)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Goddess%27_Trial?action=edit).

Goddess' Trial (女神（めがみ）の試練（しれん）, Megami no Shiren[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a fighting ritual event originating from the Holy City of [Lindwurm](Lindwurm.md "Lindwurm"), where warriors from all over come to test their might against the spirits of ancient warriors and battle ceremony held to celebrate the annual opening of the door to the [Sanctuary](Sanctuary.md "Sanctuary").

## Background

The Goddess' Trial is an essentially trial by combat event that is held every once a year on the day when the door to the [Sanctuary](Sanctuary.md "Sanctuary") opens where the challengers must come to fight a memory of the ancient warriors that are awoken from within by answering their call as a worthy opponent.

Any challenger who applies in advance can participate, but there’s no guarantee an ancient warrior will answer their call as they are slightly stronger than the challenger for to prove their worth. When a warrior's strength exceeds a certain level, a warrior spirit matching that level is summoned and fights against that warrior spirit.

If the ability is low, it will not be summoned in the first place and will be left as it is. But if a warrior spirit is summoned, it will be blocked by a barrier and become a one-on-one battle and cannot come out until the battle is over. If anyone defeat the warrior spirit, they appropriately will be awarded a commemorative medal, which can be effectively used as proof of their ability when joining a Knight Order in any nations.

In the past, there have been cases of being killed by warrior spirits.

## Participants

- [Venom](Venom.md "Venom")
- Annerose Nichtsehen
- Shadow (Unofficially)
- Toppe Batterius (Anime only)
- Neks Tinline (Anime only)
- Stihl-Aint Hapnin (Anime only)

## Trivia

- According to Alexia Midgar, several hundred contestants enter each year, but only about ten or so actually end up getting to fight.
- The entrance fee for application is one hundred thousand Zeni.
