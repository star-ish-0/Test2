# Episode 2

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%202](https://the-eminence-in-shadow.fandom.com/wiki/Episode%202)

## Shadow Garden is Born

### Kana

結成シャドウガーデン

### Romaji

Kessei Shadō Gāden

## Special Title

### English

The Eminence in Shadow Wants a Subordinate!

### Kana

陰の実力者は配下が欲しい！

### Romaji

Kage no Jitsuryokusha wa Haika ga Hoshī!

## Episode Information

### Season

1

### Episode

2

### Air Date

October 12, 2022 JP
January 2, 2023 EN

### Adapted From

Volume 1 (MN)
Volume 1 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Alpha ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| The Hated Classmate | Fencer Ordinaire |

Shadow Garden is Born (結成シャドウガーデン, Kessei Shadō Gāden[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the second episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Reborn as the son of Baron Kagenou, Cid bides his time as Background Character A while preparing for the day he can finally become the Eminence in Shadow![[1]](#cite_note-1)

魔力の存在する異世界に転生した影野は、田舎貴族カゲノー男爵家の冴えない第2子として暮らす傍ら、夜な夜な盗賊を狩り、“悪魔憑き”のエルフを救い出すなど、着々と陰の実力者への道を歩み始める。[[2]](#cite_note-2)

## Summary

At sunset in the Kagenou baronate lands, [Alpha](Alpha.md "Alpha") reports to Cid Kagenou, telling him that everything he said was true and that she found mentions in ancient texts of what they believe is Cult of Diablos. Cid acknowledges her report, and when she voices trepidation at carrying out her mission to eliminate the Cult, Cid recites how they lurk in the shadows to hunt the shadows. Alpha is once more reassured and walks over to Cid, contemplating his dream to be the Eminence in Shadow, but also thinking how Alpha was kind of a pushover.

After dying in a car incident, Minoru Kageno was reborn as the son of Baron Kagenou, an aristocrat living out in the boonies ruling a nearly remote stretch of territory. He quickly understood the situation of his reincarnation and soon felt there was magic in the air. The Kagenou family has been producing Dark Knights for generations, soldiers who can enhance their abilities using magic, and the family place their big hopes for the talented Claire Kagenou, Cid's older sister. Similar to his previous life, Cid grows up staying as a background character and doesn't draw any attention to himself. However, he ventures out at night and fight bandits to take their ill-gotten gains. Using his Slime Bodysuit, he easily kills the bandits and takes their gold and treasures, among which he finds a cage with some rotting creature. Cid realizes it's a possessed body, and sensing that it suffers from magical overloaded, he takes interest in it. Cid takes it to an empty home in an abandoned village, where he shoots it with magic and performs other experiments on it.

After a month, he finally manages to contain the magical overload and the creature then returns to its normal form, a beautiful young elf girl. Wondering his next move, Cid decides to put on an act and props himself atop a box as the elf awakens. As she is astonished to find herself healed of her possession, Cid states he broke the curse once imposed upon her, one of the heroes' descendants. To add to his story, he shows her a book about the Three Heroes who defeated Diablos and tells her its actually a true story, surprising the girl. Cid continues how after the heroes slew the monster, it cursed their bloodlines with its dying breath, but someone altered history to make the descendants into objects of scorn labeled "possessed."

Cid initially refuses to conclude his story being unable to improvise an ending, but the elf girl pleads for the name of her enemy, so Cid concludes how the "Cult of Diablos" are responsible as they are plotting to revive the demon, enraging the girl. Cid states that he works in the shadows to stop the cult, and introduces himself as "Stylish--" before correcting himself and naming himself "Shadow," he who lurks in the shadows and hunts shadows. Cid asks her if she would join him and, having lost everything, she agrees to join him and pledges to punish the guilty with death. When she takes Shadow's hand, he bestows a slime cloak to clothe her.

Cid elaborates how there may be government leaders and their ignorant subordinates, but she remains dedicate much to his glee. She further explains how they need to find more heroes descendants, collect funds and strengthen their headquarters to expand their organization, with Cid agreeing; though whispering how they'd need to do so in moderation. With their pact secure, Cid names their organization Shadow Garden and renames the girl as Alpha.

Three years pass and Cid is now 13 years old, and practices with his sister. While he can easily defeat her, still knowing the optimized sword skills of his past life, he acts weak and lets her defeat him. Claire scolds her brother before leaving to ready for her farewell party, leaving a maid to tend to Cid. As Claire is now 15 years old, the children nobles at that age start attending the Midgar Academy for Dark Knights. On the day of Claire's scheduled departure, she was abducted and her room ransacked. Cid calls on [Beta](Beta.md "Beta") for answers, and she reports that Alpha is looking for clues to finding Claire. During the last three years, Alpha had recruited more members for their organization.

Beta explains that Claire is likely still alive and was kidnapped by a high ranking member belonging to the Cult of Diablos, who probably believe Claire to be one of the heroes' descendants. Although Cid acknowledges, he thinks to himself how when the girls get involved, they think bandits are Cult members. Beta takes out a map and states they have few known hideouts, but she doesn't know which one they're keeping Claire. So Cid makes a slime knife and throws it at the map, but he ends up missing the spot he wanted, but still states that they will find his sister there. While Beta initially doesn't find anything on the map, she then figures out that the cryptograms are a bluff and there is actually a secret hideout at the location pointed by Cid. He then tells her to contact the Seven Shadows, and ponders how her acting in their roleplay deserves an award.

At the hideout, Viscount [Grease](Grease.md "Grease") is holding Claire chained with magic-sealing chains. He is impressed by her ability to still dodge at close range and comments her father taught her well. But Claire explains that she learned by fighting her brother, to which Grease then asks if he healed her when she showed signs of possession, per some rumors he heard. An incensed Claire denies it, stating there is no way he can heal her. Grease notes that they may need to look into her brother too as a precaution. Triggering Claire's protectiveness and she breaks one of the chains before injuring her other arm to free herself, intending to kill him should they touch her brother. Grease then knocks her out with a punch to her face, wanting to ready her for testing before a subordinate races in alerting Grease that there are intruders.

Grease's men are easily cut to pieces by the Seven Shadows, despite their abilities being comparable to the Royal Guard. Facing them, Alpha states they are Shadow Garden and their mission is to annihilate the Cult of Diablos, causing an angered Grease to demand to know how they knew that name and secret. He attacks Alpha, but she has no trouble blocking his attacks and injures him, stating she won't kill him until they get answers from him. Seeing he is overwhelmed, Grease takes a pill that boost his magic and he manages to push away Alpha before breaking the floor to escape through a secret tunnel. Alpha tells the girls there is no need to chase him as Shadow is after him, which is why they split up.

Meanwhile, Shadow is lost and doesn't know where the girls went while walking around the tunnels before he encounters Grease. He attacks Shadow, who easily blocks his attack, then notes that while Grease has more magic power than Alpha, he doesn't know how to use it. Shadow decides to give Grease some lessons and blocks his attacks. As Shadow attacks Grease, the Viscount wondered if he ever was that overwhelmed in battle before, recalling his master's tutelage as a boy. Grease tells him no matter how strong he is, the darkness in the world is much deeper, thinking of his daughter and her fate. However, Shadow states he will just dive deeper. Grease takes more pills and augments himself even more, wanting to show Shadow that people are worthless, fragile, and powerless. Only Shadow manages to block his attacks and then channels a large amount of magic, finishing the fight as he cuts down Grease. As he falls, Grease notes he was powerless against the darkness, but maybe Shadow won't be.

Taking his locket, Cid walks away impressed how Grease was tough for a bandit. The next day, Claire returns home under her own power in a bad mood but her wounds healed overnight, and she departed for the academy the following day. Cid is eager to go to the academy himself, but if fine as he has two more years and needs to give the girls some work. However, Alpha tells him its time they leave him, which leaves him shocked and speechless.

## Characters

- Cid Kagenou
- [Alpha](Alpha.md "Alpha")
- Mr. Kagenou
- Mrs. Kagenou
- Claire Kagenou
- [Beta](Beta.md "Beta")
- [Gamma](Gamma.md "Gamma")
- [Delta](Delta.md "Delta")
- [Eta](Eta.md "Eta")
- [Zeta](Zeta.md "Zeta")
- [Epsilon](Epsilon.md "Epsilon")
- [Grease](Grease.md "Grease")
- [Millia](Millia.md "Millia") (Mentioned)

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第２話予告≪ノーマルVer.≫「結成シャドウガーデン」

TVアニメ『陰の実力者になりたくて！』第２話予告≪スペシャルVer.≫「陰の実力者は配下が欲しい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e002>
2. <https://shadow-garden.jp/1st/story/#story2>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • **Episode 2** • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
