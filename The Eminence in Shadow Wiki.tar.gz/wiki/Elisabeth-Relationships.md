# Elisabeth/Relationships

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Elisabeth/Relationships](https://the-eminence-in-shadow.fandom.com/wiki/Elisabeth/Relationships)

[Main](Elisabeth.md "Elisabeth")

[Chronology](Elisabeth-Chronology.md "Elisabeth/Chronology")

Image Gallery

## Allies

### Shadow

Shortly following her resurrection, Shadow appeared before Elisabeth to stop her rampage. During the resulting fight, the vampire queen gave the leader a look begging him to put her out of her misery. However, Shadow instead opted to save her by hitting her with his "I AM RECOVERY ATOMIC", resulting in her fully regaining control of herself. Afterward, Elisabeth seemed grateful toward him. It also seems that she can see right through his guise as Cid Kagenou.[[1]](#cite_note-:0-1)

### [Mary](Mary.md "Mary")

Devoted servant, Mary was Elisabeth's second in command until Crimson changed her food resulting in her loss of control and tragedy. Despite ordering her to stop and kill her, Mary was unable to and sedated her into a coffin where she protected until Crimson stole her body.[[2]](#cite_note-2) Since reawakening, Mary has return to a servant, however Elisabeth treats her more as a cherished friend.

## Others

### [Crimson](Crimson.md "Crimson")

Former subordinate. Crimson was responsible for her loss of control and death of many when he mixed human blood in her food. He was almost successful in plans of forcing mankind into the mercy of vampire kind when Shadow callously annihilated him.[[1]](#cite_note-:0-1)

## References

1. Volume 3 Chapter 3: Pursuing the Blood Queen!
2. Volume 3 Chapter 2: Storming the Crimson Tower!
