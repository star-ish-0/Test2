# Perv Asshat

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Perv%20Asshat](https://the-eminence-in-shadow.fandom.com/wiki/Perv%20Asshat)

Chronology

Relationships

Image Gallery

## Perv Asshat

### Japanese

ドエム・ケツハット

### Romaji

Doemu Ketsuhatto

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Around 30s[[1]](#cite_note-V2C7-1)

### Height

Unknown

### Hair Color

Brown

### Eye Color

Light Brown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Rose Oriana (ex-fiancée)
Reina Oriana † (collaborator, lover)

## Professional Information

### Occupation

- Duke
- Royal Chancellor

### Affiliation

Oriana Kingdom
Cult of Diablos

## Debut

### Web Novel

Chapter 78

### Light Novel

Volume 2

### Manga

Chapter 24

### Anime

Episode 16

## Portrayal

### Japanese

[Show Hayami](https://en.wikipedia.org/wiki/Show_Hayami "wp:Show Hayami")

### English

Brandon Hearnsberger

### French

Eilias Changuel

### Italian

Daniel Magni

Perv Asshat (ドエム・ケツハット, Doemu Ketsuhatto[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was the Oriana Kingdom's Royal Chancellor and Rose Oriana's ex-fiancé. He was secretly a member of the Cult of Diablos who sought to become the 12th seat in the Knights of Rounds by seizing the kingdom and handing over Rose for the Cult's experimentation. However, after his crimes were publicly exposed, he was beheaded by [Mordred](Mordred.md "Mordred") to silence him.

## Appearance

Perv was a quite handsome man who appeared to be in his thirties with fairly long brown hair tied in a ponytail that reaches past his shoulders and a goatee. He donned a red noble suit with yellow outlining and white slacks.

## Personality

Perv initially appeared to be a well-respected intellectual man with a soft-spoken polite demeanor. But in truth, he was a treacherous schemer with a manipulative nature, having no loyalty to anyone but himself. He rarely showed any sign of anxiety or distress, and often had entire situations well planned out in advance. Whenever confronted, Perv was casual and uncaring, attempting to derail the conversation and make small talk. This often infuriated those he talked to.

He was almost willing to use anyone around him as pawns to further his ambitions and would switch sides if it meant benefiting his agenda as he was willing to do anything necessary and wouldn't stop at anything to achieve his goals. This included manipulating or killing anyone especially Midgar and their princess. However, Perv was self-aware of his surroundings and cautious enough to know when it'll work against him. This was demonstrated after he realized [Beatrix](Beatrix.md "Beatrix")'s presence and knew it was a terrible idea if he were to off either her or the princess.[[2]](#cite_note-V2C8-2)

Apparently, Perv was a womanizer who'd always hit on beautiful women and teenage girls whenever he had the opportunity.

He was also a vindictive man who expressed jealousy and hatred when he saw Mundane Mann as a much better swordsman than him and refused to acknowledge it. He was overconfident when he thought that his plans would succeed until Rose Oriana and Shadow foiled him each and every time.

After the Bushin Festival Tournament, he became paranoid after witnessing the mysterious figure and his organization's prowess firsthand. Because of the aforementioned, Perv doubted the Cult's abilities in maintaining their status quo and crushing their biggest opposition. At the supposed wedding ceremony with Rose, he tried to tighten the security and was still doubtful. His paranoia was caused by the consequences of failure in his mission to seize the kingdom after gaining Mordred's support. He became frightful of further failure after reporting his botched attempt at retrieving Rose and loss of their puppet king to the Round Knight.

When he realized that the Ring of Succession was missing from the box he kept, Perv tried to improvise by buying time to look for it. His premonition came true at the wedding when Rose wore the ring and exposed his crime to the attendance. This led to Mordred to behead him to prevent any further Cult's intel had from being leaked, even having him glaringly remark his incompetence.

## Powers & Abilities

As Duke and Royal Chancellor, Perv held enormous political power and influence only second to the king. Although an advisor, he was merely a representative and spokesman for the kingdom. He possessed some physical strength and magical power equal to the "Second Children" of the Cult albeit the weakest of them all.[CITATION NEEDED]

### Genius Intellect

His most prominent trait was his tremendous intellect as he was well-versed in planning through strategies and tactics while avoiding any suspicion from any party. He had a great talent for analyzing and observing his surroundings, allowing him to understand a person's pattern of thinking and to better manipulate them. He can formulate well-thought-out plans several steps ahead of others, some of which have a long term in mind. During his time as a Royal Chancellor, Perv had been engaging in politics while allowing him to effectively manipulate any situations around him.[CITATION NEEDED]

### Swordsmanship

During the Bushin Festival Tournament, he claimed to Iris that his swordsmanship was "decent" and acknowledged that he was no match for her, Beatrix, Shadow, or even Rose. This was further demonstrated when Rose overpowered him at their supposed wedding. Initially believing to be evenly matched, the former princess rebuked that his sloppy swordsmanship wouldn't be able to take anyone down before defeating him with ease.[[3]](#cite_note-V4C3-3)

### Expert Strategist & Tactician

Despite his mediocre sword prowess, Perv more than made up for his manipulative nature and political influence within the Cult. He proved himself to be a skilled and flexible tactician, as he skillfully adjusted seamlessly to any given combat situation, if not planning out events well in advance. He understood the strengths, weaknesses and mannerisms of his enemies, and created strategies to achieve victory. Despite knowing well, the strengths he possesses, Perv is highly cautious of his opponent in battle, even leaving no blind spots on his weakness.[CITATION NEEDED]

### Master Manipulator

Perv proved himself to be a very crafty and cunning man as he could deceive and manipulate others around him in various ways for other purposes. For years, he convinced everyone around him that he was a capable politician with the best intentions for his kingdom whilst performing wicked deeds. He was masterful at planning when he garnered [Mordred](Mordred.md "Mordred")'s support in elevating him to 12th seat conditionally and attracted the queen, Reina Oriana to conspire against her kingdom through brainwashing her own husband. This allowed him leeway to accomplish his objectives, ensuring that he had planned out well. Despite performing these feats, he garnered suspicion from Iris and Beatrix albeit inadvertently.[[2]](#cite_note-V2C8-2)

## Trivia

- His name is a gag by the author, as he often does for side characters.[CITATION NEEDED]
  - His name in Japanese is "Doem Ketsuhat", which was roughly translated to "Perv Asshat" in the official [Yen Press](https://en.wikipedia.org/wiki/Yen_Press_LLC "wp:Yen Press LLC") release in the West.
- In the novels, the depiction of his death varies.
  - In the Light Novel, Perv was beheaded by Mordred after Rose defeated him in a duel after she exposed him at their supposed wedding.[[3]](#cite_note-V4C3-3)
  - In the Web Novel, Shadow killed him after he broke his mind first through an experiment.

## References

1. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
2. Volume 2 Chapter 8: Lay Your Eyes on My True Powers!
3. Volume 4 Chapter 3: Crashing the Ceremony!

## Side Navigation
