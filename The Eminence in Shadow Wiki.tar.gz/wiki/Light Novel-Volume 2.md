# Light Novel/Volume 2

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%202](https://the-eminence-in-shadow.fandom.com/wiki/Light%20Novel/Volume%202)

## Light Novel Volume 2

## Publication Information

### Author

Daisuke Aizawa

### Illustrator

Touzai

### Publisher (JP)

[Kadokawa](https://en.wikipedia.org/wiki/Kadokawa "wp:Kadokawa")

### Publisher (EN)

[Yen Press LLC](https://en.wikipedia.org/wiki/Yen_Press "wp:Yen Press")

### ISBN JP

ISBN 978-4047355804

### ISBN EN

ISBN 978-1975386993

### Release Date

March 5, 2019 JP
November 10, 2020 EN

## Volume Information

### Pages

384 JP
266 EN

### Chapters

10

## Adaptations

### Manga

Volume 4, Chapter 14 - Volume 7, Chapter 26

### Anime

Episode 10 – Episode 20

Publication Order

| Previous | Next |
| --- | --- |
| Volume 1 | Volume 3 |

This is the second volume of the light novel series, The Eminence in Shadow (陰の実力者になりたくて！, Kage no Jitsuryokusha ni Naritakute![?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")).

## Synopsis

- [English](#)
- [Japanese](#)

NOTHING COULD BE FURTHER FROM THE TRUTH

Cid pays a visit to the Sacred Land, where he finds himself getting roped into the Goddess's Trial. It's a ritual event that summons warriors from the past to engage with only the most worthy from the present. When Cid squares off against the witch who brought devastation to the world, the door to the Sanctuary creaks open, granting the Shadow Garden valuable insight into the possessed and the Cult of Diablos. That is until Cid, blissfully ignorant of the conspiracies playing out behind the scenes, runs amok![[1]](#cite_note-1)

大人気・中二病×勘違い×異世界転生黙示録!!

聖地・リンドブルムで行われる「女神の試練」イベントへと訪れたシド。
一年に一度、「聖域」の扉が開かれるこの日に、突如現れたのは、かつて世界に混乱と破壊を招いたと言われる「災厄の魔女・アウロラ」だった。

「災厄の魔女」と「聖域」、そして「ディアボロス教団」と「シャドウガーデン」の思惑が錯綜する！[[2]](#cite_note-2)

## Summary

### Goddess's Trial

Cid received a letter from [Alpha](Alpha.md "Alpha"), inviting him to the Sacred Land of [Lindwurm](Lindwurm.md "Lindwurm"). Since the school had closed early due to a terrorist attack, he decided to travel there as a regular civilian via carriage, a journey that would span four days. Unfortunately, his plans were interrupted when Rose Oriana intercepted him. Rose extended an invitation for Cid to ride with her on her carriage to Lindwurm, and though Cid was initially reluctant, he ultimately accepted her offer.

During their journey, they engaged in various conversations, including a discussion about the Goddess’s Trial, which Cid misinterpreted as Rose trying to recruit him to her religion. Rose mentioned that she had been invited as a special guest for the event.

She also revealed her suspicions that a different group, distinct from Shadow Garden, was responsible for the attack on the academy. She reported this to the Knight Order, who erroneously claimed that the two organizations were the same.

Upon arriving in Lindwurm, Rose offered to take care of Cid's accommodations, placing him in a high-end hotel fit for royalty.
While in Lindwurm, Rose and Cid spent the afternoon exploring market stalls. Cid came across a keychain featuring a sinister left arm wrapped around a sword. He inquired about its significance, and Rose explained that it represented the left arm of the demon [Diablos](Aurora.md "Aurora") and the sword of the hero [Olivier](Olivier.md "Olivier"). She mentioned a legend where Olivier had severed Diablos' left arm and sealed it in Lindwurm, pointing to the ruins known as the [Sanctuary](Sanctuary.md "Sanctuary").

Cid purchased the keychain, and as they continued their tour, Rose noticed a long line of people waiting outside a bookstore. She explained that they were there to get an autograph from [Natsume](Beta.md "Beta"), the author, and expressed her desire to join the line. Cid decided to join her. He takes a look at the books, where he notices most of them are blatant plagiarism from famous titles from his past life, suspecting that Natsume might be someone reincarnated from Earth.

During their wait, Cid identified the author as [Beta](Beta.md "Beta"), who pretended not to recognize him. Beta revealed that she had been invited to Lindwurm as a special guest and had used the opportunity to gather inside information. She says as she writes the plans on Cid's book.
As they left the bookstore, Rose discovered that Cid was a fan of Natsume. They exchanged insights on Natsume's works, and Rose showed Cid her autographed book, reminding him of Beta's mention of a plan.

Later, Cid decided to indulge in one of his favorite pastimes from his previous life, taking a dip in the hot springs for relaxation. Lindwurm was famous for its hot springs, but to his disappointment, he found Alexia already there. After a period of silence, Alexia inquired about Cid's injuries, offered an awkward apology, and mentioned that she is there to investigate [Archbishop Drake](Drake.md "Drake").

Cid and Alexia discussed their apologies and motivations, with Alexia revealing that she was also invited to Lindwurm for the Goddess’s Trial event. She explained the purpose of the event, and Cid assumed that Alpha had invited him to watch her participate. Alexia shared her suspicions about Archbishop Drake and urged Cid to join the Crimson Order to learn more.

He declined her offer. After Alexia gave up her efforts to persuade Cid, she expressed her surprise at his lack of attention towards her. In response, Cid explained that he deliberately avoided staring at others to avoid making them uncomfortable. He added that Alexia should refrain from peeking at his "Excalibur".

Amused by his response, Alexia mockingly laughed and nicknamed it an "Earthworm." However, Cid decided to have the last word. He got up, looked at her, and calmly said, "You shouldn't judge things solely based on appearances. Sometimes, an earthworm simply hasn't left its scabbard yet. When the holy sword is drawn from its scabbard, its ivory blade will be unleashed, sending you on a journey to the Garden of Chaos…"

With this enigmatic declaration, Cid grabbed his towel and playfully slapped it against his buttocks before leaving the hot spring area, leaving a flustered Alexia behind.

Alpha stood in the Lindwurm cathedral, observing a statue of the hero Olivier. At the statue's base lay the dismembered body of Archbishop Drake. Alpha glanced at the statue once more, then calmly exited the scene as people began searching for the archbishop.

On the eve of the Goddess’s Trial, Cid stood atop a clock tower, watching the bustling city. His attention was drawn to a suspicious figure fleeing from the church. He transformed into his Shadow persona, intercepted the figure in a back alley, and engaged in a confrontation. The confrontation ended swiftly with the figure losing their head, and [Epsilon](Epsilon.md "Epsilon") revealed herself as the attacker. Cid and Epsilon exchanged words and discussed their plans, parting ways after.

The day of the Goddess’s Trial arrived, and guests gathered for the opening ceremony, including Natsume, Rose, and Alexia. Alexia found herself vexed by Acting Archbishop Nelson, who had called off the investigation into Archbishop Drake's death, and Natsume, who she suspected of hiding a different side from the public.

Cid attended the event from the stands, eager to engage in some shadow brokering. However, he contemplated gatecrashing the event while keeping his identity hidden, but registration hurdles made it impossible. As evening fell, the main event began, with contestants trying to summon warriors to their side. Only Annerose succeeded. The event announcer calls out the name of the next contestant: a student from the Midgar Academy for Dark Knights, Cid Kagenou.

Cid is puzzled as to why he was called despite not signing up. He decided to take an unexpected route and announced his presence as Shadow, leaping into the arena to summon his own warrior.

### Holy Ground Infiltration

### Bushin Festival Tournament

## Chapters

Note: The chapter count does not include the Appendix, which contains character profiles and 'The Chronicles of Master Shadow Complete Version: Volume 2.'

- Prologue: To Lindwurm, the Scared Land!
- Chapter 1: Fun Times at the Goddess's Trial!
- Chapter 2: Investigating the Sanctuary!
- Chapter 3: When Things Get Boring, It's Time for Explosives!
- Chapter 4: This Situation Calls for a "Who Is That Guy?!"
- Chapter 5: A Battle to Attract Only MVPs!
- Chapter 6: A Mastermind Always Plays Piano Under Moonlight!
- Chapter 7: Showing Off a Smidgen of My Strength!
- Chapter 8: Lay Your Eyes on My True Powers!
- Final Chapter: Just Who Is This Mysterious Badass?!
- Appendix

## Characters

:   In order of appearance:

- Cid Kagenou
- Rose Oriana
- [Beta](Beta.md "Beta")
- Alexia Midgar
- [Alpha](Alpha.md "Alpha")
- [Archbishop Drake](Drake.md "Drake") (Debut)
- [Epsilon](Epsilon.md "Epsilon") (Debut)
- Acting Archbishop Nelson (Debut)
- Annerose (Debut)
- [Borg](Borg.md "Borg") (Debut)
- [Aurora](Aurora.md "Aurora") (Debut)
- [Executioner Venom](Venom.md "Venom") (Debut)
- [Olivier](Olivier.md "Olivier") (Debut)
- [Delta](Delta.md "Delta")
- [Rude](Rude.md "Rude") (Debut)
- [Gamma](Gamma.md "Gamma")
- [Nu](Nu.md "Nu")
- Mundane Mann (Mentioned)
- [Quinton](Quinton.md "Quinton") (Debut)
- Skel Etal
- Po Tato (Mentioned)
- Goldy Gilded (Debut)
- Gonzales (Debut)
- Claire Kagenou
- Iris Midgar
- Zenon Griffey (Mentioned)
- [Beatrix](Beatrix.md "Beatrix") (Debut)
- Perv Asshat (Debut)
- Raphael Geerk Oriana (Debut)
- Klaus Midgar (Debut)
- Mist Dragon (Mentioned)
- [Lambda](Lambda.md "Lambda") (Debut)
- [No. 664](664.md "664") (Debut)
- [No. 665](665.md "665") (Debut)

## Illustrations

- [English](#)
- [Japanese](#)

Shadow Garden facing Nelson (EN)

Main Heroines (EN)

Shadow playing Moonlight Sonata to Rose (EN)

Table of Contents (EN)

Title Page (EN)

Alexia bathing in a hot spring

Epsilon meeting with Shadow

Shadow facing off Aurora

Alpha observing young Olivier's past

Cid using his "Hidden Technique: I AM ATOMIC" on the Sanctuary

Goldy using his “Demonic Golden Dragon! Fatality Strike!!”

Perv sitting next to Iris

Mundane Mann revealing his true identity

Beta's Profile (EN)

Gamma's Profile (EN)

Rose Oriana's Profile (EN)

Annerose's Profile (EN)

Shadow Garden facing Nelson (JP)

Main Heroines (JP)

Shadow playing Moonlight Sonata to Rose (JP)

Table of Contents (JP)

Title Page (JP)

Alexia bathing in a hot spring

Epsilon meeting with Shadow

Shadow facing off Aurora

Alpha observing young Olivier's past

Cid using his "Hidden Technique: I AM ATOMIC" on the Sanctuary

Goldy using his “Demonic Golden Dragon! Fatality Strike!!”

Perv sitting next to Iris

Mundane Mann revealing his true identity

Beta's Profile (JP)

Gamma's Profile (JP)

Rose Oriana's Profile (JP)

Annerose's Profile (JP)

## References

1. [YenPress. The Eminence in Shadow, Vol. 2 (light novel) (EN)](https://yenpress.com/9781975386993/the-eminence-in-shadow-vol-2-light-novel/#book-description-full)
2. [Kadokawa. The Eminence in Shadow 02 (JP)](https://www.kadokawa.co.jp/product/321812000831/)

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • **Volume 2** • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
