# Master of Garden

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Master%20of%20Garden](https://the-eminence-in-shadow.fandom.com/wiki/Master%20of%20Garden)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Master_of_Garden?action=edit).

## The Eminence in Shadow: Master of Garden

### Kana

陰の実力者になりたくて！マスターオブガーデン

### Romaji

Kage no Jitsuryokusha ni Naritakute! Masutā Obu Gāden

## Infomation

### Developer(s)

Aiming Inc.

### Publisher(s)

Crunchyroll Games, LLC

### Platform(s)

[iOS](https://en.wikipedia.org/wiki/iOS "wp:iOS"), [Android](https://en.wikipedia.org/wiki/Android_(operating_system) "wp:Android (operating system)"), [PC](https://en.wikipedia.org/wiki/Personal_computer "wp:Personal computer")

### Release Date

November 29, 2022

### Genre

[RPG](https://en.wikipedia.org/wiki/Role-playing_game "wp:Role-playing game"), [Gacha](https://en.wikipedia.org/wiki/Gacha_game "wp:Gacha game")

### Mode(s)

Single-player, Multiplayer

The Eminence in Shadow: Master of Garden (陰の実力者になりたくて！マスターオブガーデン, Kage no Jitsuryokusha ni Naritakute! Masutā Obu Gāden[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the game adaptation of Daisuke Aizawa's The Eminence in Shadow light novel series. The game adaptation takes material from both the Anime and Light Novel as well as creating its original content, such as covering the 2-year time skip in the story.

## Description

- [English](#)
- [Japanese](#)

Not the main character, and not the last boss. The one who lurks in the shadows of the storyline and holds all the power, hiding his true abilities by acting like a side character. The boy who longs to be a 'Shadowbroker' lives an unobtrusive life as a side character, training to gain magic power until he's killed in an accident and reincarnated into another world.

Reborn as Cid Kagenou, the boy decides to enjoy himself in this other world with a made-up scenario about "the Eminence in Shadow." He starts fooling around with secret maneuvers against an evil cult that he born from his imagination... and it turns out that the cult really does exist! The girls he took on as his subordinates on a whim began worshiping Cid as Shadow, and before he knows it, Cid has become a true "Eminence in Shadow." Before long, Cid—along with his mysterious group the Shadow Garden—will destroy the darkness of his new world.

The Strongest MC x Overwhelming Chuunibyou x A Serious Comedy Full of Misunderstandings[[1]](#cite_note-1)

それは、主人公でも、ラスボスでもない。普段は実力を隠してモブに徹し、物語に陰ながら介入して密かに実力を示す存在。この「陰の実力者」に憧れ、日々モブとして目立たず生活しながら、力を求めて修業していた少年は、事故で命を失い、異世界に転生した。シド・カゲノーとして生まれ変わった少年は、これを幸いと異世界で

「陰の実力者」設定を楽しむことにする。「妄想」で作り上げた「闇の教団」を倒すべく（おふざけで）暗躍していたところ、どうやら本当に、その「闇の教団」が存在していて……？ノリで配下にした少女たちは勘違いからシドをシャドウとして崇拝し、シドは本人も知らぬところで本物の「陰の実力者」になっていき、そしてシドが率いる陰の組織「シャドウガーデン」は、やがて世界の闇を滅ぼしていく――。

主人公最強×圧倒的中二病×勘違いシリアスコメディ!?[[2]](#cite_note-2)

## Gameplay

### Overview

The Eminence in Shadow: Master of Garden is a Gacha auto battler game with teams of five characters built around four elements and three unit roles. You, the player also have a level which you will be able to raise as you battle opponents, progress the story, and complete daily missions. The game has a stamina system which allows you to fight battles with enemies. In addition, the game has many Events, as well as PvP. The game also has Guilds with which you can fight within Guild Events (and normal events), these include Guild Rankings which come with their own rewards.

Each character has one role, which will be either Tank, Offense, or Support. Tank units, as their name suggests are typically designed to take damage and protect other units from enemy combatants. Next is Offense, these are the attackers of your team and are typically meant to be the units meant to dispatch the enemy units so you can win the battle. Finally, we have the Support units, these units are meant to heal and support the other units of the field.

Each character and enemy is also differentiated by four different elements (the white element does exist but it is exclusive to enemies), and this is important because these elements are all weak to each other as shown in the image next to this text. These elements greatly affect the amount of damage your characters take from enemies, as well as how much damage you do to your enemies.

#### Characters

All characters have a few ways to upgrade their potential in battle.

- Level Up: Leveling up characters is the simplest way to upgrade characters, although it contributes little to your potential in battle and mostly operates as a way to limit how high you can raise your Rank. How high the level of a character can be, is linked to how high level your account is and how high the character's rarity is. You can raise a character level through four types of candies, Small Magic Candy (60xp), Magic Candy (300xp), Big Magic Candy (1500xp), and Premium Magic Candy (7500xp). You can also raise the level of a character through battle, but that is substantially less efficient.
- Rarity: Raising the rarity of a character gives an extremely minor boost to your character's strength, as well as raises the level cap of your character by one level. Rarities begin from A and go up to SS++. Characters with the rarity of A will be able to level up as high as the player level, at the rarity of S one will be able to to one level above the player level cap, at the rarity of SS they can go two levels above the cap, at SS+ three levels above the players level cap, and finally at SS++ they will be four levels above the player level cap. Rarity is raised through character shards, which can be bough from in-game shops, or going through the hard versions of Seven Shadows Chronicles battles.
- Ranks: All characters have a rank that they can raise to become more powerful and unlock new skills. To raise your rank you have to level up your account and progress through the Seven Shadows Chronicles in order to gather equipment in order to rank up. Ranks 8, 13, and 18 dramatically raise the damage cap of a character.
- Awakening: Awakening is the most powerful way to upgrade a unit. All characters can go up to Awakening level 5 (more often called A5), and each awakening provides a significant boost to the skills and abilities of your character. Awakenings are unlocked via duplicates which give character-specific Magic Cores, Magic Cores can be acquired through summoning, buying through player coins in the shop, or in some cases through events or missions (these are rare however). Magic Crystals can be used to substitute for Magic Cores of specific characters, Magic Crystals can be gained through duplicates of characters once that character has reached A5 by exchanging their Magic Core (which now has no use) for a Magic Crystal, as well as through Guild Events such as Armageddon and the event shops. (There are other cases where you can gain them but they are extremely rare.)
- Gear: All units have character-specific gear with unique effects for each character. Some units also have another character-specific gear called SS+ Gear, which can only be crafted if a character has achieved SS++ Rarity as well as gathered 100 character shards on top in addition to an item called Potent Magic Drop which can be bought from the shop or given through events. All Gear has five ranks which you will need four types of Polish for, those being Polish, Fine Polish, Luxury Polish, and Shadow Wisdom Polish.

#### Combat

#### Events

#### Summon

### 1-on-1 Time

By gaining affection points, Cid Kagenou can go on dates with the girls the player has unlocked. These scenes are not canon, but the sentiments are reflective of narrative feelings. The player spends their affection points by choosing from three dialogue options. Each one unlocks a unique scene, and they continue until the date ends. If the player wishes, and possesses enough affection points, they can repeat the date to explore other conversation dialogue. Date scenes can be accessed and repeated in the flashback tab, but only if the path has been previously unlocked.

## Supplementary Narratives

The following is a list of Master of Garden stories overseen by Daisuke Aizawa, author of the original source.

##### Main Story

- Seven Shadow Chronicles

##### Events

Below are the narratives that take place within events inside of the game, separating them from the normal story.

###### Auxiliary Chapters

- Rose of Garden[[3]](#cite_note-3)
- Truth Seekers[[4]](#cite_note-4)
- Interlude[[5]](#cite_note-5)
- Masquerade[[6]](#cite_note-6)

###### Apocrypha

- Requiem for the Scattered Shadows[[7]](#cite_note-7)

## Stories

Main Stories

- [Chapter 1: Shadow Garden Assemble](#)
- [Chapter 2: Amateur Sword](#)
- [Chapter 3: Reward for Torture](#)
- [Chapter 4: I Am...](#)
- [Chapter 5: The Deceiver](#)
- [Chapter 6: Bloodshed & Strife at the Match](#)
- [Chapter 7: The Academy Under Attack](#)
- [Chapter 8: An End to Deception](#)
- [Chapter 9: Sacred Land - City of Deceit](#)
- [Chapter 10: Goddess’ Trial](#)
- [Chapter 11: Truth in Memories](#)
- [Chapter 12: A Feud Dedicated to Ruin](#)
- [Chapter 13: Your Lies, Your Wishes](#)
- [Chapter 14: The Strongest of the Weakest](#)
- [Chapter 15: Invisible Truths](#)
- [Chapter 16: Moonlight Shines in Darkness](#)
- [Chapter 17: Bet on the Moment](#)
- [Chapter 18: Dancing Puppet](#)
- [Chapter 19: Warlock’s Arrival](#)
- [Chapter 20: Legendary Red Moon](#)
- [Chapter 21: Peaceful Dream](#)
- [Chapter 22: Vampire Progenitor](#)
- [Chapter 23: It is John Smith](#)
- [Chapter 24: Covert Combat](#)
- [Chapter 25: Night of Farewells](#)
- [Chapter 26: Taker and Taken](#)
- [Chapter 27: A True Man’s Path](#)
- [Chapter 28: After Uncertainty](#)
- [Chapter 29: Shiron’s Disciple](#)
- [Chapter 30: Condemnation](#)
- [Chapter 31: I’m Atomic](#)

- Episode 1: Finding Magic
- Episode 2: Finding Alpha
- Episode 3: The Shadow Garden
- Episode 4: The Cult of Diablos
- Episode 5: Battle Aesthetic
- Episode 6: Ebony Blade

- Episode 1: To the Capital!
- Episode 2: Princess Alexia
- Episode 3: Standout Lunch
- Episode 4: Good Doggy
- Episode 5: Faultless Person
- Episode 6: Hated Sword

- Episode 1: Dim Room
- Episode 2: Royal Blood
- Episode 3: For My Family
- Episode 4: Rise of Shadows
- Episode 5: Night of Chaos
- Episode 6: Oddity Unmasked

- Episode 1: Capital Raid
- Episode 2: End the Pain
- Episode 3: Rainy Stage
- Episode 4: Clad in Ebony
- Episode 5: Ideal Sword
- Episode 6: True Strength
- Episode 7: After the Uproar

- Episode 1: Storm Mitsugoshi
- Episode 2: Gamma the Weak
- Episode 3: Royal Request
- Episode 4: Fakes in Black
- Episode 5: Royal Enemy
- Episode 6: Cocoa & Cherries

- Episode 1: Nu's Dream
- Episode 2: Rose vs Cid
- Episode 3: From a Friend
- Episode 4: Duo Dynamics
- Episode 5: Evil on the Move
- Episode 6: Looming Blade

- Episode 1: The Boy’s Idol
- Episode 2: My Role
- Episode 3: Moving the Story
- Episode 4: Behind-the-Scene
- Episode 5: You’re the Best
- Episode 6: Nu’s Past

- Episode 1: Giving Back
- Episode 2: Payback Time
- Episode 3: School in Flames
- Episode 4: The East Gate
- Episode 5: Fight & Enlight
- Episode 6: Your Path
- Episode 7: It’s a Secret.

- Episode 1: (Un) Natural
- Episode 2: Sisterly Travel
- Episode 3: That Day
- Episode 4: Our Joy and Love
- Episode 5: Popular Novelist
- Episode 6:The Faithful

- Episode 1: First in the Tub
- Episode 2: This’s Bad
- Episode 3: Audience POV
- Episode 4: The Third Choice
- Episode 5: Calamity Witch
- Episode 6: Mighty Dialogue

- Episode 1: Sketchy Pursuer?
- Episode 2: Memory Prison
- Episode 3: Uninviting Door
- Episode 4: Olivier the Hero
- Episode 5: Possessed Truth
- Episode 6: Tears of Diablos

- Episode 1: Pure Violence
- Episode 2: Corpse Carpet
- Episode 3: Holy Sword…
- Episode 4: Reactive Memory
- Episode 5: After the Hunt
- Episode 6: Heartless Hero

- Episode 1: Sanctuary Power
- Episode 2: Eyes of Violet
- Episode 3: Sunny Quiet Morn
- Episode 4: Dream Trio
- Episode 5: Everyday Sight
- Episode 6: Flex Some Muscle

- Episode 1: Bushin Festival
- Episode 2: Dul Dark Knight
- Episode 3: Annerose-Advice
- Episode 4: Promise for Rose
- Episode 5: Battle Power
- Episode 6: Victory Formula

- Episode 1: Cuz We’re Allies
- Episode 2: War God Beatrix
- Episode 3: Invincible Myth
- Episode 4: Mid-Sneeze
- Episode 5: Playtime is Over
- Episode 6: A Chased Puppet

- Episode 1: Problem-People
- Episode 2: Moonlight
- Episode 3: Down the Stairs
- Episode 4: After the Escape
- Episode 5: Rose’s Fight
- Episode 6: Separate Ways

- Episode 1: Steadfast Anger
- Episode 2: The VIPs
- Episode 3: Utter Confidence
- Episode 4: Artistic Blade
- Episode 5: A Fool’s Back
- Episode 6: After the Match

- Episode 1: Iris’s Mission
- Episode 2: War God’s Eyes
- Episode 3: Ever-Conspiracy
- Episode 4: Master’s Lie
- Episode 5: Faithful Path
- Episode 6: Childhood Secret

- Episode 1: Archenemy
- Episode 2: Naturally
- Episode 3: Facing the Music
- Episode 4: Supremely Final
- Episode 5: Warlock Shadow
- Episode 6: Dream Debris

- Episode 1: Red Moon
- Episode 2: Future Funds
- Episode 3: Sings of Rampage
- Episode 4: Night of Madness
- Episode 5: Crimson Tower
- Episode 6: The Third Force

- Episode 1: The White Demon
- Episode 2: Progenitor Blood
- Episode 3: True Nature
- Episode 4: Impossible Dream
- Episode 5: Preparation for Revival
- Episode 6: Not Much Time, Right?

- Episode 1: The Blood Queen
- Episode 2: Low Blood Pressure
- Episode 3: Explanation of a Certain Blood
- Episode 4: I am the Original
- Episode 5: The Queen and the Gentleman
- Episode 6: Sister’s Affliction

- Episode 1: A Plot by the MCA
- Episode 2: All Will Know My Name!
- Episode 3: The Value of Money
- Episode 4: Credit Collapse
- Episode 5: Encounter with Delta
- Episode 6: Tribal Rule

- Episode 1: Gamma, Attack!
- Episode 2: Suicide Swing!
- Episode 3: Alexia Improves
- Episode 4: Read or Fake
- Episode 5: Start of a Crisis
- Episode 6: Captivating Wires

- Episode 1: The Mystery Man
- Episode 2: Secret Mission
- Episode 3: Tiny Cracks
- Episode 4: Master’s Message
- Episode 5: Out of Reach
- Episode 6: Yukime’s Past

- Episode 1: Capital Concerns
- Episode 2: His True Intentions
- Episode 3: The Prize
- Episode 4: Entrusted
- Episode 5: Front & Back
- Episode 6: Beneath the Snow

- Episode 1: Boys Must Strive
- Episode 2: Rock-Paper-Scissors
- Episode 3: Today Is Our Day
- Episode 4: Volleyball Battle
- Episode 5: Flood of Tears
- Episode 6: Their Journey

- Episode 1: Soul Searching
- Episode 2: Confrontation
- Episode 3: Wriggling Schemes
- Episode 4: Quavering Kingdom
- Episode 5: Shadowy Ploys
- Episode 6: Betrayal

- Episode 1: Lambda’s Woes
- Episode 2: Entry Permit
- Episode 3: A Pupil’s Skill
- Episode 4: Castle Tour
- Episode 5: False Hope
- Episode 6: The Black Rose

- Episode 1: Her Sincerity
- Episode 2: Birth of a Dynasty
- Episode 3: A Cruel Truth
- Episode 4: Ring of Succession
- Episode 5: A Princess’s Will
- Episode 6: Ragnarok

- Episode 1: Before Creation
- Episode 2: Invisible Blade
- Episode 3: Worlds Beyond
- Episode 4: Value of Blood
- Episode 5: Failed Creation
- Episode 6: Light Dispels Dark
- Episode 7: Moonlit Encounter

Seven Shadows Chronicles

- [Part 1: Rise of Garden](#)
- [Part 2: Sturm of Velgalta](#)
- [Part 3: Secret of Sacra](#)
- [Part 4: Boughs of Shadow](#)

- [Shadow Garden, Mobilize!](#)
- [Ancient Dragon of Alexandria](#)
- [Have Mercy! Eta's Protocol](#)
- [Behold! Tuna Chaos](#)
- [Here Comes Trouble](#)
- [Intense! Unstoppable Alpha](#)
- [Brutal! Delta's Night Hunt](#)
- [She is Beauty, She is Grace!](#)
- [Watch Out, Gamma!](#)
- [Mitsugoshi, Ltd. is Open!](#)
- [Deal! Arranged Booking](#)
- [Natsume & Shiron Hang Out](#)
- [Visions... Zeta and the Prophet](#)
- [The Garden on the Eve of Battle](#)
- [Final Battle! Templar Fanatics](#)

- Episode 1: Prelude
- Episode 2: Garden Policy
- Episode 3: Shadow Covert Op
- Episode 4: Possessed Search
- Episode 5: After the Rescue

- Episode 1: The Lost City
- Episode 2: Abyss Woods
- Episode 3: Tale of Ruin
- Episode 4: Shadow's Sword
- Episode 5: Future Unlocked

- Episode 1: Eta's Scheme
- Episode 2: Defense System
- Episode 3: Magic Gear
- Episode 4: Try, Try Again
- Episode 5: The Gear's Value

- Episode 1: Day Off together
- Episode 2: Going Fishing
- Episode 3: Tasty Tuna Sammy
- Episode 4: Victory Formula
- Episode 5: A King is Born

- Episode 1: News Beginnings
- Episode 2: Open the Door
- Episode 3: N. Kafka is Born
- Episode 4: Mystery Paladin
- Episode 5: Point-Blank

- Episode 1: Poking the Bear
- Episode 2: Re-Infiltration
- Episode 3: BBQ Provcatioin
- Episode 4: Merciless Probe
- Episode 5: Grace Thy Blade

- Episode 1: Mountaineering
- Episode 2: As Cats and Dogs
- Episode 3: Begin the Hunt
- Episode 4: Brutal Diplomacy
- Episode 5: My Fangs Rejoice

- Episode 1: Inspired by Ire
- Episode 2: Presentation Row
- Episode 3: Shadow Power!
- Episode 4: Epsilon's Justice
- Episode 5: Pianist Shiron

- Episode 1: Morning Shopping
- Episode 2: Luna's Past
- Episode 3: Luna: The Truth
- Episode 4: Gamma Capriccio
- Episode 5: Shadow World Foe

- Episode 1: Info Wars Begin
- Episode 2: Plot at A-Okay Co.
- Episode 3: Deception Op
- Episode 4: Mitsugoshi Credo
- Episode 5: No Shadows Left

- Episode 1: Beta Reminisces
- Episode 2: Harsh Happenings
- Episode 3: 2 Birds 1 Stone
- Episode 4: Sponsor's Intent
- Episode 5: Ebony Swirl

- Episode 1: City-State Duo
- Episode 2: Fleeting Vacance
- Episode 3: Jugang Ruins
- Episode 4: Beta-Beehind You!
- Episode 5: Great Collapse

- Episode 1: Spy Request
- Episode 2: Saintly Prayer
- Episode 3: Secret Cathedral
- Episode 4: Wonky Background
- Episode 5: Victoria-Prophet

- Episode 1: Can You Lift?
- Episode 2: Research & Hair
- Episode 3: Garden's Enemy
- Episode 4: Cherish Shadow
- Episode 5: To the Prelude

- Episode 1: Battlefront: Part 1
- Episode 2: Battlefront: Part 2
- Episode 3: Battlefront: Part 3
- Episode 4: Reunion in Flame
- Episode 5: Prelude to a New Battle
- Coming Soon - Part 2: Strum of Velgalta

- [Operation: Rescue & Recover](#)
- [A Brilliant Mission!](#)
- [Investigation! In Search of Oil](#)
- [Possessed Cult Leader](#)
- [Cult Secrets Revealed!](#)
- [A Brilliant Mission!The Garden Heads North](#)
- [Blood Pact! Unlikely Pair](#)
- [Seven Blades Swordswoman](#)
- [The Ones We Protect](#)
- [Duel! Defeat Malak!](#)
- [Faith and Conviction](#)
- [Evil Ambition’s End](#)
- [Hero…… Lured by Illusions](#)

- Episode 1: Zeta’s Departure
- Episode 2: Lurk in Darkness, Hunt Down Shadows
- Episode 3: Possessed Heiress
- Episode 4: Nicoletta Marquez
- Episode 5: Operation: Rescue

- Episode 1: Slow and Slay
- Episode 2: The Weakest Link
- Episode 3: Pitfall Experiments
- Episode 4: Prophetess’ Doubt
- Episode 5: Destine Numbers

- Episode 1: Buried Black Gold
- Episode 2: The Land of Malid
- Episode 3: Nyle River Trouble
- Episode 4: Malak the Malevolent
- Episode 5: The Perfect Base

- Episode 1: Keep Investigating
- Episode 2: Two “Seven Blades”
- Episode 3: Confronting Sergey
- Episode 4: Not Even a Scratch
- Episode 5: Glorious Escape

- Episode 1: Possessed Lady Karen
- Episode 2: Two Ruthless Choices
- Episode 3: Cult Secrets Unveiled
- Episode 4: To Know thyself
- Episode 5:Loss and Rebirth

- Episode 1: Mysterious “Tears”
- Episode 2: Countering Regeneration
- Episode 3: Altered History
- Episode 4: Vengeance is Mine
- Episode 5: Journey to the North

- Episode 1: Secret Villa Seizure
- Episode 2: Secret Feud in Laugus
- Episode 3: RIP Mundane Man
- Episode 4: Authorized Savagery
- Episode 5: Without Loyalities

- Episode 1: Her Name is Annerose
- Episode 2: Naive Swordswoman
- Episode 3: Luna & Annerose
- Episode 4: A Knight’s Honor
- Episode 5: What is Passed Down

- Episode 1: Fallout
- Episode 2: Painted Lies
- Episode 3: Reason to Fight
- Episode 4: The Ones We Protect
- Episode 5: Embarkment

- Episode 1: Path of the Dragon
- Episode 2: Dvolutionary Dead-End
- Episode 3: Muscles Are Stored
- Episode 4: Break Apart!
- Episode 5: White Diamond

- Episode 1: People in the Stands
- Episode 2: Shadow Actress
- Episode 3: Trust’s Companion
- Episode 4: A Saint Gone Mad
- Episode 5: False Oracles

- Episode 1: The First Child
- Episode 2: Numbers Advantage
- Episode 3: “He” Is Here
- Episode 4: Dragon Awakens
- Episode 5: Summit of Strength

- Episode 1: A New Journey
- Episode 2: Sergey’s Hideout
- Episode 3: Artificial Dragons
- Episode 4: Ambition’s End
- Episode 5: A Mysterious Elf
- Coming Soon - Part 3: Secret of Sacra

- [Shadow Garden Revamp](#)
- [The Hero Revealed!](#)
- [Alexandria Rebellion](#)
- [Influencers Ahoy!](#)
- [Snaps of the Seven](#)
- [Beast Gods & Fake Legends](#)
- [Wandering Warrior](#)
- [Shadow Ninja Girl!](#)
- [The Suken Sanctuary](#)
- [Under the Academy](#)
- [Memories Revealed](#)
- [A Saint Sacrficed](#)
- [Flash! God-Killing Shadow](#)

- Episode 1: A Bitter Retreat
- Episode 2: Reorganizing
- Episode 3: Girls Reshuffled
- Episode 4: Lambda’s Favoirte
- Episode 5: Take No One Lightly

- Episode 1: Secret of the Heroes
- Episode 2: Church and Heroes
- Episode 3: Truth Amidst Lies
- Episode 4: The Lost Tribe
- Episode 5: Olivier’s Face

- Episode 1: The Situation Begins
- Episode 2: I Won’t Hurt You…
- Episode 3: Override Experiment
- Episode 4: Outcome of the Duel
- Episode 5: End of Scenario

- Episode 1: A Bodacious Debut
- Episode 2: Problematic Property
- Episode 3: An Aristocratic List
- Episode 4: A Thief of the Cult
- Episode 5: A Manor House Reborn

- Episode 1: Going Nowhere
- Episode 2: The Rolapoid Mk. 1
- Episode 3: Pictures of Us?!
- Episode 4: Check it!
- Episode 5: Memories in Photos

- Episode 1: A Hero’s Traces
- Episode 2: The Lakshmi Clan
- Episode 3: Saurva the Beast God
- Episode 4: Grave-robbing
- Episode 5: A Hero’s Confession

- Episode 1: Former Seven Blades
- Episode 2: Waters of Lindwurm
- Episode 3: The Goddess’ Trial
- Episode 4: Gold Dragon Showdown
- Episode 5: The Victorious Myth

- Episode 1: Wide-rang Investigation
- Episode 2: Cool Ninja Girl
- Episode 3: Tunnels of Midgar
- Episode 4: Hardcore Fan
- Episode 5: Garden Ninjustu

- Episode 1: Suspicious Water
- Episode 2: Underwater Secret
- Episode 3: Malak Hunting!
- Episode 4: Sanctuary Backdoor
- Episode 5: Plans for the Future

- Episode 1: Mist and Archives
- Episode 2: The Ignorant
- Episode 3: The Sealed Chapel
- Episode 4: The Call of Lili
- Episode 5: At a Later Date

- Episode 1: Return to Sanctuary
- Episode 2: Replicated Sanctuary
- Episode 3: A Hero’s Memories
- Episode 4: Sanctuary’s Defenses
- Episode 5: Violet Eyes

- Episode 1: Until We Meet Again
- Episode 2: Sacred Land Clash
- Episode 3: Paradise Lost
- Episode 4: Shadow Eat Shadow
- Episode 5: An End to Templars

- Episode 1: Victoria’s Whereabouts
- Episode 2: Backwater Village!
- Episode 3: Commencing Suppression
- Episode 4: Blasphemy
- Episode 5: Forgiveness
- Episode 6: Time Marches On
- To be continued… Part 4: Boughs of Shadow

- [The Seven Shadows Lurk](#)
- [A Land Without Magic](#)
- [In Training! Listen to Teacher](#)
- [The Strongest Pack!](#)
- [Traces! A Rose Hidden in History](#)
- [Lawless Denizens](#)
- [Beautiful Vampire Hunter](#)
- [Celebration! The Shadow Statue!](#)
- [Hide-And-Seek Battle](#)
- [Longing For the Haven](#)
- [His Unelegeant Friends](#)
- [Tracing the Traitor](#)
- [The Seven Shadows Hunt](#)

- Episode 1: The Mysterious War
- Episode 2: Seats of Discord
- Episode 3: The Lost Kingdom
- Episode 4: The Numberless Blues
- Episode 5: Family Food

- Episode 1: Alexanloris
- Episode 2: A Land Without Magic
- Episode 3: Atomic Heart
- Episode 4: Mysterious Creature
- Episode 5: Looking for Signs

- Episode 1: A Fine Day
- Episode 2: People vs Products
- Episode 3: Sales Training
- Episode 4: Complaint Training
- Episode 5: Nefarious Nobles

- Episode 1: To Know Strength
- Episode 2: Mighty is the Pen
- Episode 3: Flow of Magic
- Episode 4: Beat the Mist Dragon
- Episode 5: Delta's Dream

- Episode 1: A Familiar Pair
- Episode 2: Legend of the Black Rose
- Episode 3: Old Capital Danger Zone
- Episode 4: Girisly Experiment Site
- Episode 5: Magic vs Magic

- Episode 1: The Hunt for Knockoffs
- Episode 2: Lawless and Lively
- Episode 3: Eyes of the Fox
- Episode 4: In the Capsule
- Episode 5: Get Over Here!

- Episode 1: Tournament Memories
- Episode 2: The Vampire Hunter
- Episode 3: Differing Opinions
- Episode 4: Vampire Attack
- Episode 5: Red Moon Rising

- Episode 1: Garden's Celebration
- Episode 2: Garden's Movie
- Episode 3: Garden's Special Program
- Episode 4: Garden's Number
- Episode 5: Garden's Symbol

- Episode 1: Hide-And-Tag
- Episode 2: Searching Talent
- Episode 3: One-Of-A-Kind Strength
- Episode 4: Tyrant's Atomic
- Episode 5: I am Pi!

- Episode 1: TheBook of the Hunted
- Episode 2: First Villager Found
- Episode 3: Village of Vampires
- Episode 4: Natsume Kafka's Decision
- Episode 5: The Haven Now Gone

- Episode 1: Fashion Check!
- Episode 2: Shadow' Public Face
- Episode 3: Unknowing Extras
- Episode 4: Skel Po Assassination Plan
- Episode 5: Path We All Take

- Episode 1: Analysis of the Barren Land
- Episode 2: Count's Betrayal
- Episode 3: Defeat lagita
- Episode 4: Commando Alpha
- Episode 5: Ready For Battle

- Episode 1: A New Prelude
- Episode 2: Annihilation Battle: Part 1
- Episode 3: Annihilation Battle: Part 2
- Episode 4: Annihilation Battle: Part 3
- Episode 5: Supreme Atomic
- Coming Soon - Part 5: Edge of Realm

## Characters

- Cid Kagenou
- Claire Kagenou
- Iris Midgar
- Alexia Midgar
- Rose Oriana
- Sherry Barnett
- Shadow
- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Gamma](Gamma.md "Gamma")
- [Delta](Delta.md "Delta")
- [Epsilon](Epsilon.md "Epsilon")
- [Zeta](Zeta.md "Zeta")
- [Eta](Eta.md "Eta")
- [Nu](Nu.md "Nu")
- [Lambda](Lambda.md "Lambda")
- [Aurora](Aurora.md "Aurora")
- [Beatrix](Beatrix.md "Beatrix")
- Mundane Mann
- [Elisabeth](Elisabeth.md "Elisabeth")
- [Yukime](Yukime.md "Yukime")
- John Smith
- [Victoria](Victoria.md "Victoria")
- Annerose Nichtsehen

## Gallery

The Eminence in Shadow- Master of Garden RPG Announce Trailer

English Announcement Trailer

【陰の実力者になりたくて！マスターオブガーデン】PV

Game PV

『陰の実力者になりたくて！マスターオブガーデン』外典「散りゆく陰への鎮魂歌」AnimationPV：前島麻由「THE BAN」

## Trivia

- According to Daisuke Aizawa, the game is supervised and developed by others, but he has creative input. Daisuke now views a game as a place to tell stories and fill history gaps that he could not do in the light novel.[CITATION NEEDED]
- The game has name-dropped concepts and characters before the official light novel releases. One example is the names of a few organizations under the Knights of the Rounds: The [Loki](Loki.md "Loki") Sect, the [Hel](Hel.md "Hel") Sect, and the [Jormungandr](Jormungandr.md "Jormungandr") Sect.[[8]](#cite_note-)
- In a scene from the Apocrypha event, Rose speaks to [Elizabeth](Elisabeth.md "Elisabeth") about Oriana's kingdom, saying that she is now a [fugitive accused of being a traitor](https://the-eminence-in-shadow.fandom.com/wiki/File:Rose_confessing_that_she_is_now_a_fugitive_-_Apocrypha_Event.jpg).[[9]](#cite_note-9) This means that when the protagonist Cid and his group of girls traveled back in time, this would have occurred after the Trade War and just before the Oriana Civil War.

## External Links

- [Official Website](https://www.shadow-garden-mog.jp)
- [Official Twitter](https://twitter.com/Shadowgarden_PR)
- [Global Twitter](https://twitter.com/emishadow_rpg)

## References

1. [[Crunchyroll Games Overview](https://www.crunchyroll.com/games/eminenceinshadow/)]
2. [Master of Garden Official Website](https://www.shadow-garden-mog.jp/)
3. [Rose of Garden Event Trailer Announcement](https://x.com/shadowgardenmog/status/1628364110659469312)
4. 【カゲマス】付章「Truth Seekers」PV
5. 【カゲマス】付章「Interlude」[PV](https://www.youtube.com/watch?v=dc0O7AaPv3I)
6. [Masquerade Event Trailer Announcement](https://x.com/shadowgardenmog/status/1748661659114340829?s=46&t=LPFcBLo4FSd0hDDLWYOPPw)
7. [Apocrypha - "Trailer Announcement"](https://x.com/ShadowgardenMoG/status/1796526855434162196)
8. **Master of Garden**: Seven Shadow Chronicles, Part 1, Chapter 11-1
9. Apocrypha Event: requiem for scattered shadows" chapter 6 - Canon route 13
