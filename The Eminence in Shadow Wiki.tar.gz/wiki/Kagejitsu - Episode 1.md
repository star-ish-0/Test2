# Kagejitsu - Episode 1

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%201](https://the-eminence-in-shadow.fandom.com/wiki/Kagejitsu%20-%20Episode%201)

## Operation 1

## Special Title

### English

The Seven Shades want their operation to succeed

### Kana

七陰は作戦を成功させたい！

### Romaji

Shichi kage wa sakusen o seikō sasetai!

## Episode Information

### Season

1

### Episode

1

### Air Date

October 26, 2022

### Adapted From

Light Novel

## Staff

### Director

Minoru Ashina

### Writer

Daisuke Aizawa

Episode Navigation

| Next |
| --- |
| Operation 2 |

Operation 1 is the first episode of the spin-off series [Kage-Jitsu](Kage-Jitsu.md "Kage-Jitsu").

## Summary

Inside the lost castle of [Alexandria](Alexandria.md "Alexandria"), [Alpha](Alpha.md "Alpha") asks if all are present. Receiving an affirmative from [Beta](Beta.md "Beta"), [Gamma](Gamma.md "Gamma") comments on the rarity of all the Seven Shades congregating. [Delta](Delta.md "Delta") glances over at [Zeta](Zeta.md "Zeta") and interjects that it would happen more regularly if one member did not always disappear. [Epsilon](Epsilon.md "Epsilon") explains that such circumstances are expected; Zeta’s intelligence gathering necessitates long absences. Her response twists Zeta’s mouth into a smirk, and she provokes Delta by calling her a “Doggy”. Delta and Zeta begin to bicker, but a single clap from Alpha immediately ceases the quarreling. The meeting has officially started, prompting Delta to hastily adjuster her posture. Alpha asks Beta to outline the present situation. According to Beta, the demonic possession search device—suggested by Shadow and created by [Eta](Eta.md "Eta")—has bolstered Shadow Garden's members to over six hundred. Delta, Epsilon, and Zeta all offer exclamations of incredulity and general felicitations. Eta raises her hands and forms two Vs for victory; however, Alpha draws their attention away with the single word “but.” Beta finishes her sentence and concludes that it is far from satisfactory. Alpha continues that trail of thought, announcing that the expansion of Shadow Garden is imperative for Shadow’s ultimate goal. Epsilon quickly adds that the upcoming operation mandates perfect execution. Agreeing with Epsilon’s addition, Alpha orders Beta to report to Shadow and everyone else to their assigned positions. Saying yes in unison, most members dash away to their assignments, leaving Delta, Gamma, and Eta. Confused by Delta’s delayed departure, Gamma asks the [therianthrope](Therianthrope.md "Therianthrope") if anything is wrong. Delta hesitatingly asks the numerical significance of six hundred. Eta explains that it is a lot, causing a cheer from Delta.[[1]](#cite_note-KS1E1-1)

## Characters

- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Gamma](Gamma.md "Gamma")
- [Delta](Delta.md "Delta")
- [Epsilon](Epsilon.md "Epsilon")
- [Zeta](Zeta.md "Zeta")
- [Eta](Eta.md "Eta")

## Gallery

End Credits

## Trivia

## References

1. ["Operation 1: The Seven Shades Want Their Operation to Succeed"](https://www.youtube.com/watch?v=W1o5QiUzcpE) YouTube, October 26, 2022

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| **Episode 1** • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
