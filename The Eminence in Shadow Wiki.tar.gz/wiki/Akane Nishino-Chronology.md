# Akane Nishino/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Akane%20Nishino/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Akane%20Nishino/Chronology)

Main

Relationships

Image Gallery

## Background

### Early Childhood

Akane Nishino, born into the Nishino family and sister to Akira, gained prominence in her childhood as she embarked on an acting career, quickly rising to fame as a child actress. However, during her junior high years, she experienced a traumatic event when a stalker kidnapped her, leading to a scandal that deeply affected her. This incident compelled her to pause her acting career, and her parents took measures to ensure her safety by arranging a driver for her daily commute to and from school.

She resumed acting in high school, where she encountered Minoru Kageno, a peer she despised because she felt invisible to him. After a remedial class, unable to reach her driver, she opted to walk home. In route, a black van pulled up, and two men emerged to kidnap her. As she slipped into unconsciousness, Minoru, who was coincidentally present, was the last person she glimpsed.

Upon regaining consciousness, much to her horror, she woke up to discover herself tied and gagged. She learned from her abductors that they intended to use her as ransom from her parents before one of them tried to have their way with her. Before one of them tried proceeding, Minoru dressed as an anonymous figure dubbing himself as "Fancy Hoodlum Slayer" broke into their hideout and knocked out the would-be violator. Initially struggling to fight off the other abductor who revealed himself as an ex-soldier, during their brawl the ex-soldier recognizes him as the "Ski Mask Berserker" that had been terrorizing the local motorcycle gangs. Shortly after which Minoru brutalizes him after getting serious and revealing the real potential of the crowbars, that is, to whack with pure, unbridled speed and violence. After brutalizing Akane's abductors, Minoru freed Akane and told her to be more careful next time before fleeing the scene. Inexplicitly freed from her abductors, Akane's parents did not go public with the incident and only a selected few knew of it.

The next day, Akane reminisced about the events before she met Minoru at the school gates. To her astonishment, Minoru recalled her name, marking the moment their relationship started to mend as she opted to try conversing with him again.[[1]](#cite_note-V4AC-1) She spent time observing him and eventually came to realize that he was the ski-masked vigilante who had rescued her, which led to her developing romantic feelings for him. However, Minoru tragically passed away in a vehicle accident.[[2]](#cite_note-2) Akane was so deeply impacted by his death that she preserved his school uniform, holding onto the hope that he would return one day.

### The Birth of the First Knight

Approximately three years prior to Minoru's reincarnation as Cid Kagenou, and a few weeks or months following Minoru's demise, Japan faced an invasion by Magical Beasts. About a year after this invasion, Akane participated in a project at a human settlement known as [Arcadia](Arcadia.md "Arcadia"), serving as a test subject to develop warriors to fight against the invasive species.[[3]](#cite_note-V4C5-3) Akira initiated the project upon learning of the existence of warriors known as "Knights." The project was a success, endowing her with magical powers, and she was soon hailed as the "Original Knight." Despite this triumph, Akira remained unsatisfied and persisted in experimenting on his sister, contrary to a scientist's advice. This endeavor to amplify her powers disastrously failed when Akane lost control of her magic, unleashing havoc on Arcadia and resulting in numerous fatalities.

The traumatic event had led Akane to suppress the memory so deeply that it was nearly obliterated. Suffering from amnesia, Akane, along with Akira, sought sanctuary with a group known as Messiah, which was based at the university once belonging to their deceased family. Subconsciously, Akane held onto fragmented memories of the event, which eventually gave rise to overwhelming guilt and suicidal thoughts, causing her to hold human life in higher regard.[[4]](#cite_note-V4E-4)

Throughout their tenure at Messiah, Akane and Akira swiftly ascended the ranks, achieving the positions of captain and scientist, respectively. Akane's exceptional skills led many, including her own squadron, to hail her as their savior, a title she reluctantly accepted, insisting it was an overstatement, and she was merely fulfilling her duties. While at Messiah, Akane frequently found herself reflecting on her high school days, secretly wishing for Minoru to come to her rescue once more during challenging times.[[5]](#cite_note-V4C4-5)

## Volume 4

### Reunion

#### Light Novel/Manga

Now at the age of 20, Akane and her squadron explored an abandoned hospital where three knights had previously vanished. Knowing the area was a breeding ground for magical beasts, Akane initially resisted her team's insistence to join her, but eventually relented. After defeating numerous magical beasts, she stumbled upon an unusually large number of their carcasses. She theorized that only an Apex Beast, which she named "[Brute](Mordred.md "Mordred")", could be responsible. Her hypothesis seemed confirmed when a squad member found two [survivors](Beta.md "Beta"). Despite her team's misgivings about one survivor showing signs of awakening powers similar to hers, Akane insisted on their protection and commanded that they be taken to the Messiah's infirmary.[[5]](#cite_note-V4C4-5)

At Messiah's infirmary, Akane and her brother were briefed by the nurse, [Yuuka](Yuuka.md "Yuuka"), about the condition of two survivors. Yuuka revealed that the boy remembered nothing but his name. When Akane learned his name was Minoru, she was startled by his resemblance to a deceased classmate. Akira, suspecting that Minoru's sister Natsume was an awakener like Akane, decided to conduct experiments on her for hidden motives. Despite Akane's objections, her concerns were dismissed, and she could only hope for Natsume's safety.

Later, as the infirmary became overcrowded, Akane chose to take Minoru into her care, suspecting a link between his resemblance to her late classmate. The nurse expressed shock, but Akane reassured her, citing her adulthood and his youth as reasons not to worry. Following this, a former classmate, Yuudai Saejima, approached Akane about the overcrowding. He proposed using Minoru as a scapegoat to be devoured by magical beasts. Disgusted, Akane confronted him, which angered Yuudai, who left, accusing her of being a murderer with a dark history.

Following a heated argument with a former classmate, Akane checked on Natsume. During her visit, Akira stormed in, enraged about his missing camera. Natsume, suspected of theft, used her charm to convince the Nishinos and her caretaker of her innocence. Although Akira promised to look after her, he was preoccupied with preparing for a magical beast stampede, revealing his team's discovery of the Brute's remnants. Akane questioned his priorities, but the scientist dismissed her concerns, determined to create a stronger, more pliable pawn.

The next day, Akane assisted Minoru in moving into her room, seizing the chance to have him wear her deceased classmate's uniform. Overwhelmed by nostalgia upon seeing him in the Sakurazaka High School uniform, she broke down, mistaking Minoru for her late classmate. After a moment of reflection, she left to launder his clothes. Meanwhile, Yuudai, consumed by jealousy, burst in and accused Minoru of espionage, threatening him with torture. Akane, appalled by such misuse of authority, stood up for Minoru, arguing that the real spy had infiltrated their ranks long before his arrival. Yuudai departed, leaving a reminder of an urgent meeting, as Akane fumed over his despicable demeanor.[[3]](#cite_note-V4C5-3)

Akane, who arrived late, was excused by Commander [Haitani](Haitani.md "Haitani"), the meeting's host. During the session, Haitani presented the Knights with photographs showing numerous magical beasts' corpses at Nishino Elementary and Senior High. Yuudai, taken aback, rejected the notion that a single individual could achieve such a feat, even though the Commander suggested the First Knight might be responsible. While there was speculation about who could accomplish such acts, Haitani countered that there was no proof, dismissing it as mere conjecture, just as an alarm signaled an impending magical beast stampede.

During the stampede, Akane stood with her fellow knights to protect their stronghold. Despite their valiant efforts, the defenders were slowly overpowered. Against her superior's objections, Akane chose to draw the horde away from the base by acting as bait. Her plan nearly led to her demise until a figure in jet-black robes appeared, vanquished the remaining creatures, and then vanished. Following the turmoil, Yuuka revealed to her that Yuudai had been killed. Akane's strained relationship and history with her ex-classmate cast her as a suspect. Even as Minoru vouched for her innocence, Akane's mental state deteriorated until Yuuka tranquilized her, rendering her unconscious. Neither Minoru nor the Messiah knew that Yuuka had taken her to an isolated location.[[6]](#cite_note-V4C6-6)

After the nurse incited a stampede, the Black Knight and Natsume, who were Shadow and Beta, confronted her. She confessed to being the spy responsible for Saejima's death and a survivor of Arcadia seeking vengeance against the First Knight for her husband's death. Her husband, the scientist who attempted to curb Akira's worsening condition, succumbed to power and continued his experiments until disaster struck, claiming his life.

When the spy administered the Brute's blood to Akane, the former student's memories resurfaced. Overwhelmed, she reverted to her First Knight persona, becoming uncontrollable and fatally wounding the spy. Shadow, adeptly avoiding her frenzied attacks, restrained Akane with enchanted chains, calming her. Before losing consciousness, she was cautioned against further capture, a warning she distinctly heard.

Awakening in an unfamiliar room, Akane pieced together the events and the Black Knight's identity as Minoru Kageno. Determined to make amends, she pledged to redeem herself before seeking reunion with him.[[4]](#cite_note-V4E-4)

## Volume 5

### Under Shadow Garden's Custody

Akane was referenced briefly when [Eta](Eta.md "Eta"), a scientist from Shadow Garden, was taken to the Oriana Kingdom by [Gamma](Gamma.md "Gamma") to present her research findings to [Alpha](Alpha.md "Alpha"). In her report, Eta mentioned that Akane has a name and spoke in an incomprehensible language. She ended her report by stating that Beta's translation skills would be necessary and that the silver-haired elf introduced multiple technologies powered by electricity.[[7]](#cite_note-7)

In her journal, she detailed that the technology Beta had smuggled was irreparable with their current capabilities and estimated a 20-year gap to reach parity. Her report on the former student noted a physique more akin to humans than elves or therianthropes, along with underdeveloped magic. She expressed regret for not dissecting the subject when Beta intervened, believing it could have been done non-lethally. Convinced that Shadow had brought Beta to the Other World to advance their understanding, she sought permission for surgical exploration on the extraterrestrial. Ultimately, she surmised that the teachings of Shadow were linked to Beta's contributions, which piqued her interest in his enigmatic knowledge.[[8]](#cite_note-8)

## Volume 6

### Inside Shadow Garden

Upon waking up, Akane finds herself in an unfamiliar room and tries to escape but then meets [Beta](Beta.md "Beta"), who then explains that she's currently inside Shadow Garden's base. Akane, while exploring the base, is in awe at how advanced their magic technology is in comparison to Japan and how strong their combatants are. Beta urges Akane to fight against their weakest combatant which, at that time, is [711](Millia.md "Millia"). Akane manages to bring their fight to a draw, piquing [Eta](Eta.md "Eta")'s interest. Beta, [Epsilon](Epsilon.md "Epsilon") and the Numbers tries to stop Eta but fails due to her Anti-Magic inventions. Eta tries experimenting Akane using knowledge obtained from Sherry Barnett but was stopped by [Alpha](Alpha.md "Alpha"), who counters her Anti-Magic inventions. Alpha proceeds to put Eta into probation and Akane vows to save Minoru after hearing that he's still alive, mistakenly believing that he is being experimented on by Shadow Garden.[[9]](#cite_note-9)

## Major Medium Differences

### Volume 4

In the novel, Akane walked home after her cell phone lost power. In the anime, Akane walked home after her driver didn't pick up her call. Unbeknownst to her, her driver was assaulted by two assailants.

## References

1. Volume 4 Auxiliary Chapter: Rise of the Fancy Hoodlum Slayer!
2. Episode 1
3. Volume 4 Chapter 5: Sneaking Around in Japan, Just like the Old Days!!
4. Volume 4 Epilogue: Behold, a Full-Fledged Eminence in Shadow!
5. Volume 4 Chapter 4: Lurking in the Darkness in Fantastical Japan!
6. Volume 4 Chapter 6: Something Smells Fishy... But an Eminence in Shadow Always Cracks the Case!
7. Volume 5 Chapter 4: Peace in Our Time!
8. Volume 5 Eta’s Research Journal
9. Volume 6 Chapter 5: Welcome to Shadow Garden!
