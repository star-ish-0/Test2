# Episode 1

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%201](https://the-eminence-in-shadow.fandom.com/wiki/Episode%201)

## The Hated Classmate

### Kana

嫌いなクラスメイト

### Romaji

Kirai na Kurasumeito

## Special Title

### English

Minoru Kagenou Wants To Shine From the Shadows!

### Kana

影野ミノルは陰に潜んで活躍したい！

### Romaji

Kageno Minoru wa Kage ni Hisonde Katsuyakushitai!

## Episode Information

### Season

1

### Episode

1

### Air Date

October 5, 2022 JP
December 26, 2022 EN

### Adapted From

Chapter 47 (MN)
Volume 1, Volume 4 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

Episode Navigation

| Next |
| --- |
| Shadow Garden Is Born |

The Hated Classmate (嫌いなクラスメイト, Kirai na Kurasumeito[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the series premiere and the first episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Akane copes with her trauma by being popular and working hard to make people like her, but one boy in her class doesn’t care about her at all. That bothers her to no end.[[1]](#cite_note-1)

「陰の実力者」。それは、主人公でも、ラスボスでもない。普段は実力を隠してモブに徹し、物語に陰ながら介入して密かに実力を示す存在。
影野ミノルは幼少期からの夢である“陰の実力者”になるべく、着々と準備を進めていた。[[2]](#cite_note-2)

## Summary

One bright morning in the city of Sakurazaka, Akane Nishino wakes up and starts her daily routine of showering and dressing. Leaving the house, Akane and a chauffeur depart for her high school—a black van quietly watches the car drive away.

Akane arrives at the school and greets the many students vying for her attention. At the entrance, she encounters the one classmate she hates, Minoru Kageno. They exchange greetings, but he calls her Nishimura, much to her annoyance. She corrects Minoru and says that her name is not Nishimura. Minoru apologizes, stating he was pretty good at remembering named NPCs. Sleep frequently eludes him. This time, he calls her Nishitani. She gets quietly annoyed and corrects him again by repeating her actual name. Minoru again gets it wrong and calls her Nishimura, leaving the flabbergasted girl to her fuming. Akane notes that she does not despise him for getting her name wrong. The disdain comes from the fact that he never looks at her. Even when his eyes face her, they seem to be looking somewhere far off.

Going about her school day, Akane recalls back to when she was in middle school. She had to take a break from show business due to a scandal and has been hiding behind a mask of composure ever since. She plays the teacher's pet so that the teachers like her and plays the popular girl so students admire her. Akane carefully deliberates every action to ensure no one hates her.

After school, she calls her driver, but he does not answer due to his being assaulted. Without a driver, Akane walks home, which she has not done since the incident in middle school. On her way, the men that attacked the driver appear and abduct her. While she loses consciousness, she sees Kageno hiding around a corner.

Akane subsequently wakes up restrained in some warehouse. Noticing her movement, one kidnapper tells her that the daughter of Nishino Zaibatsu should not walk alone at night. The other kidnapper states that she just needs to stay there. Once they get the ransom, the kidnappers will set her free. Outside, Kageno observes the kidnapper and moves to change clothes and don a mask. The more energetic kidnapper expresses a desire to have some fun with Akane. He notes that this should be her second kidnapping, as the first time was because of some stalker. Before any assault occurs, Kageno comes crashing down from the roof window and introduces himself as a stylish ruffian slayer. The lead kidnapper pulls out a gun, but the masked Kageno quickly disarms him with a well-thrown shard of glass. Kageno then charges the guy, throwing him to the ground before smashing his face. Observing his moves, The other kidnapper recognizes that Kageno possesses legitimate skill. He comments that boredom overtakes him while doing kidnappings with amateurs.

The remaining kidnapper notes he is a veteran and readies a knife to attack Kageno, who uses crowbars. Although Kageno manages to disarm the man, the weight and height class disparities soon overwhelm him. Deciding to give up using crowbars like a tonfa, he instead presented their true potential as clubs, which he discovered during his skirmishes with bikers. From this comment, the man realizes the identity of his opponent. The Balaclava Berserker: A man who has been fighting the bikers with crowbars. Kageno then proceeds to break the man's leg and brutalizes him, ending the fight and turning his focus to Akane. Taking the kidnapper's knife, Kageno then frees Akane and tells her to be more careful next time. Akane then calls the police, and her father uses his connections to prevent the case from going public.

The next day, Akane goes to school and greets Kageno once more, but he correctly calls her Nishino. Instinctively correcting him, she stops when she realizes he got her name right. Peering at his eyes, he seems to be looking at her for once. She felt he was also living behind a mask, but she never got to confirm her suspicions. The hated classmate Minoru Kageno was now dead, run down by a truck.

Delving into the mind of Kageno, he cannot recall when his fascination began, but he has always dreamt of being a powerful being. He spent his days training while acting as the "background character" in his school life. Kageno reached a point where he triumph in general fights, but humans have limitations. If he became the best martial artist in the world, he might be able to beat an armed detachment of soldiers, but he would be powerless against a nuclear missile. Kageno wants to overcome those limits and is determined to do so no matter the cost. After being hit by a truck, Kageno is reborn in a new world. It is a post-industrial revolution planet with still emerging technologies, populated by various fantasy races. In this new world, Kageno had obtained magic and a group of dedicated subordinates. Now, he wants to live out his previous life goal: to be the puppet master who secretly pulls the strings in the shadows—The Eminence in Shadow.

## Characters

- Akane Nishino
- Cid Kagenou/Minoru Kageno (Earth)
- [Alpha](Alpha.md "Alpha")
- [Beta](Beta.md "Beta")
- [Gamma](Gamma.md "Gamma")
- [Delta](Delta.md "Delta")
- [Epsilon](Epsilon.md "Epsilon")
- [Zeta](Zeta.md "Zeta")
- [Eta](Eta.md "Eta")
- [Nu](Nu.md "Nu")
- [664](664.md "664")
- [665](665.md "665")
- Rose Oriana (Cameo)
- Alexia Midgar
- Claire Kagenou
- Iris Midgar (Cameo)

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第１話予告≪ノーマルVer.≫「嫌いなクラスメイト」

TVアニメ『陰の実力者になりたくて！』第１話予告≪スペシャルVer.≫「影野ミノルは陰に潜んで活躍したい！」

## Trivia

- During the scene where Minoru recalls all of the martial arts that he has learned, there was a reference to the Web Novel of Minoru learning Kendo.

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e001>
2. <https://shadow-garden.jp/1st/story/#story1>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| **Episode 1** • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
