# Cid Kagenou/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Cid%20Kagenou/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Cid%20Kagenou/Image%20Gallery)

Main

Chronology

Relationships

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Profile Pictures

Cid's profile as Minoru in English

Cid's profile as Minoru in Japanese

Cid's profile in English

Cid's profile in Japanese

Volume IllurstationsLight Novel Volume Cover

Volume 1 Cover Japanese

Volume 1 Cover English

Volume 2 Cover Japanese

Volume 2 Cover English

Volume 3 Cover Japanese

Volume 3 Cover English

Volume 4 Cover Japanese

Volume 4 Cover English

Volume 5 Cover Japanese

Volume 5 Cover English

Volume 6 Cover Japanese

Volume 6 Cover English

Cid's previous life Minoru

Cid Kagenou in Chapter 2

Cid Kagenou in Chapter 20

Cid in his outfit as Shadow, chapter 15

Cid Kagenou with Slime Makeup

Cid in his John Smith guise, chapter 34

Cid in his Jack the Ripper guise, chapter 67

Cid in his Jean Pierre guise, chapter 77

Young Cid and Claire

Shadow defeats Aurora

Cid and Claire on Manga Chapter 30 Cover

Sketch

Anri's Thanks For The Over 6 Million Copies That Where Sold Illustrations Akane & Cid by SakanoAnri

Season 1

Cid meets Alpha

Cid's "confession" to Alexia

Cid practices with Alexia

Cid visited by Alpha

Cid finding Beta/Natsume at a book signing.

Season 2

Atomic Recovery

John Smith Disguise

Cid Making Off with Po's Money

Cid and Claire

Cid and Zack

Design

Minoru, Cid's previous life

Minoru as the "Stylish Ruffian Slayer"/Ski Mask Berserker

Cid in his Midgar Academy attire

Cid as Shadow

Cid in his Mundanne Man costume

Cid in his John Smith disguise

Minoru/The Balaclava Berserker, in Cid's previous life

Illustration

Hidden Powerhouse: Cid Kagenou

Another NPC Day: Cid Kagenou

NPC Technique: Cid Kagenou

Mundane Mann: Cid Kagenou

John Smith: Cid Kagenou

Awakening Hour: Shadow

Eminence in Shadow: Cid Kagenou

The Master: Shadow

Reign of Violet Light: Shadow & Aurora

Shadow of the Night: Shadow

Shadow of the Beginning: Shadow

Cid alias Shadow: showing his face in the night

Founding Duo: Shadow & Alpha

Fox-Masked Eminence: Shadow

Poster

Master of Garden Twitter Anime Expo 2023

Shadow Garden Twitter Anime Expo 2023

Seven Shadows Chronicles: Cid and Claire Family Food
