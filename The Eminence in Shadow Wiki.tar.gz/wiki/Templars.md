# Templars

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Templars](https://the-eminence-in-shadow.fandom.com/wiki/Templars)

UNVERIFIED WIKI PAGE

Compiling Shadow Wisdom is continuous, but archivists are not omniscient. Shadow Garden encyclopedists have marked this page as potentially containing inaccurate or misleading information. We will dispatch researchers to verify the content as quickly as possible. Please be advised that a complete rework is conceivable.
Thank You For Your Patience

CLEANUP: ONLY YOU CAN IMPROVE THE WIKI!

You do not need to have peregrinated around Midgard or experienced dimensional travel help here. Shadow Garden encyclopedists have marked this page to be cleaned up by the community. You can assist the wiki by proofreading or checking if this article follows our standards and layout guide. Your contributions will make the wiki better for everyone in this community.

## Templars

### Japanese

テンプラー

### Romaji

Tenpurā

## General Information

### Leader(s)

[Victoria](Victoria.md "Victoria") (formerly)

### Status

Active

### Affiliates

Holy Church of Divine Teachings
Cult of Diablos (loosely rival associate)

### Base of Operation

Holy State of Orum

## Debut

### Web Novel

Chapter 48 (Mentioned)

### Light Novel

Volume 2 (Mentioned)

### Game

Seven Shadows Chronicles: Chapter 5

Templars (テンプラー, Tenpurā[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the Church's secret transnational organization that has been created by radical factions during their founding history. Its principal mission is to strivenly proceed on their perfect vision that has imposed for their religion and indirectly doing the Church's dirty work in the dark to preserve the world from any heretics against Goddess Beatrix.

Having operated in the shadows for thousands of years unnoticed by the public, the Templars had the responsibility of "Inquisition" rights and served as an execution department as they answerable only to the Church's authorization headed directly by Grand Inquisitor authorized by the Auditor, which filled with extremist members in their own philosophical religious zealots methodology to kill those who had been recognized as heretics, especially those with [Possession](Possession.md "Possession") symptoms.

Due to their stance against the possessed, the Templars have always clashed with the Cult of Diablos who have had a working relationship with the Church and have repeatedly fought against each other from behind the scenes to fight over the possession that their long conflict still continues until a new opposition emerged from hidden organization called Shadow Garden that shrouded in mystery, which has been labeled heretical by the Templars and currently have been still faced them for hindering their work by saving those who affected with the possessed.

## Overview

The Templars are an secret assassination organization operating under the high command of the Church authorities in charge of the Inquisition based out of Orum with their ongoing history and deeds to root out and punish heretics since ancient times. The Templars served as an de facto execution squad that specialized to kills anyone labeled a heretic, including to eliminated those with [Possession](Possession.md "Possession") symptoms on the basis of purification in the name of Goddess Beatrix from the shadows.

The Templars are from the dark side of Church's history and that apparently, it is comprised of fierce soldiers who have been through training so harsh that their members were indoctrinated to be brainwashed with radical teachings. The Templars' method of silencing leaks was when any member who might be interrogated due to the situation of being caught would commit suicide, in order to prevent their information from being leaked by self-detonation when they were taking the suicide pills.

Before the emergence of Shadow Garden, the Templars were the only oldest opposition capable of fighting the Cult of Diablos. The Templars were formally led by the Saint, [Victoria](Victoria.md "Victoria") which secretly leading a murderous group working hidden in church dogma.

## Appearance of members

## General attire, of the normal templars, of the organization.

## Attire of the Templars, of the leader type, of the organization.

The Templars at a general level wear white clothing, a white shirt with long sleeves, white in color, they carry with them a mini cape that covers their shoulders, leaving part of their chest open, white with red stripes. His clothing in general is a long scorpion coat for men, whose length reaches the union, at the foot, with a red stripe around it, at the end of this, carrying a belt at the waist, and his pants are, as seen, black, very long, down to the feet, and they wear boots, black and white.

The design of their shirts, in the upper part of their necks, they carry with them, a large red tie with single buttons, and the edges of the final sides of the tie are of a semi-gloss color. Their hands are wrapped in black overall gloves, and around their necks, they wear a black necklace, with a symbol ornament, that represents their organization. Their necks in general are covered by a layer of cloth that covers their entire neck, and on their heads they carry raven-shaped masks that cover their entire faces, while the rest of their heads, It is wrapped by the white cloth hood of their clothing, and they carry with them some hats, somewhat large, black in color, with a white stripe in the center of the head.

Although the Templars all wear the same clothes equally, there are those who wear somewhat different attire than the others, who would be the leading captains of the Templars at a normal level. The design and attire of the Templars type leader does not change much, unlike the normal Templars, these on the other hand, are heavier and stronger, with a more intimidating appearance, they wear chains that cover almost their entire arms, which they are hanging, and some thick gloves, on their hands, white with black, with reinforcement, on the nudiyos, some thick chains, which wrap their necks, in a semi-open way, and their hats, are all white.

## History

Templars is a special unit of the black sub-division that originally created to upheld their ideologic ulterior purposes for their religion dogmatism from the darkness in charged with the active pursuit and extermination of all things vile and unholy and they answered directly to the Church. As a top-secret section of the Church's institutions, they officially doesn't exist.

True to their name, they had the "Possession Inquisition Act" (〈悪魔憑（あくまつ）き〉の審問（しんもん）法（ほう）, 〈Akumatsuki〉 no Shinmon-hō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) which describing about many Templars' ways to execute the possessed symptoms when Templars are using the underground chamber at the Orum cathedral that is made for the Inquisition which are used to place a heretics brand on any subject with the [Possession](Possession.md "Possession"). Templars' existence is so secret that they are cleverly hidden their presence from the public and there was no hint of information about this dark branch's underground sub-organization, even within the Knight Order.

Although having a very important task for the Church in carrying out their actions against the possessed, the Templars have an internal conflict with the Cult of Diablos which is a heretical organization that has existed since before the Holy Church of Divine Teachings was founded intending to secure the possessed as their experimental material. Despite their respective resemblances on gathering the possessed symptoms, their long standing dispute still continue to strive for throughout history with Templars always executing the possessed to avoid their use without even handing over to the Cult, which wants to secure it.

It seems the Church also kept all the detailed records of the Templars' activities showing the places, times and people involved in the Cult gathering up the possessed, even have future entries in their records. All of the records contain a schedule which indicates that the Templars are gathering Cult's intel to get to those possessed before the Cult does.

Moreover, the Templars have created suicide pills, which is a potent poison that uses magic as a trigger. Triggering it requires use of refined magic and hence the pill has been used as a ritualistic poison to bestow death for acts of heresy recognized by the Church.

## Organization Strength and Influence

Templars boasted their superior on magic resistance and strong magical defense against physical attack due to their undergone advanced combat training with high intensity. Additionally, the Templars were very secretive on their methods of silencing any leaks of information about their whereabouts by killing themselves and eliminating everyone, including members from the Cult who might expose their organization.

However, the Templars are set under a different chain of command as they only answered to the Church. In fact, the Templars were an organization within the Church in charge of the Inquisition, which can be used against any nations government that it could make the whole world an enemy of the Church. In other words, the Church's right of Inquisition is represented as a huge power to keeps balance between the Templars and the Cult of Diablos.

Templars exercised the rights of Inquisition on a rotational basis for four years, with the bishops of Orum serving as auditors. The reason was to prevent abuse of the Inquisition's rights by the bishops of each diocese and the monopoly over Inquisition rights by the Cult.

## Membership

Templar membership is highly classified that no one in public society knows the whereabouts of its members due to their fanatical nature which assembled under the Church's banner. Members with extremist dogmas have been taught ideologic radical doctrines on the Church's propaganda to maintained lasting peace to the world in eradicating all filth by punishing heretics against the Goddess and executing the [possessed](Possession.md "Possession") accordingly under the pretext as "purification".

## Chronology

### Foundation and Operations

### Conflict with the Cult

### Encountering and Investigate "Mysterious Organization"

### Daughter of the Marquess Marquez family Case

### Sergey Gorman's Conspiracy

## Equipment and guardian creatures

## Known Members and Hierarchical Command

### Grand Inquisitor

- [Victoria](Victoria.md "Victoria") (Formerly)

### Auditor

- [Drake](Drake.md "Drake") (Deceased)

## Trivia

- The design and attire of the Templars, is inspired by the attire of "[The Doctors of the Black Plague"](https://en.wikipedia.org/wiki/Plague_doctor), which made it, all over Europe, during the 14th century, along with a rare combination of a normal white attire, worn by followers. of the church.
- Both the story and the other things that are known about the organization of the Templars are constructions of the Game as such, since they have only been mentioned, in the Light Novel, Web Novel, while the Manga and anime, not yet.
- According to [Drake](Drake.md "Drake"), the reason why the Cult of Diablos and the Church, which emerged from the Cult, supported each other is that the Church is in the position to exercise the right of Inquisition, not the Cult. In other words, what the Templars should protect more than their duty as inquisitors are their positions as guards.[[1]](#cite_note-1)
- Although the church and the Cult of Diablos seem like separate organizations, the truth is that the church, in technical terms, is part of the cult, since all its history, fame, faith and other things were devised and achieved at the level, by Cult help.[CITATION NEEDED]
- It seems that neither the church itself nor the Templars as such know the objective that the cult seeks as such, nor that the church itself as such was already taken over by the Cult from the beginning, and that the church as such , it's just another wearable puppet for them.
  - This is demonstrated, when the interim Archbishop Nelson, takes Drake place, as well as the new leader of the Templars for a while, without them knowing that he is one of the leaders of the Cult, before dying at the hands of Shadow.
- As much the beliefs, as the own faith that they have on the people, and the supposed "goddess Beatrix", who blessed the three Heroes of the other world, according to the story, is a lie propagated and made, by the Cult of Diablos, to avoid knowing the true evil and origin of everything that happened, more than 1000 years ago.[CITATION NEEDED]

## References

1. Master of Garden Seven Shadows Chronicles, Chapter 18: Investigation! In Search of Oil

## Site Navigation
