# Mrs. Kagenou

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Mrs.%20Kagenou](https://the-eminence-in-shadow.fandom.com/wiki/Mrs.%20Kagenou)

## Mrs. Kagenou

### Japanese

オカン・カゲノー

### Romaji

Okan Kagenō

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Female

### Age

Unknown

### Height

Unknown

### Hair Color

Black

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

### Relatives

Mr. Kagenou (Husband)
Claire Kagenou (Daughter)
Cid Kagenou (Son)

## Professional Information

### Occupation

Noble

### Affiliation

Kagenou Family

## Debut

### Web Novel

Chapter 4

### Light Novel

Volume 1

### Manga

Chapter 2

### Anime

Episode 2

### Game

Chapter 1 - Episode 1

## Portrayal

### Japanese

[Mai Nakahara](https://en.wikipedia.org/wiki/Mai_Nakahara "wp:Mai Nakahara")

Mrs. Kagenou (オカン・カゲノー, Okan Kagenō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the mother of Cid and Claire, and the matriarch of the Kagenou family. Like her husband, she is a noble overseeing a sector land within the Midgar Kingdom. She is ignorant to her son's true affiliation and her daughter's [possession](Aurora.md "Aurora").

## Appearance

Mrs. Kagenou is a pretty young woman with silky black hair that reaches to her shoulders, with bangs parted to her right and locks of hair in front of her ears. She wears a long-sleeved shirt, a short-sleeved women's formal vest, a ruffle tie, two layered dresses with a frilled vest, short-heeled shoes atop white socks, a notable eggshell white ascot, a long sleeve white blouse with frilled cuffs and a blue headband accessory. Altogether, Mrs. Kagenou appears to be the low-class Noblewoman she and her husband are, and dresses accordingly.

## Personality

Mrs. Kagenou seems to be warm and pleasant on the surface, especially regarding her children's upbringing, but can be quick-tempered and violent if justifiably provoked. She did not hesitate to viciously attack her husband for his cowardice when their daughter, Claire Kagenou, was abducted, calling her the only 'hope of the family', as well calling her own husband "Baldy."

She is also somewhat careless towards Cid, letting him do what he wants to focus more on Claire's growth, mainly due to Claire's prodigal aptitude for the sword and Cid's blatant nonchalant.

## Chronology

At some point in time Mr. and Mrs. Kagenou met and got married. And at some point, in time, they had Claire.

### Birth of Cid Kagenou

Mrs. Kagenou was genuinely happy to have had Cid. However, as he grew older and showed no aptitude for anything, she focused more on Claire's growth, while allowing Cid to do as he wished. This was mainly due to Claire's aptitude helping to keep their family in regard to the kingdom's peerage.

### Claire Kagenou Abduction

Following the discovery of Claire's abduction, Mrs. Kagenou was overflowed with rage due to her husband's cowardice and hesitance in taking action. So, she directed her rage towards him, violently attacking him as there son left the scene.[[1]](#cite_note-V1C1-1)

### Bushin Festival Tournament

In the anime after hearing that Claire had won the Bushin Festival, hearing of her husband excitedly talking about their daughter's victory. However, she would violently attack him for not doing anything about their son.[[2]](#cite_note-2)

## Powers & Abilities

Despite not being a Swordsman, Mrs. Kagenou has shown to have impressive strength, as when she violently attacks Mr. Kagenou, the onslaught can create powerful shockwaves.[ANIME ONLY][[3]](#cite_note-3) The punch is also strong enough to send him flying up in the air.[[4]](#cite_note-4)[MANGA ONLY]

## Relationships

### Claire Kagenou

As a mother, she loves Claire very much, as evident when she was very worried after her daughter was kidnapped.

### Cid Kagenou

Mrs. Kagenou loves Cid like any mother could, but not more than Claire, as she loves her children equally and because she considers her own son not to have good abilities in all fields. She is concerned for his future, as she would reprimand her husband for not disciplining him well enough.

### Mr. Kagenou

She respects her husband but usually scolds and slaps him whenever he doesn't confront his responsibilities properly. When a problem occurs, her husband often makes excuses to avoid the problem, so she doesn't hesitate to savagely attack and ridicule her husband's cowardice, calling him "Baldy" as an insult.

## Image Gallery

### Anime

### Manga

## Trivia

- Her surname Kagenou (カゲノー, Kagenō[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")). The word カゲ in her surname means "shadow" in Japanese.
- Both Claire and Cid have a higher opinion of their mother than of their father.[CITATION NEEDED]

## References

1. Volume 1 Chapter 1: Starting the Shadowbroker Tutorial!
2. Episode 20
3. Episode 2
4. Manga Volume 1 - Chapter 2

## Site Navigation
