# Episode 7

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%207](https://the-eminence-in-shadow.fandom.com/wiki/Episode%207)

## A Fencing Tournament of Intrigue & Bloodshed

### Kana

謀略と流血の剣術大会

### Romaji

Bōryaku to Ryūketsu no Kenjutsu Taikai

## Special Title

### English

The Eminence in Shadow Wants To Show off the Mastered Technique!

### Kana

陰の実力者は極めた奥義を見せつけたい！

### Romaji

Kage no Jitsuryokusha wa Kiwameta Ōgi wo Misetsuketai!

## Episode Information

### Season

1

### Episode

7

### Air Date

November 16, 2022 JP
February 6, 2023 EN

### Adapted From

Volume 1 (LN)

## Staff

### Director

Kazuya Nakanishi

### Writer

Kunihiko Okada

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Zeta ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Pretenders | Dark Knight Academy Under Attack |

A Fencing Tournament of Intrigue & Bloodshed (謀略と流血の剣術大会, Bōryaku to Ryūketsu no Kenjutsu Taikai[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the seventh episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

Cid gets a report from [Nu](Nu.md "Nu") about powerful cult members lurking in the Royal Capital. Too bad he's too distracted about the upcoming fencing tournament to notice.[[1]](#cite_note-1)

シドは、剣術大会でオリアナ王国の王女ローズと対戦。モブらしいやられ方で会場をざわつかせる。そんな中、黒づくめの集団がアーティファクトで魔力を制御し、学園を占拠する。[[2]](#cite_note-2)

## Summary

On a sunny day at the Midgar Academy for Dark Knights, Sherry Barnett who is feeling anxious to the point of not doing her research on the artifact in the lab room which is being guarded by [Glen](Glen.md "Glen") and Marco Granger, where she thought about her father's words about love at first sight as he want Sherry to give a response to the boy who had been waiting for her answer. Sherry then ate the chocolate from the box again, finding it very sweet and her feeling are growing infatuated toward her admirer.

In the afternoon, [Nu](Nu.md "Nu") disguises as a student and approaches Cid to tell him that the man in black they caught last night had undergone powerful brainwashing to the point of his mind already been destroyed, which is shared trait of the Cult's vanguard, the Third Children. But unfortunately with his broken mental state, Nu was unable to obtain any relevant information out of the perpetrator no matter what she tried and revealed that the black hooded cloak worn by the pretenders was obtained through black market channels, whilst unaware that Cid is distracted from thinking how Skel has registered Cid in the student preliminary tournament to participate on the upcoming Bushin Festival as the Academy's representative, with Cid beating up Skel and Po in their stomachs who both pretend to be injured as payback for signing him up without his consent.

After elaborates the Cult of Diablos' recruitment methods over the years regarding the hierarchical system of the Children of Diablos, Nu suspects that the Cult's goal in using the organization's name is to lure the real Shadow Garden out of hiding with Cid in annoyance telling her not to do anything and Nu complies with Cid's misinterpreted order which is actually for his non-participation in tomorrow's elimination tournament. As Nu also inform Cid that they recently confirmed the presence of a Named First Child in the Royal Capital called "[Rex, the Game of Betrayal](Rex.md "Rex")", she clarifies that the First Child are those who maintained their sense of self despite being one of the Children and if the Cult of Diablos are deploying Named Children to the capital, it's clear they have some other purpose in mind.

Judging the 'named' answer, Cid immediately considered the fundamental objective of the qualifying matches as the perfect opportunity to set a suitable stage for his performance, from which then told Nu that he needs some time to think as Cid leaves while thinking about the techniques he would prepare in the future. Nu, who looked at Cid, is amazed at the greatness of her master who could solve problems by finding the best solution with the certainty of having gotten the answer from the start in any circumstances as she realized the extend of Cid's thinking that which called "Shadow's Wisdom". Seeing the other students going about their afternoon, Nu reflects on how her past ended from her [Possession](Possession.md "Possession"), grateful for who she is now and preferring her current self.

Starting the day of the qualifying tournament, Claire easily wins her fight and pins her opponent to the ground, with the audience praising her performance. Meanwhile, Skel and Po place bets, lamenting their lost earnings on poor selections, before Skel sounds baffled hearing Cid is actually taking part in the elimination round. In the next match, Cid, who had decided to participate, fought against the Student Council President Rose Oriana, remembering that Rose is the princess from Oriana Kingdom, which is a land of art and culture, but also the best swordswoman in the academy. As he thinks how she is a definite "named character," he says aloud how one should be grateful for such good fortune, surprising Rose.

As their fight starts, Cid decides to show his forty-eight techniques he mastered and lets himself get hit to cough up fake blood, part of his secret background character technique-- "Spinning Drill Fall: Bloody Tornado." An unsightly defeat in the first round at the hands of an indisputable champion, Cid stops the referee before he can deem Rose the winner, wishing to continue; when he really wants to show off his other forty-seven other techniques. After Cid continues standing after each clean hit wanting the fight to continue, Rose is surprised by his determination as the president gave him an apology for underestimating him at the beginning of the match and decided to get serious in order to end their fight with a decisive blow, but the referee intercedes to save Cid, summarily announcing Rose the winner. The referee stated how it's too dangerous for Cid to continue after losing so much blood and immediately ordered a stretcher to carry Cid to the infirmary, despite protests from Cid who wanted to continue as he still had 33 techniques to show off. With the bout finished, an impressed Rose commits Cid's name to memory.

Thereafter, a heavily bandaged Cid manages to leave the infirmary in frustration while wishing he would still get a chance to show the remaining of his techniques like the performance he showed in the match earlier in the hope that he could be in that cliche scene. But suddenly, Cid is then approached by Sherry, oblivious that she is awestruck by him, who tries to ask about his condition, with Cid left confused about the unfamiliar student who himself does not know her.

At the academy cafe, Sherry explains that she watched his fight and felt Cid was incredible as he kept standing back up, even though she normally doesn't watch sword fights with Cid being grateful for the compliment and thinking that the girl had unusual sensibilities. In the next moment, Sherry timidly gives Cid a small pouch of baked cookies that she made herself as thanks and Cid accepts the gift of cookies while he thinks that her gratitude is intended for showing her those sweet background character moves. Feeling confused by Sherry's behavior when she wanted to start their relationship as friends, Cid, who didn't mind the suggestion request, accepted her friendship and Sherry tells her father that the two of them were become friends now.

Seeing the person she was talking to as the man joined them by sitting at their table, Cid recognized him as Lutheran Barnett who is the Assistant Principal of the Academy of Science, also a master swordsman that accomplished in both martial arts and science, where he was once even the champion of the Bushin Festival. Considering him an important person, Cid notes that Lutheran are in the list of people that shouldn't be interact with if he wishes to remain as obscure as possible and remembering the girl addresses the Assistant Principal as father, he realizes the girl's identity is Sherry Barnett, which unquestionably a named character as Cid admit learn his carelessness for making contact with students from the science academy.

When the two of them asked about his injury, Cid pretended to say that he is okay and would see a doctor for a check-up on the way home so that his 'real' condition would not be discovered. Lutheran told Cid that Sherry is so focused on her research that she was currently carrying out a project to researching an artifact at the request of the Knight Order, where she had no friends to interact with, which made Sherry feel embarrassed about her father for revealing it. Seeing his daughter's cheerfulness where she was still going through a lot before, Lutheran asked Cid if he could get along with Sherry. Even though Cid was reluctant to give an answer because he wanted to be an background character, he didn't want to tell either of them his true feelings and decided to agree on Lutheran's request to become Sherry's friend. After some small talk, Cid uses his injuries as an excuse to leave and decide to stay home for a few days for the time being to sell the illusion of him being recovered, as well as giving some distance.

That evening, Sherry is thinking about Cid while eating some of the chocolate he gave her, and wonders if she should visit Cid to check on him since they are friends. Recalling how he dated Alexia Midgar some time ago, she decides to go and talk with the princess. While Alexia is enjoying black coffee along with the pastries in her dormitory room while still doing on her recovery, she was called by Sherry, who is accompanied by Marco and the princess invites the students to come inside while entertaining her. Seeing Sherry drinking coffee mixed with sugar and milk, which she thought was a trend, Alexia changed the conversation, assuming that her visit is to discuss the artifact analysis. But alas, the topic that the princess thought was not what Sherry wanted to talk about until Alexia guessing about the Student Council election schedule to which Sherry replied that the Science Academy had different set days than the Dark Knight Academy.

Nervous, Sherry reveals that the reason she came was actually because she wanted to ask Alexia something about the rumors she heard about the princess having an romantic relationship with a student as Sherry mentioned Cid's name and wonders if it was true. Alexia states they broke up as they weren't dating in reality at first, but pretending to be a couple for specific reasons. Sherry gets jubilant by the news, and states she became friends with Cid the other day, progressively upsetting Alexia. Sherry wasn't able to concentrate on her research due to her curious about Alexia and Cid's relationship status, but now is glad to learn that they aren't together. Feeling that she had heard the truth in the princess's answer, Sherry excused herself while Alexia became frustrated as the princess kept shaking her coffee cup when she found out about Sherry's relationship with Cid, which then Alexia smashed the cup and the pastries so that the sound in the room was heard by Marco from the outside as Sherry left happily not hearing the princess's commotion.

Five days later, Cid returns to school and feels that everyone is a bit nicer than usual to him, hearing Skel and Po chat that today there was a announcement notice about the Student Council election, plus all the 3rd grade students were out for extracurricular activities. Rose then arrives to explain the Student Council election to fill the vacancy, while noticing Cid's return to class. Concurrently, "Gaunt Knight" commands the gathered Cult's forces underground to begin enacts their plan as he ignites an red-eyed artifact, creating a barrier around the school that only Cid seemingly notices. When Alexia returns to school, she sees the gate is closed during school hours and that the guard is dead.

Cid couldn't use his magic when he tried to test his magic control abilities and saw that all the students besides him didn't notice the oddity when the student council was giving a speech. Knowing what is really going on after hearing many footsteps, a group of masked men in black burst into the classroom claiming to be from "Shadow Garden", explaining that they are taking over the Academy. However, Rose refused to bow to their threats and wanted to challenge them, which made one of the three members intend to make an example out of the Student Council President for her defiance. As Rose decides to fight them, she soon realizes that she can't use magic due to the effects of the artifact, while the Shadow Garden pretenders are able to do so as he easily breaks the Student Council President's sword and moves in to kill her. Feeling that the students' hopes had disappeared when they saw that the fate of the Student Council President was in danger because she could not dodge a sword attack imbued with powerful magic, Cid suddenly rushed in and pushes Rose away, taking the blow and falls to the ground covered in blood.

## Characters

- Sherry Barnett
- Cid Kagenou
- [Nu](Nu.md "Nu")
- [Rex](Rex.md "Rex") (Mentioned; silhouette)
- Marco Granger
- Skel Etal
- Po Tato
- Claire Kagenou
- Rose Oriana
- Lutheran Barnett
- Alexia Midgar

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第７話予告≪スペシャルVer.≫「陰の実力者は極めた奥義を見せつけたい！」

TVアニメ『陰の実力者になりたくて！』第７話予告≪ノーマルVer.≫「謀略と流血の剣術大会」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e007>
2. <https://shadow-garden.jp/1st/story/#story7>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • **Episode 7** • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
