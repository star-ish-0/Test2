# Borg

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Borg](https://the-eminence-in-shadow.fandom.com/wiki/Borg)

## Borg

### Japanese

ボーグ

### Romaji

Bōgu

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

Warrior

## Debut

### Web Novel

Chapter 47

### Light Novel

Volume 2

### Manga

Chapter 15

### Anime

Episode 11

Borg (ボーグ, Bōgu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a legendary warrior from ancient times. He was summoned by Annerose Nichtsehen during the Bushin Festival.[[1]](#cite_note-:0-1)

## Appearance

Summoned in front of Annerose, he appeared as a humanoid figure coated in light.[[1]](#cite_note-:0-1)

## References

1. Volume 2. Chapter 1: Fun Times at the Goddess’s Trial!

## Site Navigation
