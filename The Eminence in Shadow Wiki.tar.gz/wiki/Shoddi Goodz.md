# Shoddi Goodz

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Shoddi%20Goodz](https://the-eminence-in-shadow.fandom.com/wiki/Shoddi%20Goodz)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Shoddi_Goodz?action=edit).

## Shoddi Goodz

### Japanese

ゲーテ・モーノ

### Romaji

Gēte Mōno

### Aliases

Earl Goodz

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

### Relatives

Unnamed Father (Deceased)

## Professional Information

### Affiliation

Thirteen Nightblades

## Debut

### Light Novel

Volume 6

### Manga

Chapter 67

Shoddi Goodz (ゲーテ・モーノ, Gēte Mōno[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), also known as Earl Goodz, was a noble of the Midgar Kingdom and an official member of the Thirteen Nightblades who joined the organisation to succeed his father.

## Appearance

It was stated that he had an evil face and that he was middle aged but not much else is known about his appearance.[[1]](#cite_note-:0-1)

## Personality

## Chronology

### Bloody Midgar Serial Murder Terror

He was tasked by Brad Despoht with ensuring Eliza Despoht was not imprisoned by the Knight Order.[[1]](#cite_note-:0-1) He used a document to plan what bribes and assassinations needed to tale place.[[1]](#cite_note-:0-1) However while he was at work he was assassinated by Jack The Ripper.

## Relationships

## Powers & Abilities

It was stated that his speciality was performing paperwork and adjusting interest relationships for the Thirteen Nightblades.[[1]](#cite_note-:0-1)

## Trivia

## References

1. Volume 6 - Prologue

## Site Navigation
