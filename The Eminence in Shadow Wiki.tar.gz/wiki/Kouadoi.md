# Kouadoi

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Kouadoi](https://the-eminence-in-shadow.fandom.com/wiki/Kouadoi)

## Kouadoi

### Japanese

クアドイ

### Romaji

Kuadoi

### Aliases

Raging Gale

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

First Children (Named Child)

### Affiliation

Cult of Diablos

## Debut

### Light Novel

Volume 4

### Manga

Chapter 41

### Anime

Episode 29

## Portrayal

### Japanese

[Daiki Hamano](https://en.wikipedia.org/wiki/Daiki_Hamano "wp:Daiki Hamano")

Kouadoi (クアドイ, Kuadoi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) was a Named Child of the Cult of Diablos, who was tasked to secure the "Ring of Succession".

## Appearance

Kouadoi looks like a middle-aged man with scars on his cheeks.

## Personality

Like many members of the Cult, Kouadoi had quite a confident delusion that led him to be completely convinced of his invincibility and have a severe overestimation of his own abilities.

Even though Kouadoi is the leader and the most powerful Named Child, he is a dirty coward as he didn't face Victoria head-on, only waiting until all his men were killed off, with the result of her being seriously worn out to the brink of death and then he tried to kick her down and threatened a slow, painful death.

## Chronology

### Oriana's "Black Rose" Civil War Wedding Incident

Kouadoi was ordered to lead a group of 40 First Children along with 3 Named Children to a nearby ruins site of Saisho Fort which had fallen into the hands of the Perv faction two days ago, as well as accompany Queen Reina Oriana to retrieve the "Ring of Succession", which was also known as a key for the Black Rose.

After retrieving the ring, his group got suddenly attack by Shadow Garden team led by [559](Victoria.md "Victoria") with the objective to collect the Key, during which 666 saves her mother, Queen Reina from being killed by 559's assault. During their dispute, Kouadoi takes Rose and the queen as hostages, to which 559 brands 666 a traitor to Shadow Garden and to his fortune, Kouadoi ordered his men to send Rose and her mother to Duke Perv Asshat while he engages in combat with the enemy and calls for reinforcement.

After the fight for three days and nights, Kouadoi still stands but his men are already dead. While 559 is also standing but running out of mana along with her team. He decides to kill her, but suddenly his legs got cut by her and he meets his death by the hands of Shadow himself.

## Powers & Abilities

Kouadoi was the most powerful warrior as a Named Child, considering "First Children" who have provided exceptional contributions to the Cult. Kouadoi possessed stronger physical strength and magical powers compared to average knights, from which the Cult granted him a name. He was also mentally stable.

Kouadoi was an excellent magic swordsman being able to fight against [559](Victoria.md "Victoria") and her team, even when one of his legs were severed, he is still confident on his strength by announcing his named title until he met his end at the hand of Shadow.

## Relationships

## Trivia

## References

## Site Navigation
