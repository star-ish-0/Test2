# Grant

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Grant](https://the-eminence-in-shadow.fandom.com/wiki/Grant)

STUB: This article is a stub. You can help The Eminence in Shadow Wiki by [expanding it](https://the-eminence-in-shadow.fandom.com/wiki/Grant?action=edit).

## Grant

### Japanese

グラント

### Romaji

Guranto

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Marquess

### Affiliation

Oriana Kingdom

## Debut

### Web Novel

Chapter 196

### Anime

Episode 20 (Mentioned)

Grant (グラント, Guranto[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a Marquess from Oriana Kingdom.

## Appearance

## Personality

Grant is more considerate as a patriot man and has a strong sense of obligation who has his charismatic valor by giving loyalty to the King which he even bravely forms a faction against Perv Asshat who has a greater position and influence as Chancellor than he has.

Despite his middle age, Grant is a rational individual who has an alert perception of his surroundings.

## Chronology

### Background

Grant is a Marquess who has strong influence among the nobles in the Oriana Kingdom. Throughout his career, he has remained loyal to King Raphael Geerk Oriana and a patriot to the Kingdom.

## Powers & Abilities

## Relationships

## Trivia

## References

## Site Navigation
