# Episode 3

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Episode%203](https://the-eminence-in-shadow.fandom.com/wiki/Episode%203)

## Fencer Ordinaire

### Kana

凡人の剣

### Romaji

Bonjin no Ken

## Special Title

### English

The Eminence in Shadow Wants To Become a Mob Student!

### Kana

陰の実力者はモブ生徒になりきりたい！

### Romaji

Kage no Jitsuryokusha wa Mobu Seito ni Narikiritai!

## Episode Information

### Season

1

### Episode

3

### Air Date

October 19, 2022 JP
January 9, 2023 EN

### Adapted From

Volume 1 (LN)

## Staff

### Director

Daisuke Takashima

### Writer

Kanichi Katou

### Storyboard

Kazuya Nakanishi

## Theme Music

### Opening

[HIGHEST](HIGHEST.md "HIGHEST")

### Ending

Darling in the Night (Beta ver.)

Episode Navigation

| Previous | Next |
| --- | --- |
| Shadow Garden Is Born | Sadism's Reward |

Fencer Ordinaire (凡人の剣, Bonjin no Ken[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is the third episode of the [The Eminence in Shadow](Anime.md "Anime") anime adaptation.

## Synopsis

- [English](#)
- [Japanese](#)

The Princess is supposed to reject the background character’s confession, not accept it — since when did Cid become a rom-com protagonist?[[1]](#cite_note-1)

15歳になったシドは、王都のミドガル魔剣士学園に入学。平凡な学園生活を送っていた。が、罰ゲームで王女アレクシアに告白させられたことで、安定のモブライフが激変してしまう。[[2]](#cite_note-2)

## Summary

[Alpha](Alpha.md "Alpha") told Cid that Cult of Diablos is an enormous organization that runs on a global scale and in order to fight it, they needed to split. Cid feels that's just a nice way of telling him that they are now grown up, want their freedom and don't want to continue playing this "fighting the cult" game.

When Cid turns fifteen, he enrolls in the same school as his sister in the royal capital of Midgar Kingdom. Seven months into his academy life, Cid continues to live as a background character and make friends with Skel Etal and Po Tato, other bottom-of-the-pile nobles like him. While heading to school, Skel and Po remind Cid that as he scored the worst in the test, his penalty is to confess to the most sought-after girl in school and suffer her rejection. Arriving at school, they see the girl in question, Princess Alexia Midgar, who rejects another guy's confession. However, Cid is excited about it wanting to experience such confession as a background character. That evening, he goes to confess to Alexia, shaking and muttering, he feels he done a great job as a background character confession. However, to his surprise, she accepts, stating she was waiting for someone like him.

The rumors quickly spread and people start to wonder who is Cid and what's so great about him. Cid, Skel and Po, wonder why she accepted and guess that if she accepted Cid, even Skel and Po would have a chance. Alexia then joins them at lunch, which surprises other students as that's the lower nobility section. She gets served lots of food and comments she can't eat it all. Cid then gladly started eating her food, in an attempt to make her dump him. Alexia heard that he is studying Royal Bushin fencing and wants to practice together. Cid states he is in the lowest sections, but Alexia explains she put a good word for him and she got him in Section One.

Later Cid joins Section One team, where their advisor is Zenon Griffey, the official royal fencing instructor. Cid practices with Alexia, and notices that her attacks never land, she is slow and doesn't use much magic, but realizes it's because the practice is to review their strokes and counterstrokes. While he finds her technique good, he thinks it's bland. After the practice, Alexia states he has good fencing style, but hates it as it feels she is looking at herself. Alexia tells Zenon that she is Cid's girlfriend now, who tells her that won't change the fact that she is betrothed to him, even if it's still a public secret. Cid then realizes what is going on.

After that, Cid asks Alexia that she just wanted someone to help her get out of the engagement with Zenon, and chose a low-class aristocrat, whom she could easily control. As she confirms, Cid states he doesn't want more attention and isn't interested in being mixed up in her problems. Alexia tells him that's a bit cold from him, as she knows he fake confessed to her, since his friends easily told her everything. She tells him that if the student body learns she toyed with a young girl's heart, he will not see a peaceful day in the academy. Alexia wants to continue the boyfriend act, until Zenon gives up. Cid notes that he may not give up as it's clear Cid is out of Alexia's league. Alexia knows it, but wants to buy some time and then she will deal with it somehow. Alexia takes out and throws a gold coin. Staring at it, Cid asks her if he looks like a type that can be brought. Alexia confirms and so does Cid. As she throws another coin, he jumps and gets it with his mouth, while acting like a dog. Cid notes that his parent's allowance isn't enough to carry his Eminence in Shadow operation and can't let this chance slip up.

Cid decides to continue being her boyfriend and is glad that the students focus on her having a boyfriend and not him, which lets him being the background boyfriend character. In public Alexia is prudent, but behind the scenes, she constantly badmouths Zenon. Cid decides to not argue with her and just agrees to everything she says. Cid wonders what is so bad about Zenon and Alexia states it's easy to pretend to be nice. She also judges people by flaws. Zenon doesn't have any, which is not normal for a human.

While ridding the train, Alexia tells Cid that he has the fencing basics, but nothing more than that, yet she can't take her eyes of him. He wonders what with her today as her fencing was unusually aggressive and sloppy. Alexia reveals she always wanted to be as good as her sister. She didn't have what her sister had and decided to become stronger by herself. They ended up calling Alexia "The Fencing Ordinaire". It's unfortunate that Cid's fencing is ordinary like hers, however, Cid doesn't find it unfortunate and states he likes her fencing. Alexia reveals that her sister told her the same thing after she suffered humiliating defeat at the Bushin Festival. But her sister couldn't understand how pathetic Alexia was feeling. Cid explains that he isn't a great person and wouldn't care if someone kills a million people, but there are things that people find worthless, but to him they are the most precious things in life, which is why he likes her fencing style. Alexia draws her sword and asks him what he means by that. Cid states he gets pissed off when people insult the things he likes. The train stops and Alexia leaves, telling Cid goodbye, making him guess this is the end of his unwanted relationship.

Skel and Po apologize to Cid for telling everything to Alexia, but wonder how far he got with her while dating her for two weeks. Cid states he didn't get anywhere, which annoys them as they state they would have gone all the way. At the school gate, Zenon and two other men stop Cid and his friends. Zenon states Cid should know that Alexia didn't return to her dorm last night and they are investigating it as a potential kidnapping. Since Cid was the last person seen with her, he is their first suspect. As he sees more knights, Cid surrenders and realizes he is in big trouble.

## Characters

- Cid Kagenou
- [Alpha](Alpha.md "Alpha") (Flashback)
- [Beta](Beta.md "Beta") (Flashback)
- [Gamma](Gamma.md "Gamma") (Flashback)
- [Delta](Delta.md "Delta") (Flashback)
- [Epsilon](Epsilon.md "Epsilon") (Flashback)
- [Zeta](Zeta.md "Zeta") (Flashback)
- [Eta](Eta.md "Eta") (Flashback)
- Skel Etal
- Po Tato
- Claire Kagenou (Mentioned)
- Akane Nishino (Flashback)
- Alexia Midgar
- Zenon Griffey
- Sherry Barnett (Cameo)

## Promotional Videos

TVアニメ『陰の実力者になりたくて！』第３話予告≪ノーマルVer.≫「凡人の剣」

TVアニメ『陰の実力者になりたくて！』第３話予告≪スペシャルVer.≫「陰の実力者はモブ生徒になりきりたい！」

## References

1. <https://www.hidive.com/stream/the-eminence-in-shadow/s01e003>
2. <https://shadow-garden.jp/1st/story/#story3>

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Media?action=edit)  Media | | | |
| --- | --- | --- | --- |
| Light Novel | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 | |
| [Manga](Manga.md "Manga") | Volume 1 • Volume 2 • Volume 3 • Volume 4 • Volume 5 • Volume 6 • Volume 7 • Volume 8 • Volume 9 • Volume 10 • Volume 11 • Volume 12 • Volume 13 • Volume 14 • Volume 15 • Volume 16 • Volume 17 • Volume 18 • Volume 19 | |
| [Anime](Anime.md "Anime") | Season 1 |
| Episode 1 • Episode 2 • **Episode 3** • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 • Episode 18 • Episode 19 • Episode 20 | | | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | | | |
| Movie |
| The Eminence in Shadow: Lost Echoes | | | |
| [Spinoff](Kage-Jitsu.md "Kage-Jitsu") | Season 1 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 • Episode 13 • Episode 14 • Episode 15 • Episode 16 • Episode 17 | |
| Season 2 |
| Episode 1 • Episode 2 • Episode 3 • Episode 4 • Episode 5 • Episode 6 • Episode 7 • Episode 8 • Episode 9 • Episode 10 • Episode 11 • Episode 12 | |
