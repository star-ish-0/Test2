# Venom

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Venom](https://the-eminence-in-shadow.fandom.com/wiki/Venom)

## Venom

### Japanese

ヴェノム

### Romaji

Venomu

### Aliases

Wandering Swordsman
Executioner

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

Unknown

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Unknown

### Birthday

Unknown

## Personal Information

### Status

Deceased

## Professional Information

### Occupation

- Swordsman (Formerly)
- Cult's Executioner

### Affiliation

Cult of Diablos

## Debut

### Web Novel

Chapter 50

### Light Novel

Volume 2

### Manga

Chapter 16

### Anime

Episode 12

Venom (ヴェノム, Venomu[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), publicly known as the Wandering Swordsman (流浪（るろう）の剣士（けんし）, Rurō no Kenshi[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")), was Nelson's servant who worked as the Executioner (処刑人（しょけいにん）, Shokei-nin[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) for the Cult of Diablos.

## Appearance

In the novels, Venom was only described as a dark shadow that appears in the flash.

In the Manga, Venom was a huge man wearing a full plate armor with a fur coat and long cape. More specifically, he wore an armored helmet with two horns protruding from it.

In the Anime, Venom was ordinary man wore a light armor that covers his entire body, with arm and leg guards and papers overlapping around his waist in the front and back. He covers his face with a hat, that looks like a jiāngshī hat on the paper a picture of the Cult of Diablos symbol.[[1]](#cite_note-1)

## Personality

Little known about Venom's personality, other than that he was a taciturn and composed individual to his profession, who is willing to follow his superior's orders to fulfill his mission.

## Background

Ten years ago, Venom managed to summon [Olivier](Olivier.md "Olivier") on his duel at Goddess' Trial, but he lost to him. At some point after that, Venom become Nelson's subordinate and joined the Cult of Diablos as their executioner.[[2]](#cite_note-V2P-2)

## Chronology

### Sanctuary Infiltration

On Nelson's orders, Venom was ordered to kill Archbishop [Drake](Drake.md "Drake"), in order to erase the evidence from Princess Alexia Midgar and the Crimson Order before they arrived in Sacred Land [Lindwurm](Lindwurm.md "Lindwurm") and successfully escaped from the scene.[[2]](#cite_note-V2P-2)

When Shadow sudden coming at the Goddess' Trial and left after defeating [Aurora](Aurora.md "Aurora"), Shadow Garden have arrived to enter the [Sanctuary](Sanctuary.md "Sanctuary"). [Epsilon](Epsilon.md "Epsilon") had defeated Nelson's guards and when she states that Nelson will be coming with them inside the gate, he refuses and calls his guard Venom to kill Epsilon. Venom attempts to cut Epsilon, but she bends to dodges the slash, only the slash ends up cutting her fake slime breasts. Not wanting to be exposed, Epsilon manages to reattach them and quickly defeats Venom.[[3]](#cite_note-V2C2-3)

## Powers & Abilities

Venom possessed a great ability that can even trick one of the Seven Shadows, [Epsilon](Epsilon.md "Epsilon") and capable to attack her with his fast movements. In the manga, Venom could easily launch a surprise attack on [Epsilon](Epsilon.md "Epsilon") despite his huge body.

### Equipment

In the manga, Venom used a Greatsword. While in the anime, he used a Blade of the Thorns.

## Trivia

- In the anime, several Cult members who serve as security team wear "Venom anime design appearance" and they also wear "men in black" clothes as their disguises.[[4]](#cite_note-4)[[5]](#cite_note-5)[[6]](#cite_note-6)

## References

1. Episode 12
2. Volume 2 Prologue: To Lindwurm, the Scared Land!
3. Volume 2 Chapter 2: Investigating the Sanctuary!
4. Episode 17
5. Episode 19
6. Episode 30

## Site Navigation
