# Perv Asshat/Chronology

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Perv%20Asshat/Chronology](https://the-eminence-in-shadow.fandom.com/wiki/Perv%20Asshat/Chronology)

Main

Relationships

Image Gallery

## Background

Perv was the second adopted son of Duke Asshat who joined the Cult of Diablos and through dubious means, he quickly became Oriana's Royal Chancellor by committing several illegal acts to secure the position. He masqueraded himself as a good-willed politician with a good reputation in the public eye who were unaware of his criminal activities.

Upon learning the King's treason after he refused to hold his end of their agreement and severed ties by allying with the Kingdom of Midgar, the Cult ordered Perv to brainwash him as their puppet by drugging him with his wife's help. Before he was brainwashed, King Raphael was able to send his daughter, Princess Rose to Midgar under asylum. It was then that the Cult decided to usurp the Kingdom through the Second Child.

In order to achieve a promotion within the Cult, Perv persuaded and curried favor from the 9th seat of the Knights of Rounds, [Mordred](Mordred.md "Mordred") and his faction into assisting him to be selected candidate for the vacant 12th seat under the conditions that he'll succeed. Mordred agreed in assisting him in exchange for his backing support in the Cult's upcoming internal power struggle.

Before Raphael became their puppet, he did one final act; he took possession of the "Ring of Succession", which was the key to the "Black Rose" and recorded a memento on the ring regarding Perv and the Cult's crimes. He also altered the ring ownership over to his daughter and it was through marrying her that the ring can allow control beyond its user. After finished recording, he hid the ring within his kingdom's First Fort.

While Mordred tracked the ring's location, Perv visited the Midgar's Royal Capital to retrieve Rose under the pretense of their engagement after he brainwashed the King.

## Volume 2

### Bushin Festival Tournament

Perv meets Rose and he smirked at her along with his subordinate after presenting her brainwashed father to the princess, to which Rose drew her sword and attacked him all sudden. But Perv manage to avoid her strike until his subordinates called the guards to apprehend the princess. Framed as a criminal, Rose fled into hiding as Perv threatened the princess to surrender herself before the Bushin Festival ended or he'll order her father to kill King Klaus Midgar. He also noticed that Rose showed symptoms of [Possession](Possession.md "Possession"), which means the princess will become a prime material for the Cult's experiments. Took the opportunity to use Rose, Perv and his collaborators then dissuaded Midgar's government not to get involved in interfering with Rose's affairs and personally want to handle it themselves despite having the allied countries' jurisdiction to investigate on the matter.[[1]](#cite_note-V2C4-1)

Next day, Perv and his Puppet King later had a meeting with First Princess Iris Midgar to discuss the security plan for the Bushin Festival, but he doesn't feel it needs more security. When Iris noted on that his condition was better than the report she received, Perv clarified that the report from the news story was a little exaggerated and assumed that Midgar has gone paranoid from Alexia's kidnapping. Perv state as he heard that Iris personally went to look for her sister to which he intends to follow suit to have Oriana solve their "family problems" themselves and avoid external problems. Perv added that every business will be handle by himself for the negotiations, rebuilding her order and attending the Festival. He lastly sympathized with her worries and assured her that Oriana will not cause trouble to her kingdom.[[2]](#cite_note-2)

Days later, Perv met Princess Iris again at the VIP Seating where she harbored suspicion as they both discussed about Rose's predicament, when he calmly expressed confidence that the princess will return to him once she calmed down. He explains that his puppet king will be attending the festival tomorrow citing not feeling unwell and Iris informed Perv that his father will also be attending tomorrow to spectate after he apologized that the provided security was assembled in vain, to which Perv calls it a coincidence.

The two watched the tournament when the match between Annerose Nichtsehen and Mundane Mann commenced where Iris believed Mundane will win despite the Swordswoman's favor from Perv and crowd. Mundane pulled the upset and won before Perv complimented Iris's observation. After the match, Perv had his men to search the dark horse's background and believed that he's a denizen of the Lawless City which had [a monarch](Elisabeth.md "Elisabeth")'s backing that who'll pose a threat to his plans. He lastly dismissed the idea of a possible connection to Shadow Garden and doubted that they had a motive to act at the Festival.[[3]](#cite_note-V2C7-3)

Before meeting King Klaus on the day, the Bushin Festival ends, Perv drugged Raphael once more and ordered his men to cover its odor sweet with perfume. He waited for Rose to arrive at the tournament from the threats he made believing that even if she didn't come, Perv would've ordered his puppet king kill Klaus and instigate a war that'll result in Oriana's annihilation and loss of status. He didn't ponder as the Cult's plans to install a puppet leader in Midgar Kingdom were already underway. Worried about Shadow Garden's activities and possible collaboration with Rose, Perv prepared to increase the Cult's forces around the venue.

Upon arriving for the finals, he along with Raphael met up with Iris once more, who was then surprised by the appearance of [Beatrix](Beatrix.md "Beatrix") when she suddenly noticed something off about the King. Perv had previously thought about getting rid of Princess Iris if she were to become a hindrance, but he decided against it, because Beatrix's presence would become more troublesome, and it will be a bad idea if she decided to take action against him. Even Perv was apprehensive of Mundane due to his close to non-existent background, which meant to him that he covered his tracks and had an objective. Wary of him, he anxiously decided to spectate and predict outcome of the match between Iris and Mundane.

He watched their match and became shocked that Iris was only taken down in one strike. It was after that Rose suddenly arrived as he expected and apologizes to her father, stating she made mistakes and will likely make one more, but she decided to follow the path she believes in, to which Raphael replied that forgives all of her sins. Perv is surprised as he didn't instruct the king of saying that until Rose suddenly jumps at Perv, who then uses the king as a shield. However, Rose proceeds and stabs him in his heart which eventually killed the puppet king, along with wounding Perv.

Perv is shocked as he tells Rose at how easily she killed her own father and outraged that he lost his puppet. When he sees Rose holding her blade against her neck which attempting to take her own life, Perv ordered his men to stop the princess suicide attempt and apprehend her only for them to be killed when Mundane intervene to reveal himself as Shadow.[[4]](#cite_note-V2C8-4)

#### Novel/Manga

Perv sent his men after a fleeing Rose before Shadow killed them. Realizing the unsuccessful attempt, he witnessed both Iris Midgar and [Beatrix](Beatrix.md "Beatrix") confront the Shadow Garden leader. The confrontation occurred within the arena venue of the festival coliseum, with the two swordswomen putting up a valiant effort to defeat Shadow.

Despite their joint efforts, both the onlookers and Chancellor Perv were shocked and frightened, seeing both the famous and heralded "Goddess of War" Beatrix, as the strongest magical swordswoman, of the kingdom of Midgar, Iris Midgar, being easily defeated and subdued by Shadow, in a humiliating way, before he disappeared.[[5]](#cite_note-V2FC-5)

#### Anime

Perv tried to apprehend her but had no means to when all of his men were killed by Shadow Garden members led by [Beta](Beta.md "Beta"). By the time [Beatrix](Beatrix.md "Beatrix") jumped into the fray, he saw an opportunity to escape back to Oriana without stopping at the embassy and left Raphael Geerk Oriana's corpse to his political archenemy, Marquess [Grant](Grant.md "Grant"). During his siege within the kingdom, Grant was the leader of the anti-chancellor faction who sought to prevent his usurpation.

Returning to Oriana, Perv was reprimanded by Mordred after hearing the report of his failed operation in securing Rose after Shadow interfered and conveyed his disappointment. Disgruntled by his failure, he begged for his forgiveness before informing him of their leverage over the kingdom through their royal family. Because of this, Rose will not be able to stay in hiding. Coupled with the kingdom in chaos and turmoil with the loss of their king, Perv was sure that Rose couldn't ignore it and come back. Mordred conveyed his expectation and ended his conversation by telling him not to disappoint him again.[[6]](#cite_note-6)

## Volume 3

### Red Moon Incident

Following the escape of Princess Rose because Shadow's interference for ruining his plans during the Bushin Festival which resulted in losing a puppet king to control Oriana, Perv was forced into taking control over the kingdom in the king's stead and decided to think about changing his initial foiled plans while he's still sending all of the Cult's troops to search for the location where the king had hidden the ring.

According to [Beta](Beta.md "Beta")'s report, Perv was struggling to maintain Oriana's internal affairs after Rose caused an international incident by publicly murdering her father in broad daylight. Leaving with neither a monarch nor successor, the nation descended into a civil war over the throne.[[7]](#cite_note-V3P-7)

## Volume 4

### Oriana's "Black Rose" Civil War Wedding

While still in control of the kingdom's affairs, Perv received word that the ring has been found in a ruined site near Fort First that has been capture by his faction two days ago but was unable to retrieve it as it was sealed and that only members from the royal family could break it. Thus, he sent [Kouadoi](Kouadoi.md "Kouadoi") to lead a group of 40 First Children with 3 Named to the ruins alongside Queen Reina to retrieve the "Ring of Succession".

Upon successfully breaking the seal and acquiring the ring, the deployed Cult group was ambushed by a Shadow Garden team led by [559](Victoria.md "Victoria") in which Queen Reina is nearly killed by 559's attack until the queen is saved by a member of the Numbers who which happened to be Rose Oriana and protects her mother from her superiors. Their argumentation allowed Kouadoi saw an opportunity to hold both Rose and the queen hostage during their dispute, whereupon 559 ignored the threat as she even brands Rose a traitor to Shadow Garden, making Kouadoi orders his men to send Rose along with her mother to Duke Perv Asshat while he engaged in battle with the enemy and called for reinforcements.

Although hearing the news about the Shadow Garden at Saisho Fort and the "Ring of Succession" is almost stolen away from them but Perv received a news that Rose Oriana is already captured also knowing that she become a member of Shadow Garden. Anticipating Rose's return, Perv threatened Rose that her mother will be killed if she didn't comply with his orders. Reina being her mother and only family left, Rose was forced to comply with Perv's orders under the threat of her mother's safety while unaware that she conspired with him. Despite retrieving the ring, Perv realized that the ring's ownership was altered to Rose and that only she could activate it.

Perv was forced to compromise his plans from taking over the kingdom through usurpation by marring Rose in order to win the civil war so that he could gain ownership of the ring and finally succeed in completing his mission. In doing so, this would've ensured his position as 12th seat of the Knights of Rounds and the Cult of Diablos can directly conquer Oriana Kingdom as their puppet state, as well as handing Rose over to the Cult's nefarious experimentation after they extracted Shadow Garden's intel from her.

Since news of Shadow Garden's raid at Fort First had reached Perv, he had tightened the security around the capital to ensure that Shadow Garden couldn't infiltrate and take any action that could jeopardize his plans. Unbeknownst to him however, the incident had also reached Shadow who became confused upon learning Rose's marriage with Perv. Set on stopping her from marrying, Shadow infiltrated the capital as Cid.[[8]](#cite_note-V4P-8)

While Perv was surveying the palace with his entourage, he coincidentally met [Shiron](Epsilon.md "Epsilon") who was an invited guest set to perform at their venue. However, she was with an uninvited young boy who claimed to be an apprentice. Suspicious of his presence coupled with the incident at Fort First, Perv stopped the two under the pretext of changing the castle's premise rules and that her apprentice might've been an intruder. To confirm his suspicion, Perv tried testing the alleged apprentice of his legitimacy in front of the venue of nobles. Surprisingly, Perv was too touched by the boy's performance of The "Moonlight Sonata" much to his shocked and joy that he has willing to meet the apprentices in person to ask his name but the boy refuses to telling his name and leaves with Shiron, unaware that the "Ring of Succession" has been taken by an apprentice who is none other than Cid Kagenou which he thinks that the ring is an engagement ring and considers pawning it.

After the performance, Perv barged into Rose's room after he heard that she was talking to someone. When he entered her room, he saw no one in the room but Rose. Perv confronted her about her current situation and threatened that her mother's safety was dependent on her cooperation with him. Unbeknownst to him however, Cid overheard everything of their conversation while hiding outside the room and learnt that she was coerced into the marriage.[[9]](#cite_note-V4C1-9)

Later in the night, Perv went into Reina's room and told her that once his business with Rose is over, he would publicize their relationship in front of the kingdom's citizens. While they became intimate, both of them not realized that Cid witness and heard everything they talked about until he concludes that Reina was never in danger to begin with and was conspiring in the kingdom's usurpation, all the while having an affair with The Chancellor.

Consequently, Rose found out about her own mother's affair with Perv and their involvement in seizing the Oriana Kingdom after Cid in his Shadow persona showing her the truth and reignite Rose's resolve in saving her kingdom as she became troubled and confused by her mother's betrayal and Cid's arrival until he decide to leave unknowingly that the engagement ring that Cid pocketed from her fiancé has been left in Rose's room. Unbeknownst to him however, the engagement ring he pocketed that left at the princess room which was actually the "Ring of Succession". Rose thought it was Cid's and became certain he was there to support her in her time of need after he gave her a speech about trust as a sign of both affection and devotion, to which the princess became set on saving her kingdom once more from the Cult.[[10]](#cite_note-V4C2-10)

Before the wedding day, Perv dreaded over the security in the capital to the point where he had to carry out a check on the defensive perimeter from reports of Cult agents disguised as guards to ensure his plans followed through and that Shadow Garden wouldn't interfere, as well as watching on their movements that might be currently plotting something within the kingdom. With a tight security system in place, Perv assured himself that once he married Rose, he'll snuff out intel from her and be promoted to 12th seat after seizing the kingdom if everything goes smoothly as his calculation along with the backing of the faction led by Sir [Mordred](Mordred.md "Mordred"). Despite the elevation, Perv was well aware that he had the weakest track record of achievements and that he'll have to follow Mordred to gain more political power within the Rounds and whatever faction is in control.

Upon opening the case that contained the "Ring of Succession", Perv discovered that the ring was gone and began to panic. He thought to be sure that the box containing the ring was with him at all times and the only person who knew its location was Reina. However, Perv knew that the queen didn't a motive to do so and even thought that Shadow Garden was responsible. However, he also knew it was nonsensical when they would've simply killed him for it.

Left with no one else to deduct, Perv realizes that this act must have been caused by an inside job from the work of Mordred's opposing faction with their wicked motives and want to ruin Perv, which got him played by setting a cruel trap for him by stealing the ring and leaving the box. Believing that an internal power struggle must have begun if his assumption was correct, Perv assumed that his dream of becoming a Rounds had already shatter as his promotion to the 12th seat vanishes and Perv would definitely be killed for sure if Mordred finds out about his blunder.

Therefore, Perv sought to find the ring himself without using any Cult personnel due to their loyalty with Mordred. Fortunately, Perv still has some time left before he actually needs the ring, and he can probably buy himself time for three days before the handoff. At the time Perv wanted to do a search for the "Ring of Succession", Mordred spoke to him telepathically for congratulate and expect great things from Perv because everything is already setup for him in the honorary promotion that the 12th seat would be his once the mission is over and hope not to disappoint him. Uncertain of what the future holds, Perv anxiously continued on with the wedding.

At the wedding ceremony while Perv is waiting for the bride's vow, Rose suddenly proclaims her refusal to marry when she stated that she was indeed fully responsible for killing her father with Rose providing clarification in accusing Perv of being guilty of his crimes against the kingdom for manipulating the king, defiling the queen, and plotting to overthrow the government which is considered the highest treason.

Perv, who heard her refusal, asked Rose not to mess around by taking back what she had just said and say her vow like a good little girl so that he was willing to ignore what she had just done by reminding her about her mother hostage, Rose didn't want to obey Perv's orders because she promised herself that she would make her love come true, whatever the cost when she presented the Ring of Succession, much to Perv's shocked.

When Perv saw the ring is activated and a recording of the late king Raphael's projection appeared to play to everyone in attendance. The king exposed Perv as the main culprit in his manipulation while implying his wife's involvement on his crimes for an attempt to brainwash the king and the Cult's conspiracy to usurping the kingdom along with revealing all the criminal activities carried out by Perv, as well as his helplessness in his struggle to continue fighting to protect his country until Raphael lastly entrusted Oriana's future to his daughter and implored the citizens to believe in her as Rose will lead their nation to greatness before the recording finished.

Realizing that his plans have completely fallen through, Perv desperately tried to order for his now ex-fiancé's apprehension. Haven seen through everything, the guards at the venue glared at Perv in response. Now confronted by the princess, an enraged Perv attacked Rose and their final skirmish commenced. Initially thought to be evenly matched, Rose overpowered him and avoided fatally wounding him to confess his sins. Before finished his sentence, Perv was beheaded by the fed-up Mordred before cutting Reina down.[[11]](#cite_note-V4C3-11)

## Legacy

In response to Perv's failures exposing their activities within the Oriana Kingdom, the Cult of Diablos moved quickly to do damage control. Using their connections with the Holy Church, they branded Oriana a "heretic state", effectively cutting the nation off from international support. Also, to prevent their existence from being completely exposed, the Cult began preparing to initiate a "holy war" to destroy the Kingdom.

With Perv gone, Shadow Garden moved quick to fill the power vacuum within the Oriana Kingdom and vowed to aid their new ally. Overall, as stated by [Alpha](Alpha.md "Alpha"), despite Perv's death and their influence over Oriana having waned, the Cult will not die as long as their beliefs live.[[12]](#cite_note-12)

## References

1. Volume 2 Chapter 4: This Situation Calls for a "Who Is That Guy?!"
2. Episode 16
3. Volume 2 Chapter 7: Showing Off a Smidgen of My Strength!
4. Volume 2 Chapter 8: Lay Your Eyes on My True Powers!
5. Volume 2 Final Chapter: Just Who Is This Mysterious Badass?!
6. Episode 20
7. Volume 3 Prologue: Heading to the Lawless City over Fall Break!
8. Volume 4 Prologue: It's Time for a War in the Oriana Kingdom!
9. Volume 4 Chapter 1: Putting the Kibosh on Rose Oriana's Wedding!
10. Volume 4 Chapter 2: Begin Operation: Obstruction!
11. Volume 4 Chapter 3: Crashing the Ceremony!
12. Volume 5 Chapter 4 The World is at Peace Today
