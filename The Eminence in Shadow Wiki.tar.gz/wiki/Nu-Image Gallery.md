# Nu/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Nu/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Nu/Image%20Gallery)

[Main](Nu.md "Nu")

[Chronology](Nu-Chronology.md "Nu/Chronology")

[Relationships](Nu-Relationships.md "Nu/Relationships")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Nu's face

Nu in her battle suit

Nu reports to Cid

Nu defeats a Shadow Garden impostor

Design

Nu in her Mitsugoshi Employee Uniform

Nu in her Slime Bodysuit

Master of Disguise: Nu

All in the Shadows: Nu

Elegantly, Discreetly: Nu

Game Event: Be Mine! Sweet Valentine
