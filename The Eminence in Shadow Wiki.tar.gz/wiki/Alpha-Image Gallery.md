# Alpha/Image Gallery

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Alpha/Image%20Gallery](https://the-eminence-in-shadow.fandom.com/wiki/Alpha/Image%20Gallery)

[Main](Alpha.md "Alpha")

[Chronology](Alpha-Chronology.md "Alpha/Chronology")

[Relationships](Alpha-Relationships.md "Alpha/Relationships")

- [Light Novel](#)
- [Manga](#)
- [Anime](#)
- [Game](#)

Volume 1

Volume 2

Volume 3

Volume 5

Profile

Cid and Alpha's first meeting

Alpha observing young Olivier's past

Beta's Homecoming

Cid and Alpha at the bar

Alpha and other girls in the past

Alpha meets Cid

Young Alpha in her slime suit

Teen Alpha in her slime suit

White Slime Suit Alpha

Shadow Encounter: Alpha

Garden Genesis: Alpha

First of the Seven: Alpha

Thankful Heart: Alpha

Shadow in the Sun: Alpha

Spring Sword Dance: Alpha

Honor Student: Alpha

The Perfect Gift: Alpha

First Member: Alpha

First White Shadow: Alpha

Lost in Summer: Alpha

In-game model; Lost in Summer

Feverish Fortune: Alpha

Game Event: Interlude

Game Event: Highest Dream II

Game Event: Apocrypha "Requiem for the Falling Shadows": Alpha hugs Beta/Demoniac part 1

Game Event: Apocrypha "Requiem for the Falling Shadows": Alpha hugs Beta/Demoniac part 2

Feverish Fortune: Alpha and Yukime.png

Eternal Valkyrie: Alpha

Founding Duo: Shadow & Alpha
