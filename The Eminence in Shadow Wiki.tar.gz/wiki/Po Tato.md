# Po Tato

> Fonte: [https://the-eminence-in-shadow.fandom.com/wiki/Po%20Tato](https://the-eminence-in-shadow.fandom.com/wiki/Po%20Tato)

## Po Tato

### Japanese

ジャガ・イモ

### Romaji

Jaga Imo

## Characteristics

### Race

[Human](Human.md "Human")

### Gender

Male

### Age

15

### Height

Unknown

### Hair Color

Unknown

### Eye Color

Black

### Birthday

June 15

## Personal Information

### Status

Alive

## Professional Information

### Occupation

Student

### Affiliation

Midgar Academy for Dark Knights

## Debut

### Web Novel

Chapter 10

### Light Novel

Volume 1

### Manga

Chapter 3

### Anime

Episode 3

## Portrayal

### Japanese

Shin Matsushige

### English

[Greg Ayres](https://en.wikipedia.org/wiki/Greg_Ayres "wp:Greg Ayres")

### French

Jean-Rémi Tichit

### Italian

Marcello Gobbi

### German

Mio Lechenmayr

Po Tato (ジャガ・イモ, Jaga Imo[?](https://en.wikipedia.org/wiki/Help:Installing_Japanese_character_sets "wikipedia:Help:Installing Japanese character sets")) is a student of Midgar Academy for Dark Knights and a mob friend of Cid Kagenou. He is the second son of the Baron Tato Family.

## Appearance

Po Tato is a small and bony boy with unremarkable facial features. According to Cid Kagenou, he remains unattractive at any angle.[[1]](#cite_note-V1C2-1) The handsome atmosphere would never develop around the boy.

## Personality

Po is an average teenager with no outstanding qualities or quirks. He has demonstrated unusual attention toward some interests and his devotion can be described as "obsessive." [[2]](#cite_note-V1C5-2)

His aspirations are simple but unattainable. Po’s puerile fantasy, like Skel's, is to indulge in the messy world of high school carnality, preferably with an attractive woman. Any attempt to fulfill this dream is met with setbacks and failures.

## Chronology

### The Kidnapping of Alexia Midgar

At school, Po, Cid, and Skel made a bet about their upcoming exam. The one with the lowest grade has to confess to Princess Alexia. Cid loses the bet and asks the princess to be his girlfriend, and Alexia accepts the proposal and the two start a "relationship". Po and Skel make their surprise and envy known during the lunch hour.[[1]](#cite_note-V1C2-1)

Alexia later reveals to Cid that she spoke to Skel and Po who told her about the bet.

### Midgar Academy Terrorist Attack

The three boys spend their time off waiting in line at Mitsugoshi Company to buy chocolate. A [beautiful attendant](Nu.md "Nu") approaches the boys and asks Cid to participate in a user survey. Po and Skel request inclusion, but she only expresses interest in Cid. The attendant guides Cid to answer a questionnaire as the two covetously look at their receding backs.[[3]](#cite_note-3)

The purpose of the chocolate was to assist confessional endeavors. He and Cid watch Skel try to offer chocolate to an upper-class girl but leave him to his fate when an angry boyfriend appears. Po tries his luck with chocolate and approaches a girl in the Midgar Academy Library. The girl recognizes him as a supposed stalker, to his great dismay. He tries to clarify his actions but is unsuccessful.[[2]](#cite_note-V1C5-2)

### Bushin Festival Tournament

### Red Moon Incident

### Great Trading Company Conflict

### The Academy Disappearances

### Bloody Midgar Serial Murder Terror

## Image Gallery

## Trivia

- His Japanese name, Jaga Imo literally means potato.

## References

1. Volume 1 Chapter 2: Assuming the Role of a Side Character at School!
2. Volume 1 Chapter 5: Mastering the Peaceful Life of a Nobody!
3. Volume 1 Chapter 4: The Two Sides of the Shadow Garden?!

## Site Navigation

| v • [e](https://the-eminence-in-shadow.fandom.com/wiki/Template:Navbox_Midgar_Academy_for_Dark_Knights?action=edit)  Midgar Academy for Dark Knights | | |
| --- | --- | --- |
| Staff | Lutheran Barnett • Zenon Griffey • [Willow](Willow.md "Willow") • [Dr. Medi](Mu.md "Mu") | |
| Third-years | Claire Kagenou • [Nina](Nina.md "Nina") | |
| Second-years | Rose Oriana | |
| First-years | Cid Kagenou • Skel Etal • **Po Tato** • Alexia Midgar • Christina Hope • [Isaac](Isaac.md "Isaac") • Suzuki Hope • [Kanade](Kanade.md "Kanade") | |
| Alumni | Iris Midgar • Sherry Barnett | |
| Unknown Year | Eliza Despoht | |
